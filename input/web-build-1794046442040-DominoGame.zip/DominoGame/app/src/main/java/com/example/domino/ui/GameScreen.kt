package com.example.domino.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.ui.draw.paint
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.domino.R
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domino.model.*
import com.example.domino.viewmodel.GameViewModel
import com.example.domino.viewmodel.ProgressViewModel

@Composable
private fun RoundIconButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(RoundedCornerShape(12.dp))
            .background(Color(0x99000000)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun GameScreen(
    vm: GameViewModel,
    progressVm: ProgressViewModel,
    adReady: Boolean,
    muted: Boolean,
    onToggleMute: () -> Unit,
    onWatchAdForDouble: () -> Unit,
    onExit: () -> Unit
) {
    val state by vm.state.collectAsState()
    val progress by progressVm.state.collectAsState()
    var confirmExit by remember { mutableStateOf(false) }
    BackHandler { confirmExit = true }

    val myTurn = state.status == Status.PLAYING && state.turn == Turn.PLAYER
    val playableIds = remember(state.playerHand, state.board) {
        state.playerMoves.map { it.tile.id }.toSet()
    }
    val wood = Brush.verticalGradient(listOf(Color(0xFF4A2E17), Color(0xFF2B1A0C)))
    val felt = Brush.radialGradient(listOf(Color(0xFF1F7A45), Color(0xFF0B3A20)))

    Column(
        Modifier.fillMaxSize().paint(painterResource(R.drawable.bg_wood), contentScale = ContentScale.Crop).statusBarsPadding().navigationBarsPadding().padding(10.dp)
    ) {
        ScoreBoard(state.playerScore, state.aiScore, state.boneyard.size, state.turn)
        Text(
            "الجولة ${state.round}  •  الهدف $TARGET_SCORE نقطة",
            color = Palette.text, fontSize = 12.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 4.dp)
        )
        Spacer(Modifier.height(6.dp))
        AiHandView(state.aiHand.size)
        Spacer(Modifier.height(8.dp))

        Box(
            Modifier.weight(1f).fillMaxWidth()
                .clip(RoundedCornerShape(24.dp)).paint(painterResource(R.drawable.bg_felt), contentScale = ContentScale.Crop)
                .border(4.dp, Color(0xFF7A4A24), RoundedCornerShape(24.dp))
        ) {
            BoardView(
                board = state.board,
                startTileId = state.startTileId,
                lastPlacedId = state.lastPlacedId,
                selectableSides = state.selectableSides,
                onSideClick = vm::onSideSelected,
                modifier = Modifier.fillMaxSize()
            )
            Row(
                Modifier.align(Alignment.TopStart).padding(10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                RoundIconButton("🏠") { confirmExit = true }
                RoundIconButton(if (muted) "🔇" else "🔊", onToggleMute)
            }
        }

        Spacer(Modifier.height(8.dp))
        Text(
            state.message, color = Color(0xFFFFE9A8), fontSize = 15.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Box(Modifier.fillMaxWidth().height(48.dp), contentAlignment = Alignment.Center) {
            if (state.canPlayerDraw) {
                Button(onClick = vm::onDrawClicked) { Text("اسحب من المكدس (${state.boneyard.size})") }
            }
        }
        HandView(
            hand = state.playerHand,
            playableIds = playableIds,
            selectedId = state.selectedTileId,
            myTurn = myTurn,
            onTileClick = vm::onTileClicked,
            modifier = Modifier.fillMaxWidth()
        )
    }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("الخروج إلى الرئيسية؟") },
            text = { Text("ستنتهي المباراة الحالية.") },
            confirmButton = { TextButton(onClick = { confirmExit = false; progressVm.clearReward(); onExit() }) { Text("خروج") } },
            dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("متابعة اللعب") } }
        )
    }

    if (state.status == Status.ROUND_OVER) {
        val r = state.result
        val rw = progress.reward
        val matchOver = state.matchWinner != null
        AlertDialog(
            onDismissRequest = {},
            icon = if (state.matchWinner == Winner.PLAYER) {
                { Image(painterResource(R.drawable.icon_trophy), null, Modifier.size(84.dp)) }
            } else null,
            confirmButton = {
                Button(onClick = { progressVm.clearReward(); vm.nextRound() }) {
                    Text(if (matchOver) "مباراة جديدة" else "الجولة التالية")
                }
            },
            dismissButton = {
                TextButton(onClick = { progressVm.clearReward(); onExit() }) { Text("الرئيسية") }
            },
            title = {
                Text(
                    when {
                        state.matchWinner == Winner.PLAYER -> "🏆 فزت بالمباراة!"
                        state.matchWinner == Winner.AI -> "خسرت المباراة"
                        r?.winner == Winner.PLAYER -> "🎉 فزت بالجولة!"
                        r?.winner == Winner.AI -> "خسرت الجولة"
                        else -> "تعادل"
                    }
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (r?.blocked == true) Text("اللعبة مغلقة (Block) — يفوز صاحب النقاط الأقل.")
                    Text("نقاط الجولة: ${r?.points ?: 0}")
                    Text("أنت ${state.playerScore}  |  الكمبيوتر ${state.aiScore}  (الهدف $TARGET_SCORE)")
                    if (rw != null) {
                        Text(
                            "🪙 +${rw.coins} عملة" + if (rw.doubled) "  (×2 ✓)" else "",
                            fontWeight = FontWeight.Bold
                        )
                        Text("⭐ +${rw.xp} خبرة")
                        rw.levelUp?.let { Text("🌟 ترقّيت إلى المستوى $it!", fontWeight = FontWeight.Bold) }
                        if (!rw.doubled && adReady) {
                            Button(onClick = onWatchAdForDouble, modifier = Modifier.fillMaxWidth()) {
                                Text("🎬 ضاعف العملات")
                            }
                        }
                    }
                }
            }
        )
    }
}
