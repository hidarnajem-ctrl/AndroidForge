package com.image.compressor

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

class PixoraApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        AppCompatDelegate.setDefaultNightMode(
            prefs.getInt(Prefs.NIGHT_MODE, AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        )
        // English is the default language until the user picks another one
        if (AppCompatDelegate.getApplicationLocales().isEmpty) {
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags("en"))
        }
    }
}

object Prefs {
    const val NAME = "pixora_settings"
    const val NIGHT_MODE = "night_mode"
    const val HISTORY = "history_json"
}
