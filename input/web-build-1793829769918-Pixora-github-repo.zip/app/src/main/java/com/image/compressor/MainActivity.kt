package com.image.compressor

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.os.LocaleListCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.image.compressor.databinding.ActivityMainBinding
import com.image.compressor.databinding.ItemHistoryBinding
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var ads: AdManager
    private val vm: MainViewModel by viewModels()

    private val picker = registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        if (uris.isNotEmpty()) vm.setSources(uris)
    }
    private val writePermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCompression() else snack(R.string.err_permission)
    }

    private val languageCodes = listOf("en", "ar", "es", "fr", "de")
    private val languageNames by lazy {
        listOf("English", "العربية", "Español", "Français", "Deutsch")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, max(bars.bottom, ime.bottom))
            WindowInsetsCompat.CONSUMED
        }

        setupControls()
        ads = AdManager(this, b.bannerContainer)
        ads.start { required -> b.btnPrivacyOptions.isVisible = required }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { vm.state.collect(::render) }
                launch { vm.history.collect(::renderHistory) }
                launch { vm.events.collect(::onEvent) }
            }
        }
    }

    private fun setupControls() {
        val openPicker = {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        b.btnPick.setOnClickListener { openPicker() }
        b.dropzone.setOnClickListener { openPicker() }

        b.slider.addOnChangeListener { _, value, fromUser ->
            b.tvQualityValue.text = getString(R.string.quality_value, value.toInt())
            if (fromUser) b.chipGroup.clearCheck()
        }
        b.tvQualityValue.text = getString(R.string.quality_value, b.slider.value.toInt())
        mapOf(b.chipSmall to 50f, b.chipBalanced to 75f, b.chipBest to 90f).forEach { (chip, q) ->
            chip.setOnClickListener { b.slider.value = q }
        }
        b.formatGroup.addOnButtonCheckedListener { _, _, _ -> updateQualityEnabled() }
        updateQualityEnabled()

        b.btnCompress.setOnClickListener { onCompressClicked() }
        b.btnShare.setOnClickListener { share() }
        b.btnClearHistory.setOnClickListener { vm.clearHistory() }
        b.btnPrivacy.setOnClickListener { openPrivacyPolicy() }
        b.btnPrivacyOptions.setOnClickListener { ads.showPrivacyOptions() }

        b.btnTheme.setIconResource(if (isNight()) R.drawable.ic_sun else R.drawable.ic_moon)
        b.btnTheme.setOnClickListener { toggleTheme() }
        b.btnLanguage.setOnClickListener { showLanguageDialog() }
    }

    // ---------- theme & language ----------
    private fun isNight() = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    private fun toggleTheme() {
        val mode = if (isNight()) AppCompatDelegate.MODE_NIGHT_NO else AppCompatDelegate.MODE_NIGHT_YES
        getSharedPreferences(Prefs.NAME, MODE_PRIVATE).edit().putInt(Prefs.NIGHT_MODE, mode).apply()
        AppCompatDelegate.setDefaultNightMode(mode)
    }

    private fun showLanguageDialog() {
        val current = AppCompatDelegate.getApplicationLocales()
        val currentCode = if (current.isEmpty) "en" else current[0]?.language.orEmpty()
        val checked = languageCodes.indexOf(currentCode).coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.language_title)
            .setSingleChoiceItems(languageNames.toTypedArray(), checked) { dialog, which ->
                dialog.dismiss()
                AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(languageCodes[which]))
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ---------- compress ----------
    private fun updateQualityEnabled() {
        val lossless = b.formatGroup.checkedButtonId == R.id.btnPng
        b.slider.isEnabled = !lossless
        b.chipGroup.isEnabled = !lossless
        listOf(b.chipSmall, b.chipBalanced, b.chipBest).forEach { it.isEnabled = !lossless }
        b.tvQualityValue.alpha = if (lossless) 0.4f else 1f
    }

    private fun formatIndex() = when (b.formatGroup.checkedButtonId) {
        R.id.btnPng -> 1
        R.id.btnWebp -> 2
        else -> 0
    }

    private var dimsOk = true
    private fun readDim(et: TextInputEditText, til: TextInputLayout): Int? {
        til.error = null
        val text = et.text?.toString()?.trim().orEmpty()
        if (text.isEmpty()) return null
        val v = text.toIntOrNull()
        if (v == null || v < 1 || v > ImageProcessor.MAX_SIDE) {
            til.error = getString(R.string.err_dim)
            dimsOk = false
            return null
        }
        return v
    }

    private fun onCompressClicked() {
        dimsOk = true
        readDim(b.etWidth, b.tilWidth)
        readDim(b.etHeight, b.tilHeight)
        if (!dimsOk) return
        val needsPermission = Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        if (needsPermission) writePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE) else startCompression()
    }

    private fun startCompression() {
        dimsOk = true
        val w = readDim(b.etWidth, b.tilWidth)
        val h = readDim(b.etHeight, b.tilHeight)
        if (!dimsOk) return
        vm.compress(formatIndex(), b.slider.value.toInt(), w, h)
    }

    // ---------- rendering ----------
    private fun locale(): Locale = resources.configuration.locales[0]

    private fun size(bytes: Long): String = when {
        bytes <= 0L -> "—"
        bytes >= 1024L * 1024L -> String.format(locale(), "%.2f MB", bytes / (1024.0 * 1024.0))
        else -> String.format(locale(), "%.1f KB", bytes / 1024.0)
    }

    private fun render(s: MainViewModel.UiState) {
        val src = s.source
        b.ivPreview.setImageBitmap(src?.preview)
        b.emptyState.isVisible = src == null
        b.tvSourceInfo.isVisible = src != null
        if (src != null) {
            b.tvSourceInfo.text = if (src.uris.size == 1)
                getString(R.string.selected_one, src.firstWidth, src.firstHeight, size(src.totalBytes))
            else getString(R.string.selected_many, src.uris.size, size(src.totalBytes))
        }
        b.btnPick.isEnabled = !s.busy
        b.dropzone.isEnabled = !s.busy
        b.btnCompress.isEnabled = src != null && !s.busy
        b.btnCompress.text = if (s.busy) getString(R.string.compressing, minOf(s.done + 1, s.total), s.total)
        else getString(R.string.compress_button)
        b.progress.isVisible = s.busy
        if (s.busy) {
            b.progress.max = s.total
            b.progress.setProgressCompat(s.done, true)
        }
        renderResult(s.result?.takeIf { it.outputs.isNotEmpty() })
    }

    private fun renderResult(r: MainViewModel.Batch?) {
        b.cardResult.isVisible = r != null
        if (r == null) return
        val orig = r.originalBytes
        val now = r.newBytes
        b.tvResultTitle.text = getString(R.string.result_title)
        if (orig > 0L) {
            val pct = (orig - now) * 100.0 / orig
            val smaller = pct >= 0
            b.ringBox.isVisible = true
            b.ring.setProgressCompat(if (smaller) pct.roundToInt().coerceIn(0, 100) else 0, true)
            b.tvRing.text = String.format(locale(), if (smaller) "%d%%" else "+%d%%", abs(pct).roundToInt())
            b.tvResultSizes.text = getString(R.string.result_sizes, size(orig), size(now)) + "\n" +
                getString(if (smaller) R.string.result_smaller else R.string.result_larger)
        } else {
            b.ringBox.isVisible = false
            b.tvResultSizes.text = getString(R.string.result_only, size(now))
        }
        b.tvResultMeta.text = buildString {
            append(getString(R.string.result_location))
            if (r.failed > 0) append("\n").append(getString(R.string.result_failed, r.failed))
        }
        b.ivResult.setImageBitmap(r.preview)
    }

    private fun renderHistory(list: List<HistoryRecord>) {
        b.historyList.removeAllViews()
        b.tvHistoryEmpty.isVisible = list.isEmpty()
        b.btnClearHistory.isVisible = list.isNotEmpty()
        list.take(10).forEach { rec ->
            val row = ItemHistoryBinding.inflate(layoutInflater, b.historyList, false)
            row.tvName.text = rec.name
            row.tvDetail.text = "${rec.format} · " + getString(R.string.result_sizes, size(rec.original), size(rec.compressed))
            if (rec.original > 0L) {
                val pct = ((rec.original - rec.compressed) * 100.0 / rec.original).roundToInt()
                row.tvPct.text = String.format(locale(), if (pct >= 0) "−%d%%" else "+%d%%", abs(pct))
                row.tvPct.setTextColor(ContextCompat.getColor(this, if (pct >= 0) R.color.good else R.color.bad))
            } else row.tvPct.isVisible = false
            b.historyList.addView(row.root)
        }
    }

    private fun onEvent(e: MainViewModel.Event) {
        when (e) {
            is MainViewModel.Event.Finished -> if (e.ok > 0) {
                b.scroll.post { b.scroll.smoothScrollTo(0, b.cardResult.top) }
                ads.onTaskCompleted()
            } else snack(R.string.err_failed)
            MainViewModel.Event.LoadFailed -> snack(R.string.err_load)
        }
    }

    private fun snack(resId: Int) = Snackbar.make(b.root, resId, Snackbar.LENGTH_LONG).show()

    // ---------- share & links ----------
    private fun share() {
        val outs = vm.state.value.result?.outputs.orEmpty()
        if (outs.isEmpty()) return
        val intent = if (outs.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = outs[0].mime
                putExtra(Intent.EXTRA_STREAM, outs[0].uri)
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "image/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList<Uri>(outs.map { it.uri }))
            }
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(intent, getString(R.string.share_chooser)))
    }

    private fun openPrivacyPolicy() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.privacy_policy_url))))
        } catch (_: Exception) { /* no browser installed */ }
    }

    override fun onPause() { ads.pause(); super.onPause() }
    override fun onResume() { super.onResume(); ads.resume() }
    override fun onDestroy() { ads.destroy(); super.onDestroy() }
}
