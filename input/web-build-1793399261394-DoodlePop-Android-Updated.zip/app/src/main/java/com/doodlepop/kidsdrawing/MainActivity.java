package com.doodlepop.kidsdrawing;

import android.app.Activity;
import android.content.ContentValues;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.RequestConfiguration;

import java.io.OutputStream;
import java.util.Arrays;

public class MainActivity extends Activity {
    private WebView webView;
    private AdView adView;
    private LinearLayout adSlot;

    // Google's official demo banner unit. Replace with your own AdMob unit before release.
    private static final String TEST_BANNER_ID = "ca-app-pub-3940256099942544/9214589741";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(255, 249, 240));
        getWindow().setNavigationBarColor(Color.rgb(255, 249, 240));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(255, 249, 240));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(255, 249, 240));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setTextZoom(100);
        webView.addJavascriptInterface(new DoodlePopBridge(this), "DoodlePopAndroid");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        root.addView(webView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        // A visually separated, bottom-anchored banner area to reduce accidental taps by children.
        adSlot = new LinearLayout(this);
        adSlot.setOrientation(LinearLayout.VERTICAL);
        adSlot.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        adSlot.setBackgroundColor(Color.rgb(255, 249, 240));
        TextView adLabel = new TextView(this);
        adLabel.setText("إعلان");
        adLabel.setTextSize(10);
        adLabel.setTextColor(Color.rgb(120, 100, 70));
        adLabel.setGravity(android.view.Gravity.CENTER);
        adSlot.addView(adLabel, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(16)));
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        int adWidth = (int) (metrics.widthPixels / metrics.density);
        AdSize bannerSize = AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
        adView = new AdView(this);
        adView.setAdUnitId(TEST_BANNER_ID);
        adView.setAdSize(bannerSize);
        adSlot.addView(adView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, bannerSize.getHeightInPixels(this)));
        root.addView(adSlot, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        setContentView(root);
        webView.loadUrl("file:///android_asset/www/index.html");

        // DoodlePop is designed for children: request child-directed, G-rated ads only.
        RequestConfiguration requestConfiguration = new RequestConfiguration.Builder()
                .setTagForChildDirectedTreatment(RequestConfiguration.TAG_FOR_CHILD_DIRECTED_TREATMENT_TRUE)
                .setTagForUnderAgeOfConsent(RequestConfiguration.TAG_FOR_UNDER_AGE_OF_CONSENT_TRUE)
                .setMaxAdContentRating(RequestConfiguration.MAX_AD_CONTENT_RATING_G)
                .build();
        MobileAds.setRequestConfiguration(requestConfiguration);
        MobileAds.initialize(this, initializationStatus -> runOnUiThread(() -> {
            if (adView != null) {
                AdRequest request = new AdRequest.Builder().build();
                adView.setAdListener(new AdListener() {
                    @Override public void onAdFailedToLoad(LoadAdError error) {
                        if (adSlot != null) adSlot.setVisibility(View.GONE);
                    }
                    @Override public void onAdLoaded() {
                        if (adSlot != null) adSlot.setVisibility(View.VISIBLE);
                    }
                });
                adView.loadAd(request);
            }
        }));
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onPause() {
        if (adView != null) adView.pause();
        if (webView != null) webView.onPause();
        super.onPause();
    }
    @Override protected void onResume() {
        super.onResume();
        if (adView != null) adView.resume();
        if (webView != null) webView.onResume();
    }
    @Override protected void onDestroy() {
        if (adView != null) { adView.destroy(); adView = null; }
        if (webView != null) { webView.removeJavascriptInterface("DoodlePopAndroid"); webView.destroy(); webView = null; }
        super.onDestroy();
    }

    private static class DoodlePopBridge {
        private final MainActivity activity;
        DoodlePopBridge(MainActivity activity) { this.activity = activity; }
        @JavascriptInterface public boolean saveImage(String dataUrl, String requestedFileName) {
            Uri imageUri = null;
            try {
                if (dataUrl == null || !dataUrl.startsWith("data:image/png;base64,")) { showMessage("Could not save drawing"); return false; }
                byte[] imageBytes = Base64.decode(dataUrl.substring(dataUrl.indexOf(',') + 1), Base64.DEFAULT);
                if (imageBytes.length == 0) { showMessage("Drawing is empty"); return false; }
                String fileName = requestedFileName == null ? "DoodlePop-Masterpiece.png" : requestedFileName;
                fileName = fileName.replaceAll("[^A-Za-z0-9._-]", "_");
                if (!fileName.toLowerCase().endsWith(".png")) fileName += ".png";
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/DoodlePop");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
                imageUri = activity.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (imageUri == null) { showMessage("Could not create image file"); return false; }
                try (OutputStream output = activity.getContentResolver().openOutputStream(imageUri)) {
                    if (output == null) throw new IllegalStateException("Image output stream unavailable");
                    output.write(imageBytes); output.flush();
                }
                ContentValues completed = new ContentValues(); completed.put(MediaStore.Images.Media.IS_PENDING, 0);
                activity.getContentResolver().update(imageUri, completed, null, null);
                showMessage("Saved to Pictures/DoodlePop"); return true;
            } catch (Exception error) {
                if (imageUri != null) { try { activity.getContentResolver().delete(imageUri, null, null); } catch (Exception ignored) {} }
                showMessage("Unable to save drawing"); return false;
            }
        }
        private void showMessage(final String message) { activity.runOnUiThread(() -> Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()); }
    }
}
