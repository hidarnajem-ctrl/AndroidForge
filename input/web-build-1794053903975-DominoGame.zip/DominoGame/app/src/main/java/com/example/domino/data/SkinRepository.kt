package com.example.domino.data

import android.content.Context

class SkinRepository(context: Context) {
    private val prefs = context.getSharedPreferences("domino_skins", Context.MODE_PRIVATE)

    fun unlocked(): Set<String> =
        (prefs.getStringSet(KEY_UNLOCKED, emptySet()) ?: emptySet()).toSet() + FREE

    fun selected(): String = prefs.getString(KEY_SELECTED, "classic") ?: "classic"

    fun unlock(id: String) {
        val set = (prefs.getStringSet(KEY_UNLOCKED, emptySet()) ?: emptySet()).toMutableSet()
        set += id
        prefs.edit().putStringSet(KEY_UNLOCKED, set).apply()
    }

    fun select(id: String) { prefs.edit().putString(KEY_SELECTED, id).apply() }

    private companion object {
        const val KEY_UNLOCKED = "unlocked"
        const val KEY_SELECTED = "selected"
        val FREE = setOf("classic")
    }
}
