package com.example.domino.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.domino.data.ProgressRepository
import com.example.domino.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** العملات والخبرة والمستوى والإحصائيات. */
class ProgressViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ProgressRepository(app)
    private val _state = MutableStateFlow(repo.load())
    val state: StateFlow<ProgressState> = _state.asStateFlow()

    private fun commit(s: ProgressState) { _state.value = s; repo.save(s) }

    fun onRoundFinished(e: RoundEvent) {
        val s = _state.value
        val won = e.winner == Winner.PLAYER
        var coins = if (won) 20 else 5
        var xp = if (won) 15 else 5
        val matchDone = e.matchWinner != null
        val matchWon = e.matchWinner == Winner.PLAYER
        if (matchWon) { coins += 100; xp += 40 }

        var newXp = s.xp + xp
        var level = s.level
        var levelUp: Int? = null
        while (newXp >= xpNeeded(level)) {
            newXp -= xpNeeded(level)
            level++
            levelUp = level
            coins += 50                       // مكافأة الترقية
        }
        commit(
            s.copy(
                coins = s.coins + coins, xp = newXp, level = level,
                rounds = s.rounds + 1, roundWins = s.roundWins + if (won) 1 else 0,
                matches = s.matches + if (matchDone) 1 else 0,
                matchWins = s.matchWins + if (matchWon) 1 else 0,
                history = if (matchDone) (s.history + matchWon).takeLast(10) else s.history,
                reward = Reward(coins, xp, levelUp)
            )
        )
    }

    /** مضاعفة مكافأة الجولة بعد مشاهدة إعلان (مرة واحدة). */
    fun doubleReward() {
        val s = _state.value
        val r = s.reward ?: return
        if (r.doubled) return
        commit(s.copy(coins = s.coins + r.coins, reward = r.copy(coins = r.coins * 2, doubled = true)))
    }

    fun clearReward() { _state.value = _state.value.copy(reward = null) }
    fun addCoins(n: Int) = commit(_state.value.copy(coins = _state.value.coins + n))

    fun spend(n: Int): Boolean {
        val s = _state.value
        if (s.coins < n) return false
        commit(s.copy(coins = s.coins - n))
        return true
    }

    fun setName(name: String) = commit(_state.value.copy(name = name))
    fun markHelpSeen() = commit(_state.value.copy(helpSeen = true))

    // ───────── عجلة الحظ والقدرات ─────────
    private fun today() = System.currentTimeMillis() / 86_400_000L

    fun useFreeSpin() = commit(_state.value.copy(lastFreeSpinDay = today()))

    fun grantPrize(prize: WheelPrize, times: Int) {
        val s = _state.value
        commit(
            when (prize.power) {
                null -> s.copy(coins = s.coins + prize.coins * times)
                PowerUp.HINT -> s.copy(hints = s.hints + times)
                PowerUp.REVEAL -> s.copy(reveals = s.reveals + times)
                PowerUp.LUCK -> s.copy(lucks = s.lucks + times)
                PowerUp.REDO -> s.copy(redos = s.redos + times)
            }
        )
    }

    /** يُستدعى بعد نجاح استعمال القدرة داخل اللعب. */
    fun consume(kind: PowerUp) {
        val s = _state.value
        commit(
            when (kind) {
                PowerUp.HINT -> s.copy(hints = (s.hints - 1).coerceAtLeast(0))
                PowerUp.REVEAL -> s.copy(reveals = (s.reveals - 1).coerceAtLeast(0))
                PowerUp.LUCK -> s.copy(lucks = (s.lucks - 1).coerceAtLeast(0))
                PowerUp.REDO -> s.copy(redos = (s.redos - 1).coerceAtLeast(0))
            }
        )
    }
}
