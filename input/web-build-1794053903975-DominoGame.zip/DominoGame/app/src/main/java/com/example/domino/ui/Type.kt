package com.example.domino.ui

import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.example.domino.R

/** خط IBM Plex Sans Arabic (رخصة OFL). */
val AppFont = FontFamily(
    Font(R.font.ibm_plex_sans_arabic_regular, FontWeight.Normal),
    Font(R.font.ibm_plex_sans_arabic_medium, FontWeight.Medium),
    Font(R.font.ibm_plex_sans_arabic_semibold, FontWeight.SemiBold),
    Font(R.font.ibm_plex_sans_arabic_bold, FontWeight.Bold)
)

val AppTypography: Typography = Typography().let { t ->
    t.copy(
        displayLarge = t.displayLarge.copy(fontFamily = AppFont),
        displayMedium = t.displayMedium.copy(fontFamily = AppFont),
        displaySmall = t.displaySmall.copy(fontFamily = AppFont),
        headlineLarge = t.headlineLarge.copy(fontFamily = AppFont),
        headlineMedium = t.headlineMedium.copy(fontFamily = AppFont),
        headlineSmall = t.headlineSmall.copy(fontFamily = AppFont),
        titleLarge = t.titleLarge.copy(fontFamily = AppFont),
        titleMedium = t.titleMedium.copy(fontFamily = AppFont),
        titleSmall = t.titleSmall.copy(fontFamily = AppFont),
        bodyLarge = t.bodyLarge.copy(fontFamily = AppFont),
        bodyMedium = t.bodyMedium.copy(fontFamily = AppFont),
        bodySmall = t.bodySmall.copy(fontFamily = AppFont),
        labelLarge = t.labelLarge.copy(fontFamily = AppFont),
        labelMedium = t.labelMedium.copy(fontFamily = AppFont),
        labelSmall = t.labelSmall.copy(fontFamily = AppFont)
    )
}

/** ألوان النوافذ والأزرار الافتراضية بما يناسب الطاولة الخضراء والذهب. */
val DominoColors = darkColorScheme(
    primary = Color(0xFFFFB300),
    onPrimary = Color(0xFF3B2000),
    background = Color(0xFF052E16),
    surface = Color(0xFF14321F),
    surfaceContainerHigh = Color(0xFF14321F),
    onSurface = Color(0xFFEDE3C8),
    onSurfaceVariant = Color(0xFFEDE3C8)
)
