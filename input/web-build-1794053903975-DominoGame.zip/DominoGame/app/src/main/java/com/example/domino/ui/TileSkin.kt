package com.example.domino.ui

import androidx.annotation.DrawableRes
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import com.example.domino.R

/** تصميم لأحجار الدومينو. texture = صورة ملمس تُرسم على وجه الحجر. */
data class TileSkin(
    val id: String,
    val name: String,
    val price: Int,
    val faceTop: Color,
    val faceBottom: Color,
    val border: Color,
    val divider: Color,
    val pip: Color,
    val glow: Boolean = false,
    @DrawableRes val texture: Int? = null
) { val premium: Boolean get() = price > 0 }

object TileSkins {
    val Classic = TileSkin("classic", "العاجي الكلاسيكي", 0,
        Color(0xFFFFFDF5), Color(0xFFEFE6D0), Color(0xFF8A7B5A), Color(0xFF6B5E45), Color(0xFF1A1A1A))
    val Marble = TileSkin("marble", "الرخام الذهبي", 500,
        Color(0xFFF4F0E8), Color(0xFFDAD3C5), Color(0xFFC9A24B), Color(0xFFB8860B), Color(0xFF2B1B05),
        texture = R.drawable.tex_marble)
    val Leather = TileSkin("leather", "الجلد الأسود", 400,
        Color(0xFF2A2A2A), Color(0xFF0E0E0E), Color(0xFFD4A017), Color(0xFFD4A017), Color(0xFFF5D060),
        texture = R.drawable.tex_leather)
    val Mahogany = TileSkin("mahogany", "خشب الماهوغني", 400,
        Color(0xFF8A2A12), Color(0xFF4A0F08), Color(0xFFE6B34A), Color(0xFFE6B34A), Color(0xFFFFF1D6),
        texture = R.drawable.tex_mahogany)
    val Sapphire = TileSkin("sapphire", "الياقوت الأزرق", 600,
        Color(0xFF3F6FD8), Color(0xFF14337A), Color(0xFF9DB8FF), Color(0xFFBBD0FF), Color(0xFFFFFFFF),
        texture = R.drawable.tex_gem)
    val Emerald = TileSkin("emerald", "الزمرد", 500,
        Color(0xFF36C98A), Color(0xFF0C6B45), Color(0xFFB8FFE0), Color(0xFFD5FFEE), Color(0xFFFFFFFF))
    val Gold = TileSkin("gold", "الذهب الفاخر", 600,
        Color(0xFFFFE082), Color(0xFFD4A017), Color(0xFF8A6508), Color(0xFF7A5A08), Color(0xFF3B2A05))
    val Neon = TileSkin("neon", "النيون المضيء", 800,
        Color(0xFF1B1F33), Color(0xFF0A0C18), Color(0xFF00E5FF), Color(0xFF00E5FF), Color(0xFF00F0FF), glow = true)

    val all = listOf(Classic, Marble, Leather, Mahogany, Sapphire, Emerald, Gold, Neon)
    fun byId(id: String) = all.firstOrNull { it.id == id } ?: Classic
}

val LocalTileSkin = compositionLocalOf { TileSkins.Classic }
