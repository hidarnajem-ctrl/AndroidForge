package com.example.domino

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.ui.text.TextStyle
import com.example.domino.ui.App
import com.example.domino.ui.AppFont
import com.example.domino.ui.AppTypography
import com.example.domino.ui.DominoColors

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = DominoColors, typography = AppTypography) {
                ProvideTextStyle(TextStyle(fontFamily = AppFont)) { App() }
            }
        }
    }
}
