package com.example.domino.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.domino.data.SkinRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class SkinState(val unlocked: Set<String>, val selectedId: String)

class SkinViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SkinRepository(app)
    private val _state = MutableStateFlow(SkinState(repo.unlocked(), repo.selected()))
    val state: StateFlow<SkinState> = _state.asStateFlow()

    fun select(id: String) {
        if (id !in _state.value.unlocked) return
        repo.select(id)
        _state.update { it.copy(selectedId = id) }
    }

    /** يُستدعى بعد نيل المكافأة من الإعلان: يفتح التصميم ويفعّله. */
    fun unlock(id: String) {
        repo.unlock(id)
        repo.select(id)
        _state.update { it.copy(unlocked = it.unlocked + id, selectedId = id) }
    }
}
