package com.example.domino

object AppLinks {
    /** سياسة الخصوصية — منشورة على الويب من Google Docs (رابط /pub عام). */
    const val PRIVACY_POLICY =
        "https://docs.google.com/document/d/e/2PACX-1vR0UC_e-TQnqNSEePzuwbz6xAMS3PKZQe9eQjQUIslnaVRovoUerUvsiE5KR7CiNFs2ZtykBYxUuUXx/pub"
}
