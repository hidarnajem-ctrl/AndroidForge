package com.example.domino.ads

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/**
 * يحمّل إعلاناً بمكافأة مسبقاً ويعرضه عند الطلب.
 * ⚠️ المعرّف أدناه هو معرّف اختبار رسمي من Google — استبدله بمعرّفك الحقيقي قبل النشر.
 */
class RewardedAdManager(private val context: Context) {

    var isReady by mutableStateOf(false)
        private set

    private var ad: RewardedAd? = null
    private var loading = false

    init {
        MobileAds.initialize(context) {}
        load()
    }

    fun load() {
        if (loading || ad != null) return
        loading = true
        RewardedAd.load(context, AdIds.REWARDED, AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(loaded: RewardedAd) {
                    ad = loaded; loading = false; isReady = true
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    ad = null; loading = false; isReady = false
                }
            })
    }

    /** onReward تُستدعى فقط إذا أكمل المستخدم المشاهدة واستحق المكافأة. */
    fun show(activity: Activity, onReward: () -> Unit, onFail: (String) -> Unit) {
        val current = ad
        if (current == null) {
            load()
            onFail("الإعلان غير جاهز بعد، حاول بعد لحظات")
            return
        }
        var rewarded = false
        current.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                ad = null; isReady = false; load()
                if (rewarded) onReward()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                ad = null; isReady = false; load()
                onFail("تعذّر عرض الإعلان")
            }
        }
        current.show(activity) { rewarded = true }
    }

}
