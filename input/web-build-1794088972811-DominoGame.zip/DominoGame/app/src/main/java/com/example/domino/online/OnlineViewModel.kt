package com.example.domino.online

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.domino.model.*
import com.example.domino.viewmodel.GameController
import com.example.domino.viewmodel.GameState
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.random.Random

enum class LobbyPhase { IDLE, CONNECTING, WAITING, SEARCHING, IN_GAME }

data class LobbyState(
    val phase: LobbyPhase = LobbyPhase.IDLE,
    val code: String? = null,
    val error: String? = null
)

/**
 * اللعب مع صديق عبر الإنترنت (Firebase Realtime Database).
 * الغرفة: rooms/{رمز من 6 أرقام} — المضيف ينشئها والضيف ينضم إليها.
 * البحث العشوائي: queue/waiting يحمل رمز غرفة لاعب ينتظر.
 * كل حركة تُطبَّق داخل معاملة (Transaction) على نص اللعبة، فلا يحدث تعارض بين الهاتفين.
 */
class OnlineViewModel(app: Application) : AndroidViewModel(app), GameController {

    private val _lobby = MutableStateFlow(LobbyState())
    val lobby: StateFlow<LobbyState> = _lobby.asStateFlow()

    private val _state = MutableStateFlow(GameState(online = true))
    override val state: StateFlow<GameState> = _state.asStateFlow()

    private val _sounds = MutableSharedFlow<GameSound>(extraBufferCapacity = 16)
    override val sounds: SharedFlow<GameSound> = _sounds.asSharedFlow()

    private val _events = MutableSharedFlow<RoundEvent>(extraBufferCapacity = 4)
    override val roundEvents: SharedFlow<RoundEvent> = _events.asSharedFlow()

    val isConfigured: Boolean get() = FirebaseConfig.isConfigured

    private var db: FirebaseDatabase? = null
    private var uid: String? = null
    private var myName = "لاعب"
    private var myAvatar = "default"

    private var role = HOST
    private var roomRef: DatabaseReference? = null
    private var roomListener: ValueEventListener? = null
    private var connListener: ValueEventListener? = null
    private var queued = false

    private var game: NetGame? = null
    private var oppName = "صديقك"
    private var oppAvatar = "default"
    private var oppLeft = false
    private var selectedId: Int? = null
    private var localMessage: String? = null
    private var reportedSeq = -1
    private var passSeq = -1
    private var passJob: Job? = null

    // ═════════════ الدخول للغرف ═════════════

    fun createRoom(name: String, avatar: String) = viewModelScope.launch {
        setMe(name, avatar)
        _lobby.value = LobbyState(LobbyPhase.CONNECTING)
        if (!ensureReady()) return@launch
        val code = newRoom() ?: return@launch fail("تعذّر إنشاء الغرفة، حاول مرة أخرى")
        role = HOST
        listen(code)
        _lobby.value = LobbyState(LobbyPhase.WAITING, code)
    }

    fun joinRoom(code: String, name: String, avatar: String) = viewModelScope.launch {
        setMe(name, avatar)
        _lobby.value = LobbyState(LobbyPhase.CONNECTING)
        if (!ensureReady()) return@launch
        if (!join(code.trim())) return@launch fail("الرمز غير صحيح أو الغرفة ممتلئة")
        role = GUEST
        listen(code.trim())
    }

    fun playRandom(name: String, avatar: String) = viewModelScope.launch {
        setMe(name, avatar)
        _lobby.value = LobbyState(LobbyPhase.CONNECTING)
        if (!ensureReady()) return@launch
        val myCode = newRoom() ?: return@launch fail("تعذّر الاتصال، حاول مرة أخرى")
        val queue = db!!.getReference("queue").child("waiting")
        var theirCode: String? = null
        val ok = queue.transact { md ->
            theirCode = null
            val m = md.value as? Map<*, *>
            val ts = (m?.get("ts") as? Number)?.toLong() ?: 0L
            val other = m?.get("uid") as? String
            if (m != null && other != null && other != uid && System.currentTimeMillis() - ts < 60_000) {
                theirCode = m["code"] as? String
                md.value = null
            } else {
                md.value = mapOf("code" to myCode, "uid" to uid, "ts" to System.currentTimeMillis())
            }
            true
        }
        if (!ok) {
            db!!.getReference("rooms").child(myCode).removeValue()
            return@launch fail("تعذّر الاتصال، حاول مرة أخرى")
        }
        val target = theirCode
        if (target != null) {
            // وجدنا لاعباً ينتظر: نحذف غرفتنا وننضم إلى غرفته
            db!!.getReference("rooms").child(myCode).removeValue()
            if (!join(target)) return@launch fail("لم يعد اللاعب متاحاً، حاول مرة أخرى")
            role = GUEST
            listen(target)
        } else {
            role = HOST
            queued = true
            listen(myCode)
            _lobby.value = LobbyState(LobbyPhase.SEARCHING, myCode)
        }
    }

    /** إلغاء الانتظار أو مغادرة المباراة. */
    fun leave() {
        val ref = roomRef
        val wasWaiting = _lobby.value.phase == LobbyPhase.WAITING || _lobby.value.phase == LobbyPhase.SEARCHING
        val myUid = uid
        if (queued) {
            db?.getReference("queue")?.child("waiting")?.let { q ->
                viewModelScope.launch {
                    q.transact { md ->
                        val m = md.value as? Map<*, *>
                        if (m?.get("uid") == myUid) md.value = null
                        true
                    }
                }
            }
        }
        if (ref != null) {
            val onlineKey = if (role == HOST) "hostOnline" else "guestOnline"
            ref.child(onlineKey).onDisconnect().cancel()
            if (wasWaiting && role == HOST) ref.removeValue() else ref.child(onlineKey).setValue(false)
        }
        reset()
    }

    // ═════════════ أوامر اللعب (GameController) ═════════════

    override fun onTileClicked(tile: DominoTile) {
        val g = game ?: return
        if (g.status != PLAYING || g.turn != role || oppLeft) return
        val sides = GameEngine.legalSides(tile, g.board)
        when {
            sides.isEmpty() -> {
                sfx(GameSound.INVALID)
                selectedId = null
                localMessage = "هذا الحجر لا يطابق أي طرف"
                publish()
            }
            sides.size == 1 -> play(tile, sides.first())
            else -> {
                sfx(GameSound.SELECT)
                selectedId = if (selectedId == tile.id) null else tile.id
                localMessage = "اختر الطرف: اضغط على علامة + في اللوحة"
                publish()
            }
        }
    }

    override fun onSideSelected(side: Side) {
        val g = game ?: return
        val tile = g.hand(role).firstOrNull { it.id == selectedId } ?: return
        if (side in GameEngine.legalSides(tile, g.board)) play(tile, side)
    }

    override fun onDrawTile(tileId: Int) {
        val r = role
        sendAction { it.draw(r, tileId) }
    }

    override fun nextRound() {
        val seq = game?.seq ?: return
        sendAction { if (it.seq == seq) it.nextRound() else null }
    }

    private fun play(tile: DominoTile, side: Side) {
        selectedId = null
        localMessage = null
        val r = role
        sendAction { it.play(r, tile.id, side) }
    }

    private fun sendAction(f: (NetGame) -> NetGame?) {
        val ref = roomRef?.child("game") ?: return
        viewModelScope.launch {
            ref.transact { md ->
                val g = (md.value as? String)?.let { NetGame.fromJson(it) } ?: return@transact false
                val n = f(g) ?: return@transact false
                md.value = n.toJson()
                true
            }
        }
    }

    // ═════════════ استقبال التحديثات ═════════════

    private fun onRoom(s: DataSnapshot) {
        if (!s.exists()) {
            if (_lobby.value.phase == LobbyPhase.IN_GAME) { oppLeft = true; publish() }
            else if (role == GUEST) fail("أُغلقت الغرفة")
            return
        }
        val op = if (role == HOST) "guest" else "host"
        oppName = s.child("${op}Name").getValue(String::class.java) ?: "صديقك"
        oppAvatar = (s.child("${op}Avatar").getValue(String::class.java) ?: "default")
            .let { if (it.startsWith("custom")) "default" else it }
        val joined = s.child("${op}Uid").exists()
        val online = s.child("${op}Online").getValue(Boolean::class.java) ?: false
        val gameStr = s.child("game").getValue(String::class.java)
        if (!joined || gameStr == null) return

        if (_lobby.value.phase != LobbyPhase.IN_GAME) {
            _lobby.value = LobbyState(LobbyPhase.IN_GAME, _lobby.value.code)
            queued = false
        }
        oppLeft = !online
        NetGame.fromJson(gameStr)?.let { applyGame(it) } ?: publish()
    }

    private fun applyGame(g: NetGame) {
        val prev = game
        game = g
        if (prev != null && prev.seq != g.seq) {
            localMessage = null
            when {
                g.board.size > prev.board.size || (g.round != prev.round && g.status == PLAYING) -> sfx(GameSound.PLACE)
                g.yard.size < prev.yard.size -> sfx(GameSound.DRAW)
            }
        }
        if (selectedId != null && (g.turn != role || g.hand(role).none { it.id == selectedId })) selectedId = null
        publish()

        if (g.status == ROUND_OVER && reportedSeq != g.seq) {
            reportedSeq = g.seq
            val res = g.result
            if (res != null && prev != null) {
                val w = mapWinner(res.winner)
                _events.tryEmit(RoundEvent(w, res.points, g.matchWinner?.let { mapWinner(it) }))
                viewModelScope.launch {
                    delay(450)
                    sfx(when (w) { Winner.PLAYER -> GameSound.WIN; Winner.AI -> GameSound.LOSE; else -> GameSound.SELECT })
                }
            }
        }
        // تمرير تلقائي إن لم يكن لديّ حجر والمخزون فارغ
        if (g.status == PLAYING && g.turn == role && g.yard.isEmpty() &&
            GameEngine.possibleMoves(g.hand(role), g.board).isEmpty() && passSeq != g.seq
        ) {
            passSeq = g.seq
            passJob?.cancel()
            passJob = viewModelScope.launch {
                delay(1400)
                val r = role
                sendAction { it.pass(r) }
            }
        }
    }

    private fun mapWinner(w: String) = when (w) {
        role -> Winner.PLAYER
        DRAW -> Winner.DRAW
        else -> Winner.AI
    }

    private fun publish() {
        val g = game ?: return
        val me = role
        val op = otherRole(me)
        val myTurn = g.turn == me
        val hand = g.hand(me)
        val msg = localMessage ?: when {
            oppLeft -> "غادر $oppName المباراة"
            g.status != PLAYING -> ""
            !myTurn -> "دور $oppName..."
            GameEngine.possibleMoves(hand, g.board).isNotEmpty() -> "دورك — اختر حجراً مضيئاً"
            g.yard.isNotEmpty() -> "لا تملك حجراً مناسباً — اختر حجراً من المخزون"
            else -> "لا حجارة مناسبة — سيُمرَّر دورك"
        }
        _state.value = GameState(
            board = g.board,
            startTileId = g.startId,
            playerHand = hand,
            aiHand = g.hand(op),
            boneyard = g.yard,
            turn = if (myTurn) Turn.PLAYER else Turn.AI,
            status = if (g.status == PLAYING) Status.PLAYING else Status.ROUND_OVER,
            passes = g.passes,
            selectedTileId = selectedId,
            lastPlacedId = g.lastPlaced,
            playerScore = g.score(me),
            aiScore = g.score(op),
            message = msg,
            result = g.result?.let { RoundResult(mapWinner(it.winner), it.points, it.blocked) },
            round = g.round,
            matchWinner = g.matchWinner?.let { mapWinner(it) },
            online = true,
            opponentName = oppName,
            opponentAvatar = oppAvatar,
            opponentLeft = oppLeft
        )
    }

    // ═════════════ Firebase ═════════════

    private fun setMe(name: String, avatar: String) {
        myName = name
        myAvatar = if (avatar.startsWith("custom")) "default" else avatar
    }

    private fun fail(msg: String) {
        stopListening()
        _lobby.value = LobbyState(LobbyPhase.IDLE, error = msg)
    }

    private suspend fun ensureReady(): Boolean {
        if (!FirebaseConfig.isConfigured) {
            fail("اللعب الأونلاين غير مفعّل بعد (إعدادات Firebase فارغة)")
            return false
        }
        if (db != null && uid != null) return true
        return try {
            val ctx = getApplication<Application>()
            val app = FirebaseApp.getApps(ctx).firstOrNull { it.name == APP_NAME }
                ?: FirebaseApp.initializeApp(
                    ctx,
                    FirebaseOptions.Builder()
                        .setApiKey(FirebaseConfig.API_KEY)
                        .setApplicationId(FirebaseConfig.APP_ID)
                        .setProjectId(FirebaseConfig.PROJECT_ID)
                        .setDatabaseUrl(FirebaseConfig.DATABASE_URL)
                        .build(),
                    APP_NAME
                )
            val auth = FirebaseAuth.getInstance(app)
            val user = auth.currentUser ?: auth.signInAnonymously().awaitTask().user
            uid = user?.uid ?: throw IllegalStateException("no user")
            db = FirebaseDatabase.getInstance(app, FirebaseConfig.DATABASE_URL)
            true
        } catch (e: Exception) {
            fail("تعذّر الاتصال بالخادم. تأكد من الإنترنت ثم حاول مرة أخرى.")
            false
        }
    }

    private suspend fun newRoom(): String? {
        val d = db ?: return null
        repeat(6) {
            val code = Random.nextInt(100000, 1000000).toString()
            val ok = d.getReference("rooms").child(code).transact { md ->
                if (md.value != null) false
                else {
                    md.value = mapOf(
                        "hostUid" to uid, "hostName" to myName, "hostAvatar" to myAvatar,
                        "hostOnline" to true, "createdAt" to System.currentTimeMillis()
                    )
                    true
                }
            }
            if (ok) return code
        }
        return null
    }

    private suspend fun join(code: String): Boolean {
        val d = db ?: return false
        if (code.length != 6) return false
        return d.getReference("rooms").child(code).transact { md ->
            val m = md.value as? Map<*, *> ?: return@transact false
            val host = m["hostUid"] as? String ?: return@transact false
            if (host == uid) return@transact false
            val guest = m["guestUid"] as? String
            if (guest != null && guest != uid) return@transact false
            md.child("guestUid").value = uid
            md.child("guestName").value = myName
            md.child("guestAvatar").value = myAvatar
            md.child("guestOnline").value = true
            if (m["game"] == null) md.child("game").value = NetGame.deal(1, 0, 0, 0).toJson()
            true
        }
    }

    private fun listen(code: String) {
        stopListening()
        val d = db ?: return
        val ref = d.getReference("rooms").child(code)
        roomRef = ref
        val onlineRef = ref.child(if (role == HOST) "hostOnline" else "guestOnline")

        // عند عودة الاتصال نعيد تسجيل «متصل»، وعند الانقطاع يصبح «غير متصل» تلقائياً
        val conn = object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                if (s.getValue(Boolean::class.java) == true) {
                    onlineRef.onDisconnect().setValue(false)
                    onlineRef.setValue(true)
                }
            }
            override fun onCancelled(e: DatabaseError) {}
        }
        d.getReference(".info/connected").addValueEventListener(conn)
        connListener = conn

        val l = object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) = onRoom(s)
            override fun onCancelled(e: DatabaseError) { fail("انقطع الاتصال بالغرفة") }
        }
        ref.addValueEventListener(l)
        roomListener = l
    }

    private fun stopListening() {
        roomListener?.let { roomRef?.removeEventListener(it) }
        connListener?.let { db?.getReference(".info/connected")?.removeEventListener(it) }
        roomListener = null
        connListener = null
    }

    private fun reset() {
        stopListening()
        passJob?.cancel()
        roomRef = null
        game = null
        queued = false
        oppLeft = false
        selectedId = null
        localMessage = null
        reportedSeq = -1
        passSeq = -1
        _lobby.value = LobbyState()
        _state.value = GameState(online = true)
    }

    private fun sfx(s: GameSound) { _sounds.tryEmit(s) }

    override fun onCleared() {
        if (roomRef != null) leave()
        super.onCleared()
    }

    private companion object { const val APP_NAME = "domino-online" }
}

// ═════════════ أدوات مساعدة ═════════════

private suspend fun <T> Task<T>.awaitTask(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { cont.resume(it) }
    addOnFailureListener { cont.resumeWithException(it) }
}

/**
 * معاملة على الخادم. update تعيد true إن غيّرت البيانات، false للإلغاء.
 * إن كانت النسخة المحلية فارغة نترك الخادم يعيد المحاولة بالقيمة الحقيقية.
 */
private suspend fun DatabaseReference.transact(update: (MutableData) -> Boolean): Boolean =
    suspendCancellableCoroutine { cont ->
        var applied = false
        runTransaction(object : Transaction.Handler {
            override fun doTransaction(current: MutableData): Transaction.Result {
                val wasNull = current.value == null
                applied = update(current)
                return when {
                    applied -> Transaction.success(current)
                    wasNull -> Transaction.success(current)
                    else -> Transaction.abort()
                }
            }

            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                if (cont.isActive) cont.resume(error == null && committed && applied)
            }
        })
    }
