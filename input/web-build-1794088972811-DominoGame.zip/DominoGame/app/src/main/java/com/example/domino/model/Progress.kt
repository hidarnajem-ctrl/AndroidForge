package com.example.domino.model

const val TARGET_SCORE = 100      // المباراة تنتهي عند الوصول لهذه النقاط
const val AD_COIN_REWARD = 50     // عملات الإعلان المجاني

/** الخبرة المطلوبة للانتقال من المستوى الحالي: 100 ثم 150 ثم 200... */
fun xpNeeded(level: Int) = 50 + 50 * level

data class RoundEvent(val winner: Winner, val points: Int, val matchWinner: Winner?)

data class Reward(val coins: Int, val xp: Int, val levelUp: Int?, val doubled: Boolean = false)

data class ProgressState(
    val coins: Int = 100,
    val xp: Int = 0,
    val level: Int = 1,
    val name: String = "لاعب جديد",
    val matches: Int = 0,
    val matchWins: Int = 0,
    val rounds: Int = 0,
    val roundWins: Int = 0,
    val history: List<Boolean> = emptyList(),   // نتائج آخر المباريات (الأقدم أولاً)
    val helpSeen: Boolean = false,
    val reward: Reward? = null,
    val hints: Int = 0,
    val reveals: Int = 0,
    val lucks: Int = 0,
    val redos: Int = 0,
    val lastFreeSpinDay: Long = -1L,
    val avatar: String = "default"
) {
    fun powerCount(k: PowerUp) = when (k) {
        PowerUp.HINT -> hints
        PowerUp.REVEAL -> reveals
        PowerUp.LUCK -> lucks
        PowerUp.REDO -> redos
    }
}

/** قدرات تُكسب من عجلة الحظ وتُستعمل داخل اللعب. */
enum class PowerUp { HINT, REVEAL, LUCK, REDO }

enum class WheelPrize(val coins: Int = 0, val power: PowerUp? = null) {
    COINS_100(coins = 100), COINS_200(coins = 200), COINS_300(coins = 300),
    HINT(power = PowerUp.HINT), REVEAL(power = PowerUp.REVEAL),
    LUCK(power = PowerUp.LUCK), REDO(power = PowerUp.REDO)
}

/** ترتيب الأقسام على العجلة (مع عقارب الساعة بدءاً من الأعلى) وأوزان احتمالها. */
val WHEEL_ORDER = listOf(
    WheelPrize.COINS_200, WheelPrize.REDO, WheelPrize.COINS_100, WheelPrize.HINT,
    WheelPrize.REVEAL, WheelPrize.LUCK, WheelPrize.COINS_100, WheelPrize.COINS_300
)
val WHEEL_WEIGHTS = listOf(12, 10, 20, 12, 12, 10, 20, 4)
