package com.example.domino.ui

import androidx.activity.compose.BackHandler
import androidx.annotation.DrawableRes
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.domino.R
import com.example.domino.model.GameSound
import com.example.domino.model.WHEEL_ORDER
import com.example.domino.model.WHEEL_WEIGHTS
import com.example.domino.model.WheelPrize
import kotlin.math.roundToInt
import kotlin.random.Random
import kotlinx.coroutines.launch

private const val SEGMENTS = 8
private const val STEP = 360f / SEGMENTS

private val WhiteSeg = Color(0xFFF6F1FA)
private val PurpleSeg = Color(0xFF9B30D9)
private val GoldSeg = Color(0xFFE8B84A)
private val TextPurple = Color(0xFF5B0E8F)
private val segmentColors = listOf(WhiteSeg, PurpleSeg, WhiteSeg, PurpleSeg, WhiteSeg, PurpleSeg, WhiteSeg, GoldSeg)

private fun pickIndex(): Int {
    var r = Random.nextInt(WHEEL_WEIGHTS.sum())
    WHEEL_WEIGHTS.forEachIndexed { i, w -> if (r < w) return i; r -= w }
    return 0
}

@DrawableRes
private fun prizeIcon(p: WheelPrize): Int = when (p) {
    WheelPrize.HINT -> R.drawable.reward_hint
    WheelPrize.REVEAL -> R.drawable.reward_reveal
    WheelPrize.LUCK -> R.drawable.reward_luck
    WheelPrize.REDO -> R.drawable.reward_redo
    else -> R.drawable.reward_coin_pile
}

private fun prizeLabel(p: WheelPrize): String = when (p) {
    WheelPrize.HINT -> "تلميح"
    WheelPrize.REVEAL -> "كشف أحجار الخصم"
    WheelPrize.LUCK -> "حظ: سحب حجر مناسب"
    WheelPrize.REDO -> "إعادة توزيع الأحجار"
    else -> "عملات"
}

/** وجه العجلة (الأقسام + الأيقونات + الأرقام) ويدور بزاوية rotation. */
@Composable
private fun WheelFace(rotation: Float, modifier: Modifier) {
    val measurer = rememberTextMeasurer()
    val coin = ImageBitmap.imageResource(R.drawable.icon_coin)
    val hint = ImageBitmap.imageResource(R.drawable.reward_hint)
    val reveal = ImageBitmap.imageResource(R.drawable.reward_reveal)
    val luck = ImageBitmap.imageResource(R.drawable.reward_luck)
    val redo = ImageBitmap.imageResource(R.drawable.reward_redo)
    val icons = listOf(coin, redo, coin, hint, reveal, luck, coin, coin)   // نفس ترتيب WHEEL_ORDER

    Canvas(modifier) {
        val c = Offset(size.width / 2f, size.height / 2f)
        val r = size.minDimension * 0.40f
        rotate(rotation, c) {
            for (i in 0 until SEGMENTS) {
                drawArc(
                    color = segmentColors[i],
                    startAngle = -90f + i * STEP - STEP / 2f,
                    sweepAngle = STEP,
                    useCenter = true,
                    topLeft = Offset(c.x - r, c.y - r),
                    size = Size(2 * r, 2 * r)
                )
            }
            for (i in 0 until SEGMENTS) {
                rotate(i * STEP + STEP / 2f, c) {
                    drawLine(Color(0x66B8860B), c, Offset(c.x, c.y - r), strokeWidth = 2f)
                }
            }
            for (i in 0 until SEGMENTS) {
                val prize = WHEEL_ORDER[i]
                val isCoin = prize.coins > 0
                rotate(i * STEP, c) {
                    val img = icons[i]
                    val w = r * if (isCoin) 0.30f else 0.34f
                    val h = w * img.height / img.width
                    val iconY = c.y - r * (if (isCoin) 0.50f else 0.55f)
                    drawImage(
                        img,
                        dstOffset = IntOffset((c.x - w / 2f).roundToInt(), (iconY - h / 2f).roundToInt()),
                        dstSize = IntSize(w.roundToInt(), h.roundToInt())
                    )
                    val label = if (isCoin) "${prize.coins}" else "1"
                    val layout = measurer.measure(
                        label,
                        TextStyle(
                            color = if (segmentColors[i] == PurpleSeg) Color.White else TextPurple,
                            fontSize = (r * 0.15f).toSp(),
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    )
                    drawText(
                        layout,
                        topLeft = Offset(c.x - layout.size.width / 2f, c.y - r * 0.82f - layout.size.height / 2f)
                    )
                }
            }
        }
    }
}

/**
 * شاشة «دوران الحظ»: دوران مجاني كل يوم، ودوران إضافي بمشاهدة إعلان.
 * بعد الدوران تظهر نافذة المكافأة: «جمع» أو «مضاعفة» بإعلان.
 */
@Composable
fun WheelScreen(
    freeSpin: Boolean,
    adReady: Boolean,
    onClose: () -> Unit,
    onConsumeFreeSpin: () -> Unit,
    onWatchAd: (onReward: () -> Unit) -> Unit,
    onCollect: (prize: WheelPrize, times: Int) -> Unit,
    playSound: (GameSound) -> Unit
) {
    val scope = rememberCoroutineScope()
    val rotation = remember { Animatable(0f) }
    var spinning by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<WheelPrize?>(null) }

    BackHandler { if (!spinning) onClose() }

    fun startSpin() {
        if (spinning) return
        spinning = true
        playSound(GameSound.SELECT)
        val idx = pickIndex()
        scope.launch {
            val cur = rotation.value
            val jitter = Random.nextFloat() * 28f - 14f
            val desired = -idx * STEP + jitter
            val delta = (((desired - cur) % 360f) + 360f) % 360f
            rotation.animateTo(
                cur + 360f * 5 + delta,
                tween(4800, easing = CubicBezierEasing(0.12f, 0.65f, 0.12f, 1f))
            )
            spinning = false
            result = WHEEL_ORDER[idx]
            playSound(GameSound.WIN)
        }
    }

    fun onSpinClick() {
        if (spinning || result != null) return
        if (freeSpin) { onConsumeFreeSpin(); startSpin() }
        else if (adReady) onWatchAd { startSpin() }
    }

    val pulse = rememberInfiniteTransition(label = "glow")
    val glowAlpha by pulse.animateFloat(0.55f, 0.95f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "a")

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wheelSize = minOf(maxWidth - 24.dp, 380.dp)

        FullBackground(R.drawable.bg_felt)
        FullBackground(R.drawable.curtains)
        if (result != null) {
            Image(painterResource(R.drawable.confetti), null, Modifier.fillMaxSize().graphicsLayer { alpha = 0.9f },
                contentScale = androidx.compose.ui.layout.ContentScale.Crop)
        }

        RibbonTitle(
            "دوران الحظ",
            Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 70.dp).width(280.dp),
            fontSize = 26.sp
        )

        Box(Modifier.align(Alignment.Center).size(wheelSize)) {
            Image(
                painterResource(R.drawable.glow_light), null,
                Modifier.fillMaxSize().scale(1.45f).graphicsLayer { alpha = glowAlpha }
            )
            WheelFace(rotation.value, Modifier.fillMaxSize())
            Image(painterResource(R.drawable.wheel_rim), null, Modifier.fillMaxSize())
            Image(painterResource(R.drawable.wheel_hub), null, Modifier.align(Alignment.Center).size(wheelSize * 0.21f))
            Image(
                painterResource(R.drawable.wheel_pointer), null,
                Modifier.align(Alignment.TopCenter).offset(y = -(wheelSize * 0.07f)).width(wheelSize * 0.14f)
            )
        }

        Column(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 36.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            GoldButton(
                text = if (freeSpin) "غزل مجاناً" else "غزل",
                modifier = Modifier.width(260.dp),
                enabled = !spinning && result == null && (freeSpin || adReady),
                adBadge = !freeSpin,
                onClick = ::onSpinClick
            )
            Spacer(Modifier.height(8.dp))
            Text(
                if (freeSpin) "لديك دوران مجاني اليوم" else "عُد غداً لدوران مجاني، أو شاهد إعلاناً لدوران إضافي",
                color = Palette.text, fontSize = 12.sp, textAlign = TextAlign.Center
            )
        }

        Image(
            painterResource(R.drawable.btn_close), null,
            Modifier.align(Alignment.TopStart).statusBarsPadding().padding(14.dp).size(44.dp)
                .clickable(enabled = !spinning) { onClose() }
        )
    }

    result?.let { prize ->
        Dialog(onDismissRequest = {}) {
            Panel(Modifier.fillMaxWidth()) {
                Text(
                    "مكافآتك", color = Palette.gold, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(painterResource(prizeIcon(prize)), null, Modifier.size(96.dp))
                    Spacer(Modifier.width(14.dp))
                    Text(
                        "+${if (prize.coins > 0) prize.coins else 1}",
                        color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    prizeLabel(prize), color = Palette.text, fontSize = 14.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
                Spacer(Modifier.height(14.dp))
                GoldButton("مضاعفة ×2", enabled = adReady, adBadge = true) {
                    onWatchAd { onCollect(prize, 2); result = null }
                }
                Spacer(Modifier.height(10.dp))
                GoldButton("جمع", green = true) {
                    // يعرض إعلاناً بمكافأة قبل الجمع؛ إن لم يكن الإعلان جاهزاً تُجمع الجائزة مباشرة
                    if (adReady) onWatchAd { onCollect(prize, 1); result = null }
                    else { onCollect(prize, 1); result = null }
                }
            }
        }
    }
}
