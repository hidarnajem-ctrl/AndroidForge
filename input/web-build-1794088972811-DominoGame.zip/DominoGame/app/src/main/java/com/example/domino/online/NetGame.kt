package com.example.domino.online

import com.example.domino.model.DominoTile
import com.example.domino.model.GameEngine
import com.example.domino.model.Side
import com.example.domino.model.TARGET_SCORE
import org.json.JSONArray
import org.json.JSONObject

const val HOST = "host"
const val GUEST = "guest"
const val DRAW = "draw"
const val PLAYING = "playing"
const val ROUND_OVER = "round_over"

fun otherRole(r: String) = if (r == HOST) GUEST else HOST

data class NetResult(val winner: String, val points: Int, val blocked: Boolean)

/** حالة المباراة كما تُحفظ في الخادم (نص JSON واحد ليُحدَّث دفعة واحدة). */
data class NetGame(
    val board: List<DominoTile>,
    val startId: Int,
    val hostHand: List<DominoTile>,
    val guestHand: List<DominoTile>,
    val yard: List<DominoTile>,
    val turn: String,
    val passes: Int,
    val scoreHost: Int,
    val scoreGuest: Int,
    val round: Int,
    val status: String,
    val lastPlaced: Int,
    val result: NetResult?,
    val matchWinner: String?,
    val seq: Int
) {
    fun hand(role: String) = if (role == HOST) hostHand else guestHand
    fun score(role: String) = if (role == HOST) scoreHost else scoreGuest
    private fun withHand(role: String, h: List<DominoTile>) =
        if (role == HOST) copy(hostHand = h) else copy(guestHand = h)

    fun toJson(): String {
        fun tiles(l: List<DominoTile>) = JSONArray().apply {
            l.forEach { put(JSONArray().put(it.id).put(it.left).put(it.right)) }
        }
        val o = JSONObject()
            .put("board", tiles(board)).put("start", startId)
            .put("hh", tiles(hostHand)).put("gh", tiles(guestHand)).put("yard", tiles(yard))
            .put("turn", turn).put("passes", passes)
            .put("sh", scoreHost).put("sg", scoreGuest).put("round", round)
            .put("status", status).put("last", lastPlaced).put("seq", seq)
        result?.let {
            o.put("res", JSONObject().put("w", it.winner).put("p", it.points).put("b", it.blocked))
        }
        matchWinner?.let { o.put("mw", it) }
        return o.toString()
    }

    // ───────── القواعد (تُطبَّق داخل معاملة الخادم) ─────────
    private fun canAct(role: String) = status == PLAYING && turn == role
    private fun hasMove(role: String) = GameEngine.possibleMoves(hand(role), board).isNotEmpty()

    fun play(role: String, tileId: Int, side: Side): NetGame? {
        if (!canAct(role)) return null
        val tile = hand(role).firstOrNull { it.id == tileId } ?: return null
        if (side !in GameEngine.legalSides(tile, board)) return null
        val n = withHand(role, hand(role) - tile).copy(
            board = GameEngine.place(board, tile, side),
            passes = 0, lastPlaced = tile.id, seq = seq + 1
        )
        return if (n.hand(role).isEmpty()) n.finish() else n.copy(turn = otherRole(role))
    }

    fun draw(role: String, tileId: Int): NetGame? {
        if (!canAct(role) || hasMove(role)) return null
        val t = yard.firstOrNull { it.id == tileId } ?: return null
        return withHand(role, hand(role) + t).copy(yard = yard - t, seq = seq + 1)
    }

    fun pass(role: String): NetGame? {
        if (!canAct(role) || hasMove(role) || yard.isNotEmpty()) return null
        val p = passes + 1
        val n = copy(passes = p, seq = seq + 1)
        return if (p >= 2) n.finish() else n.copy(turn = otherRole(role))
    }

    private fun finish(): NetGame {
        val hp = GameEngine.pips(hostHand)
        val gp = GameEngine.pips(guestHand)
        val r = when {
            hostHand.isEmpty() -> NetResult(HOST, gp, false)
            guestHand.isEmpty() -> NetResult(GUEST, hp, false)
            hp < gp -> NetResult(HOST, gp - hp, true)
            gp < hp -> NetResult(GUEST, hp - gp, true)
            else -> NetResult(DRAW, 0, true)
        }
        val sh = scoreHost + if (r.winner == HOST) r.points else 0
        val sg = scoreGuest + if (r.winner == GUEST) r.points else 0
        val mw = if ((sh >= TARGET_SCORE || sg >= TARGET_SCORE) && sh != sg) (if (sh > sg) HOST else GUEST) else null
        return copy(status = ROUND_OVER, result = r, scoreHost = sh, scoreGuest = sg, matchWinner = mw, seq = seq + 1)
    }

    /** الجولة التالية، أو مباراة جديدة إن كانت المباراة قد انتهت. */
    fun nextRound(): NetGame? {
        if (status != ROUND_OVER) return null
        return if (matchWinner != null) deal(1, 0, 0, seq) else deal(round + 1, scoreHost, scoreGuest, seq)
    }

    companion object {
        fun deal(round: Int, sh: Int, sg: Int, prevSeq: Int): NetGame {
            val deck = GameEngine.fullSet().shuffled()
            val h = deck.take(7)
            val g = deck.drop(7).take(7)
            val yard = deck.drop(14)
            val all = h.map { it to HOST } + g.map { it to GUEST }
            val (first, owner) = all.maxBy { (t, _) -> if (t.isDouble) 100 + t.left else t.pips }
            return NetGame(
                board = listOf(first), startId = first.id,
                hostHand = if (owner == HOST) h - first else h,
                guestHand = if (owner == GUEST) g - first else g,
                yard = yard, turn = otherRole(owner), passes = 0,
                scoreHost = sh, scoreGuest = sg, round = round,
                status = PLAYING, lastPlaced = first.id,
                result = null, matchWinner = null, seq = prevSeq + 1
            )
        }

        fun fromJson(s: String): NetGame? = runCatching {
            val o = JSONObject(s)
            fun tiles(key: String): List<DominoTile> {
                val a = o.getJSONArray(key)
                return (0 until a.length()).map {
                    val t = a.getJSONArray(it)
                    DominoTile(t.getInt(0), t.getInt(1), t.getInt(2))
                }
            }
            val res = o.optJSONObject("res")?.let {
                NetResult(it.getString("w"), it.getInt("p"), it.getBoolean("b"))
            }
            NetGame(
                board = tiles("board"), startId = o.getInt("start"),
                hostHand = tiles("hh"), guestHand = tiles("gh"), yard = tiles("yard"),
                turn = o.getString("turn"), passes = o.getInt("passes"),
                scoreHost = o.getInt("sh"), scoreGuest = o.getInt("sg"), round = o.getInt("round"),
                status = o.getString("status"), lastPlaced = o.getInt("last"),
                result = res, matchWinner = if (o.has("mw")) o.getString("mw") else null,
                seq = o.getInt("seq")
            )
        }.getOrNull()
    }
}
