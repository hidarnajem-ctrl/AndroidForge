package com.example.domino.viewmodel

import com.example.domino.model.DominoTile
import com.example.domino.model.GameSound
import com.example.domino.model.RoundEvent
import com.example.domino.model.Side
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

/** ما تحتاجه شاشة اللعب، سواء ضد الكمبيوتر أو ضد صديق أونلاين. */
interface GameController {
    val state: StateFlow<GameState>
    val sounds: SharedFlow<GameSound>
    val roundEvents: SharedFlow<RoundEvent>

    fun onTileClicked(tile: DominoTile)
    fun onSideSelected(side: Side)
    fun onDrawTile(tileId: Int)
    fun nextRound()

    // القدرات متاحة ضد الكمبيوتر فقط
    fun useHint(): Boolean = false
    fun useReveal(): Boolean = false
    fun useLuck(): Boolean = false
    fun useRedo(): Boolean = false
}
