package com.example.domino.ui

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.domino.R
import com.example.domino.model.TARGET_SCORE

private data class Rule(@DrawableRes val icon: Int, val title: String, val body: String)

private val rules = listOf(
    Rule(R.drawable.help_target, "الهدف", "تخلّص من كل أحجارك أولاً. تنتهي المباراة عندما يصل أحد اللاعبين إلى $TARGET_SCORE نقطة."),
    Rule(R.drawable.icon_play, "اللعب", "اختر حجراً مضيئاً يطابق أحد طرفي السلسلة. إن طابق الطرفين معاً اضغط علامة + في اللوحة لاختيار الجهة."),
    Rule(R.drawable.icon_boneyard, "السحب", "إن لم يكن لديك حجر مناسب يظهر مخزون القطع فوق الطاولة؛ اختر أي حجر مقلوب لسحبه، واستمر حتى تجد حجراً صالحاً. إذا فرغ المخزون يُمرَّر دورك."),
    Rule(R.drawable.icon_lock, "الإغلاق", "إذا تعذّر اللعب على الطرفين تُغلق الجولة، ويفوز صاحب مجموع النقاط الأقل."),
    Rule(R.drawable.help_points, "النقاط", "يربح الفائز نقاط أحجار خصمه المتبقية (وفي الإغلاق: الفرق بين المجموعين)."),
    Rule(R.drawable.icon_coin, "المكافآت", "تربح عملات وخبرة بعد كل جولة، وتستعملها لفتح تصاميم جديدة من «المجموعات»."),
    Rule(R.drawable.wheel_mini, "عجلة الحظ", "دوران مجاني كل يوم (ودوران إضافي بإعلان) يمنحك عملات أو قدرات: تلميح، كشف أحجار الخصم، حظ (سحب حجر مناسب)، وإعادة توزيع الأحجار. تستعملها من الأزرار فوق يدك أثناء اللعب. القدرة التي ليس لديك رصيد منها تكون مقفلة، وتفتحها مرة واحدة بمشاهدة إعلان.")
)

@Composable
fun HelpDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Panel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.icon_book), null, Modifier.size(width = 44.dp, height = 26.dp))
                Spacer(Modifier.width(8.dp))
                Text("طريقة اللعب", color = Palette.gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))
            Column(
                Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                rules.forEach { rule ->
                    Row(verticalAlignment = Alignment.Top) {
                        Image(painterResource(rule.icon), null, Modifier.size(36.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(rule.title, color = Palette.gold, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Text(rule.body, color = Palette.text, fontSize = 14.sp, lineHeight = 22.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            GoldButton("فهمت", onClick = onDismiss)
        }
    }
}
