package com.example.domino.ads

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

/** إعلان بيني يُحمَّل مسبقاً. onDone تُستدعى دائماً (بعد الإغلاق أو إن لم يكن جاهزاً) لتكمل اللعبة. */
class InterstitialAdManager(private val context: Context) {
    private var ad: InterstitialAd? = null
    private var loading = false

    init {
        MobileAds.initialize(context) {}
        load()
    }

    fun load() {
        if (loading || ad != null) return
        loading = true
        InterstitialAd.load(context, AdIds.INTERSTITIAL, AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(loaded: InterstitialAd) { ad = loaded; loading = false }
                override fun onAdFailedToLoad(error: LoadAdError) { ad = null; loading = false }
            })
    }

    fun show(activity: Activity?, onDone: () -> Unit) {
        val current = ad
        if (current == null || activity == null) { load(); onDone(); return }
        current.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { ad = null; load(); onDone() }
            override fun onAdFailedToShowFullScreenContent(error: AdError) { ad = null; load(); onDone() }
        }
        current.show(activity)
    }
}
