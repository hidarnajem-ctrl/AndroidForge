package com.example.domino.ads

import com.example.domino.BuildConfig

/**
 * نسخة Debug تعرض إعلانات اختبار (آمنة للتجربة)،
 * ونسخة Release تعرض إعلاناتك الحقيقية من حساب AdMob.
 * ⚠️ لا تضغط على إعلاناتك الحقيقية بنفسك، فقد يُغلق حساب AdMob.
 */
object AdIds {
    private const val REAL_REWARDED = "ca-app-pub-1341061237626351/6586710091"
    private const val REAL_INTERSTITIAL = "ca-app-pub-1341061237626351/3964416188"
    private const val REAL_BANNER = "ca-app-pub-1341061237626351/6969853473"

    private const val TEST_REWARDED = "ca-app-pub-3940256099942544/5224354917"
    private const val TEST_INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712"
    private const val TEST_BANNER = "ca-app-pub-3940256099942544/9214589741"

    val REWARDED: String get() = if (BuildConfig.DEBUG) TEST_REWARDED else REAL_REWARDED
    val INTERSTITIAL: String get() = if (BuildConfig.DEBUG) TEST_INTERSTITIAL else REAL_INTERSTITIAL
    val BANNER: String get() = if (BuildConfig.DEBUG) TEST_BANNER else REAL_BANNER
}
