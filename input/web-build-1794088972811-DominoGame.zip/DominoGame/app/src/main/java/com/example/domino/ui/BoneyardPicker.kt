package com.example.domino.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.paint
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domino.R
import com.example.domino.model.DominoTile

private val DieFaces = mapOf(
    0 to emptyList(),
    1 to listOf(0.5f to 0.5f),
    2 to listOf(0.27f to 0.27f, 0.73f to 0.73f),
    3 to listOf(0.27f to 0.27f, 0.5f to 0.5f, 0.73f to 0.73f),
    4 to listOf(0.27f to 0.27f, 0.73f to 0.27f, 0.27f to 0.73f, 0.73f to 0.73f),
    5 to listOf(0.27f to 0.27f, 0.73f to 0.27f, 0.5f to 0.5f, 0.27f to 0.73f, 0.73f to 0.73f),
    6 to listOf(0.27f to 0.25f, 0.73f to 0.25f, 0.27f to 0.5f, 0.73f to 0.5f, 0.27f to 0.75f, 0.73f to 0.75f)
)

/** مربع صغير يُظهر رقم أحد طرفي اللوحة (الرقم الذي تحتاج مطابقته). */
@Composable
private fun DieFace(value: Int, size: Dp = 30.dp) {
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension
        drawRoundRect(Color(0xFF5A2A12), cornerRadius = CornerRadius(s * 0.18f))
        DieFaces[value]?.forEach { (x, y) ->
            drawCircle(Color(0xFFFFF3DC), s * 0.09f, Offset(x * s, y * s))
        }
    }
}

/**
 * مخزون القطع: يظهر فوق الطاولة عندما لا تملك حجراً مناسباً.
 * الأحجار مقلوبة، ويختار اللاعب أي حجر يريد سحبه.
 * يبقى ظاهراً حتى تحصل على حجر صالح أو يفرغ المخزون.
 */
@Composable
fun BoneyardPicker(
    boneyard: List<DominoTile>,
    openEnds: List<Int>,
    onPick: (DominoTile) -> Unit,
    modifier: Modifier = Modifier
) {
    run {
        Column(modifier.fillMaxWidth().padding(horizontal = 10.dp)) {
            // ─── الشريط العلوي: أرقام الأطراف + العنوان ───
            Row(
                Modifier
                    .padding(horizontal = 18.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFFFFE3C2), Color(0xFFF2C79A))))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                openEnds.distinct().forEach {
                    DieFace(it)
                    Spacer(Modifier.width(6.dp))
                }
                Text(
                    "اسحب من مخزون القطع",
                    color = Color(0xFF3B1E0A), fontSize = 16.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f).padding(start = 8.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }

            // ─── الصينية الخشبية ───
            val trayShape = RoundedCornerShape(22.dp)
            val tray = androidx.compose.ui.graphics.ImageBitmap.imageResource(R.drawable.tray_wood)
            BoxWithConstraints(
                Modifier
                    .fillMaxWidth()
                    .drawBehind {
                        val cs = (tray.width * 0.11f).toInt()
                        val cd = 34.dp.toPx()
                        drawNineSlice(tray, cs, cs, cd, cd)
                    }
                    .padding(horizontal = 22.dp, vertical = 22.dp)
            ) {
                val cols = 7
                val gap = 6.dp
                val inner = 10.dp
                val cell = ((maxWidth - inner * 2 - gap * (cols - 1)) / cols).coerceAtMost(44.dp)
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(inner)
                ) {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(cols),
                        horizontalArrangement = Arrangement.spacedBy(gap, Alignment.CenterHorizontally),
                        verticalArrangement = Arrangement.spacedBy(gap),
                        userScrollEnabled = false,
                        modifier = Modifier.heightIn(max = cell * 2 * 3 + gap * 2)
                    ) {
                        items(boneyard, key = { it.id }) { t ->
                            Box(
                                Modifier
                                    .animateItem(
                                        fadeOutSpec = spring(stiffness = Spring.StiffnessMedium),
                                        placementSpec = spring(dampingRatio = 0.8f, stiffness = 300f)
                                    )
                                    .clickable { onPick(t) },
                                contentAlignment = Alignment.Center
                            ) {
                                TileView(null, faceDown = true, cell = cell)
                            }
                        }
                    }
                }
            }
            Text(
                "متبقي ${boneyard.size} قطعة — اختر أي حجر",
                color = Palette.text, fontSize = 12.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 6.dp)
            )
        }
    }
}

