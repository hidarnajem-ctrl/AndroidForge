# تفعيل اللعب الأونلاين (Firebase)

1. ادخل https://console.firebase.google.com بحساب Google واضغط **Create a project**، سمّه مثلاً `domino-game`، ويمكنك إيقاف Google Analytics.
2. من الصفحة الرئيسية للمشروع اضغط أيقونة **Android**:
   - Package name: `com.example.domino`
   - اضغط Register app ثم **Download google-services.json** واحفظه.
3. من القائمة الجانبية: **Build ← Authentication ← Get started ← Sign-in method ← Anonymous ← Enable ← Save**.
4. من القائمة الجانبية: **Build ← Realtime Database ← Create Database** واختر أقرب موقع (مثلاً europe-west1)، ثم **Start in locked mode**.
5. في تبويب **Rules** الصق القواعد التالية واضغط **Publish**:

```json
{
  "rules": {
    "rooms": { ".read": "auth != null", ".write": "auth != null" },
    "queue": { ".read": "auth != null", ".write": "auth != null" }
  }
}
```

6. أرسل ملف `google-services.json` لـ Claude، أو انسخ القيم بنفسك إلى
   `app/src/main/java/com/example/domino/online/FirebaseConfig.kt`:
   - `API_KEY` ← `client[0].api_key[0].current_key`
   - `APP_ID` ← `client[0].client_info.mobilesdk_app_id`
   - `PROJECT_ID` ← `project_info.project_id`
   - `DATABASE_URL` ← `project_info.firebase_url` (إن لم يظهر، انسخ الرابط من أعلى صفحة Realtime Database)
