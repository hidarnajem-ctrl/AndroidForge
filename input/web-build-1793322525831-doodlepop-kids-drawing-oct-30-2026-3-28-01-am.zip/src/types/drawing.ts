export type ToolType = 'brush' | 'eraser' | 'stamp';

export type BrushSize = 'small' | 'medium' | 'large';

export interface ColorOption {
  id: string;
  name: string;
  hex: string;
  isRainbow?: boolean;
}

export interface StampOption {
  id: string;
  name: string;
  emoji: string;
  iconName: string;
}

export interface BackgroundColorOption {
  id: string;
  name: string;
  color: string;
  textColor: string;
}

export const BRUSH_SIZES: Record<BrushSize, { size: number; label: string; dotClass: string }> = {
  small: { size: 6, label: 'Small', dotClass: 'w-2.5 h-2.5' },
  medium: { size: 16, label: 'Medium', dotClass: 'w-5 h-5' },
  large: { size: 32, label: 'Large', dotClass: 'w-8 h-8' },
};

export const COLOR_PALETTE: ColorOption[] = [
  { id: 'red', name: 'Cherry Red', hex: '#EF4444' },
  { id: 'orange', name: 'Sunny Orange', hex: '#F97316' },
  { id: 'yellow', name: 'Banana Yellow', hex: '#EAB308' },
  { id: 'green', name: 'Grass Green', hex: '#22C55E' },
  { id: 'blue', name: 'Ocean Blue', hex: '#3B82F6' },
  { id: 'purple', name: 'Berry Purple', hex: '#A855F7' },
  { id: 'pink', name: 'Bubblegum Pink', hex: '#EC4899' },
  { id: 'black', name: 'Midnight Black', hex: '#1E293B' },
  { id: 'white', name: 'Cloud White', hex: '#FFFFFF' },
  { id: 'rainbow', name: 'Magic Rainbow', hex: 'linear-gradient(135deg, #f87171, #fbbf24, #34d399, #60a5fa, #c084fc)', isRainbow: true },
];

export const STAMP_LIST: StampOption[] = [
  { id: 'star', name: 'Star', emoji: '⭐', iconName: 'Star' },
  { id: 'heart', name: 'Heart', emoji: '❤️', iconName: 'Heart' },
  { id: 'smile', name: 'Smiley', emoji: '😄', iconName: 'Smile' },
  { id: 'sun', name: 'Sun', emoji: '☀️', iconName: 'Sun' },
  { id: 'flower', name: 'Flower', emoji: '🌸', iconName: 'Flower' },
  { id: 'butterfly', name: 'Butterfly', emoji: '🦋', iconName: 'Bug' },
  { id: 'paw', name: 'Puppy Paw', emoji: '🐾', iconName: 'Footprints' },
  { id: 'crown', name: 'Crown', emoji: '👑', iconName: 'Crown' },
];

export const BACKGROUND_OPTIONS: BackgroundColorOption[] = [
  { id: 'white', name: 'White Paper', color: '#FFFFFF', textColor: '#1E293B' },
  { id: 'cream', name: 'Warm Cream', color: '#FFFBEB', textColor: '#1E293B' },
  { id: 'blackboard', name: 'Chalkboard', color: '#1E293B', textColor: '#F8FAFC' },
  { id: 'night', name: 'Night Sky', color: '#0F172A', textColor: '#F8FAFC' },
];
