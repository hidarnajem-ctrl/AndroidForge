import React, { useState } from 'react';
import { Download, Share, PlusSquare, X, Smartphone } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  onTapSound?: () => void;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ onTapSound }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // If already installed or running as standalone, don't show
  if (isInstalled) {
    return null;
  }

  // Chromium / Android / Desktop flow
  if (isInstallable) {
    return (
      <button
        onClick={() => {
          onTapSound?.();
          install();
        }}
        className="kid-btn flex items-center gap-1.5 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-2xl bg-amber-400 hover:bg-amber-300 active:bg-amber-500 text-amber-950 font-bold text-xs sm:text-sm shadow-[0_3px_0_#d97706] border-2 border-amber-500"
        title="Install DoodlePop on your device!"
        aria-label="Install App"
      >
        <Download className="w-4 h-4 stroke-[2.5]" />
        <span className="hidden xs:inline">Install</span>
      </button>
    );
  }

  // iOS Safari flow
  if (isIOS) {
    return (
      <>
        <button
          onClick={() => {
            onTapSound?.();
            setShowIOSGuide(true);
          }}
          className="kid-btn flex items-center gap-1.5 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-2xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-bold text-xs sm:text-sm shadow-[0_3px_0_#d97706] border-2 border-amber-500"
          title="Install on iOS"
          aria-label="Install on iOS"
        >
          <Smartphone className="w-4 h-4 stroke-[2.5]" />
          <span className="hidden xs:inline">Install</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-kid-pop">
            <div className="relative w-full max-w-sm rounded-3xl bg-white p-6 shadow-2xl border-4 border-amber-400 text-slate-800">
              <button
                onClick={() => setShowIOSGuide(false)}
                className="absolute top-4 right-4 p-1 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="text-center mb-4">
                <div className="w-14 h-14 mx-auto mb-2 rounded-2xl bg-amber-100 border-2 border-amber-400 flex items-center justify-center text-2xl">
                  🎨
                </div>
                <h3 className="text-xl font-bold text-slate-900">Install DoodlePop</h3>
                <p className="text-xs text-slate-500 mt-1">Play full-screen with no browser bars!</p>
              </div>

              <div className="space-y-3 bg-amber-50/60 p-4 rounded-2xl border border-amber-200 text-sm">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-blue-500 text-white flex items-center justify-center shrink-0">
                    <Share className="w-4 h-4" />
                  </div>
                  <span>1. Tap the <strong>Share</strong> button in Safari's bottom toolbar.</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500 text-white flex items-center justify-center shrink-0">
                    <PlusSquare className="w-4 h-4" />
                  </div>
                  <span>2. Scroll down and tap <strong>Add to Home Screen</strong>.</span>
                </div>
              </div>

              <button
                onClick={() => setShowIOSGuide(false)}
                className="kid-btn mt-5 w-full rounded-2xl bg-amber-400 py-3 text-sm font-bold text-amber-950 shadow-[0_3px_0_#d97706] hover:bg-amber-300"
              >
                Got It! 👍
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
