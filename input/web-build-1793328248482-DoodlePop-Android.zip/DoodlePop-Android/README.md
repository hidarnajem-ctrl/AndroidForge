# DoodlePop Android — standalone offline build

This is an Android application project for **DoodlePop Kids Drawing**. It packages the drawing interface inside the APK; it does not load the interface from a website.

## Offline design

- The drawing interface, styles, scripts, colors, shapes, stamps, and coloring templates are bundled in `app/src/main/assets/index.html`.
- The app does not declare Android's `INTERNET` permission.
- The saved-artwork gallery uses IndexedDB on the device, with a small localStorage fallback.
- The native Android bridge writes exported PNG images to `Pictures/DoodlePop` in the phone's image gallery.
- No Google Fonts, CDN, remote API, server, account, or sign-in is required at runtime.

## Build with AndroidIDE

1. Extract this ZIP on your phone.
2. In AndroidIDE, open/import the extracted **DoodlePop-Android** folder (the folder containing `settings.gradle`).
3. Set the Gradle JDK to **Java 17**.
4. Ensure Android SDK Platform **35** and Build Tools **35.0.0** are installed. The project uses Android Gradle Plugin `8.6.1` and Gradle `8.7`.
5. Sync the Gradle project, then run the `:app:assembleDebug` task or use **Build APK**.
6. The debug APK should be created at:

   `app/build/outputs/apk/debug/app-debug.apk`

## Build from a terminal

From this folder, with Gradle 8.7 and Android SDK 35 installed:

```bash
gradle assembleDebug
```

## Notes

- Minimum supported Android version: Android 10 (API 29), chosen so image export can use the modern MediaStore API without broad storage permissions.
- The application ID is `com.doodlepop.kidsdrawing`.
- App version: `1.0.0`.
- The original React/Vite project from the supplied ZIP is preserved in `original-web-source/` for reference. The Android build uses the bundled self-contained offline page so no npm/Node build step is required on the phone.
- This project ZIP is source code, not a prebuilt APK. It must be built once in AndroidIDE (or by the included GitHub Actions workflow) to produce the installable APK.
