/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import confetti from 'canvas-confetti';
import {
  ToolType,
  BrushSize,
  ColorOption,
  StampOption,
  ShapeOption,
  ShapeFillMode,
  SavedArtwork,
  ColoringTemplate,
  COLOR_PALETTE,
  STAMP_LIST,
  SHAPES_LIST,
  BACKGROUND_OPTIONS,
} from './types/drawing';
import { Canvas, CanvasHandle } from './components/Canvas';
import { HeaderBar } from './components/HeaderBar';
import { ColorPalette } from './components/ColorPalette';
import { ToolBar } from './components/ToolBar';
import { ConfirmationModal } from './components/ConfirmationModal';
import { GalleryModal } from './components/GalleryModal';
import { TemplatesModal } from './components/TemplatesModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { useSoundEffects } from './hooks/useSoundEffects';
import { useOfflineGallery } from './hooks/useOfflineGallery';

export default function App() {
  const canvasRef = useRef<CanvasHandle | null>(null);

  // Drawing state
  const [tool, setTool] = useState<ToolType>('brush');
  const [selectedColor, setSelectedColor] = useState<ColorOption>(COLOR_PALETTE[0]); // Red
  const [brushSize, setBrushSize] = useState<BrushSize>('medium');
  const [selectedStamp, setSelectedStamp] = useState<StampOption>(STAMP_LIST[0]); // Star
  const [selectedShape, setSelectedShape] = useState<ShapeOption>(SHAPES_LIST[0]); // Circle
  const [shapeFillMode, setShapeFillMode] = useState<ShapeFillMode>('fill');
  const [backgroundColor, setBackgroundColor] = useState<string>(BACKGROUND_OPTIONS[0].color); // White paper

  // History & Modal states
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);
  const [showClearModal, setShowClearModal] = useState(false);
  const [showGalleryModal, setShowGalleryModal] = useState(false);
  const [showTemplatesModal, setShowTemplatesModal] = useState(false);
  const [saveToast, setSaveToast] = useState(false);

  // Sound effects
  const {
    soundEnabled,
    toggleSound,
    playPop,
    playSwoosh,
    playTrash,
    playSparkle,
    playFanfare,
  } = useSoundEffects();

  // Offline Gallery hook
  const { artworks, saveArtwork, deleteArtwork } = useOfflineGallery();

  // Handlers
  const handleSelectColor = (color: ColorOption) => {
    setSelectedColor(color);
    if (tool === 'eraser') {
      setTool('brush');
    }
  };

  const handleSelectTool = (newTool: ToolType) => {
    setTool(newTool);
  };

  const handleUndo = () => {
    playSwoosh();
    canvasRef.current?.undo();
  };

  const handleRedo = () => {
    playSwoosh();
    canvasRef.current?.redo();
  };

  const handleClearClick = () => {
    setShowClearModal(true);
  };

  const handleConfirmClear = () => {
    playTrash();
    canvasRef.current?.clear();
    setShowClearModal(false);
  };

  const handleCancelClear = () => {
    playPop();
    setShowClearModal(false);
  };

  // Save drawing to offline storage + download image
  const handleSaveDrawing = () => {
    if (!canvasRef.current) return;
    const dataUrl = canvasRef.current.exportImage(backgroundColor);
    if (!dataUrl) return;

    // Save to offline storage gallery
    saveArtwork(dataUrl, backgroundColor);

    // Trigger celebration fanfare sound
    playFanfare();

    // Trigger playful multi-color confetti explosion
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#EF4444', '#F97316', '#EAB308', '#22C55E', '#3B82F6', '#EC4899', '#A855F7'],
      });
    } catch {
      // ignore
    }

    // Trigger download PNG to device
    const link = document.createElement('a');
    const timestamp = new Date().toISOString().slice(0, 10);
    link.download = `DoodlePop-Masterpiece-${timestamp}.png`;
    link.href = dataUrl;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    // Show celebratory toast
    setSaveToast(true);
    setTimeout(() => {
      setSaveToast(false);
    }, 2800);
  };

  // Open artwork from offline gallery onto canvas
  const handleOpenArtwork = (artwork: SavedArtwork) => {
    if (!canvasRef.current) return;
    if (artwork.backgroundColor) {
      setBackgroundColor(artwork.backgroundColor);
    }
    canvasRef.current.loadDrawing(artwork.dataUrl);
    playSparkle();
  };

  // Download artwork from gallery card
  const handleDownloadArtwork = (artwork: SavedArtwork) => {
    const link = document.createElement('a');
    link.download = `${artwork.title}.png`;
    link.href = artwork.dataUrl;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    playPop();
  };

  // Load a coloring template onto the canvas
  const handleSelectTemplate = (template: ColoringTemplate) => {
    if (!canvasRef.current) return;
    setBackgroundColor('#FFFFFF'); // Set clean white canvas for coloring
    canvasRef.current.loadTemplate(template.id);
    setTool('brush');
    playSparkle();
  };

  return (
    <div className="fixed inset-0 w-full h-full flex flex-col justify-between p-2 sm:p-3 pb-[env(safe-area-inset-bottom,8px)] pt-[env(safe-area-inset-top,8px)] gap-1.5 sm:gap-2.5 bg-gradient-to-b from-amber-100/90 via-orange-50 to-amber-100/90 overflow-hidden select-none touch-none">
      {/* Top Header Bar */}
      <HeaderBar
        canUndo={canUndo}
        canRedo={canRedo}
        soundEnabled={soundEnabled}
        savedCount={artworks.length}
        onUndo={handleUndo}
        onRedo={handleRedo}
        onClearClick={handleClearClick}
        onSaveClick={handleSaveDrawing}
        onOpenGallery={() => setShowGalleryModal(true)}
        onOpenTemplates={() => setShowTemplatesModal(true)}
        onToggleSound={toggleSound}
        onTapSound={playPop}
      />

      {/* Main Drawing Canvas: takes up majority of screen */}
      <main className="flex-1 w-full relative min-h-0 flex items-center justify-center">
        <Canvas
          ref={canvasRef}
          tool={tool}
          selectedColor={selectedColor}
          brushSize={brushSize}
          selectedStamp={selectedStamp}
          selectedShape={selectedShape}
          shapeFillMode={shapeFillMode}
          backgroundColor={backgroundColor}
          onStrokeStart={() => {}}
          onStrokeEnd={() => {}}
          onStampPlaced={playSparkle}
          onShapePlaced={playSparkle}
          onHistoryChange={(undoable, redoable) => {
            setCanUndo(undoable);
            setCanRedo(redoable);
          }}
        />

        {/* Celebratory Artwork Saved Toast */}
        {saveToast && (
          <div className="absolute top-4 z-40 bg-white/95 backdrop-blur-md px-5 py-3 rounded-2xl shadow-xl border-2 border-emerald-400 text-emerald-800 font-extrabold text-sm sm:text-base flex items-center gap-2 animate-kid-pop">
            <span className="text-2xl">🎉</span>
            <span>تم حفظ اللوحة في معرضك وجهازك!</span>
          </div>
        )}
      </main>

      {/* Color Palette (Scrollable/Centered) */}
      <ColorPalette
        selectedColor={selectedColor}
        isEraser={tool === 'eraser'}
        onSelectColor={handleSelectColor}
        onTapSound={playPop}
      />

      {/* Bottom Controls Bar (Pen, Eraser, Shapes, Stamps, Brush Sizes, Paper BG) */}
      <ToolBar
        tool={tool}
        brushSize={brushSize}
        selectedColor={selectedColor}
        selectedStamp={selectedStamp}
        selectedShape={selectedShape}
        shapeFillMode={shapeFillMode}
        backgroundColor={backgroundColor}
        onSelectTool={handleSelectTool}
        onSelectBrushSize={setBrushSize}
        onSelectStamp={setSelectedStamp}
        onSelectShape={setSelectedShape}
        onSelectShapeFillMode={setShapeFillMode}
        onSelectBackground={setBackgroundColor}
        onTapSound={playPop}
        onMagicSound={playSparkle}
      />

      {/* Clear Canvas Confirmation Modal */}
      <ConfirmationModal
        isOpen={showClearModal}
        onConfirm={handleConfirmClear}
        onCancel={handleCancelClear}
      />

      {/* Saved Artworks Offline Gallery Modal */}
      <GalleryModal
        isOpen={showGalleryModal}
        artworks={artworks}
        onClose={() => setShowGalleryModal(false)}
        onOpenArtwork={handleOpenArtwork}
        onDeleteArtwork={deleteArtwork}
        onDownloadArtwork={handleDownloadArtwork}
        onTapSound={playPop}
      />

      {/* Offline Coloring Templates Modal */}
      <TemplatesModal
        isOpen={showTemplatesModal}
        onClose={() => setShowTemplatesModal(false)}
        onSelectTemplate={handleSelectTemplate}
        onTapSound={playPop}
        onMagicSound={playSparkle}
      />

      {/* PWA Offline Mode Indicator */}
      <OfflineIndicator />
    </div>
  );
}
