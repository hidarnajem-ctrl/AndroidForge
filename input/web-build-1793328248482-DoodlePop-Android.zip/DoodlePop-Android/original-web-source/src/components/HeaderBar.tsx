import React, { useState } from 'react';
import {
  Undo2,
  Redo2,
  Trash2,
  Download,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
  Palette,
  Images,
  BookOpen,
  Wifi,
  Sparkles,
} from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';

interface HeaderBarProps {
  canUndo: boolean;
  canRedo: boolean;
  soundEnabled: boolean;
  savedCount: number;
  onUndo: () => void;
  onRedo: () => void;
  onClearClick: () => void;
  onSaveClick: () => void;
  onOpenGallery: () => void;
  onOpenTemplates: () => void;
  onToggleSound: () => void;
  onTapSound?: () => void;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({
  canUndo,
  canRedo,
  soundEnabled,
  savedCount,
  onUndo,
  onRedo,
  onClearClick,
  onSaveClick,
  onOpenGallery,
  onOpenTemplates,
  onToggleSound,
  onTapSound,
}) => {
  const [isFullscreen, setIsFullscreen] = useState(false);

  const toggleFullscreen = () => {
    onTapSound?.();
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
      }
      setIsFullscreen(false);
    }
  };

  return (
    <header className="w-full bg-white/95 backdrop-blur-md px-2 py-1.5 sm:px-4 sm:py-2.5 rounded-2xl sm:rounded-3xl shadow-md border-2 border-amber-200/90 flex items-center justify-between gap-1 sm:gap-2 shrink-0">
      {/* Brand logo & title */}
      <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
        <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-br from-rose-500 to-amber-500 text-white flex items-center justify-center shadow-[0_3px_0_#be123c] border border-rose-300">
          <Palette className="w-5 h-5 sm:w-6 sm:h-6 stroke-[2.5]" />
        </div>
        <div>
          <h1 className="text-base sm:text-xl font-bold tracking-tight text-slate-900 leading-none flex items-center gap-1">
            <span>Doodle</span>
            <span className="text-rose-500">Pop</span>
          </h1>
          <div className="flex items-center gap-1 mt-0.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[10px] text-emerald-700 font-bold leading-tight">
              100% أوفلاين
            </span>
          </div>
        </div>
      </div>

      {/* Main Action Buttons */}
      <div className="flex items-center gap-1 sm:gap-1.5 overflow-x-auto no-scrollbar py-0.5">
        {/* Undo Button */}
        <button
          onClick={() => {
            if (canUndo) {
              onTapSound?.();
              onUndo();
            }
          }}
          disabled={!canUndo}
          className={`kid-btn w-9 h-9 sm:w-11 sm:h-11 rounded-2xl flex items-center justify-center font-bold transition shrink-0 ${
            canUndo
              ? 'bg-sky-100 hover:bg-sky-200 text-sky-700 border-2 border-sky-300 shadow-[0_2px_0_#0284c7]'
              : 'bg-slate-100 text-slate-300 border-2 border-slate-200 cursor-not-allowed opacity-50'
          }`}
          title="Undo last stroke"
          aria-label="Undo"
        >
          <Undo2 className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2.5]" />
        </button>

        {/* Redo Button */}
        <button
          onClick={() => {
            if (canRedo) {
              onTapSound?.();
              onRedo();
            }
          }}
          disabled={!canRedo}
          className={`kid-btn w-9 h-9 sm:w-11 sm:h-11 rounded-2xl flex items-center justify-center font-bold transition shrink-0 ${
            canRedo
              ? 'bg-sky-100 hover:bg-sky-200 text-sky-700 border-2 border-sky-300 shadow-[0_2px_0_#0284c7]'
              : 'bg-slate-100 text-slate-300 border-2 border-slate-200 cursor-not-allowed opacity-50'
          }`}
          title="Redo stroke"
          aria-label="Redo"
        >
          <Redo2 className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2.5]" />
        </button>

        {/* Clear Canvas (Trash) */}
        <button
          onClick={() => {
            onTapSound?.();
            onClearClick();
          }}
          className="kid-btn w-9 h-9 sm:w-11 sm:h-11 rounded-2xl bg-rose-100 hover:bg-rose-200 text-rose-600 border-2 border-rose-300 shadow-[0_2px_0_#e11d48] flex items-center justify-center shrink-0"
          title="Clear whole drawing"
          aria-label="Clear Canvas"
        >
          <Trash2 className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2.5]" />
        </button>

        {/* Gallery Button with Badge */}
        <button
          onClick={() => {
            onTapSound?.();
            onOpenGallery();
          }}
          className="kid-btn relative h-9 px-2 sm:h-11 sm:px-3 rounded-2xl bg-amber-100 hover:bg-amber-200 text-amber-900 border-2 border-amber-300 shadow-[0_2px_0_#d97706] flex items-center gap-1 font-bold shrink-0"
          title="معرض رسوماتي المحفوظة"
          aria-label="Gallery"
        >
          <Images className="w-4 h-4 text-amber-700 stroke-[2.4]" />
          <span className="text-xs font-bold hidden xxs:inline">معرضي</span>
          {savedCount > 0 && (
            <span className="w-4 h-4 rounded-full bg-amber-600 text-white text-[10px] font-black flex items-center justify-center">
              {savedCount}
            </span>
          )}
        </button>

        {/* Templates Button */}
        <button
          onClick={() => {
            onTapSound?.();
            onOpenTemplates();
          }}
          className="kid-btn h-9 px-2 sm:h-11 sm:px-3 rounded-2xl bg-pink-100 hover:bg-pink-200 text-pink-900 border-2 border-pink-300 shadow-[0_2px_0_#db2777] flex items-center gap-1 font-bold shrink-0"
          title="قوالب تلوين جاهزة"
          aria-label="Coloring Templates"
        >
          <BookOpen className="w-4 h-4 text-pink-700 stroke-[2.4]" />
          <span className="text-xs font-bold hidden xxs:inline">تلوين</span>
        </button>

        {/* Save Drawing Button */}
        <button
          onClick={() => {
            onTapSound?.();
            onSaveClick();
          }}
          className="kid-btn h-9 px-2.5 sm:h-11 sm:px-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-white font-bold text-xs sm:text-sm border-2 border-emerald-600 shadow-[0_2px_0_#047857] flex items-center gap-1 shrink-0"
          title="حفظ الرسمة في المعرض والصور"
          aria-label="Save Artwork"
        >
          <Download className="w-4 h-4 stroke-[2.8]" />
          <span className="font-extrabold hidden xxs:inline">حفظ</span>
        </button>
      </div>

      {/* Auxiliary: Sound, Fullscreen, PWA Install */}
      <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
        {/* PWA Install Button */}
        <PWAInstallButton onTapSound={onTapSound} />

        {/* Sound FX Toggle */}
        <button
          onClick={() => {
            onTapSound?.();
            onToggleSound();
          }}
          className="kid-btn w-8 h-8 sm:w-10 sm:h-10 rounded-2xl bg-amber-100 hover:bg-amber-200 text-amber-800 border-2 border-amber-300 shadow-[0_2px_0_#d97706] flex items-center justify-center shrink-0"
          title={soundEnabled ? 'Mute sound effects' : 'Turn sound effects on'}
          aria-label="Toggle Sound"
        >
          {soundEnabled ? (
            <Volume2 className="w-4 h-4 stroke-[2.2]" />
          ) : (
            <VolumeX className="w-4 h-4 stroke-[2.2] text-amber-500" />
          )}
        </button>

        {/* Fullscreen Button */}
        <button
          onClick={toggleFullscreen}
          className="kid-btn hidden sm:flex w-8 h-8 sm:w-10 sm:h-10 rounded-2xl bg-amber-100 hover:bg-amber-200 text-amber-800 border-2 border-amber-300 shadow-[0_2px_0_#d97706] items-center justify-center shrink-0"
          title={isFullscreen ? 'Exit full screen' : 'Full screen mode'}
          aria-label="Toggle Fullscreen"
        >
          {isFullscreen ? (
            <Minimize2 className="w-4 h-4 stroke-[2.2]" />
          ) : (
            <Maximize2 className="w-4 h-4 stroke-[2.2]" />
          )}
        </button>
      </div>
    </header>
  );
};
