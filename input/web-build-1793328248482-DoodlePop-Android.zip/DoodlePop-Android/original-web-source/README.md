# DoodlePop Kids Drawing Studio 🎨

A mobile-first, 100% offline-ready Kids Drawing Progressive Web App (PWA) built with **React**, **Vite**, **TypeScript**, and **Tailwind CSS**.

---

## 🚀 Quick Start (تشغيل المشروع محلياً)

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Start the local development server**:
   ```bash
   npm run dev
   ```
   Open [http://localhost:3000](http://localhost:3000) in your browser.

3. **Build for production**:
   ```bash
   npm run build
   ```

---

## 📱 Features (الميزات)

- 🖍️ **Child-Friendly Touch Canvas**: Smooth quadratic Bézier interpolation, multi-touch gesture prevention (no accidental zooming or scrolling).
- 🌈 **Vibrant Palette & Rainbow Pen**: Solid bright colors plus an animated Magic Rainbow pen.
- 📐 **Shapes Tool**: Circle, Square, Triangle, Star, Diamond, and Heart with Solid Fill vs Outline mode.
- ⭐ **Fun Stamps**: Placeable emojis scaled to brush size.
- 🖼️ **100% Offline Drawing Gallery**: Saves drawings locally in the browser so kids can view and re-open them anytime without internet.
- 🎨 **Built-in Coloring Templates**: 6 offline coloring pages (Dinosaur, Rocket, Puppy, Butterfly, Robot, Flower).
- 🔊 **Web Audio Synthesizer**: Joyful sound effects with zero external audio assets.
- 📦 **PWA & Android Installable**: Web App Manifest, maskable icons, and service worker caching.

---

## 🤖 Convert to Native Android APK (تحويل إلى ملف APK)

### Method 1: Using PWABuilder (أسهل طريقة - دقيقة واحدة)
1. Deploy or host this project on any hosting (Vercel, Netlify, Cloud Run, GitHub Pages).
2. Go to [https://www.pwabuilder.com](https://www.pwabuilder.com).
3. Enter your deployed URL and click **Android -> Generate Package (APK)**.

### Method 2: Using Capacitor (مشروع أندرويد محلي عبر Android Studio)
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init DoodlePop com.doodlepop.kidsapp --web-dir dist
npm run build
npx cap add android
npx cap open android
```
Then build the APK directly in Android Studio!
