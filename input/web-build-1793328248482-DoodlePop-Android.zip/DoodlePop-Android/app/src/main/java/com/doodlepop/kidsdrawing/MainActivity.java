package com.doodlepop.kidsdrawing;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;
import java.lang.ref.WeakReference;

/**
 * DoodlePop standalone offline host.
 * All application HTML/CSS/JavaScript is packaged in app/src/main/assets/index.html.
 * The app deliberately does not request INTERNET permission or open remote pages.
 */
public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureSystemBars();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(255, 249, 237));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setHapticFeedbackEnabled(true);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setSupportZoom(false);
        webView.getSettings().setBuiltInZoomControls(false);
        webView.getSettings().setDisplayZoomControls(false);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            webView.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            webView.getSettings().setSafeBrowsingEnabled(true);
        }

        webView.addJavascriptInterface(new NativeBridge(this), "DoodlePopNative");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Keep navigation inside the bundled app. No browser or network navigation.
                Uri uri = request.getUrl();
                String host = uri.getHost();
                return host == null || !host.equals("doodlepop.local");
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return url == null || !url.startsWith("https://doodlepop.local/");
            }
        });

        setContentView(webView);
        loadBundledApp();
    }

    private void configureSystemBars() {
        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(true);
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(Color.rgb(255, 102, 130));
        window.setNavigationBarColor(Color.rgb(255, 249, 237));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }

    private void loadBundledApp() {
        try (InputStream input = getAssets().open("index.html");
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = input.read(buffer)) != -1) {
                output.write(buffer, 0, read);
            }
            String html = output.toString("UTF-8");
            // The synthetic HTTPS origin enables reliable DOM storage without network access.
            webView.loadDataWithBaseURL(
                    "https://doodlepop.local/",
                    html,
                    "text/html",
                    "UTF-8",
                    null
            );
        } catch (Exception error) {
            Toast.makeText(this, "تعذر تشغيل DoodlePop: " + error.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript(
                    "(function(){var m=document.getElementById('modal');if(m&&m.classList.contains('open')){m.classList.remove('open');return true;}return false;})()",
                    value -> {
                        if (!"true".equals(value)) {
                            finish();
                        }
                    }
            );
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.removeJavascriptInterface("DoodlePopNative");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    public static class NativeBridge {
        private final Context context;
        private final WeakReference<Activity> activityRef;

        NativeBridge(Activity activity) {
            this.context = activity.getApplicationContext();
            this.activityRef = new WeakReference<>(activity);
        }

        /** Saves an image generated inside the offline drawing canvas to Pictures/DoodlePop. */
        @JavascriptInterface
        public void saveImage(String dataUrl, String requestedName) {
            try {
                if (dataUrl == null || !dataUrl.startsWith("data:image/png;base64,")) {
                    showToast("تعذر حفظ الصورة");
                    return;
                }
                String encoded = dataUrl.substring(dataUrl.indexOf(',') + 1);
                byte[] imageBytes = Base64.decode(encoded, Base64.DEFAULT);
                String safeName = sanitizeName(requestedName);
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, safeName);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DoodlePop");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);

                Uri collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                Uri imageUri = context.getContentResolver().insert(collection, values);
                if (imageUri == null) {
                    showToast("تعذر إنشاء ملف الصورة");
                    return;
                }
                try (OutputStream stream = context.getContentResolver().openOutputStream(imageUri, "w")) {
                    if (stream == null) throw new IllegalStateException("Output stream unavailable");
                    stream.write(imageBytes);
                    stream.flush();
                }
                ContentValues complete = new ContentValues();
                complete.put(MediaStore.Images.Media.IS_PENDING, 0);
                context.getContentResolver().update(imageUri, complete, null, null);
                showToast("تم حفظ الصورة في Pictures / DoodlePop");
            } catch (Exception error) {
                showToast("فشل حفظ الصورة. جرّب مرة أخرى.");
            }
        }

        private String sanitizeName(String name) {
            String base = name == null ? "DoodlePop-Artwork" : name.trim();
            base = base.replaceAll("[^\\p{L}\\p{N}._-]", "_");
            if (base.isEmpty()) base = "DoodlePop-Artwork";
            if (!base.toLowerCase(Locale.ROOT).endsWith(".png")) base += ".png";
            return base;
        }

        private void showToast(String message) {
            Activity activity = activityRef.get();
            if (activity != null && !activity.isFinishing()) {
                activity.runOnUiThread(() -> Toast.makeText(activity, message, Toast.LENGTH_SHORT).show());
            }
        }
    }
}
