# JavaScript interface methods are called by the bundled local HTML page.
-keepclassmembers class com.doodlepop.kidsdrawing.MainActivity$NativeBridge {
    @android.webkit.JavascriptInterface <methods>;
}
