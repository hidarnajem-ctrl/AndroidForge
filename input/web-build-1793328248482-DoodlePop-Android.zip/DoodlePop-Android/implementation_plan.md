# 100% Offline Android Kids Drawing App & Gallery

Transform DoodlePop into a fully standalone, offline-first Android application that launches and operates with zero internet connection, featuring an offline drawing gallery and built-in coloring book templates.

## User Review & Critical Decisions

> [!IMPORTANT]
> The app is built with an offline-first Progressive Web App (PWA) architecture. Once loaded or installed on an Android device, all code, fonts, sound synthesizers, and assets will be precached via the Service Worker so the app opens and functions flawlessly in airplane mode or with no connectivity.

- **Offline Storage Strategy**: Use browser `localStorage` and `IndexedDB` to store kids' saved masterpieces locally on the device without requiring any server connection or accounts.
- **Built-in Offline Coloring Templates**: Include built-in coloring pages (Rocket, Dino, Puppy, Butterfly) so kids always have offline activities ready.
- **Android APK Readiness**: Maintain full Web App Manifest, maskable splash icons, and standalone flags so the app can be installed directly from Chrome or converted into a `.apk` file using standard TWA / PWABuilder tooling.

---

## 1. Overview & Core Concept

- **What It Does**: A completely offline kids drawing pad and coloring studio. Kids can draw, stamp, place geometric shapes, save multiple creations to a local device gallery, and reload them anytime without an active internet connection.
- **Target Audience**: Young kids, parents, and teachers using Android tablets or smartphones on airplanes, road trips, or areas without Wi-Fi.
- **Key Value**: Guaranteed 100% reliability offline with native Android splash screen, full-screen canvas, and instant startup time.

---

## 2. User Experience & Visual Design

- **Offline Indicator**: A discreet badge in the header shows "Ready Offline" (أوفلاين جاهز) or an unobtrusive status informing the user that everything is saved locally.
- **My Artworks Gallery Modal**:
  - A new "Gallery" (معرض رسوماتي) button in the header.
  - A kid-friendly grid of saved artworks with thumbnail previews.
  - One-tap actions: "Open & Continue Drawing" (فتح وإكمال الرسم) or "Export / Download" or "Delete" with confirmation.
- **Coloring Templates Drawer**:
  - Quick button in toolbar to load clean coloring sheet outlines (Dino, Rocket, Cat, Flower).
  - Kids can color inside and around the outlines using regular pens, rainbow pen, or stamps.
- **Visual Theme & Anti-Slop Integrity**:
  - Warm cream background (`#FFFBEB`) with playful amber/rose borders.
  - Large tactile buttons ($\ge 44\text{px}$) with 3D drop-shadows and bounce feedback.
  - Zero external web font dependencies during offline mode by preloading and local font fallbacks.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Client-Side Storage vs Cloud Database**
  - *Chosen Approach*: Local storage (IndexedDB / localStorage) with base64/blob storage.
  - *Why*: True offline operation without requiring user login, Firebase credentials, or network requests.
- **Decision 2: Service Worker Precache Configuration**
  - *Chosen Approach*: `vite-plugin-pwa` with `CacheFirst` strategy and complete local asset bundling.
  - *Why*: Ensures every single font, icon, script, and stylesheet is cached immediately on first visit, enabling instant boot without network connectivity.

---

## 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────┐
│                 DoodlePop Android PWA                       │
├───────────────────────────────┬─────────────────────────────┤
│        Header Controls        │    Offline Status Badge     │
│  [Undo] [Redo] [Trash] [Save] │      [My Art Gallery]       │
├───────────────────────────────┴─────────────────────────────┤
│                                                             │
│                HTML5 Canvas (Drawing Area)                  │
│       • Touch & Stylus Tracker (Zero Network Req)           │
│       • Web Audio API Synthesizer (Zero Audio Files)        │
│       • Smooth Quadratic Bézier Line Smoothing              │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│                    Color & Rainbow Palette                  │
├─────────────────────────────────────────────────────────────┤
│       ToolBar: [Pen] [Eraser] [Shapes] [Stamps] [Templates] │
├─────────────────────────────────────────────────────────────┤
│           Offline Service Worker & Storage Layer            │
│  ┌─────────────────────────────┐  ┌──────────────────────┐  │
│  │   Workbox Precache Cache    │  │ IndexedDB / Storage  │  │
│  │   (HTML, JS, CSS, Icons)    │  │ (Saved Masterpieces) │  │
│  └─────────────────────────────┘  └──────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

### Component & State Mapping
1. `useOfflineStorage.ts`: Hook managing local storage of artworks (id, title, thumbnail, timestamp, background).
2. `GalleryModal.tsx`: Grid modal showing saved local drawings with thumbnail cards, delete, and reload buttons.
3. `TemplatesModal.tsx`: Built-in vector coloring outlines for offline coloring fun.
4. `vite.config.ts`: Enhanced Workbox precache patterns and runtime caching for full offline coverage.
