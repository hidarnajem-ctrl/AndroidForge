package com.doodlepop.kidsdrawing;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import androidx.webkit.WebViewAssetLoader;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.RequestConfiguration;

import java.io.OutputStream;
import java.util.Arrays;

public class MainActivity extends Activity {
    private WebView webView;
    private LinearLayout rootLayout;
    private FrameLayout bannerContainer;
    private AdView bannerAd;
    private InterstitialAd interstitialAd;
    private int successfulSaves = 0;
    private boolean adsInitialized = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(255, 249, 240));
        getWindow().setNavigationBarColor(Color.rgb(255, 249, 240));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }

        rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setBackgroundColor(Color.rgb(255, 249, 240));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(255, 249, 240));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setTextZoom(100);
        webView.addJavascriptInterface(new DoodlePopBridge(this), "DoodlePopAndroid");
        webView.setWebChromeClient(new WebChromeClient());
        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return assetLoader.shouldInterceptRequest(Uri.parse(url));
            }
        });
        rootLayout.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        bannerContainer = new FrameLayout(this);
        bannerContainer.setBackgroundColor(Color.rgb(255, 249, 240));
        rootLayout.addView(bannerContainer, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        setContentView(rootLayout);
        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html");
        initializeAds(bannerContainer);
    }

    private void initializeAds(FrameLayout bannerContainer) {
        RequestConfiguration configuration = new RequestConfiguration.Builder()
                .setTagForChildDirectedTreatment(RequestConfiguration.TAG_FOR_CHILD_DIRECTED_TREATMENT_TRUE)
                .setMaxAdContentRating(RequestConfiguration.MAX_AD_CONTENT_RATING_G)
                .build();
        MobileAds.setRequestConfiguration(configuration);
        new Thread(() -> MobileAds.initialize(this, initializationStatus ->
            runOnUiThread(() -> {
                adsInitialized = true;
                loadBanner(bannerContainer);
                loadInterstitial();
            })
        )).start();
    }

    private AdRequest childSafeAdRequest() {
        return new AdRequest.Builder().build();
    }

    private void loadBanner(FrameLayout container) {
        if (isFinishing() || isDestroyed()) return;
        if (bannerAd != null) {
            container.removeView(bannerAd);
            bannerAd.destroy();
        }
        bannerAd = new AdView(this);
        bannerAd.setAdUnitId(BuildConfig.ADMOB_BANNER_ID);
        bannerAd.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(
                this, (int) (getResources().getDisplayMetrics().widthPixels /
                getResources().getDisplayMetrics().density)));
        container.addView(bannerAd, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));
        bannerAd.loadAd(childSafeAdRequest());
    }

    private void loadInterstitial() {
        if (!adsInitialized || isFinishing() || isDestroyed()) return;
        InterstitialAd.load(this, BuildConfig.ADMOB_INTERSTITIAL_ID, childSafeAdRequest(),
                new InterstitialAdLoadCallback() {
                    @Override public void onAdLoaded(InterstitialAd ad) {
                        interstitialAd = ad;
                        interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                            @Override public void onAdDismissedFullScreenContent() {
                                interstitialAd = null;
                                // Full-screen ads can leave WebView/viewport measurements stale on some devices.
                                restoreAppLayoutAfterAd();
                                loadInterstitial();
                            }
                            @Override public void onAdFailedToShowFullScreenContent(AdError error) {
                                interstitialAd = null;
                                restoreAppLayoutAfterAd();
                                loadInterstitial();
                            }
                        });
                    }
                    @Override public void onAdFailedToLoad(LoadAdError error) {
                        interstitialAd = null;
                    }
                });
    }

    private void onDrawingSaved() {
        successfulSaves++;
        // Show only after repeated user-initiated saves, never on app launch.
        if (successfulSaves >= 5) {
            successfulSaves = 0;
            if (interstitialAd != null && !isFinishing() && !isDestroyed()) {
                InterstitialAd ad = interstitialAd;
                interstitialAd = null;
                ad.show(this);
            }
        }
    }

    private void openPrivacyPolicy() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://hidarnajem-ctrl.github.io/doodlepop-privacy-policy/"));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Could not open privacy policy", Toast.LENGTH_SHORT).show();
        }
    }


    /** Restore native and WebView dimensions after a full-screen interstitial closes. */
    private void restoreAppLayoutAfterAd() {
        if (isFinishing() || isDestroyed()) return;
        Runnable restore = () -> {
            if (isFinishing() || isDestroyed() || webView == null || rootLayout == null) return;
            rootLayout.requestLayout();
            rootLayout.invalidate();
            webView.setVisibility(View.VISIBLE);
            webView.requestLayout();
            webView.invalidate();
            if (bannerContainer != null) {
                bannerContainer.requestLayout();
                bannerContainer.invalidate();
            }
            // Trigger the web app's ResizeObserver/window resize handlers so the drawing canvas
            // recalculates its full available size rather than staying at the old viewport size.
            webView.evaluateJavascript(
                "window.dispatchEvent(new Event('resize'));" +
                "if (window.visualViewport) window.visualViewport.dispatchEvent(new Event('resize'));",
                null);
        };
        if (webView != null) {
            webView.post(restore);
            webView.postDelayed(restore, 350);
            webView.postDelayed(restore, 850);
        }
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) restoreAppLayoutAfterAd();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onPause() {
        if (webView != null) webView.onPause();
        if (bannerAd != null) bannerAd.pause();
        super.onPause();
    }
    @Override protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
        if (bannerAd != null) bannerAd.resume();
        restoreAppLayoutAfterAd();
    }
    @Override protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("DoodlePopAndroid");
            webView.destroy();
            webView = null;
        }
        if (bannerAd != null) { bannerAd.destroy(); bannerAd = null; }
        super.onDestroy();
    }

    private static class DoodlePopBridge {
        private final MainActivity activity;
        DoodlePopBridge(MainActivity activity) { this.activity = activity; }

        @JavascriptInterface public boolean saveImage(String dataUrl, String requestedFileName) {
            Uri imageUri = null;
            try {
                if (dataUrl == null || !dataUrl.startsWith("data:image/png;base64,")) {
                    showMessage("Could not save drawing"); return false;
                }
                byte[] imageBytes = Base64.decode(dataUrl.substring(dataUrl.indexOf(',') + 1), Base64.DEFAULT);
                if (imageBytes.length == 0) { showMessage("Drawing is empty"); return false; }
                String fileName = requestedFileName == null ? "DoodlePop-Masterpiece.png" : requestedFileName;
                fileName = fileName.replaceAll("[^A-Za-z0-9._-]", "_");
                if (!fileName.toLowerCase().endsWith(".png")) fileName += ".png";
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/DoodlePop");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
                imageUri = activity.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (imageUri == null) { showMessage("Could not create image file"); return false; }
                try (OutputStream output = activity.getContentResolver().openOutputStream(imageUri)) {
                    if (output == null) throw new IllegalStateException("Image output stream unavailable");
                    output.write(imageBytes); output.flush();
                }
                ContentValues completed = new ContentValues();
                completed.put(MediaStore.Images.Media.IS_PENDING, 0);
                activity.getContentResolver().update(imageUri, completed, null, null);
                activity.runOnUiThread(activity::onDrawingSaved);
                showMessage("Saved to Pictures/DoodlePop");
                return true;
            } catch (Exception error) {
                if (imageUri != null) {
                    try { activity.getContentResolver().delete(imageUri, null, null); } catch (Exception ignored) {}
                }
                showMessage("Unable to save drawing"); return false;
            }
        }
        @JavascriptInterface public void openPrivacyPolicy() {
            activity.runOnUiThread(activity::openPrivacyPolicy);
        }
        private void showMessage(final String message) {
            activity.runOnUiThread(() -> Toast.makeText(activity, message, Toast.LENGTH_SHORT).show());
        }
    }
}
