package com.example.domino.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domino.R
import com.example.domino.model.AD_COIN_REWARD
import com.example.domino.model.ProgressState
import com.example.domino.model.TARGET_SCORE

@Composable
fun HomeScreen(
    progress: ProgressState,
    adReady: Boolean,
    freeSpin: Boolean,
    onPlay: () -> Unit,
    onOnline: () -> Unit,
    onHelp: () -> Unit,
    onFreeCoins: () -> Unit,
    onWheel: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                LevelBar(progress.level, progress.xp, Modifier.weight(1f))
                CoinChip(progress.coins)
            }
            Spacer(Modifier.weight(1f))
            Image(painterResource(R.drawable.app_icon), null, Modifier.size(120.dp))
            Spacer(Modifier.height(6.dp))
            RibbonTitle("دومينو", Modifier.width(260.dp), fontSize = 28.sp)
            Text("العب ضد الكمبيوتر حتى $TARGET_SCORE نقطة", color = Palette.text, fontSize = 14.sp)
            Spacer(Modifier.height(18.dp))
            val btn = Modifier.widthIn(max = 340.dp)
            GoldButton("العب الآن", btn, icon = R.drawable.icon_play, onClick = onPlay)
            Spacer(Modifier.height(10.dp))
            GoldButton("العب مع صديق", btn, icon = R.drawable.result_draw, onClick = onOnline)
            Spacer(Modifier.height(10.dp))
            GoldButton(
                "+$AD_COIN_REWARD عملة مجاناً", btn, green = true, enabled = adReady,
                adBadge = true, onClick = onFreeCoins
            )
            Spacer(Modifier.height(10.dp))
            GoldButton("طريقة اللعب", btn, green = true, icon = R.drawable.icon_book, onClick = onHelp)
            Spacer(Modifier.weight(1.2f))
        }

        // أيقونة عجلة الحظ
        val t = rememberInfiniteTransition(label = "wobble")
        val rot by t.animateFloat(
            -8f, 8f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "rot"
        )
        Box(
            Modifier.align(Alignment.BottomStart).padding(start = 14.dp, bottom = 14.dp)
                .size(84.dp).clickable(onClick = onWheel)
        ) {
            Image(
                painterResource(R.drawable.wheel_mini), null,
                Modifier.fillMaxSize().graphicsLayer { rotationZ = rot }
            )
            if (freeSpin) {
                Box(
                    Modifier.align(Alignment.TopEnd).size(24.dp).clip(CircleShape).background(Color(0xFFE53935)),
                    contentAlignment = Alignment.Center
                ) { Text("!", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
            } else {
                Image(painterResource(R.drawable.badge_ad), null, Modifier.align(Alignment.TopEnd).size(26.dp))
            }
        }
    }
}
