package com.example.domino.online

/**
 * املأ هذه القيم من ملف google-services.json الخاص بمشروعك في Firebase.
 * ما دامت فارغة يبقى اللعب الأونلاين معطّلاً، وتعمل باقي اللعبة بشكل طبيعي.
 */
object FirebaseConfig {
    const val API_KEY = "AIzaSyCzbftdSWdYfLCpY17dI8-WRk3hwxAxZP4"        // client[0].api_key[0].current_key
    const val APP_ID = "1:1033703570289:android:effbc18a833d316571d4d0"         // client[0].client_info.mobilesdk_app_id
    const val PROJECT_ID = "domino-game-c0978"     // project_info.project_id
    const val DATABASE_URL = "https://domino-game-c0978-default-rtdb.europe-west1.firebasedatabase.app"   // project_info.firebase_url  (مثال: https://xxx-default-rtdb.firebaseio.com)

    val isConfigured: Boolean
        get() = API_KEY.isNotBlank() && APP_ID.isNotBlank() && DATABASE_URL.isNotBlank()
}
