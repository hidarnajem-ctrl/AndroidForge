package com.example.domino.ui

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domino.R
import com.example.domino.online.LobbyPhase
import com.example.domino.online.LobbyState

@Composable
fun OnlineScreen(
    lobby: LobbyState,
    configured: Boolean,
    onCreate: () -> Unit,
    onJoin: (String) -> Unit,
    onRandom: () -> Unit,
    onCancel: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var code by remember { mutableStateOf("") }
    BackHandler { onCancel(); onBack() }

    Box(Modifier.fillMaxSize()) {
        FullBackground(R.drawable.bg_home)
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(56.dp))
            RibbonTitle("العب مع صديق", Modifier.width(280.dp), fontSize = 24.sp)
            Spacer(Modifier.height(16.dp))

            Panel(Modifier.fillMaxWidth()) {
                when {
                    !configured -> {
                        Text(
                            "اللعب الأونلاين غير مفعّل بعد.\nيجب إضافة إعدادات Firebase إلى التطبيق أولاً.",
                            color = Palette.text, fontSize = 15.sp, textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    lobby.phase == LobbyPhase.CONNECTING || lobby.phase == LobbyPhase.IN_GAME -> {
                        Loading("جارٍ الاتصال...")
                    }

                    lobby.phase == LobbyPhase.WAITING -> {
                        Text("رمز الغرفة", color = Palette.text, fontSize = 15.sp,
                            modifier = Modifier.align(Alignment.CenterHorizontally))
                        Text(
                            lobby.code ?: "", color = Palette.gold, fontSize = 44.sp, fontWeight = FontWeight.Bold,
                            letterSpacing = 6.sp, modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                        Text(
                            "أرسل الرمز لصديقك ليدخله في «الانضمام بالرمز»",
                            color = Palette.text, fontSize = 13.sp, textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(12.dp))
                        Loading("بانتظار صديقك...")
                        Spacer(Modifier.height(12.dp))
                        GoldButton("مشاركة الرمز", green = true, icon = R.drawable.result_draw) {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, "تعال نلعب دومينو! رمز الغرفة: ${lobby.code}")
                            }
                            context.startActivity(Intent.createChooser(send, "مشاركة الرمز"))
                        }
                        Spacer(Modifier.height(10.dp))
                        GoldButton("إلغاء", onClick = onCancel)
                    }

                    lobby.phase == LobbyPhase.SEARCHING -> {
                        Loading("جارٍ البحث عن لاعب...")
                        Spacer(Modifier.height(16.dp))
                        GoldButton("إلغاء", onClick = onCancel)
                    }

                    else -> {
                        GoldButton("إنشاء غرفة", icon = R.drawable.icon_play, onClick = onCreate)
                        Spacer(Modifier.height(18.dp))
                        Text("الانضمام بالرمز", color = Palette.gold, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        OutlinedTextField(
                            value = code,
                            onValueChange = { v -> code = v.filter { it.isDigit() }.take(6) },
                            singleLine = true,
                            placeholder = { Text("000000", color = Color(0x88EDE3C8)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            textStyle = TextStyle(
                                color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center, letterSpacing = 6.sp
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Palette.gold, unfocusedBorderColor = Palette.trim,
                                cursorColor = Palette.gold
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        GoldButton("انضمام", green = true, enabled = code.length == 6) { onJoin(code) }
                        Spacer(Modifier.height(18.dp))
                        GoldButton("لاعب عشوائي", green = true, icon = R.drawable.avatar_ai, onClick = onRandom)
                    }
                }
                lobby.error?.let {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        it, color = Color(0xFFFF8A80), fontSize = 14.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
        Image(
            painterResource(R.drawable.btn_close), null,
            Modifier.align(Alignment.TopStart).statusBarsPadding().padding(14.dp).size(44.dp)
                .clickable { onCancel(); onBack() }
        )
    }
}

@Composable
private fun ColumnScope.Loading(text: String) {
    CircularProgressIndicator(color = Palette.gold, modifier = Modifier.align(Alignment.CenterHorizontally))
    Spacer(Modifier.height(8.dp))
    Text(text, color = Palette.text, fontSize = 14.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
}
