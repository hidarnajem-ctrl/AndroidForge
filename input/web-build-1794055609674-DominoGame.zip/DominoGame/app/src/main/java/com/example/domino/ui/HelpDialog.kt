package com.example.domino.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.domino.model.TARGET_SCORE

private val rules = listOf(
    "🎯 الهدف" to "تخلّص من كل أحجارك أولاً. تنتهي المباراة عندما يصل أحد اللاعبين إلى $TARGET_SCORE نقطة.",
    "▶️ اللعب" to "اختر حجراً مضيئاً يطابق أحد طرفي السلسلة. إن طابق الطرفين معاً اضغط علامة + في اللوحة لاختيار الجهة.",
    "📥 السحب" to "إن لم يكن لديك حجر مناسب اسحب من المكدس حتى تجد حجراً صالحاً. إذا فرغ المكدس يُمرَّر دورك.",
    "🔒 الإغلاق" to "إذا تعذّر اللعب على الطرفين تُغلق الجولة، ويفوز صاحب مجموع النقاط الأقل.",
    "🧮 النقاط" to "يربح الفائز نقاط أحجار خصمه المتبقية (وفي الإغلاق: الفرق بين المجموعين).",
    "🪙 المكافآت" to "تربح عملات وخبرة بعد كل جولة، وتستعملها لفتح تصاميم جديدة من «المجموعات».",
    "🎡 عجلة الحظ" to "دوران مجاني كل يوم (ودوران إضافي بإعلان) يمنحك عملات أو قدرات: تلميح، كشف أحجار الخصم، حظ (سحب حجر مناسب)، وإعادة توزيع الأحجار. تستعملها من الأزرار فوق يدك أثناء اللعب. القدرة التي ليس لديك رصيد منها تكون مقفلة 🔒، وتفتحها مرة واحدة بمشاهدة إعلان."
)

@Composable
fun HelpDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Panel(Modifier.fillMaxWidth()) {
            Text("📖 طريقة اللعب", color = Palette.gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Column(
                Modifier.heightIn(max = 400.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                rules.forEach { (title, body) ->
                    Column {
                        Text(title, color = Palette.gold, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text(body, color = Palette.text, fontSize = 14.sp, lineHeight = 22.sp)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            GoldButton("فهمت", onClick = onDismiss)
        }
    }
}
