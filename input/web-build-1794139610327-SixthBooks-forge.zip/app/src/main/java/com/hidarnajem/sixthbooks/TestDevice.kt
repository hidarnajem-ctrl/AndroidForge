package com.hidarnajem.sixthbooks

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.provider.Settings
import android.widget.Toast
import java.security.MessageDigest

/**
 * تسجيل هاتف المطوّر كهاتف اختبار في AdMob بدون معرّف الإعلانات (AD_ID).
 * التطبيق موجّه للأطفال فلا يقرأ معرّف الإعلانات، لذلك لا يعمل تسجيل الهاتف من لوحة AdMob.
 * بدلاً من ذلك نسجّل رمز الهاتف داخل الكود في Config.TEST_DEVICE_IDS.
 *
 * للحصول على رمز هاتفك: اضغط مطوّلاً على زر الكتاب الذهبي، فيُنسخ الرمز.
 */
object TestDevice {

    /** الرمز الذي يستخدمه AdMob لتمييز الهاتف: MD5 لمعرّف Android بحروف كبيرة */
    @SuppressLint("HardwareIds")
    fun id(context: Context): String {
        val androidId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: ""
        return MessageDigest.getInstance("MD5")
            .digest(androidId.toByteArray())
            .joinToString("") { "%02X".format(it) }
    }

    fun copyToClipboard(context: Context) {
        val id = id(context)
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("AdMob test device", id))
        val registered = id in Config.TEST_DEVICE_IDS || BuildConfig.DEBUG
        Toast.makeText(
            context,
            if (registered) "إعلانات تجريبية مفعّلة على هذا الهاتف ✓\n$id"
            else "تم نسخ رمز الهاتف:\n$id",
            Toast.LENGTH_LONG
        ).show()
    }
}
