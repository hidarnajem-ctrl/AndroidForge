// Android Studio may offer newer plugin versions when you open the project; accepting them is fine.
plugins {
    id("com.android.application") version "8.11.1" apply false
    id("org.jetbrains.kotlin.android") version "2.1.21" apply false
}
