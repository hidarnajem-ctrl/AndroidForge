package com.doodlepop.kidsdrawing;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.Locale;
import java.lang.ref.WeakReference;

/**
 * DoodlePop standalone Android host with AdMob integration.
 * Debug builds use Google's test ad IDs. Release builds use the app's AdMob IDs.
 */
public class MainActivity extends Activity {
    private static final String PRIVACY_URL =
            "https://hidarnajem-ctrl.github.io/doodlepop-privacy-policy/";
    private static final String TAG = "DoodlePopAds";

    private WebView webView;
    private AdView bannerAdView;
    private InterstitialAd interstitialAd;
    private int successfulSavesSinceInterstitial = 0;
    private boolean adShowing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureSystemBars();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(255, 249, 237));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(255, 249, 237));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setHapticFeedbackEnabled(true);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setSupportZoom(false);
        webView.getSettings().setBuiltInZoomControls(false);
        webView.getSettings().setDisplayZoomControls(false);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            webView.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            webView.getSettings().setSafeBrowsingEnabled(true);
        }

        webView.addJavascriptInterface(new NativeBridge(this), "DoodlePopNative");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                return host == null || !host.equals("doodlepop.local");
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return url == null || !url.startsWith("https://doodlepop.local/");
            }
        });

        root.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        FrameLayout adContainer = new FrameLayout(this);
        adContainer.setBackgroundColor(Color.rgb(255, 249, 237));
        root.addView(adContainer, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        setContentView(root);
        loadBundledApp();
        initializeAds(adContainer);
    }

    private void initializeAds(FrameLayout adContainer) {
        // DoodlePop is designed primarily for children: request child-directed treatment
        // and restrict ad content to the G rating. These settings do not replace Play Families compliance.
        RequestConfiguration configuration = new RequestConfiguration.Builder()
                .setTagForChildDirectedTreatment(
                        RequestConfiguration.TAG_FOR_CHILD_DIRECTED_TREATMENT_TRUE)
                .setMaxAdContentRating(RequestConfiguration.MAX_AD_CONTENT_RATING_G)
                .build();
        MobileAds.setRequestConfiguration(configuration);

        new Thread(() -> MobileAds.initialize(this, status -> runOnUiThread(() -> {
            loadBanner(adContainer);
            loadInterstitial();
        }))).start();
    }

    private void loadBanner(FrameLayout container) {
        if (isFinishing() || container == null) return;
        bannerAdView = new AdView(this);
        bannerAdView.setAdUnitId(BuildConfig.BANNER_AD_UNIT_ID);
        int widthDp = (int) (getResources().getDisplayMetrics().widthPixels
                / getResources().getDisplayMetrics().density);
        bannerAdView.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, widthDp));
        container.removeAllViews();
        container.addView(bannerAdView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));
        bannerAdView.loadAd(new AdRequest.Builder().build());
    }

    private void loadInterstitial() {
        if (isFinishing()) return;
        InterstitialAd.load(this, BuildConfig.INTERSTITIAL_AD_UNIT_ID,
                new AdRequest.Builder().build(),
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(InterstitialAd ad) {
                        interstitialAd = ad;
                        Log.d(TAG, "Interstitial ad loaded");
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError error) {
                        interstitialAd = null;
                        Log.w(TAG, "Interstitial ad failed: " + error.getMessage());
                    }
                });
    }

    private void onArtworkSavedSuccessfully() {
        runOnUiThread(() -> {
            successfulSavesSinceInterstitial++;
            // Interstitials are limited to an occasional pause after several successful saves,
            // never during drawing strokes or on app launch.
            if (successfulSavesSinceInterstitial >= 5 && interstitialAd != null
                    && !adShowing && !isFinishing()) {
                successfulSavesSinceInterstitial = 0;
                adShowing = true;
                InterstitialAd ad = interstitialAd;
                interstitialAd = null;
                ad.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        adShowing = false;
                        loadInterstitial();
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(
                            com.google.android.gms.ads.AdError error) {
                        adShowing = false;
                        loadInterstitial();
                    }
                });
                ad.show(MainActivity.this);
            }
        });
    }

    private void openPrivacyPolicy() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(PRIVACY_URL));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر فتح سياسة الخصوصية", Toast.LENGTH_SHORT).show();
        }
    }

    private void configureSystemBars() {
        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(true);
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(Color.rgb(255, 102, 130));
        window.setNavigationBarColor(Color.rgb(255, 249, 237));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }

    private void loadBundledApp() {
        try (InputStream input = getAssets().open("index.html");
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
            String html = output.toString("UTF-8");
            webView.loadDataWithBaseURL("https://doodlepop.local/", html, "text/html", "UTF-8", null);
        } catch (Exception error) {
            Toast.makeText(this, "تعذر تشغيل DoodlePop: " + error.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript(
                    "(function(){var m=document.getElementById('modal');if(m&&m.classList.contains('open')){m.classList.remove('open');return true;}return false;})()",
                    value -> {
                        if (!"true".equals(value)) finish();
                    });
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (bannerAdView != null) {
            bannerAdView.destroy();
            bannerAdView = null;
        }
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.removeJavascriptInterface("DoodlePopNative");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    public static class NativeBridge {
        private final Context context;
        private final WeakReference<MainActivity> activityRef;

        NativeBridge(MainActivity activity) {
            this.context = activity.getApplicationContext();
            this.activityRef = new WeakReference<>(activity);
        }

        @JavascriptInterface
        public void openPrivacyPolicy() {
            MainActivity activity = activityRef.get();
            if (activity != null && !activity.isFinishing()) {
                activity.runOnUiThread(activity::openPrivacyPolicy);
            }
        }

        /** Saves an image generated inside the offline drawing canvas to Pictures/DoodlePop. */
        @JavascriptInterface
        public void saveImage(String dataUrl, String requestedName) {
            try {
                if (dataUrl == null || !dataUrl.startsWith("data:image/png;base64,")) {
                    showToast("تعذر حفظ الصورة");
                    return;
                }
                String encoded = dataUrl.substring(dataUrl.indexOf(',') + 1);
                byte[] imageBytes = Base64.decode(encoded, Base64.DEFAULT);
                String safeName = sanitizeName(requestedName);
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, safeName);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DoodlePop");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);

                Uri collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                Uri imageUri = context.getContentResolver().insert(collection, values);
                if (imageUri == null) {
                    showToast("تعذر إنشاء ملف الصورة");
                    return;
                }
                try (OutputStream stream = context.getContentResolver().openOutputStream(imageUri, "w")) {
                    if (stream == null) throw new IllegalStateException("Output stream unavailable");
                    stream.write(imageBytes);
                    stream.flush();
                }
                ContentValues complete = new ContentValues();
                complete.put(MediaStore.Images.Media.IS_PENDING, 0);
                context.getContentResolver().update(imageUri, complete, null, null);
                showToast("تم حفظ الصورة في Pictures / DoodlePop");
                MainActivity activity = activityRef.get();
                if (activity != null) activity.onArtworkSavedSuccessfully();
            } catch (Exception error) {
                showToast("فشل حفظ الصورة. جرّب مرة أخرى.");
            }
        }

        private String sanitizeName(String name) {
            String base = name == null ? "DoodlePop-Artwork" : name.trim();
            base = base.replaceAll("[^\\p{L}\\p{N}._-]", "_");
            if (base.isEmpty()) base = "DoodlePop-Artwork";
            if (!base.toLowerCase(Locale.ROOT).endsWith(".png")) base += ".png";
            return base;
        }

        private void showToast(String message) {
            MainActivity activity = activityRef.get();
            if (activity != null && !activity.isFinishing()) {
                activity.runOnUiThread(() -> Toast.makeText(activity, message, Toast.LENGTH_SHORT).show());
            }
        }
    }
}
