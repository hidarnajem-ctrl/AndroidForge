package com.example.domino.data

import android.content.Context
import com.example.domino.model.ProgressState

class ProgressRepository(context: Context) {
    private val p = context.getSharedPreferences("domino_progress", Context.MODE_PRIVATE)

    fun load() = ProgressState(
        coins = p.getInt("coins", 100),
        xp = p.getInt("xp", 0),
        level = p.getInt("level", 1),
        name = p.getString("name", null) ?: "لاعب جديد",
        matches = p.getInt("matches", 0),
        matchWins = p.getInt("matchWins", 0),
        rounds = p.getInt("rounds", 0),
        roundWins = p.getInt("roundWins", 0),
        history = (p.getString("history", "") ?: "").map { it == '1' },
        helpSeen = p.getBoolean("helpSeen", false)
    )

    fun save(s: ProgressState) {
        p.edit()
            .putInt("coins", s.coins).putInt("xp", s.xp).putInt("level", s.level)
            .putString("name", s.name)
            .putInt("matches", s.matches).putInt("matchWins", s.matchWins)
            .putInt("rounds", s.rounds).putInt("roundWins", s.roundWins)
            .putString("history", s.history.joinToString("") { if (it) "1" else "0" })
            .putBoolean("helpSeen", s.helpSeen)
            .apply()
    }
}
