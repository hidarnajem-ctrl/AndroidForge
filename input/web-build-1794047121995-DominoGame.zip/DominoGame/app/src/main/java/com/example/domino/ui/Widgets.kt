package com.example.domino.ui

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domino.R
import com.example.domino.model.xpNeeded
import kotlin.math.roundToInt

object Palette {
    val gold = Color(0xFFFFD54F)
    val goldDark = Color(0xFF3B2000)
    val text = Color(0xFFEDE3C8)
    val panel = Color(0xFF14532D)
    val trim = Color(0xFFC9A24B)
}

// ───────── رسم صورة بتقسيم 9 أجزاء: الزوايا ثابتة والوسط يتمدد ─────────
internal fun DrawScope.drawNineSlice(img: ImageBitmap, srcX: Int, srcY: Int, dstX: Float, dstY: Float) {
    val w = img.width
    val h = img.height
    val xs = intArrayOf(0, srcX, w - srcX, w)
    val ys = intArrayOf(0, srcY, h - srcY, h)
    val dx = floatArrayOf(0f, dstX, size.width - dstX, size.width)
    val dy = floatArrayOf(0f, dstY, size.height - dstY, size.height)
    for (r in 0..2) for (c in 0..2) {
        val sw = xs[c + 1] - xs[c]
        val sh = ys[r + 1] - ys[r]
        val dw = (dx[c + 1] - dx[c]).roundToInt()
        val dh = (dy[r + 1] - dy[r]).roundToInt()
        if (sw <= 0 || sh <= 0 || dw <= 0 || dh <= 0) continue
        drawImage(
            img, IntOffset(xs[c], ys[r]), IntSize(sw, sh),
            IntOffset(dx[c].roundToInt(), dy[r].roundToInt()), IntSize(dw, dh),
            filterQuality = FilterQuality.Medium
        )
    }
}

/** صورة زر «حبة» تتمدد أفقياً دون تشويه الأطراف المستديرة. */
@Composable
fun PillImage(@DrawableRes res: Int, modifier: Modifier = Modifier) {
    val img = ImageBitmap.imageResource(res)
    Canvas(modifier) { drawNineSlice(img, img.height / 2, 0, size.height / 2, 0f) }
}

@Composable
fun FullBackground(@DrawableRes res: Int, modifier: Modifier = Modifier.fillMaxSize()) {
    Image(painterResource(res), null, modifier, contentScale = ContentScale.Crop)
}

@Composable
fun GoldButton(
    text: String,
    modifier: Modifier = Modifier,
    green: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Box(
        modifier
            .fillMaxWidth()
            .height(62.dp)
            .graphicsLayer { alpha = if (enabled) 1f else 0.5f }
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        PillImage(if (green) R.drawable.btn_green else R.drawable.btn_gold, Modifier.matchParentSize())
        Text(
            text,
            color = if (green) Color.White else Palette.goldDark,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun RibbonTitle(text: String, modifier: Modifier = Modifier, fontSize: TextUnit = 20.sp) {
    val p = painterResource(R.drawable.ribbon_gold)
    val ratio = p.intrinsicSize.let { if (it.isSpecified && it.height > 0f) it.width / it.height else 3f }
    Box(modifier.aspectRatio(ratio), contentAlignment = Alignment.Center) {
        Image(p, null, Modifier.matchParentSize(), contentScale = ContentScale.FillBounds)
        Text(
            text, color = Palette.goldDark, fontSize = fontSize, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )
    }
}

@Composable
fun CoinChip(coins: Int, modifier: Modifier = Modifier) {
    Row(
        modifier.clip(RoundedCornerShape(20.dp)).background(Color(0x99000000))
            .padding(start = 6.dp, end = 12.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(painterResource(R.drawable.icon_coin), null, Modifier.size(28.dp))
        Spacer(Modifier.width(6.dp))
        Text("$coins", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun LevelBar(level: Int, xp: Int, modifier: Modifier = Modifier) {
    val need = xpNeeded(level)
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(width = 78.dp, height = 40.dp), contentAlignment = Alignment.Center) {
            Image(painterResource(R.drawable.icon_star), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            Text("$level", color = Palette.goldDark, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(6.dp))
        Column(Modifier.weight(1f)) {
            Text("$xp / $need", color = Palette.text, fontSize = 12.sp)
            Spacer(Modifier.height(3.dp))
            Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(Color(0x66000000))) {
                Box(
                    Modifier.fillMaxWidth((xp.toFloat() / need).coerceIn(0f, 1f))
                        .fillMaxHeight().background(Palette.gold)
                )
            }
        }
    }
}

/** لوحة بإطار ذهبي مزخرف (صورة 9-slice). */
@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val img = ImageBitmap.imageResource(R.drawable.frame_popup)
    Column(
        modifier
            .drawBehind {
                val cs = (img.width * 0.2f).roundToInt()
                val cd = 50.dp.toPx()
                drawNineSlice(img, cs, cs, cd, cd)
            }
            .padding(horizontal = 26.dp, vertical = 28.dp),
        content = content
    )
}

@Composable
fun BottomNav(selected: Screen, onSelect: (Screen) -> Unit) {
    val items = listOf(
        Triple(Screen.COLLECTION, "🎨", "المجموعات"),
        Triple(Screen.HOME, "🏠", "الرئيسية"),
        Triple(Screen.PROFILE, "👤", "الملف الشخصي")
    )
    Box(Modifier.fillMaxWidth()) {
        Image(painterResource(R.drawable.bg_wood), null, Modifier.matchParentSize(), contentScale = ContentScale.Crop)
        Box(Modifier.matchParentSize().background(Color(0x66000000)))
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            items.forEach { (screen, icon, label) ->
                val on = screen == selected
                Column(
                    Modifier.weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (on) Color(0x44FFD54F) else Color.Transparent)
                        .clickable { onSelect(screen) }
                        .padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(icon, fontSize = 22.sp)
                    Text(
                        label, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        color = if (on) Palette.gold else Palette.text
                    )
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(2.dp).background(Palette.trim).align(Alignment.TopCenter))
    }
}
