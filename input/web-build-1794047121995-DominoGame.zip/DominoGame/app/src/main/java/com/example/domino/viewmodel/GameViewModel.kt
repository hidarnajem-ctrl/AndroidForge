package com.example.domino.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domino.model.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class GameState(
    val board: List<DominoTile> = emptyList(),
    val startTileId: Int = -1,              // الحجر الأول: مرساة التخطيط الثابتة
    val playerHand: List<DominoTile> = emptyList(),
    val aiHand: List<DominoTile> = emptyList(),
    val boneyard: List<DominoTile> = emptyList(),
    val turn: Turn = Turn.PLAYER,
    val status: Status = Status.PLAYING,
    val passes: Int = 0,
    val selectedTileId: Int? = null,
    val lastPlacedId: Int? = null,
    val playerScore: Int = 0,
    val aiScore: Int = 0,
    val message: String = "",
    val result: RoundResult? = null,
    val round: Int = 1,
    val matchWinner: Winner? = null
) {
    val playerMoves: List<Move> get() = GameEngine.possibleMoves(playerHand, board)
    val canPlayerDraw: Boolean
        get() = status == Status.PLAYING && turn == Turn.PLAYER &&
                playerMoves.isEmpty() && boneyard.isNotEmpty()
    val selectableSides: Set<Side>
        get() {
            val t = playerHand.find { it.id == selectedTileId } ?: return emptySet()
            return GameEngine.legalSides(t, board)
        }
}

class GameViewModel : ViewModel() {

    private val _state = MutableStateFlow(GameState())
    val state: StateFlow<GameState> = _state.asStateFlow()

    private val _sounds = MutableSharedFlow<GameSound>(extraBufferCapacity = 16)
    val sounds: SharedFlow<GameSound> = _sounds.asSharedFlow()
    private fun sfx(s: GameSound) { _sounds.tryEmit(s) }

    private val _events = MutableSharedFlow<RoundEvent>(extraBufferCapacity = 4)
    val roundEvents: SharedFlow<RoundEvent> = _events.asSharedFlow()

    private var aiJob: Job? = null

    init { startRound(resetScores = true) }

    // ───────────── بدء جولة ─────────────
    private fun startRound(resetScores: Boolean) {
        aiJob?.cancel()
        val deck = GameEngine.fullSet().shuffled()
        val p = deck.take(7)
        val a = deck.drop(7).take(7)
        val yard = deck.drop(14)

        val all = p.map { it to true } + a.map { it to false }
        val (first, byPlayer) = all.maxBy { (t, _) -> if (t.isDouble) 100 + t.left else t.pips }

        val old = _state.value
        _state.value = GameState(
            board = listOf(first),
            startTileId = first.id,
            playerHand = if (byPlayer) p - first else p,
            aiHand = if (!byPlayer) a - first else a,
            boneyard = yard,
            turn = if (byPlayer) Turn.AI else Turn.PLAYER,
            lastPlacedId = first.id,
            playerScore = if (resetScores) 0 else old.playerScore,
            aiScore = if (resetScores) 0 else old.aiScore,
            round = if (resetScores) 1 else old.round + 1
        )
        sfx(GameSound.PLACE)
        afterTurnChange()
    }

    /** مباراة جديدة من الصفر (النقاط 0 والجولة 1). */
    fun startNewMatch() = startRound(resetScores = true)

    /** الجولة التالية، أو مباراة جديدة إن كانت المباراة قد انتهت. */
    fun nextRound() = startRound(resetScores = _state.value.matchWinner != null)

    // ───────────── أحداث اللاعب ─────────────
    fun onTileClicked(tile: DominoTile) {
        val s = _state.value
        if (s.status != Status.PLAYING || s.turn != Turn.PLAYER) return
        val sides = GameEngine.legalSides(tile, s.board)
        when {
            sides.isEmpty() -> {
                sfx(GameSound.INVALID)
                _state.value = s.copy(selectedTileId = null, message = "هذا الحجر لا يطابق أي طرف")
            }
            sides.size == 1 -> playMove(Turn.PLAYER, tile, sides.first())
            else -> {
                sfx(GameSound.SELECT)
                _state.value = s.copy(
                    selectedTileId = if (s.selectedTileId == tile.id) null else tile.id,
                    message = "اختر الطرف: اضغط على علامة + في اللوحة"
                )
            }
        }
    }

    fun onSideSelected(side: Side) {
        val s = _state.value
        val tile = s.playerHand.find { it.id == s.selectedTileId } ?: return
        if (side in GameEngine.legalSides(tile, s.board)) playMove(Turn.PLAYER, tile, side)
    }

    fun onDrawClicked() {
        val s = _state.value
        if (!s.canPlayerDraw) return
        sfx(GameSound.DRAW)
        _state.value = s.copy(
            playerHand = s.playerHand + s.boneyard.first(),
            boneyard = s.boneyard.drop(1),
            selectedTileId = null
        )
        afterTurnChange()
    }

    // ───────────── منطق الحركة ─────────────
    private fun other(t: Turn) = if (t == Turn.PLAYER) Turn.AI else Turn.PLAYER

    private fun playMove(who: Turn, tile: DominoTile, side: Side) {
        val s = _state.value
        val base = if (who == Turn.PLAYER) s.copy(playerHand = s.playerHand - tile)
        else s.copy(aiHand = s.aiHand - tile)
        val n = base.copy(
            board = GameEngine.place(s.board, tile, side),
            passes = 0, selectedTileId = null, lastPlacedId = tile.id
        )
        sfx(GameSound.PLACE)
        if (n.playerHand.isEmpty() || n.aiHand.isEmpty()) {
            finishRound(n)
            return
        }
        _state.value = n.copy(turn = other(who))
        afterTurnChange()
    }

    private fun pass(who: Turn) {
        val s = _state.value
        val passes = s.passes + 1
        sfx(GameSound.INVALID)
        if (passes >= 2) { finishRound(s.copy(passes = passes)); return }
        _state.value = s.copy(passes = passes, turn = other(who))
        afterTurnChange()
    }

    private fun finishRound(s: GameState) {
        val pp = GameEngine.pips(s.playerHand)
        val ap = GameEngine.pips(s.aiHand)
        val result = when {
            s.playerHand.isEmpty() -> RoundResult(Winner.PLAYER, ap, false)
            s.aiHand.isEmpty() -> RoundResult(Winner.AI, pp, false)
            pp < ap -> RoundResult(Winner.PLAYER, ap - pp, true)
            ap < pp -> RoundResult(Winner.AI, pp - ap, true)
            else -> RoundResult(Winner.DRAW, 0, true)
        }
        viewModelScope.launch {
            delay(450)
            sfx(when (result.winner) {
                Winner.PLAYER -> GameSound.WIN
                Winner.AI -> GameSound.LOSE
                Winner.DRAW -> GameSound.SELECT
            })
        }
        val ps = s.playerScore + if (result.winner == Winner.PLAYER) result.points else 0
        val aiS = s.aiScore + if (result.winner == Winner.AI) result.points else 0
        val matchWinner = if ((ps >= TARGET_SCORE || aiS >= TARGET_SCORE) && ps != aiS)
            (if (ps > aiS) Winner.PLAYER else Winner.AI) else null
        _state.value = s.copy(
            status = Status.ROUND_OVER,
            result = result,
            playerScore = ps,
            aiScore = aiS,
            matchWinner = matchWinner,
            selectedTileId = null
        )
        _events.tryEmit(RoundEvent(result.winner, result.points, matchWinner))
    }

    private fun setMessage(m: String) = _state.update { it.copy(message = m) }

    private fun afterTurnChange() {
        val s = _state.value
        if (s.status != Status.PLAYING) return
        when (s.turn) {
            Turn.AI -> { setMessage("الكمبيوتر يفكّر..."); runAi() }
            Turn.PLAYER -> when {
                s.playerMoves.isNotEmpty() -> setMessage("دورك — اختر حجراً مضيئاً")
                s.boneyard.isNotEmpty() -> setMessage("لا تملك حجراً مناسباً — اسحب من المكدس")
                else -> viewModelScope.launch {
                    setMessage("لا حجارة مناسبة والمكدس فارغ — سيُمرَّر دورك")
                    delay(1400)
                    val c = _state.value
                    if (c.status == Status.PLAYING && c.turn == Turn.PLAYER &&
                        c.playerMoves.isEmpty() && c.boneyard.isEmpty()
                    ) pass(Turn.PLAYER)
                }
            }
        }
    }

    // ───────────── الذكاء الاصطناعي ─────────────
    private fun runAi() {
        aiJob?.cancel()
        aiJob = viewModelScope.launch {
            delay(900)
            while (true) {
                val s = _state.value
                if (s.status != Status.PLAYING || s.turn != Turn.AI) return@launch
                val move = GameEngine.chooseAiMove(s.aiHand, s.board)
                when {
                    move != null -> { playMove(Turn.AI, move.tile, move.side); return@launch }
                    s.boneyard.isNotEmpty() -> {
                        sfx(GameSound.DRAW)
                        _state.value = s.copy(
                            aiHand = s.aiHand + s.boneyard.first(),
                            boneyard = s.boneyard.drop(1),
                            message = "الكمبيوتر يسحب من المكدس..."
                        )
                        delay(650)
                    }
                    else -> { pass(Turn.AI); return@launch }
                }
            }
        }
    }
}
