package com.example.domino.model

const val TARGET_SCORE = 100      // المباراة تنتهي عند الوصول لهذه النقاط
const val AD_COIN_REWARD = 50     // عملات الإعلان المجاني

/** الخبرة المطلوبة للانتقال من المستوى الحالي: 100 ثم 150 ثم 200... */
fun xpNeeded(level: Int) = 50 + 50 * level

data class RoundEvent(val winner: Winner, val points: Int, val matchWinner: Winner?)

data class Reward(val coins: Int, val xp: Int, val levelUp: Int?, val doubled: Boolean = false)

data class ProgressState(
    val coins: Int = 100,
    val xp: Int = 0,
    val level: Int = 1,
    val name: String = "لاعب جديد",
    val matches: Int = 0,
    val matchWins: Int = 0,
    val rounds: Int = 0,
    val roundWins: Int = 0,
    val history: List<Boolean> = emptyList(),   // نتائج آخر المباريات (الأقدم أولاً)
    val helpSeen: Boolean = false,
    val reward: Reward? = null
)
