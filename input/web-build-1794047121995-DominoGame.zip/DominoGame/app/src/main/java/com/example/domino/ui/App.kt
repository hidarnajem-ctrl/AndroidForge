package com.example.domino.ui

import android.widget.Toast
import com.example.domino.R
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.domino.ads.RewardedAdManager
import com.example.domino.ads.findActivity
import com.example.domino.model.AD_COIN_REWARD
import com.example.domino.model.GameSound
import com.example.domino.sound.SoundManager
import com.example.domino.viewmodel.GameViewModel
import com.example.domino.viewmodel.ProgressViewModel
import com.example.domino.viewmodel.SkinViewModel

enum class Screen { HOME, COLLECTION, PROFILE, GAME }

@Composable
fun App() {
    val context = LocalContext.current
    val gameVm: GameViewModel = viewModel()
    val skinVm: SkinViewModel = viewModel()
    val progressVm: ProgressViewModel = viewModel()
    val skins by skinVm.state.collectAsState()
    val progress by progressVm.state.collectAsState()

    val sound = remember { SoundManager(context) }
    val ads = remember { RewardedAdManager(context.applicationContext) }
    val activity = remember(context) { context.findActivity() }

    var screen by remember { mutableStateOf(Screen.HOME) }
    var muted by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }

    DisposableEffect(Unit) { onDispose { sound.release() } }
    LaunchedEffect(muted) { sound.enabled = !muted }
    LaunchedEffect(gameVm) { gameVm.sounds.collect { sound.play(it) } }
    LaunchedEffect(gameVm) { gameVm.roundEvents.collect { progressVm.onRoundFinished(it) } }
    LaunchedEffect(progress.helpSeen) { if (!progress.helpSeen) showHelp = true }

    fun watchAd(onReward: () -> Unit) {
        activity?.let { act ->
            ads.show(
                act, onReward,
                onFail = { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() }
            )
        }
    }

    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl,
        LocalTileSkin provides TileSkins.byId(skins.selectedId)
    ) {
        Box(
            Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF14532D), Color(0xFF052E16))))
        ) {
            if (screen != Screen.GAME) FullBackground(R.drawable.bg_home)
            if (screen == Screen.GAME) {
                GameScreen(
                    vm = gameVm,
                    progressVm = progressVm,
                    adReady = ads.isReady,
                    muted = muted,
                    onToggleMute = { muted = !muted },
                    onWatchAdForDouble = { watchAd { progressVm.doubleReward(); sound.play(GameSound.WIN) } },
                    onExit = { screen = Screen.HOME }
                )
            } else {
                Column(Modifier.fillMaxSize()) {
                    Box(Modifier.weight(1f).statusBarsPadding()) {
                        when (screen) {
                            Screen.HOME -> HomeScreen(
                                progress = progress,
                                adReady = ads.isReady,
                                onPlay = { gameVm.startNewMatch(); screen = Screen.GAME },
                                onHelp = { showHelp = true },
                                onFreeCoins = {
                                    watchAd {
                                        progressVm.addCoins(AD_COIN_REWARD)
                                        sound.play(GameSound.WIN)
                                        Toast.makeText(context, "🪙 +$AD_COIN_REWARD عملة", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )
                            Screen.COLLECTION -> CollectionScreen(
                                skins = skins,
                                coins = progress.coins,
                                adReady = ads.isReady,
                                onSelect = { skinVm.select(it.id); sound.play(GameSound.SELECT) },
                                onBuy = {
                                    if (progressVm.spend(it.price)) { skinVm.unlock(it.id); sound.play(GameSound.WIN) }
                                },
                                onWatchAd = { sk -> watchAd { skinVm.unlock(sk.id); sound.play(GameSound.WIN) } }
                            )
                            Screen.PROFILE -> ProfileScreen(progress, onRename = progressVm::setName)
                            Screen.GAME -> {}
                        }
                    }
                    BottomNav(screen) { screen = it }
                }
            }
            if (showHelp) HelpDialog { showHelp = false; progressVm.markHelpSeen() }
        }
    }
}
