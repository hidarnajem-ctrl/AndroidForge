package com.example.domino.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domino.R
import com.example.domino.model.AD_COIN_REWARD
import com.example.domino.model.ProgressState
import com.example.domino.model.TARGET_SCORE

@Composable
fun HomeScreen(
    progress: ProgressState,
    adReady: Boolean,
    onPlay: () -> Unit,
    onHelp: () -> Unit,
    onFreeCoins: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            LevelBar(progress.level, progress.xp, Modifier.weight(1f))
            CoinChip(progress.coins)
        }
        Spacer(Modifier.weight(1f))
        Image(painterResource(R.drawable.app_icon), null, Modifier.size(150.dp))
        Spacer(Modifier.height(6.dp))
        RibbonTitle("دومينو", Modifier.width(260.dp), fontSize = 28.sp)
        Text("العب ضد الكمبيوتر حتى $TARGET_SCORE نقطة", color = Palette.text, fontSize = 14.sp)
        Spacer(Modifier.height(26.dp))
        val btn = Modifier.widthIn(max = 340.dp)
        GoldButton("▶  العب الآن", btn, onClick = onPlay)
        Spacer(Modifier.height(10.dp))
        GoldButton("🎬  +$AD_COIN_REWARD عملة مجاناً", btn, green = true, enabled = adReady, onClick = onFreeCoins)
        Spacer(Modifier.height(10.dp))
        GoldButton("📖  طريقة اللعب", btn, green = true, onClick = onHelp)
        Spacer(Modifier.weight(1.2f))
    }
}
