package com.baghdadroad.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var map: MapView
    private lateinit var statusText: TextView
    private lateinit var searchInput: EditText
    private lateinit var searchButton: Button
    private lateinit var routeButton: Button
    private var destination: GeoPoint? = null
    private var destinationName: String = ""
    private var currentPoint: GeoPoint? = null

    private val prefs by lazy { getSharedPreferences("baghdad_road", Context.MODE_PRIVATE) }

    private val locationPermission = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.any { it }) showCurrentLocation()
        else showStatus("لم يتم منح إذن الموقع. يمكنك البحث واستخدام الخريطة دون تحديد موقعك.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().load(
            applicationContext,
            android.preference.PreferenceManager.getDefaultSharedPreferences(applicationContext)
        )
        Configuration.getInstance().userAgentValue = packageName

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF4F7F6.toInt())
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(0xFF176B5B.toInt())
        }
        header.addView(TextView(this).apply {
            text = "Baghdad Road"
            textSize = 24f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        })
        header.addView(TextView(this).apply {
            text = "دليلك لاستكشاف شوارع بغداد"
            textSize = 14f
            setTextColor(0xFFE5F2EF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(3), 0, 0)
        })
        root.addView(header)

        val controlsScroll = ScrollView(this)
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(6))
        }
        searchInput = EditText(this).apply {
            hint = "ابحث عن شارع أو مكان في بغداد"
            textSize = 15f
            singleLine = true
            setPadding(dp(12), dp(8), dp(12), dp(8))
            imeOptions = EditorInfo.IME_ACTION_SEARCH
        }
        controls.addView(searchInput, matchWrap())
        val searchRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        searchButton = Button(this).apply {
            text = "🔎 بحث"
            isAllCaps = false
            setOnClickListener { searchPlace() }
        }
        routeButton = Button(this).apply {
            text = "🧭 الاتجاهات"
            isAllCaps = false
            isEnabled = false
            setOnClickListener { openDirections() }
        }
        searchRow.addView(searchButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        searchRow.addView(routeButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        controls.addView(searchRow)

        val categoryLabel = TextView(this).apply {
            text = "أماكن قريبة وخدمات"
            textSize = 14f
            setTextColor(0xFF254B43.toInt())
            setPadding(dp(3), dp(4), dp(3), 0)
        }
        controls.addView(categoryLabel)
        val categoryScroll = HorizontalScrollView(this)
        val categories = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        addCategory(categories, "🏥 مستشفيات", "hospital")
        addCategory(categories, "💊 صيدليات", "pharmacy")
        addCategory(categories, "🍽️ مطاعم", "restaurant")
        addCategory(categories, "⛽ وقود", "fuel")
        addCategory(categories, "🛍️ أسواق", "supermarket")
        categoryScroll.addView(categories)
        controls.addView(categoryScroll)

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val locateButton = Button(this).apply {
            text = "📍 موقعي"
            isAllCaps = false
            setOnClickListener { requestLocation() }
        }
        val favoriteButton = Button(this).apply {
            text = "⭐ المكان المحفوظ"
            isAllCaps = false
            setOnClickListener { openFavorite() }
        }
        val saveButton = Button(this).apply {
            text = "حفظ ⭐"
            isAllCaps = false
            setOnClickListener { saveFavorite() }
        }
        actionRow.addView(locateButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        actionRow.addView(favoriteButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        actionRow.addView(saveButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        controls.addView(actionRow)

        statusText = TextView(this).apply {
            text = "الخريطة متمركزة على بغداد. ابحث عن مكان أو اختر إحدى الخدمات. يلزم الإنترنت لتحميل الخريطة والبحث."
            textSize = 12.5f
            setTextColor(0xFF374741.toInt())
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        controls.addView(statusText)
        controlsScroll.addView(controls)
        root.addView(controlsScroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        map = MapView(this).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(12.0)
            controller.setCenter(GeoPoint(33.3152, 44.3661))
            setUseDataConnection(true)
            contentDescription = "خريطة بغداد"
        }
        root.addView(map, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { searchPlace(); true } else false
        }
    }

    private fun addCategory(parent: LinearLayout, label: String, query: String) {
        parent.addView(Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { openMapsSearch(query) }
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(46)).apply {
            marginEnd = dp(4)
        })
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun searchPlace() {
        val query = searchInput.text.toString().trim()
        if (query.isBlank()) {
            searchInput.error = "اكتب اسم المكان أو الشارع أولاً"
            return
        }
        hideKeyboard()
        setBusy(true)
        showStatus("جارٍ البحث عن «$query» في بغداد…")
        thread {
            try {
                val encoded = URLEncoder.encode("$query, Baghdad, Iraq", "UTF-8")
                val url = URL("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q=$encoded")
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 12000
                    readTimeout = 12000
                    setRequestProperty("User-Agent", "BaghdadRoadAndroid/1.1 (map search)")
                }
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                connection.disconnect()
                val array = JSONArray(response)
                if (array.length() == 0) {
                    runOnUiThread {
                        setBusy(false)
                        showStatus("لم نعثر على نتيجة. جرّب اسمًا أوضح، أو استخدم البحث في خرائط Google.")
                        Toast.makeText(this, "لم يتم العثور على المكان", Toast.LENGTH_LONG).show()
                    }
                    return@thread
                }
                val item = array.getJSONObject(0)
                val lat = item.getDouble("lat")
                val lon = item.getDouble("lon")
                val name = item.optString("display_name", query)
                runOnUiThread {
                    setBusy(false)
                    destination = GeoPoint(lat, lon)
                    destinationName = query
                    routeButton.isEnabled = true
                    val point = destination!!
                    map.controller.animateTo(point)
                    map.controller.setZoom(16.0)
                    map.overlays.removeAll { it is Marker && it.title == "نتيجة البحث" }
                    map.overlays.add(Marker(map).apply {
                        position = point
                        title = "نتيجة البحث"
                        snippet = name
                        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                    })
                    map.invalidate()
                    showStatus("تم العثور على: $name")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setBusy(false)
                    showStatus("تعذر البحث. تحقق من الإنترنت ثم حاول مجددًا، أو استخدم أزرار الخدمات.")
                }
            }
        }
    }

    private fun setBusy(busy: Boolean) {
        searchButton.isEnabled = !busy
        searchInput.isEnabled = !busy
        if (!busy) searchButton.text = "🔎 بحث" else searchButton.text = "جارٍ البحث…"
    }

    private fun openMapsSearch(category: String) {
        val center = currentPoint
        val query = if (center != null) "$category near ${center.latitude},${center.longitude}" else "$category in Baghdad, Iraq"
        val uri = Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(query))
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        catch (_: Exception) { showStatus("تعذر فتح الخرائط على هذا الجهاز.") }
    }

    private fun openDirections() {
        val target = destination
        if (target == null) {
            showStatus("ابحث عن وجهتك أولاً ثم اضغط الاتجاهات.")
            return
        }
        val origin = currentPoint
        val uri = if (origin != null) {
            Uri.parse("https://www.google.com/maps/dir/?api=1&origin=${origin.latitude},${origin.longitude}&destination=${target.latitude},${target.longitude}&travelmode=driving")
        } else {
            Uri.parse("https://www.google.com/maps/dir/?api=1&destination=${target.latitude},${target.longitude}&travelmode=driving")
        }
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        catch (_: Exception) { showStatus("تعذر فتح الاتجاهات.") }
    }

    private fun saveFavorite() {
        val target = destination
        if (target == null) {
            showStatus("ابحث عن مكان أولاً حتى تتمكن من حفظه.")
            return
        }
        prefs.edit()
            .putString("favorite_name", destinationName)
            .putString("favorite_lat", target.latitude.toString())
            .putString("favorite_lon", target.longitude.toString())
            .apply()
        Toast.makeText(this, "تم حفظ $destinationName في المفضلة", Toast.LENGTH_LONG).show()
    }

    private fun openFavorite() {
        val name = prefs.getString("favorite_name", null)
        val lat = prefs.getString("favorite_lat", null)?.toDoubleOrNull()
        val lon = prefs.getString("favorite_lon", null)?.toDoubleOrNull()
        if (name == null || lat == null || lon == null) {
            showStatus("لا يوجد مكان محفوظ بعد. ابحث عن مكان ثم اضغط حفظ.")
            return
        }
        destinationName = name
        destination = GeoPoint(lat, lon)
        routeButton.isEnabled = true
        map.controller.animateTo(destination)
        map.controller.setZoom(16.0)
        map.overlays.removeAll { it is Marker && it.title == "المكان المحفوظ" }
        map.overlays.add(Marker(map).apply {
            position = destination
            title = "المكان المحفوظ"
            snippet = name
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        })
        map.invalidate()
        showStatus("تم فتح المكان المحفوظ: $name")
    }

    private fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun requestLocation() {
        if (hasLocationPermission()) showCurrentLocation()
        else locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    @Suppress("MissingPermission")
    private fun showCurrentLocation() {
        val manager = getSystemService(LOCATION_SERVICE) as LocationManager
        val providers = try { manager.getProviders(true) } catch (_: Exception) { emptyList() }
        var bestLocation: Location? = null
        for (provider in providers) {
            val location = try { manager.getLastKnownLocation(provider) } catch (_: Exception) { null }
            if (location != null && (bestLocation == null || location.accuracy < bestLocation!!.accuracy)) bestLocation = location
        }
        val location = bestLocation
        if (location == null) {
            showStatus("لم يُعثر على موقع حديث. فعّل الموقع (GPS) وانتقل إلى مكان مفتوح ثم حاول مجددًا.")
            Toast.makeText(this, "تعذر تحديد الموقع الحالي", Toast.LENGTH_LONG).show()
            return
        }
        val point = GeoPoint(location.latitude, location.longitude)
        currentPoint = point
        map.controller.animateTo(point)
        map.controller.setZoom(16.0)
        map.overlays.removeAll { it is Marker && it.title == "موقعي الحالي" }
        map.overlays.add(Marker(map).apply {
            position = point
            title = "موقعي الحالي"
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        })
        map.invalidate()
        showStatus("تم تحديد موقعك. اختر خدمة قريبة أو ابحث عن وجهتك.")
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
    }

    private fun showStatus(message: String) { if (::statusText.isInitialized) statusText.text = message }

    override fun onResume() { super.onResume(); if (::map.isInitialized) map.onResume() }
    override fun onPause() { if (::map.isInitialized) map.onPause(); super.onPause() }
    override fun onDestroy() { if (::map.isInitialized) map.onDetach(); super.onDestroy() }
}
