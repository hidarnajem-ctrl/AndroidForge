# Privacy Policy — Pixora
Last updated: [DATE]

**Photos.** Pixora compresses photos entirely on your device. Your photos are never uploaded to our servers or shared with anyone, except when you choose to share a result yourself.

**Storage.** Compressed photos are saved to Pictures/Pixora on your device. A short list of recent file names and sizes and your theme/language choices are stored locally in the app and can be cleared at any time.

**Advertising.** Pixora shows ads using Google AdMob. AdMob may collect and use device identifiers (such as the Advertising ID), IP address and ad-interaction data to serve and measure ads, and may personalise ads where you consent. Where required (for example in the EEA/UK) we ask for your consent and you can change it any time via "Ad privacy settings" in the app. See Google's policy: https://policies.google.com/technologies/ads

**Children.** Pixora is not directed to children under 13.

**Contact.** [YOUR EMAIL]

---
# سياسة الخصوصية — Pixora
تتم معالجة الصور بالكامل على جهازك ولا تُرفع إلى أي خادم. تُحفظ الصور المضغوطة في Pictures/Pixora. يعرض التطبيق إعلانات Google AdMob التي قد تستخدم معرّف الإعلانات وعنوان IP وبيانات التفاعل مع الإعلانات، ونطلب موافقتك حيث يلزم ويمكنك تغييرها من "إعدادات خصوصية الإعلانات". التطبيق غير موجّه للأطفال دون 13 عاماً. للتواصل: [بريدك].
