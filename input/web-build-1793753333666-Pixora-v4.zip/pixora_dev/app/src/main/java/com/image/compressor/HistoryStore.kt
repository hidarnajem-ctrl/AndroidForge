package com.image.compressor

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HistoryRecord(val name: String, val format: String, val original: Long, val compressed: Long)

object HistoryStore {
    private const val LIMIT = 20

    fun load(ctx: Context): List<HistoryRecord> = try {
        val arr = JSONArray(ctx.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE).getString(Prefs.HISTORY, "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            HistoryRecord(o.optString("name"), o.optString("format"), o.optLong("original"), o.optLong("compressed"))
        }
    } catch (_: Exception) { emptyList() }

    fun save(ctx: Context, list: List<HistoryRecord>) {
        val arr = JSONArray()
        list.take(LIMIT).forEach {
            arr.put(JSONObject().put("name", it.name).put("format", it.format).put("original", it.original).put("compressed", it.compressed))
        }
        ctx.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE).edit().putString(Prefs.HISTORY, arr.toString()).apply()
    }
}
