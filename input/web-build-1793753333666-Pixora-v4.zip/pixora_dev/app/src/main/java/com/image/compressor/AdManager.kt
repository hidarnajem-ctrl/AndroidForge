package com.image.compressor

import android.app.Activity
import android.os.SystemClock
import android.widget.FrameLayout
import androidx.core.view.isGone
import androidx.core.view.isVisible
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import java.util.concurrent.atomic.AtomicBoolean

/**
 * AdMob wrapper that follows Google's rules:
 *  - asks for consent (UMP / GDPR) before any ad request,
 *  - initialises the SDK off the main thread,
 *  - one adaptive banner + a rate-limited interstitial shown only AFTER a finished task.
 */
class AdManager(private val activity: Activity, private val container: FrameLayout) {

    private val consent = UserMessagingPlatform.getConsentInformation(activity)
    private val started = AtomicBoolean(false)
    private var banner: AdView? = null
    private var interstitial: InterstitialAd? = null

    fun start(onPrivacyOptionsRequired: (Boolean) -> Unit) {
        consent.requestConsentInfoUpdate(
            activity,
            ConsentRequestParameters.Builder().build(),
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) {
                    onPrivacyOptionsRequired(
                        consent.privacyOptionsRequirementStatus == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
                    )
                    initIfAllowed()
                }
            },
            { initIfAllowed() }
        )
        initIfAllowed() // consent may already have been gathered in a previous session
    }

    fun showPrivacyOptions() {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { }
    }

    private fun initIfAllowed() {
        if (!consent.canRequestAds() || started.getAndSet(true)) return
        Thread {
            MobileAds.initialize(activity) {
                activity.runOnUiThread {
                    if (!activity.isDestroyed) {
                        loadBanner()
                        loadInterstitial()
                    }
                }
            }
        }.start()
    }

    private fun loadBanner() {
        val dm = activity.resources.displayMetrics
        val widthDp = (dm.widthPixels / dm.density).toInt()
        val view = AdView(activity).apply {
            adUnitId = BuildConfig.ADMOB_BANNER_ID
            setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, widthDp))
            adListener = object : AdListener() {
                override fun onAdLoaded() { container.isVisible = true }
                override fun onAdFailedToLoad(error: LoadAdError) { container.isGone = true }
            }
        }
        banner = view
        container.addView(view)
        view.loadAd(AdRequest.Builder().build())
    }

    private fun loadInterstitial() {
        InterstitialAd.load(
            activity, BuildConfig.ADMOB_INTERSTITIAL_ID, AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitial = ad
                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() { interstitial = null; loadInterstitial() }
                        override fun onAdFailedToShowFullScreenContent(error: AdError) { interstitial = null; loadInterstitial() }
                    }
                }
                override fun onAdFailedToLoad(error: LoadAdError) { interstitial = null }
            }
        )
    }

    /** Call after a successful compression. Shows at most one interstitial every 3rd task and every 2 minutes. */
    fun onTaskCompleted() {
        completedTasks++
        val now = SystemClock.elapsedRealtime()
        val ad = interstitial ?: return
        if (completedTasks % 3 == 0 && now - lastShown > 120_000L && !activity.isFinishing) {
            lastShown = now
            ad.show(activity)
        }
    }

    fun pause() { banner?.pause() }
    fun resume() { banner?.resume() }
    fun destroy() { banner?.destroy(); banner = null; interstitial = null }

    private companion object {
        var completedTasks = 0
        var lastShown = 0L
    }
}
