package com.image.compressor

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** All heavy image work. Never call from the main thread. */
object ImageProcessor {
    const val MAX_SIDE = 12000
    private const val MAX_PIXELS = 24_000_000L

    class Format(val label: String, val ext: String, val mime: String, val codec: Bitmap.CompressFormat, val lossless: Boolean)

    @Suppress("DEPRECATION")
    fun format(index: Int): Format = when (index) {
        1 -> Format("PNG", "png", "image/png", Bitmap.CompressFormat.PNG, true)
        2 -> Format(
            "WebP", "webp", "image/webp",
            if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP,
            false
        )
        else -> Format("JPG", "jpg", "image/jpeg", Bitmap.CompressFormat.JPEG, false)
    }

    data class Info(val width: Int, val height: Int, val bytes: Long)
    data class Output(val uri: Uri, val name: String, val bytes: Long, val originalBytes: Long, val format: String, val mime: String)

    fun fileSize(ctx: Context, uri: Uri): Long = try {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
            if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else 0L
        } ?: 0L
    } catch (_: Exception) { 0L }

    private fun exifOrientation(ctx: Context, uri: Uri): Int = try {
        ctx.contentResolver.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL
    } catch (_: Exception) { ExifInterface.ORIENTATION_NORMAL }

    private fun swapsSides(o: Int) = o == ExifInterface.ORIENTATION_TRANSPOSE || o == ExifInterface.ORIENTATION_ROTATE_90 ||
        o == ExifInterface.ORIENTATION_TRANSVERSE || o == ExifInterface.ORIENTATION_ROTATE_270

    /** Upright (EXIF-corrected) dimensions without decoding pixels. */
    fun info(ctx: Context, uri: Uri): Info {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IOException("Unreadable image")
        val swap = swapsSides(exifOrientation(ctx, uri))
        return Info(
            if (swap) bounds.outHeight else bounds.outWidth,
            if (swap) bounds.outWidth else bounds.outHeight,
            fileSize(ctx, uri)
        )
    }

    /** Final size for the requested width/height (either may be null) keeping a sane pixel budget. */
    fun targetSize(srcW: Int, srcH: Int, reqW: Int?, reqH: Int?): Pair<Int, Int> {
        var w: Double
        var h: Double
        when {
            reqW != null && reqH != null -> { w = reqW.toDouble(); h = reqH.toDouble() }
            reqW != null -> { w = reqW.toDouble(); h = srcH.toDouble() * reqW / srcW }
            reqH != null -> { h = reqH.toDouble(); w = srcW.toDouble() * reqH / srcH }
            else -> { w = srcW.toDouble(); h = srcH.toDouble() }
        }
        val pixels = w * h
        if (pixels > MAX_PIXELS) {
            val s = sqrt(MAX_PIXELS / pixels)
            w *= s; h *= s
        }
        return w.roundToInt().coerceAtLeast(1) to h.roundToInt().coerceAtLeast(1)
    }

    /** Decodes upright, down-sampled so memory stays small yet never below [wantW]x[wantH]. */
    fun decode(ctx: Context, uri: Uri, wantW: Int, wantH: Int): Bitmap {
        val orientation = exifOrientation(ctx, uri)
        val i = info(ctx, uri)
        var sample = 1
        while (i.width / (sample * 2) >= wantW && i.height / (sample * 2) >= wantH) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IOException("Decode failed")
        return applyOrientation(raw, orientation)
    }

    fun preview(ctx: Context, uri: Uri, maxSide: Int = 900): Bitmap = decode(ctx, uri, maxSide, maxSide)

    private fun applyOrientation(bmp: Bitmap, o: Int): Bitmap {
        val m = Matrix()
        when (o) {
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(-90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(-90f)
            else -> return bmp
        }
        val out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        if (out !== bmp) bmp.recycle()
        return out
    }

    /** JPEG has no alpha: paint transparent PNG/WebP pixels on white instead of black. */
    private fun flattenOnWhite(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        Canvas(out).apply { drawColor(Color.WHITE); drawBitmap(src, 0f, 0f, null) }
        return out
    }

    fun process(ctx: Context, src: Uri, fmt: Format, quality: Int, reqW: Int?, reqH: Int?, index: Int): Output {
        val info = info(ctx, src)
        val (tw, th) = targetSize(info.width, info.height, reqW, reqH)
        val decoded = decode(ctx, src, tw, th)
        var scaled = decoded
        var flat = decoded
        try {
            if (decoded.width != tw || decoded.height != th) scaled = Bitmap.createScaledBitmap(decoded, tw, th, true)
            flat = if (fmt.ext == "jpg" && scaled.hasAlpha()) flattenOnWhite(scaled) else scaled
            val buffer = ByteArrayOutputStream()
            if (!flat.compress(fmt.codec, if (fmt.lossless) 100 else quality, buffer)) throw IOException("Compression failed")
            val bytes = buffer.toByteArray()
            val name = outputName(fmt, index)
            val uri = saveToGallery(ctx, bytes, fmt, name)
            return Output(uri, name, bytes.size.toLong(), info.bytes, fmt.label, fmt.mime)
        } finally {
            setOf(flat, scaled, decoded).forEach { if (!it.isRecycled) it.recycle() }
        }
    }

    private fun outputName(fmt: Format, index: Int): String {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return "Pixora_${stamp}_${index + 1}.${fmt.ext}"
    }

    @Suppress("DEPRECATION")
    private fun saveToGallery(ctx: Context, bytes: ByteArray, fmt: Format, name: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, fmt.mime)
        }
        val resolver = ctx.contentResolver
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Pixora")
            values.put(MediaStore.Images.Media.IS_PENDING, 1)
            val uri = resolver.insert(MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values)
                ?: throw IOException("Could not create file")
            try {
                resolver.openOutputStream(uri)?.use { it.write(bytes) } ?: throw IOException("No output stream")
                resolver.update(uri, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                throw e
            }
            return uri
        }
        // Android 7-9: write the file ourselves (needs WRITE_EXTERNAL_STORAGE) and register it.
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Pixora")
        if (!dir.exists() && !dir.mkdirs()) throw IOException("Could not create folder")
        val file = File(dir, name)
        file.writeBytes(bytes)
        values.put(MediaStore.Images.Media.DATA, file.absolutePath)
        return resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: throw IOException("Could not register file")
    }
}
