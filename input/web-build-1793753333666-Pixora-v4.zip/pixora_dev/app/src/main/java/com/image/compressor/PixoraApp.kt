package com.image.compressor

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate

class PixoraApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val prefs = getSharedPreferences(Prefs.NAME, MODE_PRIVATE)
        AppCompatDelegate.setDefaultNightMode(
            prefs.getInt(Prefs.NIGHT_MODE, AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        )
    }
}

object Prefs {
    const val NAME = "pixora_settings"
    const val NIGHT_MODE = "night_mode"
    const val HISTORY = "history_json"
}
