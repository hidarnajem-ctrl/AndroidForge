package com.image.compressor

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {

    class Source(val uris: List<Uri>, val preview: Bitmap?, val firstWidth: Int, val firstHeight: Int, val totalBytes: Long)
    class Batch(val outputs: List<ImageProcessor.Output>, val failed: Int, val preview: Bitmap?) {
        val originalBytes get() = outputs.sumOf { it.originalBytes }
        val newBytes get() = outputs.sumOf { it.bytes }
    }
    data class UiState(
        val source: Source? = null,
        val busy: Boolean = false,
        val done: Int = 0,
        val total: Int = 0,
        val result: Batch? = null
    )
    sealed interface Event {
        data class Finished(val ok: Int, val failed: Int) : Event
        data object LoadFailed : Event
    }

    private val ctx get() = getApplication<Application>()
    private val _state = MutableStateFlow(UiState())
    val state = _state.asStateFlow()
    private val _history = MutableStateFlow(HistoryStore.load(app))
    val history = _history.asStateFlow()
    private val _events = Channel<Event>(Channel.BUFFERED)
    val events = _events.receiveAsFlow()

    fun setSources(uris: List<Uri>) {
        if (_state.value.busy) return
        viewModelScope.launch {
            try {
                val source = withContext(Dispatchers.IO) {
                    val first = ImageProcessor.info(ctx, uris.first())
                    val preview = ImageProcessor.preview(ctx, uris.first())
                    val total = uris.sumOf { ImageProcessor.fileSize(ctx, it) }
                    Source(uris, preview, first.width, first.height, total)
                }
                _state.update { it.copy(source = source, result = null) }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
                _events.send(Event.LoadFailed)
            }
        }
    }

    fun compress(formatIndex: Int, quality: Int, reqW: Int?, reqH: Int?) {
        val source = _state.value.source ?: return
        if (_state.value.busy) return
        _state.update { it.copy(busy = true, done = 0, total = source.uris.size, result = null) }
        viewModelScope.launch {
            val fmt = ImageProcessor.format(formatIndex)
            val outputs = ArrayList<ImageProcessor.Output>()
            var failed = 0
            withContext(Dispatchers.Default) {
                source.uris.forEachIndexed { index, uri ->
                    try {
                        outputs += ImageProcessor.process(ctx, uri, fmt, quality, reqW, reqH, index)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Throwable) { // includes OutOfMemoryError on huge photos
                        failed++
                    }
                    _state.update { it.copy(done = index + 1) }
                }
            }
            val preview = outputs.firstOrNull()?.let {
                try { withContext(Dispatchers.IO) { ImageProcessor.preview(ctx, it.uri) } } catch (_: Throwable) { null }
            }
            if (outputs.isNotEmpty()) {
                val added = outputs.map { HistoryRecord(it.name, it.format, it.originalBytes, it.bytes) }.asReversed()
                _history.update { (added + it).take(20) }
                HistoryStore.save(ctx, _history.value)
            }
            _state.update { it.copy(busy = false, result = Batch(outputs, failed, preview)) }
            _events.send(Event.Finished(outputs.size, failed))
        }
    }

    fun clearHistory() {
        _history.value = emptyList()
        HistoryStore.save(ctx, emptyList())
    }
}
