# AdMob / UMP ship their own consumer rules. Nothing extra is required.
# Keep line numbers for readable crash reports in Play Console:
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
