package com.example.domino

object AppLinks {
    /** سياسة الخصوصية (Google Docs). يجب أن تكون مشاركتها: «أي شخص لديه الرابط — عارض». */
    const val PRIVACY_POLICY =
        "https://docs.google.com/document/d/1PNWsi39XC5k5lVw6PXX15cl_6Jg6oxV8rR8eo6_Xgtk/view"
}
