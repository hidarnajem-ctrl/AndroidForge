package com.example.domino.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import com.example.domino.R
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domino.model.ProgressState

private fun pct(part: Int, total: Int) = if (total == 0) "" else "  (${part * 100 / total}%)"

@Composable
private fun StatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Palette.text, fontSize = 15.sp)
        Text(value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x33FFFFFF)))
}

@Composable
fun ProfileScreen(p: ProgressState, onRename: (String) -> Unit, modifier: Modifier = Modifier) {
    var editing by remember { mutableStateOf(false) }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        RibbonTitle("الملف الشخصي", Modifier.width(220.dp).align(Alignment.CenterHorizontally))
        Panel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.avatar_default), null, Modifier.size(72.dp))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Row(Modifier.clickable { editing = true }, verticalAlignment = Alignment.CenterVertically) {
                        Text(p.name, color = Palette.gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(8.dp))
                        Image(painterResource(R.drawable.icon_edit), null, Modifier.size(20.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                    LevelBar(p.level, p.xp)
                }
            }
        }

        Panel(Modifier.fillMaxWidth()) {
            Text("الإحصائيات", color = Palette.gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            StatRow("المباريات التي تم لعبها", "${p.matches}")
            StatRow("المباريات التي فزت بها", "${p.matchWins}${pct(p.matchWins, p.matches)}")
            StatRow("الجولات التي تم لعبها", "${p.rounds}")
            StatRow("الجولات التي فزت بها", "${p.roundWins}${pct(p.roundWins, p.rounds)}")
        }

        Panel(Modifier.fillMaxWidth()) {
            Text("آخر 10 مباريات", color = Palette.gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            val last = p.history.takeLast(10).reversed()
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (i in 0 until 10) {
                    val v = last.getOrNull(i)
                    if (v != null) {
                        Image(
                            painterResource(if (v) R.drawable.result_win else R.drawable.result_lose), null,
                            Modifier.weight(1f).aspectRatio(1f)
                        )
                    } else {
                        Box(
                            Modifier.weight(1f).aspectRatio(1f).clip(CircleShape).background(Color(0x66000000)),
                            contentAlignment = Alignment.Center
                        ) { Text("${i + 1}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }
    }

    if (editing) {
        var text by remember { mutableStateOf(p.name) }
        AlertDialog(
            onDismissRequest = { editing = false },
            title = { Text("اسم اللاعب") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { if (it.length <= 14) text = it },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = { onRename(text.trim().ifEmpty { p.name }); editing = false }) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { editing = false }) { Text("إلغاء") } }
        )
    }
}
