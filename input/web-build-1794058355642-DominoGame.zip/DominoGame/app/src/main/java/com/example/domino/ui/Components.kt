package com.example.domino.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlin.math.roundToInt
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domino.R
import com.example.domino.model.DominoTile
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.res.painterResource
import com.example.domino.model.Side
import com.example.domino.model.Turn
import kotlinx.coroutines.delay

private const val P1 = 0.28f
private const val P2 = 0.5f
private const val P3 = 0.72f
private val Gold = Color(0xFFFFD54F)

private fun pipLayout(n: Int): List<Pair<Float, Float>> = when (n) {
    0 -> emptyList()
    1 -> listOf(P2 to P2)
    2 -> listOf(P1 to P1, P3 to P3)
    3 -> listOf(P1 to P1, P2 to P2, P3 to P3)
    4 -> listOf(P1 to P1, P3 to P1, P1 to P3, P3 to P3)
    5 -> pipLayout(4) + (P2 to P2)
    else -> listOf(P1 to P1, P3 to P1, P1 to P2, P3 to P2, P1 to P3, P3 to P3)
}

private fun DrawScope.drawPips(n: Int, origin: Offset, side: Float, color: Color, glow: Boolean) {
    pipLayout(n).forEach { (fx, fy) ->
        val c = Offset(origin.x + fx * side, origin.y + fy * side)
        if (glow) drawCircle(color.copy(alpha = 0.28f), side * 0.17f, c)
        drawCircle(color, side * 0.085f, c)
    }
}

// ───────────────────────── TileView ─────────────────────────
/** حجر دومينو: عاجي بزوايا منحنية ونقاط واضحة. cell = طول الضلع القصير. */
@Composable
fun TileView(
    tile: DominoTile?,
    modifier: Modifier = Modifier,
    horizontal: Boolean = false,
    cell: Dp = 28.dp,
    highlighted: Boolean = false,
    dimmed: Boolean = false,
    faceDown: Boolean = false,
    skin: TileSkin = LocalTileSkin.current,
    onClick: (() -> Unit)? = null
) {
    val w = if (horizontal) cell * 2 else cell
    val h = if (horizontal) cell else cell * 2
    val scale by animateFloatAsState(
        if (highlighted) 1.08f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "tileScale"
    )
    val shape = RoundedCornerShape(cell * 0.2f)
    val texture = skin.texture?.let { ImageBitmap.imageResource(it) }
    val back = if (faceDown || tile == null) ImageBitmap.imageResource(R.drawable.tile_back) else null

    Canvas(
        modifier = modifier
            .size(w, h)
            .graphicsLayer { scaleX = scale; scaleY = scale; alpha = if (dimmed) 0.5f else 1f }
            .shadow(if (highlighted) 10.dp else 4.dp, shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
    ) {
        val c = size.minDimension
        val cr = CornerRadius(c * 0.2f)
        if (faceDown || tile == null) {
            if (back != null) {
                drawImage(
                    back, dstOffset = IntOffset.Zero,
                    dstSize = IntSize(size.width.roundToInt(), size.height.roundToInt())
                )
            }
            return@Canvas
        }
        if (texture != null) {
            val path = Path().apply { addRoundRect(RoundRect(0f, 0f, size.width, size.height, cr)) }
            clipPath(path) {
                val tw = texture.width
                val th = texture.height
                val horiz = size.width > size.height
                val sw = if (horiz) tw else tw / 2
                val sh = if (horiz) th / 2 else th
                drawImage(
                    texture, IntOffset((tw - sw) / 2, (th - sh) / 2), IntSize(sw, sh),
                    IntOffset.Zero, IntSize(size.width.roundToInt(), size.height.roundToInt())
                )
            }
            // لمعة خفيفة فوق الملمس
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0x33FFFFFF), Color.Transparent, Color(0x40000000))),
                cornerRadius = cr
            )
        } else {
            drawRoundRect(Brush.verticalGradient(listOf(skin.faceTop, skin.faceBottom)), cornerRadius = cr)
        }
        drawRoundRect(skin.border, cornerRadius = cr, style = Stroke(1.6.dp.toPx()))

        val inset = c * 0.18f
        val divider = skin.divider
        if (horizontal) {
            drawLine(divider, Offset(size.width / 2, inset), Offset(size.width / 2, size.height - inset), c * 0.04f)
            drawPips(tile.left, Offset(0f, 0f), c, skin.pip, skin.glow)
            drawPips(tile.right, Offset(c, 0f), c, skin.pip, skin.glow)
        } else {
            drawLine(divider, Offset(inset, size.height / 2), Offset(size.width - inset, size.height / 2), c * 0.04f)
            drawPips(tile.left, Offset(0f, 0f), c, skin.pip, skin.glow)
            drawPips(tile.right, Offset(0f, c), c, skin.pip, skin.glow)
        }
    }
}

// ───────────────────────── HandView ─────────────────────────
@Composable
fun HandView(
    hand: List<DominoTile>,
    playableIds: Set<Int>,
    selectedId: Int?,
    myTurn: Boolean,
    hintId: Int? = null,
    onTileClick: (DominoTile) -> Unit,
    modifier: Modifier = Modifier
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        LazyRow(
            modifier = modifier.padding(top = 20.dp),
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            items(hand, key = { it.id }) { t ->
                val lift by animateDpAsState(if (t.id == selectedId || t.id == hintId) 18.dp else 0.dp, label = "lift")
                TileView(
                    tile = t,
                    cell = 36.dp,
                    highlighted = t.id == selectedId || (myTurn && t.id in playableIds),
                    dimmed = myTurn && t.id !in playableIds,
                    modifier = Modifier.animateItem().offset(y = -lift),
                    onClick = { onTileClick(t) }
                )
            }
        }
    }
}

/** أحجار الخصم مقلوبة. */
@Composable
fun AiHandView(count: Int, modifier: Modifier = Modifier, reveal: List<DominoTile>? = null) {
    Row(
        modifier
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        if (reveal != null) reveal.forEach { TileView(it, cell = 22.dp) }
        else repeat(count) { TileView(null, faceDown = true, cell = 18.dp) }
    }
}

// ───────────────────────── ScoreBoard ─────────────────────────
@Composable
private fun ScoreItem(name: String, score: Int, active: Boolean, avatar: Int) {
    val color by animateColorAsState(if (active) Gold else Color(0xFFEDE3C8), label = "scoreColor")
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(44.dp).clip(CircleShape)
                .border(if (active) 3.dp else 0.dp, if (active) Gold else Color.Transparent, CircleShape),
            contentAlignment = Alignment.Center
        ) { Image(painterResource(avatar), null, Modifier.size(40.dp)) }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(name, color = color, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text("$score", color = color, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ScoreBoard(
    playerScore: Int,
    aiScore: Int,
    boneyard: Int,
    turn: Turn,
    modifier: Modifier = Modifier
) {
    val panel = ImageBitmap.imageResource(R.drawable.scoreboard_panel)
    Row(
        modifier
            .fillMaxWidth()
            .drawBehind {
                val cs = (panel.height * 0.30f).roundToInt()
                val cd = 26.dp.toPx()
                drawNineSlice(panel, cs, cs, cd, cd)
            }
            .padding(horizontal = 22.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        ScoreItem("أنت", playerScore, turn == Turn.PLAYER, R.drawable.avatar_default)
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.icon_boneyard), null, Modifier.size(width = 34.dp, height = 30.dp))
            Text("$boneyard", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        ScoreItem("الكمبيوتر", aiScore, turn == Turn.AI, R.drawable.avatar_ai)
    }
}
