package com.example.domino.ads

/**
 * ⚠️ هذه معرّفات اختبار رسمية من Google.
 * استبدلها بمعرّفاتك من حساب AdMob قبل النشر (وأيضاً APPLICATION_ID في AndroidManifest.xml).
 */
object AdIds {
    const val REWARDED = "ca-app-pub-3940256099942544/5224354917"
    const val INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712"
    const val BANNER = "ca-app-pub-3940256099942544/9214589741"
}
