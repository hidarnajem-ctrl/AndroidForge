package com.example.domino.ui

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

/** تصميم (Skin) لأحجار الدومينو. premium = يُفتح بمشاهدة إعلان بمكافأة. */
data class TileSkin(
    val id: String,
    val name: String,
    val premium: Boolean,
    val faceTop: Color,
    val faceBottom: Color,
    val border: Color,
    val divider: Color,
    val pip: Color,
    val glow: Boolean = false
)

object TileSkins {
    val Classic = TileSkin(
        "classic", "العاجي الكلاسيكي", false,
        Color(0xFFFFFDF5), Color(0xFFEFE6D0), Color(0xFF8A7B5A), Color(0xFF6B5E45), Color(0xFF1A1A1A)
    )
    val Ebony = TileSkin(
        "ebony", "الأبنوس الملكي", true,
        Color(0xFF3A3A3A), Color(0xFF111111), Color(0xFFC9A24B), Color(0xFFC9A24B), Color(0xFFF5F0E1)
    )
    val Gold = TileSkin(
        "gold", "الذهب الفاخر", true,
        Color(0xFFFFE082), Color(0xFFD4A017), Color(0xFF8A6508), Color(0xFF7A5A08), Color(0xFF3B2A05)
    )
    val Sapphire = TileSkin(
        "sapphire", "الياقوت الأزرق", true,
        Color(0xFF3F6FD8), Color(0xFF14337A), Color(0xFF9DB8FF), Color(0xFFBBD0FF), Color(0xFFFFFFFF)
    )
    val Ruby = TileSkin(
        "ruby", "العقيق الأحمر", true,
        Color(0xFFD94452), Color(0xFF7A1220), Color(0xFFFFC1C8), Color(0xFFFFD6DA), Color(0xFFFFE9B0)
    )
    val Emerald = TileSkin(
        "emerald", "الزمرد", true,
        Color(0xFF36C98A), Color(0xFF0C6B45), Color(0xFFB8FFE0), Color(0xFFD5FFEE), Color(0xFFFFFFFF)
    )
    val Neon = TileSkin(
        "neon", "النيون المضيء", true,
        Color(0xFF1B1F33), Color(0xFF0A0C18), Color(0xFF00E5FF), Color(0xFF00E5FF), Color(0xFF00F0FF), glow = true
    )

    val all = listOf(Classic, Ebony, Gold, Sapphire, Ruby, Emerald, Neon)
    fun byId(id: String) = all.firstOrNull { it.id == id } ?: Classic
}

val LocalTileSkin = compositionLocalOf { TileSkins.Classic }
