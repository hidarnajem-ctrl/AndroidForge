package com.example.domino.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.domino.model.DominoTile

private val Gold = Color(0xFFFFD54F)
private val Sample = DominoTile(0, 6, 4)

@Composable
fun SkinShopDialog(
    unlocked: Set<String>,
    selectedId: String,
    adReady: Boolean,
    onSelect: (TileSkin) -> Unit,
    onWatchAd: (TileSkin) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF2B1A0C))
                .border(2.dp, Color(0xFF7A4A24), RoundedCornerShape(24.dp))
                .padding(16.dp)
        ) {
            Text("🎨 أحجار مميزة", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(
                "افتح أي تصميم بمشاهدة إعلان قصير",
                color = Color(0xFFEDE3C8), fontSize = 13.sp,
                modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
            )
            Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState())) {
                TileSkins.all.forEach { skin ->
                    val isUnlocked = skin.id in unlocked
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TileView(Sample, horizontal = true, cell = 34.dp, skin = skin)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                (if (!isUnlocked) "🔒 " else "") + skin.name,
                                color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium
                            )
                            Text(
                                if (skin.premium) "مميز" else "مجاني",
                                color = if (skin.premium) Gold else Color(0xFFB9D8B0), fontSize = 12.sp
                            )
                        }
                        when {
                            !isUnlocked -> Button(
                                enabled = adReady,
                                onClick = { onWatchAd(skin) },
                                contentPadding = PaddingValues(horizontal = 12.dp)
                            ) { Text(if (adReady) "🎬 شاهد إعلاناً" else "جارٍ التحميل...", fontSize = 13.sp) }

                            skin.id == selectedId ->
                                Text("✓ مستخدم", color = Gold, fontWeight = FontWeight.Bold, fontSize = 14.sp)

                            else -> Button(
                                onClick = { onSelect(skin) },
                                contentPadding = PaddingValues(horizontal = 12.dp)
                            ) { Text("استخدام", fontSize = 13.sp) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onDismiss, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("إغلاق") }
        }
    }
}
