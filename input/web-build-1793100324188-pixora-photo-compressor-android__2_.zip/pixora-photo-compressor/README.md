# Pixora Photo Compressor (Native Android)

A complete, high-performance native Android application written in Kotlin and Jetpack Compose (Material 3).

## Features
- 100% On-Device Local Privacy
- Android System Photo Picker
- Memory-safe sub-sampling (inSampleSize)
- Quality Slider (10% - 100%)
- Aspect-ratio preserving resizer
- WebP, JPEG, PNG formats
- Transparency safeguard
- Save to MediaStore (Pictures/Pixora) and share via FileProvider
- Full English and Arabic RTL support
