package com.pixora.photocompressor

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.pixora.photocompressor.ui.CompressorScreen
import com.pixora.photocompressor.ui.PhotoCompressorViewModel
import com.pixora.photocompressor.ui.theme.PixoraTheme

class MainActivity : ComponentActivity() {

    private val viewModel: PhotoCompressorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Handle incoming image from "Share to Pixora" intent from other apps
        handleIncomingIntent(intent)

        setContent {
            PixoraTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    CompressorScreen(viewModel = viewModel)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type?.startsWith("image/") == true) {
            val imageUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri
            }
            if (imageUri != null) {
                viewModel.onImagePicked(imageUri)
            }
        }
    }
}
