# Arrow Exit 1.0.4 Preview

Open this project in Android Studio and build the debug APK.

New: Cosmetic Shop in Settings. Background themes and arrow palettes are bought once with coins; owned items can be equipped at no extra cost. Existing 1.0.3.1 gameplay/economy features are retained.

Version: 1.0.4 (versionCode 4).
