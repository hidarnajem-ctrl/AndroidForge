# Arrow Exit / مَخرَج — مشروع أندرويد

اللعبة نفسها صفحة ويب داخل التطبيق (`app/src/main/assets/index.html`)، والتطبيق يضيف حولها:

- **إعلانات AdMob:** بانر أسفل شاشة اللعب، وإعلان بيني بعد كل مرحلتين، وإعلانات بمكافأة للتلميحات والمسارات والإعادة.
- **رسالة موافقة الخصوصية:** نموذج Google UMP الذي يشترطه AdMob لمستخدمي أوروبا والمملكة المتحدة، وزر «خيارات الخصوصية» في الإعدادات عند الحاجة.
- **خدمات ألعاب Google Play:** تسجيل دخول تلقائي، و١٦ إنجازاً، و٤ لوحات صدارة، وحفظ سحابي للتقدّم.
- **تكامل مع النظام:** اهتزاز، وزر الرجوع، والوضع الداكن، واسم التطبيق بثماني لغات.

> معرّفات AdMob الحقيقية موجودة في المشروع. خدمات Play Games **متوقفة** إلى أن تضع معرّفاتها. ستجد التفاصيل أدناه.

---

## ١. البناء بدون Android Studio (AndroidForge)

المشروع جاهز للبناء السحابي، ففيه ملفات `gradlew` ومفتاح الرفع.

1. في [AndroidForge](https://professional-x.github.io/AndroidForge/) اربط حساب GitHub بالتوكن كما يطلب الموقع.
2. ارفع ملف المشروع `.zip` كما هو، فملفات المشروع في جذره مباشرة.
3. اختر نوع البناء حسب ما تريد:

| تريد | اختر | الناتج |
|---|---|---|
| تجربة اللعبة على هاتفك | **release** | APK موقّع بمفتاحك، يُثبَّت مباشرة |
| الرفع إلى Google Play | **bundle** | ملف `.aab` موقّع بمفتاح الرفع |

> **لماذا لا debug؟** البناء السحابي يصنع مفتاح debug جديداً في كل مرة. لذلك لن يُحدَّث التطبيق فوق النسخة السابقة، وخدمات Play Games لن تتعرّف عليه. استخدم **release** للتجربة دائماً.

4. حمّل الملف من قسم Download وثبّته أو ارفعه.

> **⚠️ قبل تثبيت أي نسخة على هاتفك:** أضفه كجهاز اختبار في AdMob (الخطوة ٣.٥)، حتى لا تُحسب مشاهداتك ونقراتك على إعلاناتك الحقيقية.

**إن فشل البناء:** انسخ آخر ٣٠ سطراً من السجلّ (Live log) وأرسلها.

### مفتاح الرفع (مهم جداً)

مجلد `keystore/` فيه مفتاح الرفع `upload-key.jks`، وكلمة مروره في `keystore.properties`. كل ملف AAB ترفعه إلى Google Play يجب أن يكون موقّعاً بهذا المفتاح نفسه.

- **احتفظ بنسخة من ملف الـZIP** في مكان آمن، مثل Google Drive أو بريدك.
- **اجعل مستودع GitHub الذي ينشئه AndroidForge خاصاً (Private)،** حتى لا يرى أحد المفتاح.
- أُضيفت قواعد إلى `.gitignore` لمنع إضافة مجلد `keystore/` وملفات المفاتيح وكلمات المرور مستقبلاً. لكن إذا كانت هذه الملفات قد أُضيفت إلى Git سابقاً، فلن يكفي `.gitignore` لإزالتها من سجل المستودع؛ يجب إزالة الملفات من التتبّع وسجل Git، وإذا كان المستودع عاماً فتعامل مع مفتاح الرفع على أنه مكشوف واطلب استبداله من Play Console قبل استخدامه للنشر.
- لا ترسل ملف ZIP الذي يحتوي على مجلد `keystore/` إلى أي شخص، ولا ترفعه إلى مستودع عام.
- **فعّل Play App Signing** عند أول رفع، وهو الافتراضي. بعدها تحفظ Google مفتاح التوقيع النهائي، وإذا ضاع مفتاح الرفع يمكن طلب استبداله من دعم Play Console.

بصمة مفتاح الرفع، وتحتاجها لخدمات ألعاب Play في الخطوة ٥:

```
SHA-1:   6E:15:48:17:26:31:75:D3:A1:EC:AC:06:81:E2:19:D4:9D:B0:68:12
SHA-256: 47:26:B6:0B:CD:6A:F6:41:C3:AC:E9:B0:83:E4:C0:42:A2:1E:C8:23:0B:50:A9:0D:4C:44:C2:D2:57:DF:08:21
```

### إن توفر لك حاسوب لاحقاً

افتح المجلد في [Android Studio](https://developer.android.com/studio) عبر **File ← Open**، وانتظر المزامنة، ثم اضغط ▶ **Run**.

> **ملاحظة:** الخط المستدير يُحمَّل من Google Fonts. بدون إنترنت يظهر خط الهاتف العادي، واللعبة تعمل كما هي.

## ٢. اسم الحزمة (قبل أول رفع، ولا يمكن تغييره بعده)

في `app/build.gradle.kts` غيّر السطر التالي إلى اسم خاص بك:

```kotlin
applicationId = "com.arrowexit.game"
```

مثلاً `com.yourname.arrowexit`. لا تغيّر `namespace`.

## ٣. AdMob

1. في [AdMob](https://admob.google.com) اختر **Apps ← Add app ← Android**. إن لم تكن اللعبة منشورة بعد فاختر أنها غير موجودة على المتجر، ويمكنك ربطها لاحقاً.
2. أنشئ ثلاث وحدات إعلانية: **Banner** و**Interstitial** و**Rewarded**.
3. ✅ المعرّفات الأربعة (معرّف التطبيق والوحدات الثلاث) موجودة في `app/src/main/res/values/ads.xml`.
4. أنشئ رسالة الموافقة من **Privacy & messaging** لأوروبا والمملكة المتحدة، والتطبيق يعرضها تلقائياً.
5. **أضف هاتفك كجهاز اختبار:** في AdMob افتح **Settings ← Test devices ← Add test device**، والصق معرّف الإعلانات من هاتفك (إعدادات أندرويد ← Google ← الإعلانات).

> **⚠️ مهم:** لا تضغط على إعلاناتك الحقيقية أبداً، فقد يُوقَف حسابك. اختبر دائماً بالمعرّفات التجريبية أو بجهاز اختبار.

## ٤. Google Play Console

1. أنشئ حساب مطوّر وادفع الرسوم لمرة واحدة، ثم اختر **Create app**.
2. **سياسة الخصوصية مطلوبة** لأن التطبيق يعرض إعلانات. رابطها موجود داخل اللعبة (الإعدادات ← سياسة الخصوصية)، وضعه أيضاً في **App content ← Privacy policy**:
   `https://docs.google.com/document/d/e/2PACX-1vRbH3PtqfDcxym56KI3tCEq2e6YbhotnpZf6jiib6NzOqJpf2kXhKK6fsdQIpf2Aa3l2l7aCfkaq7fw/pub`
3. في **App content** أكمل البنود التالية:
   - **Ads:** نعم، التطبيق يحتوي إعلانات.
   - **Data safety:** اذكر أن AdMob يجمع معرّف الإعلانات وبيانات الجهاز، وأن خدمات Play Games تستخدم حساب اللاعب.
   - **Target audience:** اختر **١٣ سنة فأكثر**. اختيار فئة الأطفال يُخضع التطبيق لسياسة العائلات ويستلزم إعدادات إعلانية مختلفة.
   - **Content rating:** أكمل الاستبيان.
4. انسخ أوصاف المتجر من `STORE_LISTING.md`، فهي جاهزة بثماني لغات.

## ٥. خدمات ألعاب Google Play

في Play Console افتح **Play Games Services ← Setup and management ← Configuration**.

1. أنشئ مشروع ألعاب جديداً لهذه اللعبة، وانسخ **Project ID** إلى `game_services_project_id` في `res/values/games.xml`.
2. **Credentials:** أنشئ بيانات اعتماد Android لكل بصمة **SHA-1** من التاليتين:
   - **بصمة مفتاح Google:** من **Test and release ← App integrity ← App signing**. هذه تعمل مع النسخة التي يحمّلها الناس من المتجر.
   - **بصمة مفتاح الرفع:** موجودة في الخطوة ١ أعلاه. هذه تعمل مع ملفات APK التي تبنيها بنفسك للتجربة.
3. **Saved games:** فعّلها، فالحفظ السحابي يعتمد عليها.
4. **Testers:** أضف بريدك لتختبر قبل النشر.
5. أنشئ الإنجازات ولوحات الصدارة التالية، وضع معرّف كل منها في `games.xml` مكان `REPLACE`.

### الإنجازات

| المفتاح في `games.xml` | الاسم (English) | النوع | الخطوات | نقاط مقترحة |
|---|---|---|---|---|
| `ach_first_win` | First Exit | عادي | – | 5 |
| `ach_levels_10` | On Your Way | تدريجي | 10 | 10 |
| `ach_levels_50` | Arrow Expert | تدريجي | 50 | 50 |
| `ach_levels_100` | Master of Exits | تدريجي | 100 | 100 |
| `ach_perfect` | Flawless | عادي | – | 10 |
| `ach_perfect_10` | Precision | تدريجي | 10 | 30 |
| `ach_stars_100` | Starry Sky | تدريجي | 100 | 50 |
| `ach_timed_1` | Beat the Clock | عادي | – | 15 |
| `ach_speed` | Lightning | عادي | – | 40 |
| `ach_lock_1` | Lockpicker | عادي | – | 10 |
| `ach_two_1` | Both Ways | عادي | – | 10 |
| `ach_ice_10` | Icebreaker | تدريجي | 10 | 20 |
| `ach_shapes_all` | Every Shape | تدريجي | 5 | 40 |
| `ach_no_help` | No Help Needed | عادي | – | 30 |
| `ach_daily_1` | Player of the Day | عادي | – | 10 |
| `ach_streak_7` | Full Week | تدريجي | 7 | 60 |

**ملاحظات:**
- يجب أن يطابق عدد الخطوات في Play Console الجدول تماماً.
- أسماء الإنجازات وأوصافها بكل اللغات موجودة داخل اللعبة (`TX` في `index.html`)، فانسخها إلى ترجمات Play Console.
- يحتاج كل إنجاز أيقونة مربعة بحجم 512×512.

### لوحات الصدارة

| المفتاح | الاسم | التنسيق | الترتيب |
|---|---|---|---|
| `lb_stars` | Total stars | رقمي | الأكبر أفضل |
| `lb_levels` | Levels completed | رقمي | الأكبر أفضل |
| `lb_streak` | Longest day streak | رقمي | الأكبر أفضل |
| `lb_daily` | Fastest daily challenge | **وقت** (اللعبة ترسله بالميلي ثانية) | **الأصغر أفضل** |

6. بعد ملء المعرّفات انشر إعدادات خدمات الألعاب (**Publish**).

## ٦. بناء ملف الرفع (AAB)

1. في AndroidForge اختر **bundle**، فيخرج ملف `.aab` موقّعاً بمفتاح الرفع تلقائياً.
2. ارفعه إلى مسار **Internal testing** أولاً، وجرّب كل شيء، ثم انتقل للإنتاج.
3. مع كل تحديث جديد ارفع `versionCode` بواحد في `app/build.gradle.kts`، مثلاً من `1` إلى `2`، وإلا يرفض Google Play الملف.

## ٧. أين يوجد كل شيء؟

| ما تريد تغييره | الملف |
|---|---|
| اللعبة نفسها (المراحل، النصوص، الألوان) | `app/src/main/assets/index.html` |
| معرّفات الإعلانات | `app/src/main/res/values/ads.xml` |
| معرّفات Play Games | `app/src/main/res/values/games.xml` |
| اسم التطبيق بكل لغة | `app/src/main/res/values-*/strings.xml` |
| أيقونة التطبيق | `app/src/main/res/drawable/ic_launcher_*.xml` |
| منطق الإعلانات | `AdsManager.kt` |
| منطق Play Games والحفظ السحابي | `PlayGamesManager.kt` |
| الجسر بين اللعبة وأندرويد | `WebBridge.kt` |

## ٨. كيف تتواصل اللعبة مع التطبيق؟

- **من اللعبة إلى التطبيق:** تستدعي `window.AndroidBridge` لعرض الإعلانات، وفتح الإنجازات، والحفظ.
- **من التطبيق إلى اللعبة:** يردّ عبر `window.NativeEvents` بنتيجة الإعلان، وحالة تسجيل الدخول، والتقدّم المحفوظ في السحابة.
- **عند فتح الملف في متصفح عادي:** لا يوجد الجسر، فتعمل الإعلانات التجريبية ويُحفظ كل شيء على الجهاز.
- **عند تعذّر تحميل إعلان بمكافأة:** تُمنح الإعادة واستعادة القلب والوقت الإضافي مجاناً، حتى لا يعلق اللاعب. أما التلميحات والمسارات فتظهر معها رسالة «لا يوجد إعلان متاح الآن».


## Version 1.0.2 Preview – Economy Update

See `CHANGELOG-1.0.2.md` for the new coin wallet, daily login reward, and tool shop. The Android app loads the game logic from the inline script in `app/src/main/assets/index.html`; `game.js` is kept in sync as the editable source copy.


## 1.0.2.1 Shop polish
See `CHANGELOG-1.0.2.1.md` for the shop dialog fixes and validation notes.


## Version 1.0.3 preview — Worlds & Treasure Chests

- Six themed worlds with 20 levels each and progress indicators.
- World cards unlock automatically from existing level progress.
- Each completed world grants one claimable treasure chest: coins plus one hint and one path.
- Chest claims are saved locally and included in Play Games cloud-save data.
- Existing level list, daily challenge, shop, ads, achievements, settings, and all eight languages remain available.
- Build and test the Android APK on a connected development machine before publishing.


## 1.0.4.2 startup fix
See `CHANGELOG-1.0.4.2.md`. The packaged page and `game.js` are synchronized; the missing Settings cosmetic-shop button that halted startup in 1.0.4.1 is now present and defensively bound.


## Version 1.0.4.3

The home screen now has compact side-by-side shortcuts for Worlds and Backgrounds. The Backgrounds shortcut opens the cosmetic shop directly on its Backgrounds tab. Cosmetic shop access has been moved out of Settings; arrow styles remain available from the shop tabs. See `CHANGELOG-1.0.4.3.md`.
