from pathlib import Path
p=Path('/mnt/data/arrowexit_v102/app/src/main/assets/index.html')
s=p.read_text()
# CSS economy
needle='/* simulated ads */'
css='''/* economy: coins, daily login rewards and a lightweight booster shop */
.wallet{display:flex;align-items:center;justify-content:space-between;gap:10px;width:100%;padding:10px 14px;border:1px solid var(--dot);border-radius:16px;background:var(--surface);color:var(--ink);font-weight:800}
.wallet .coin{display:inline-flex;align-items:center;gap:7px;color:var(--ink)}
.coinmark{width:24px;height:24px;border-radius:50%;display:inline-grid;place-items:center;background:linear-gradient(145deg,#ffe59a,#d99a24);color:#744b08;font-size:14px;box-shadow:inset 0 1px 2px #fff8}
.wallet button{border:0;border-radius:10px;background:var(--ink);color:var(--bg);padding:7px 11px;font:inherit;font-size:13px}
.econ-head{display:flex;justify-content:space-between;align-items:center;gap:10px;margin:8px 0 14px}
.econ-balance{font-size:20px;font-weight:900;display:flex;align-items:center;gap:7px}
.daygrid{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:5px;margin:12px 0 16px}
.daybox{border:1px solid var(--dot);background:var(--bg);border-radius:11px;padding:8px 2px;font-size:11px;display:grid;gap:4px;justify-items:center}
.daybox b{font-size:14px}.daybox.done{border-color:var(--accent);background:var(--cell)}.daybox.today{outline:2px solid var(--accent)}
.shopitem{display:grid;grid-template-columns:42px minmax(0,1fr) auto;align-items:center;gap:10px;text-align:start;border:1px solid var(--dot);border-radius:14px;padding:10px;margin:8px 0;background:var(--bg)}
.shopitem .si{width:40px;height:40px;border-radius:12px;background:var(--cell);display:grid;place-items:center;font-size:21px}
.shopitem small{display:block;color:var(--muted);font-weight:600}.shopitem button{border:0;border-radius:10px;background:var(--ink);color:var(--bg);padding:8px 10px;font:inherit;font-weight:800}.shopitem button:disabled{opacity:.45}
.econ-tabs{display:flex;gap:7px;margin-bottom:12px}.econ-tabs button{flex:1;border:1px solid var(--dot);border-radius:11px;padding:9px;background:var(--bg);color:var(--ink);font:inherit;font-weight:800}.econ-tabs button.active{background:var(--ink);color:var(--bg)}
'''
s=s.replace(needle,css+needle)
# Home wallet before play
needle='    <button class="big" id="hPlay" type="button">'
html='''    <div class="wallet"><span class="coin"><span class="coinmark">◆</span><span id="homeCoins">0</span></span><span style="display:flex;gap:7px"><button id="hDailyReward" type="button" data-i="dailyReward"></button><button id="hShop" type="button" data-i="shop"></button></span></div>
'''
s=s.replace(needle,html+needle)
# economy overlay before tutorial
needle='  <!-- new special arrow intro -->'
overlay='''  <!-- daily rewards and booster shop -->
  <div class="overlay" id="economy" hidden>
    <div class="card" style="max-height:82vh;overflow:auto;text-align:start">
      <div class="econ-head"><h2 id="econTitle" style="margin:0"></h2><div class="econ-balance"><span class="coinmark">◆</span><span id="econCoins">0</span></div></div>
      <div class="econ-tabs"><button id="econDailyTab" class="active" type="button"></button><button id="econShopTab" type="button"></button></div>
      <div id="econDailyPanel"><p id="dailyIntro" style="text-align:center"></p><div class="daygrid" id="dayGrid"></div><div class="acts"><button id="claimDaily" type="button"></button></div></div>
      <div id="econShopPanel" hidden><p id="shopIntro" style="text-align:center"></p><div id="shopItems"></div></div>
      <div class="acts" style="margin-top:12px"><button class="alt" id="econClose" type="button" data-i="close"></button></div>
    </div>
  </div>

'''
s=s.replace(needle,overlay+needle)
# translation entries add after dailyDone entry
needle='"dailyDone":["Done ✓","أُنجز ✓","Hecho ✓","Feito ✓","Selesai ✓","Tamam ✓","Готово ✓","Fait ✓"],'
trans='''"dailyReward":["Daily gift","هدية يومية","Regalo diario","Presente diário","Hadiah harian","Günlük hediye","Ежедневный подарок","Cadeau quotidien"],"shop":["Shop","المتجر","Tienda","Loja","Toko","Mağaza","Магазин","Boutique"],"dailyIntro":["Claim a gift every day. Day 7 brings a bigger bonus.","احصل على هدية كل يوم، ومكافأة أكبر في اليوم السابع.","Reclama un regalo cada día. El día 7 trae una bonificación mayor.","Resgate um presente por dia. O dia 7 traz um bônus maior.","Klaim hadiah setiap hari. Hari ke-7 memberi bonus lebih besar.","Her gün ödül al. 7. gün daha büyük bonus verir.","Получай подарок каждый день. На 7-й день — большой бонус.","Réclame un cadeau chaque jour. Le 7e jour offre un bonus."],"shopIntro":["Spend coins on helpful boosters.","استخدم العملات لشراء أدوات المساعدة.","Usa monedas para comprar ayudas.","Use moedas para comprar ajudas.","Gunakan koin untuk membeli bantuan.","Yardımcı güçlendirmeler için jeton harca.","Трать монеты на полезные усиления.","Dépense des pièces pour acheter des aides."],"claimDaily":["Claim today's gift","استلام هدية اليوم","Reclamar regalo de hoy","Resgatar presente de hoje","Klaim hadiah hari ini","Bugünün ödülünü al","Забрать подарок дня","Réclamer le cadeau du jour"],"claimedToday":["Claimed today ✓","تم الاستلام اليوم ✓","Reclamado hoy ✓","Resgatado hoje ✓","Sudah diklaim ✓","Bugün alındı ✓","Получено сегодня ✓","Déjà réclamé ✓"],"day":["Day","اليوم","Día","Dia","Hari","Gün","День","Jour"],"coinsEarned":["+{n} coins earned","حصلت على {n} عملة","Has ganado {n} monedas","Você ganhou {n} moedas","Kamu mendapat {n} koin","{n} jeton kazandın","Получено монет: {n}","+{n} pièces gagnées"],"shopHints":["3 hints","3 تلميحات","3 pistas","3 dicas","3 petunjuk","3 ipucu","3 подсказки","3 indices"],"shopGuides":["3 path guides","3 مسارات","3 rutas","3 rotas","3 panduan jalur","3 yol rehberi","3 подсказки пути","3 aides de chemin"],"buy":["Buy","شراء","Comprar","Comprar","Beli","Satın al","Купить","Acheter"],"notEnough":["Not enough coins","عملاتك غير كافية","No tienes suficientes monedas","Moedas insuficientes","Koin tidak cukup","Yeterli jeton yok","Недостаточно монет","Pas assez de pièces"],"purchaseDone":["Added to your items ✓","أضيفت إلى أدواتك ✓","Añadido a tus objetos ✓","Adicionado aos seus itens ✓","Ditambahkan ke itemmu ✓","Eşyalarına eklendi ✓","Добавлено ✓","Ajouté à tes objets ✓"],"coins":["Coins","العملات","Monedas","Moedas","Koin","Jetonlar","Монеты","Pièces"],'''
s=s.replace(needle,needle+trans)
# persistent state
s=s.replace("  wins:store.get('mk_wins',0), seen:store.get('mk_seen',{}),", "  wins:store.get('mk_wins',0), seen:store.get('mk_seen',{}),\n  coins:store.get('mk_coins',0), economy:store.get('mk_economy',{lastClaim:'',streak:0}),")
s=s.replace("sound:P.sound,vib:P.vib,hints:P.hints,guides:P.guides,wins:P.wins,seen:P.seen,lang:P.lang,ach:P.ach,st:P.st", "sound:P.sound,vib:P.vib,hints:P.hints,guides:P.guides,wins:P.wins,seen:P.seen,lang:P.lang,ach:P.ach,st:P.st,coins:P.coins,economy:P.economy")
s=s.replace("function cloudData(){return{v:1,unlocked:P.unlocked,stars:P.stars,daily:P.daily,hints:P.hints,guides:P.guides,wins:P.wins,seen:P.seen,ach:P.ach,st:P.st}}", "function cloudData(){return{v:2,unlocked:P.unlocked,stars:P.stars,daily:P.daily,hints:P.hints,guides:P.guides,wins:P.wins,seen:P.seen,ach:P.ach,st:P.st,coins:P.coins,economy:P.economy}}")
s=s.replace("  if(!c||c.v!==1)return;", "  if(!c||![1,2].includes(c.v))return;")
s=s.replace("  Object.assign(P.st.shapes,s.shapes||{});\n  save();", "  Object.assign(P.st.shapes,s.shapes||{});\n  if(c.v>=2){P.coins=Math.max(P.coins,Number(c.coins)||0);if(c.economy&&(c.economy.lastClaim||'')>(P.economy.lastClaim||''))P.economy=c.economy}\n  save();")
# refresh home update coins
s=s.replace("  $('sStreak').textContent=ar((P.daily.last===dayKey()||P.daily.last===yesterday())?P.daily.streak:0);", "  $('sStreak').textContent=ar((P.daily.last===dayKey()||P.daily.last===yesterday())?P.daily.streak:0);\n  $('homeCoins').textContent=ar(P.coins);")
# Win rewards: compute reward before timeout and add coins once per regular/daily completed
s=s.replace("  const stars=hearts,time=T('time',{t:fmt(elapsed)}),resultMeta=time+' · '+T('mistakes',{n:ar(mistakes)});", "  const stars=hearts,time=T('time',{t:fmt(elapsed)}),coinReward=(mode==='daily'?35:10+stars*10),resultMeta=time+' · '+T('mistakes',{n:ar(mistakes)});\n  P.coins+=coinReward;save();")
s=s.replace("p:resultMeta+' · '+T('streakN',{n:ar(P.daily.streak)}),", "p:resultMeta+' · '+T('streakN',{n:ar(P.daily.streak)})+' · '+T('coinsEarned',{n:ar(coinReward)}),")
s=s.replace("overlay({stars,t:T(stars===3?'perfectT':'wellDone'),p:resultMeta,", "overlay({stars,t:T(stars===3?'perfectT':'wellDone'),p:resultMeta+' · '+T('coinsEarned',{n:ar(coinReward)}),")
# Add economy functions and handlers before tools section
needle='/* ---------- tools ---------- */'
econ='''/* ---------- coins, daily login rewards and shop ---------- */
const DAILY_REWARDS=[10,15,20,25,30,40,100];
const COIN_PRICES={hints:60,guides:60};
function economyRefresh(){
  $('econCoins').textContent=ar(P.coins);$('homeCoins').textContent=ar(P.coins);
  const claimed=P.economy.lastClaim===dayKey();
  $('claimDaily').disabled=claimed;$('claimDaily').textContent=T(claimed?'claimedToday':'claimDaily');
  $('dayGrid').innerHTML=DAILY_REWARDS.map((n,i)=>{const done=i<P.economy.streak%7||claimed&&i===Math.min(6,P.economy.streak%7);return `<div class="daybox ${done?'done':''} ${!claimed&&i===P.economy.streak%7?'today':''}"><span>${T('day')} ${ar(i+1)}</span><b>◆${ar(n)}</b>${done?'✓':''}</div>`}).join('');
  $('shopItems').innerHTML='';
  for(const [kind,price,ico] of [['hints',COIN_PRICES.hints,'💡'],['guides',COIN_PRICES.guides,'➜']]){
    const row=document.createElement('div');row.className='shopitem';
    const name=T(kind==='hints'?'shopHints':'shopGuides');
    row.innerHTML=`<span class="si">${ico}</span><span><b>${name}</b><small>◆ ${ar(price)} · ${T(kind==='hints'?'hint':'paths')}</small></span><button type="button">${T('buy')}</button>`;
    const b=row.querySelector('button');b.disabled=P.coins<price;b.onclick=()=>{if(P.coins<price){toast(T('notEnough'));return}P.coins-=price;P[kind]+=3;save();updateTools();economyRefresh();toast(T('purchaseDone'))};
    $('shopItems').appendChild(row);
  }
}
function openEconomy(tab='daily'){
  $('economy').hidden=false;economyRefresh();economyTab(tab);
}
function economyTab(tab){
  const daily=tab==='daily';$('econDailyPanel').hidden=!daily;$('econShopPanel').hidden=daily;
  $('econDailyTab').classList.toggle('active',daily);$('econShopTab').classList.toggle('active',!daily);
  $('econTitle').textContent=T(daily?'dailyReward':'shop');$('dailyIntro').textContent=T('dailyIntro');$('shopIntro').textContent=T('shopIntro');
}
$('hDailyReward').onclick=()=>openEconomy('daily');$('hShop').onclick=()=>openEconomy('shop');
$('econDailyTab').onclick=()=>economyTab('daily');$('econShopTab').onclick=()=>economyTab('shop');
$('econClose').onclick=()=>{$('economy').hidden=true};
$('claimDaily').onclick=()=>{
  if(P.economy.lastClaim===dayKey())return;
  const prev=new Date();prev.setDate(prev.getDate()-1);const yesterdayKey=dayKey(prev);
  P.economy.streak=P.economy.lastClaim===yesterdayKey?(P.economy.streak%7)+1:1;
  const reward=DAILY_REWARDS[P.economy.streak-1]||10;P.economy.lastClaim=dayKey();P.coins+=reward;save();economyRefresh();refreshHome();toast(T('coinsEarned',{n:ar(reward)}));
};

'''
s=s.replace(needle,econ+needle)
# update Android back overlay
s=s.replace("if(!$('tut').hidden||!$('ov').hidden||!$('adR').hidden||!$('adI').hidden)return true;", "if(!$('tut').hidden||!$('ov').hidden||!$('adR').hidden||!$('adI').hidden)return true;\n    if(!$('economy').hidden){$('economy').hidden=true;return true;}")
# add close economy on language change? refresh text via applyLang
s=s.replace("  refreshChip();\n  for(const v", "  refreshChip();if(!$('economy').hidden){economyRefresh();economyTab($('econDailyPanel').hidden?'shop':'daily')}\n  for(const v")
p.write_text(s)
