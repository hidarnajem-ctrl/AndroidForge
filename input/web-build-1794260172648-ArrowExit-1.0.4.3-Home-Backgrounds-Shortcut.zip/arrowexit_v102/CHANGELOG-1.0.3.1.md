# Arrow Exit 1.0.3.1

## Shop pricing correction
- Hint price is now 400 coins in all eight supported languages.
- Path reveal price is now 400 coins in all eight supported languages.
- Purchase eligibility checks require at least 400 coins.
- Each successful purchase deducts exactly 400 coins.
- Existing world map, world chests, levels, daily rewards, ads, and save systems are retained.

## Android
- versionCode: 3
- versionName: 1.0.3.1

This is a source-project preview. Build and test the APK on the project owner's environment before release.
