# أوصاف صفحة المتجر (Google Play)
لكل لغة: **اسم التطبيق** (حتى ٣٠ حرفاً)، و**الوصف المختصر** (حتى ٨٠ حرفاً)، و**الوصف الكامل** (حتى ٤٠٠٠ حرف). انسخ كل قسم إلى Play Console ← حضور المتجر ← الترجمات.
ملاحظة: «العب حتى دون إنترنت» صحيحة للعب نفسه؛ الإعلانات والإنجازات والحفظ السحابي تحتاج اتصالاً.

---

## English (en-US)

**اسم التطبيق** (24/30)

```
Arrow Exit: Arrow Puzzle
```

**الوصف المختصر** (79/80)

```
Tap arrows in the right order and clear the board. A calm, clever logic puzzle.
```

**الوصف الكامل** (841/4000)

```
Every arrow points the way out. Your job is to find the right order.

Tap an arrow whose path is clear and it slides off the board, opening the way for the next one. Tap one that's blocked and you lose a life. Plan ahead and clear the board with a perfect run.

WHAT'S INSIDE
• Hundreds of levels that grow from gentle to tricky
• Boards in different shapes: heart, circle, diamond, cross and hourglass
• Timed levels for when you want a challenge
• Special arrows: locked, two-way and frozen
• A new daily challenge every day, with a streak to keep
• Stars for every level and 16 achievements
• Leaderboards and cloud save with Google Play Games
• Three color themes and a dark mode
• Hints and path guides when you're stuck

Short sessions, quiet design, and a satisfying whoosh as each arrow leaves the board. Play anywhere, even offline.
```

---

## العربية (ar)

**اسم التطبيق** (18/30)

```
مَخرَج: لغز الأسهم
```

**الوصف المختصر** (62/80)

```
المس الأسهم بالترتيب الصحيح وأفرغ اللوحة. لغز منطقي هادئ وذكي.
```

**الوصف الكامل** (657/4000)

```
كل سهم يشير إلى طريق الخروج، ومهمتك أن تجد الترتيب الصحيح.

المس سهماً طريقه مفتوح فينزلق خارج اللوحة ويفتح الطريق لغيره. أما إن لمست سهماً طريقه مسدود فستخسر قلباً. خطّط مسبقاً وأفرغ اللوحة بحل مثالي.

ماذا ستجد في اللعبة؟
• مئات المراحل تتدرّج من السهل إلى الصعب
• لوحات بأشكال مختلفة: قلب، دائرة، معيّن، صليب، ساعة رملية
• مراحل موقوتة لمن يحب التحدي
• أسهم خاصة: مقفلة، باتجاهين، ومجمّدة
• تحدٍّ يومي جديد كل يوم مع سلسلة أيام
• نجوم لكل مرحلة و١٦ إنجازاً
• لوحات صدارة وحفظ سحابي عبر Google Play Games
• ثلاث سمات ألوان ووضع داكن
• تلميحات وإظهار للمسارات عندما تحتار

جلسات قصيرة، تصميم هادئ، وصوت خروج مريح مع كل سهم. العب في أي مكان، حتى دون إنترنت.
```

---

## Español (es-ES / es-419)

**اسم التطبيق** (29/30)

```
Arrow Exit: Puzzle de flechas
```

**الوصف المختصر** (78/80)

```
Toca las flechas en el orden correcto y vacía el tablero. Un puzzle tranquilo.
```

**الوصف الكامل** (814/4000)

```
Cada flecha señala la salida. Tu misión es encontrar el orden correcto.

Toca una flecha con el camino libre y saldrá del tablero, abriendo paso a la siguiente. Si tocas una bloqueada, pierdes una vida. Planea tus jugadas y vacía el tablero sin errores.

QUÉ INCLUYE
• Cientos de niveles, de fáciles a desafiantes
• Tableros con formas: corazón, círculo, rombo, cruz y reloj de arena
• Niveles contrarreloj
• Flechas especiales: bloqueadas, dobles y congeladas
• Un reto diario nuevo cada día, con racha
• Estrellas en cada nivel y 16 logros
• Clasificaciones y guardado en la nube con Google Play Juegos
• Tres temas de color y modo oscuro
• Pistas y guía de rutas cuando te atasques

Partidas cortas, diseño relajante y un sonido satisfactorio con cada flecha que sale. Juega donde quieras, incluso sin conexión.
```

---

## Português (pt-BR)

**اسم التطبيق** (25/30)

```
Arrow Exit: Quebra-cabeça
```

**الوصف المختصر** (75/80)

```
Toque nas setas na ordem certa e esvazie o tabuleiro. Um desafio relaxante.
```

**الوصف الكامل** (784/4000)

```
Cada seta aponta a saída. Sua missão é descobrir a ordem certa.

Toque em uma seta com o caminho livre e ela sai do tabuleiro, abrindo espaço para a próxima. Toque em uma bloqueada e você perde uma vida. Planeje e esvazie o tabuleiro sem erros.

O QUE TEM NO JOGO
• Centenas de fases, das fáceis às desafiadoras
• Tabuleiros com formatos: coração, círculo, losango, cruz e ampulheta
• Fases cronometradas
• Setas especiais: trancadas, duplas e congeladas
• Um desafio diário novo todo dia, com sequência
• Estrelas em cada fase e 16 conquistas
• Placares e salvamento na nuvem com o Google Play Games
• Três temas de cores e modo escuro
• Dicas e guia de rotas quando travar

Partidas curtas, visual tranquilo e um som gostoso a cada seta que sai. Jogue onde quiser, até sem internet.
```

---

## Bahasa Indonesia (id)

**اسم التطبيق** (27/30)

```
Arrow Exit: Teka-teki Panah
```

**الوصف المختصر** (75/80)

```
Ketuk panah dengan urutan yang tepat dan kosongkan papan. Teka-teki santai.
```

**الوصف الكامل** (865/4000)

```
Setiap panah menunjuk jalan keluar. Tugasmu adalah menemukan urutan yang tepat.

Ketuk panah yang jalannya terbuka, dan panah itu meluncur keluar papan serta membuka jalan bagi panah lain. Ketuk panah yang terhalang, dan nyawamu berkurang. Rencanakan langkahmu dan kosongkan papan tanpa kesalahan.

FITUR
• Ratusan level dari mudah hingga menantang
• Papan berbagai bentuk: hati, lingkaran, belah ketupat, silang, jam pasir
• Level berwaktu untuk tantangan lebih
• Panah khusus: terkunci, dua arah, dan beku
• Tantangan harian baru setiap hari, dengan hari beruntun
• Bintang di setiap level dan 16 pencapaian
• Papan peringkat dan simpan cloud dengan Google Play Games
• Tiga tema warna dan mode gelap
• Petunjuk dan panduan jalur saat kamu buntu

Sesi singkat, desain tenang, dan suara memuaskan setiap kali panah keluar. Main di mana saja, bahkan tanpa internet.
```

---

## Türkçe (tr)

**اسم التطبيق** (24/30)

```
Arrow Exit: Ok Bulmacası
```

**الوصف المختصر** (74/80)

```
Okları doğru sırayla dokun ve tahtayı boşalt. Sakin ve zekice bir bulmaca.
```

**الوصف الكامل** (718/4000)

```
Her ok çıkışı gösterir. Senin görevin doğru sırayı bulmak.

Yolu açık bir oka dokun; tahtadan kayarak çıkar ve sıradaki oka yol açar. Yolu kapalı bir oka dokunursan bir can kaybedersin. Önceden plan yap ve tahtayı hatasız boşalt.

OYUNDA NELER VAR
• Kolaydan zora yüzlerce bölüm
• Farklı şekillerde tahtalar: kalp, daire, karo, artı ve kum saati
• Süreli bölümler
• Özel oklar: kilitli, çift yönlü ve donmuş
• Her gün yeni bir günlük görev ve seri
• Her bölümde yıldızlar ve 16 başarım
• Google Play Games ile sıralamalar ve bulut kaydı
• Üç renk teması ve karanlık mod
• Takıldığında ipuçları ve yol rehberi

Kısa oturumlar, sakin tasarım ve her ok çıktığında tatmin edici bir ses. İnternet olmadan da her yerde oyna.
```

---

## Русский (ru)

**اسم التطبيق** (23/30)

```
Arrow Exit: головоломка
```

**الوصف المختصر** (72/80)

```
Нажимай на стрелки в правильном порядке и очисти поле. Спокойная логика.
```

**الوصف الكامل** (773/4000)

```
Каждая стрелка указывает на выход. Твоя задача — найти правильный порядок.

Нажми на стрелку со свободным путём, и она уедет с поля, освобождая дорогу следующей. Нажмёшь на заблокированную — потеряешь жизнь. Думай наперёд и очисти поле без ошибок.

ЧТО ВНУТРИ
• Сотни уровней — от простых до сложных
• Поля разных форм: сердце, круг, ромб, крест и песочные часы
• Уровни на время
• Особые стрелки: запертые, двусторонние и замёрзшие
• Новое задание дня каждый день и серия дней
• Звёзды за каждый уровень и 16 достижений
• Таблицы рекордов и облачное сохранение в Google Play Играх
• Три цветовые темы и тёмный режим
• Подсказки и показ путей, если застрял

Короткие партии, спокойный дизайн и приятный звук с каждой уходящей стрелкой. Играй где угодно, даже без интернета.
```

---

## Français (fr-FR)

**اسم التطبيق** (30/30)

```
Arrow Exit : Puzzle de flèches
```

**الوصف المختصر** (76/80)

```
Touche les flèches dans le bon ordre et vide le plateau. Un puzzle apaisant.
```

**الوصف الكامل** (845/4000)

```
Chaque flèche indique la sortie. À toi de trouver le bon ordre.

Touche une flèche dont le chemin est libre : elle quitte le plateau et ouvre la voie à la suivante. Touche une flèche bloquée et tu perds une vie. Anticipe et vide le plateau sans faute.

AU PROGRAMME
• Des centaines de niveaux, des plus simples aux plus corsés
• Des plateaux en forme de cœur, cercle, losange, croix et sablier
• Des niveaux chronométrés
• Des flèches spéciales : verrouillées, doubles et gelées
• Un nouveau défi du jour chaque jour, avec ta série
• Des étoiles à chaque niveau et 16 succès
• Classements et sauvegarde cloud avec Google Play Jeux
• Trois thèmes de couleurs et un mode sombre
• Indices et affichage des chemins quand tu bloques

Des parties courtes, un design calme et un son agréable à chaque flèche qui sort. Joue partout, même hors connexion.
```
