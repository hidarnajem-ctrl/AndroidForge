# Arrow Exit 1.0.3 — Worlds & Treasure Chests

- Added a six-world progression map, each world containing 20 levels.
- Added per-world treasure chests with one-time rewards (coins, one hint, one path).
- Added local persistence and cloud-save merge support for claimed world chests.
- Preserved existing levels, daily challenge, stars, achievements, shop, ads, languages and gameplay.
- Existing level progress unlocks worlds automatically; world chests unlock after all 20 levels in that world are completed.

Preview build: verify Android packaging and Play Games cloud restore on device before release.
