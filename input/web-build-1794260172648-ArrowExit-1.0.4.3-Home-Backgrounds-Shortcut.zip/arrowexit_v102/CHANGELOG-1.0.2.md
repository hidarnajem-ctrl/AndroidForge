# Arrow Exit 1.0.2 – Economy Update (Preview)

- Added a persistent coin wallet on the home screen.
- First-time level completion grants 20–40 coins based on the star result; replaying a completed level does not farm coins.
- Added one daily login reward per local calendar day (25 coins, increasing by current daily-challenge streak up to 60).
- Added a tool shop: hints and path guides cost 40 coins each.
- Saved coin balance, daily claim date, and rewarded-level ledger locally; included them in the existing Play Games cloud payload/merge.
- Preserved existing game board, levels, eight languages, hearts, ads, hints, paths, and achievements.

## Validation
- JavaScript syntax checked with Node.js.
- Android APK build was not run in this environment because the Gradle 8.13 distribution is not cached and network download is unavailable.
- Please build and test on the same Android setup used for the 1.0.1 preview before publishing.
