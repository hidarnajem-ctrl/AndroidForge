# Arrow Exit 1.0.4.1 — Rewarded Cosmetic Unlock

- Added an optional **Watch an ad to unlock** action to unowned cosmetic items when the player's coin balance is below that item's price.
- Uses the existing native AdMob rewarded-ad unit, `AdsManager`, JavaScript bridge, and UMP consent flow. No new ad unit or SDK was introduced.
- The selected cosmetic is unlocked and equipped only after the native rewarded callback confirms the reward (`result == 1`).
- Closing the ad early, a show failure, or no-fill grants no cosmetic and deducts no coins.
- Added a guard against duplicate concurrent reward requests and re-checks ownership before granting.
- Preserved direct coin purchases, existing themes/palettes, worlds, chests, game levels, and existing AdMob banner/interstitial/rewarded behavior.
- Added localized reward labels/messages for all eight supported languages.
