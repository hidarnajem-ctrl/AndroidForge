# Arrow Exit 1.0.4.3

- Added a compact two-button home shortcut row for Worlds and Backgrounds.
- Added direct access to the cosmetic shop's Backgrounds tab from the home screen.
- Removed the duplicate cosmetic-shop entry from Settings.
- Kept the arrow-style tab, rewarded-ad unlock flow, coin purchases, ownership, and equipped-theme persistence.
- Bumped Android versionCode to 7 and versionName to 1.0.4.3.

Build verification: JavaScript syntax and HTML/runtime synchronization checked. Android APK build not performed in this environment.
