# Arrow Exit 1.0.4.2 — Startup and Board Rendering Fix

## Root cause
The 1.0.4.1 JavaScript bootstrap attempted to attach a click handler to `#setCosmetics`, but the Settings markup did not contain that element. This threw a `TypeError` during startup and stopped the remainder of the game initialization. As a result, the app could show partial UI while the home/game initialization and board animation loop never started.

## Fix
- Added a visible Cosmetic Shop button to Settings, using the existing translated `cosmeticShop` label.
- Guarded the optional button binding so a future markup mismatch cannot abort the whole game startup.
- Synchronized `game.js` with the packaged `app/src/main/assets/index.html` script to prevent source/package drift.
- Preserved the existing AdMob rewarded-ad callback and reward flow, cosmetics, levels, worlds, coins, chests, and other game features.
- Updated Android version to versionCode 6 / versionName 1.0.4.2.

## Verification
- JavaScript syntax check passed.
- Headless Chromium startup completed without JavaScript page errors.
- Started Level 1 and confirmed the board canvas was sized and arrows rendered.
- Opened Settings → Cosmetic Shop and confirmed cosmetic cards and rewarded-ad buttons rendered.
- Android APK build was not run in this environment.
