# Arrow Exit 1.0.3.1

Patch release based on Arrow Exit 1.0.3.

Shop prices:
- Hint: 400 coins
- Path reveal: 400 coins

Both the displayed price and the actual deduction/affordability checks use 400 coins.

Build with Android Studio / Gradle using Java 17. Test the shop with balances below 400, exactly 400, and above 400 before publishing.
