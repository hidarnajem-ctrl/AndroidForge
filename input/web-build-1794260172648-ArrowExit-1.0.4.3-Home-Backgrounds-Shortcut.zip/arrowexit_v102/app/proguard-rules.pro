# Keep the methods the game page calls through window.AndroidBridge
-keepattributes JavascriptInterface
-keepclassmembers class com.arrowexit.game.WebBridge {
    @android.webkit.JavascriptInterface <methods>;
}
