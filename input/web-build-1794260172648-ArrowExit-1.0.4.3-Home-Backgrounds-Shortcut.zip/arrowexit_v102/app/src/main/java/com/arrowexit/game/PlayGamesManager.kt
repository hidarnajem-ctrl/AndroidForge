package com.arrowexit.game

import android.app.Activity
import com.google.android.gms.games.PlayGames
import com.google.android.gms.games.SnapshotsClient
import com.google.android.gms.games.snapshot.SnapshotMetadataChange
import org.json.JSONObject

/**
 * Google Play Games Services v2: automatic sign-in, achievements, leaderboards and cloud save.
 *
 * The game uses its own keys (e.g. "first_win", "stars"). The matching Play Console IDs go in
 * res/values/games.xml as ach_<key> and lb_<key>. While game_services_project_id is "0",
 * Play Games stays off and progress is kept on the device only.
 */
class PlayGamesManager(
    private val act: Activity,
    private val runJs: (String) -> Unit,
) {
    private val enabled: Boolean =
        act.getString(R.string.game_services_project_id).let { it.isNotBlank() && it != "0" }
    private var started = false
    private var signedIn = false

    // Cloud save is serialized: one write at a time, keeping only the newest pending one.
    private var saving = false
    private var pendingSave: String? = null

    /** Called when the page is ready to receive events. */
    fun onPageReady() {
        if (!enabled) { sendState(); return }
        if (!started) {
            started = true
            PlayGames.getGamesSignInClient(act).isAuthenticated.addOnCompleteListener { task ->
                setSignedIn(task.isSuccessful && task.result.isAuthenticated)
            }
        } else sendState()
    }

    fun signIn() {
        if (!enabled) return
        PlayGames.getGamesSignInClient(act).signIn().addOnCompleteListener { task ->
            setSignedIn(task.isSuccessful && task.result.isAuthenticated)
        }
    }

    private fun setSignedIn(value: Boolean) {
        signedIn = value
        sendState()
        if (value) loadProgress()
    }

    private fun sendState() = runJs("window.NativeEvents&&NativeEvents.pgsState($signedIn,$enabled)")

    /** Looks up ach_<key> / lb_<key> in games.xml; null until a real ID is filled in. */
    private fun idFor(prefix: String, key: String): String? {
        val res = act.resources.getIdentifier(prefix + key, "string", act.packageName)
        if (res == 0) return null
        return act.getString(res).takeIf { it.isNotBlank() && !it.startsWith("REPLACE") }
    }

    fun unlock(key: String) {
        if (!signedIn) return
        idFor("ach_", key)?.let { PlayGames.getAchievementsClient(act).unlock(it) }
    }

    fun setSteps(key: String, steps: Int) {
        if (!signedIn || steps <= 0) return
        idFor("ach_", key)?.let { PlayGames.getAchievementsClient(act).setSteps(it, steps) }
    }

    fun submitScore(board: String, score: Long) {
        if (!signedIn || score <= 0) return
        idFor("lb_", board)?.let { PlayGames.getLeaderboardsClient(act).submitScore(it, score) }
    }

    @Suppress("DEPRECATION")
    fun showAchievements() {
        PlayGames.getAchievementsClient(act).achievementsIntent
            .addOnSuccessListener { act.startActivityForResult(it, RC_UI) }
    }

    @Suppress("DEPRECATION")
    fun showLeaderboards() {
        PlayGames.getLeaderboardsClient(act).allLeaderboardsIntent
            .addOnSuccessListener { act.startActivityForResult(it, RC_UI) }
    }

    // ---- cloud save (Saved Games must be turned on in Play Console) ----
    fun saveProgress(json: String) {
        if (!signedIn) return
        if (saving) { pendingSave = json; return }
        saving = true
        val client = PlayGames.getSnapshotsClient(act)
        client.open(SNAPSHOT, true, SnapshotsClient.RESOLUTION_POLICY_MOST_RECENTLY_MODIFIED)
            .addOnSuccessListener { result ->
                val snapshot = result.data
                if (snapshot == null) { finishSave(); return@addOnSuccessListener }
                snapshot.snapshotContents.writeBytes(json.toByteArray(Charsets.UTF_8))
                val change = SnapshotMetadataChange.Builder().setDescription("Progress").build()
                client.commitAndClose(snapshot, change).addOnCompleteListener { finishSave() }
            }
            .addOnFailureListener { finishSave() }
    }

    private fun finishSave() {
        saving = false
        pendingSave?.let { pendingSave = null; saveProgress(it) }
    }

    private fun loadProgress() {
        val client = PlayGames.getSnapshotsClient(act)
        client.open(SNAPSHOT, true, SnapshotsClient.RESOLUTION_POLICY_MOST_RECENTLY_MODIFIED)
            .addOnSuccessListener { result ->
                val snapshot = result.data ?: return@addOnSuccessListener
                val bytes = runCatching { snapshot.snapshotContents.readFully() }.getOrNull()
                client.discardAndClose(snapshot)
                if (bytes != null && bytes.isNotEmpty()) {
                    val text = String(bytes, Charsets.UTF_8)
                    runJs("window.NativeEvents&&NativeEvents.cloudLoad(${JSONObject.quote(text)})")
                }
            }
    }

    companion object {
        private const val SNAPSHOT = "progress"
        private const val RC_UI = 9001
    }
}
