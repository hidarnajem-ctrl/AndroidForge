package com.arrowexit.game

import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat

/**
 * Hosts the game page (assets/index.html) in a WebView, with a native AdMob banner under it.
 * The page talks to Android through [WebBridge] (window.AndroidBridge) and receives events
 * through window.NativeEvents (see [runJs]).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    lateinit var ads: AdsManager
        private set
    lateinit var games: PlayGamesManager
        private set

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Draw edge to edge, then pad the content so nothing sits under the status/navigation bars.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = !night
            isAppearanceLightNavigationBars = !night
        }
        val root = findViewById<View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        web = findViewById(R.id.web)
        web.setBackgroundColor(ContextCompat.getColor(this, R.color.bg))
        web.overScrollMode = View.OVER_SCROLL_NEVER

        // Serve assets from https://appassets.androidplatform.net/assets/ so localStorage works normally.
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == ASSET_HOST) return false
                // Any outside link opens in the browser, never inside the game.
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, request.url)) }
                return true
            }
        }
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
            textZoom = 100
        }

        ads = AdsManager(this, findViewById<FrameLayout>(R.id.bannerHost), ::runJs)
        games = PlayGamesManager(this, ::runJs)
        web.addJavascriptInterface(WebBridge(this), "AndroidBridge")
        web.loadUrl("https://$ASSET_HOST/assets/index.html")

        // Back button: let the game close dialogs / go to its home screen first.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.NativeEvents?String(window.NativeEvents.back()):'false'") { result ->
                    if (result != "\"true\"") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })

        ads.start()
    }

    /** Runs JavaScript in the page on the UI thread. */
    fun runJs(script: String) {
        runOnUiThread { if (!isFinishing) web.evaluateJavascript(script, null) }
    }

    override fun onPause() {
        ads.onPause()
        web.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        ads.onResume()
    }

    override fun onDestroy() {
        ads.onDestroy()
        web.destroy()
        super.onDestroy()
    }

    companion object {
        const val ASSET_HOST = "appassets.androidplatform.net"
    }
}
