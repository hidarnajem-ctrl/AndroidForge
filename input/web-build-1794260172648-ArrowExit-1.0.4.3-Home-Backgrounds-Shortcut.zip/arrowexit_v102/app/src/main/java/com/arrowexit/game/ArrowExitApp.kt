package com.arrowexit.game

import android.app.Application
import com.google.android.gms.games.PlayGamesSdk

class ArrowExitApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Play Games is initialized once per process, as Google recommends, but only when configured.
        val id = getString(R.string.game_services_project_id)
        if (id.isNotBlank() && id != "0") PlayGamesSdk.initialize(this)
    }
}
