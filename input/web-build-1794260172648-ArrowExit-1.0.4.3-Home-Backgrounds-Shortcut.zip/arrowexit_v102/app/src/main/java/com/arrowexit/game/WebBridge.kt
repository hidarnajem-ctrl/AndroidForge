package com.arrowexit.game

import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.webkit.JavascriptInterface

/**
 * Methods the game page can call as window.AndroidBridge.*.
 * They arrive on a background thread, so anything touching views is posted to the UI thread.
 */
class WebBridge(private val act: MainActivity) {

    private fun ui(block: () -> Unit) = act.runOnUiThread(block)

    /** The page has loaded and window.NativeEvents is ready to receive events. */
    @JavascriptInterface fun ready() = ui { act.games.onPageReady() }

    // ---- ads ----
    @JavascriptInterface fun setBanner(show: Boolean) = ui { act.ads.setBanner(show) }
    @JavascriptInterface fun showInterstitial(id: Int) = ui { act.ads.showInterstitial(id) }
    @JavascriptInterface fun showRewarded(id: Int) = ui { act.ads.showRewarded(id) }
    @JavascriptInterface fun privacyRequired(): Boolean = act.ads.privacyOptionsRequired()
    @JavascriptInterface fun privacyOptions() = ui { act.ads.showPrivacyOptions() }

    // ---- Play Games ----
    @JavascriptInterface fun pgsSignIn() = ui { act.games.signIn() }
    @JavascriptInterface fun pgsUnlock(key: String) = ui { act.games.unlock(key) }
    @JavascriptInterface fun pgsSteps(key: String, steps: Double) = ui { act.games.setSteps(key, steps.toInt()) }
    @JavascriptInterface fun pgsSubmit(board: String, score: Double) = ui { act.games.submitScore(board, score.toLong()) }
    @JavascriptInterface fun pgsShowAchievements() = ui { act.games.showAchievements() }
    @JavascriptInterface fun pgsShowLeaderboards() = ui { act.games.showLeaderboards() }
    @JavascriptInterface fun pgsSave(json: String) = ui { act.games.saveProgress(json) }

    // ---- haptics (navigator.vibrate is not available inside a WebView) ----
    @JavascriptInterface fun vibrate(ms: Double) {
        val duration = ms.toLong().coerceIn(1, 400)
        val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (act.getSystemService(VibratorManager::class.java))?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            act.getSystemService(Vibrator::class.java)
        }
        vibrator?.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE))
    }
}
