# Arrow Exit 1.0.4.1

## Rewarded cosmetic unlock
When a player has fewer coins than the price of an unowned cosmetic, its card offers an optional **Watch an ad to unlock** button. The Android app uses the existing AdMob rewarded unit and existing consent flow. The selected cosmetic is unlocked and equipped only when AdMob reports that the reward was earned. No coins are deducted.

If the player closes the ad early, the ad fails to show, or no ad is available, no cosmetic is granted. Existing coin purchases and all previous game features remain available.

## Safe testing
Before testing on your phone, register it as an AdMob test device or temporarily use Google's rewarded test ad unit. Never click your own live ads. A real rewarded-ad fill is not guaranteed on every request.

Version: 1.0.4.1 (versionCode 5).
