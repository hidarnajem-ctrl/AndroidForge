# Arrow Exit — UX polish preview

This is a conservative first gameplay/UX update. Existing game rules, level generation, saves, ads integration, languages, and Android bridge are retained.

## Changes
- Added a localized mistake count to the level-complete and daily-challenge result summary.
- Added a subtle particle trail while arrows leave the board.
- Slightly enlarged the arrow tap-selection tolerance while preserving nearest-arrow selection.
- Added a short entrance animation to result/tutorial overlays.
- Respects the device's reduced-motion accessibility preference for overlay animations.
- Kept `game.js` identical to the JavaScript embedded in `app/src/main/assets/index.html`.

## Checks performed
- JavaScript syntax check: passed.
- Embedded JavaScript/source parity: passed.
- Level generator regression: 300 generated levels, 0 unsolvable results in the greedy solvability check (6,955 arrows total).
- Android APK build: not verified; Gradle 8.13 could not be downloaded because this environment could not reach `services.gradle.org`.

## Signing-key safety
The ZIP intentionally excludes the `keystore/` directory and all signing credentials. Keep the original upload keystore and passwords in a secure offline backup. If the app is already published, you must continue using the same valid upload key (or the Play Console's configured upload-key reset process); do not replace it casually.
