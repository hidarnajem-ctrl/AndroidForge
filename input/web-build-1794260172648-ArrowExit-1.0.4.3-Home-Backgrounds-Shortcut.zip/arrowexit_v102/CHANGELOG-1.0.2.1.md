# Arrow Exit 1.0.2.1 — Shop polish

- Removed the duplicate close action from the economy/shop dialog. The dialog now uses the existing dedicated close button only.
- Redesigned the shop balance as a clearly visible wallet row with a coin icon and emphasized amount.
- Added a clear insufficient-coins notice.
- Disabled both purchase buttons when the player has fewer than 40 coins, preventing confusing failed purchases.
- Kept the existing 40-coin price, purchase effects, save keys, daily reward logic, level rewards, language strings, ads, and gameplay unchanged.
- Updated both `app/src/main/assets/index.html` (the Android WebView source) and the root `game.js` copy.

## Validation
- `node --check` passed for the embedded game script.
- `node --check` passed for the root `game.js`.
- APK build was not run in this environment.
