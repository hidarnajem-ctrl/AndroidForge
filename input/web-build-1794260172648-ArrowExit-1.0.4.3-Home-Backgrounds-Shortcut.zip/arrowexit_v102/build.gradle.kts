// Android Studio may offer newer plugin versions when you open the project; accepting them is fine.
plugins {
    id("com.android.application") version "8.11.1" apply false
    // Must be 2.3+ : play-services-ads 25.x is compiled with Kotlin 2.3.
    id("org.jetbrains.kotlin.android") version "2.3.0" apply false
}
