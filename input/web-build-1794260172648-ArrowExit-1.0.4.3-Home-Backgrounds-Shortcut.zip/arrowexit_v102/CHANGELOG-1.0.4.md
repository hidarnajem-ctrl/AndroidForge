# Arrow Exit 1.0.4 — Cosmetic Shop

- Added a cosmetic shop reachable from Settings.
- Added four premium board themes: Ocean, Rose, Midnight, and Sunset.
- Added three arrow palettes: Aurora, Candy, and Golden.
- Items are purchased once with in-game coins and can be equipped again without paying.
- Ownership and equipped cosmetics are stored locally and included in Play Games cloud save data.
- Existing worlds, chests, levels, lives, tool shop prices (400 coins), daily rewards, ads, languages, and gameplay are retained.

This is a preview build. A real Android APK build and device testing are still required.
