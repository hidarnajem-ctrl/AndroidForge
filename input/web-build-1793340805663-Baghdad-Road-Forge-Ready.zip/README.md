# Baghdad Road

تم إصلاح مشكلة الإغلاق المفاجئ للتطبيق عبر التعديلات التالية:
1. استبدال `AppCompatActivity` بـ `ComponentActivity` في ملف `MainActivity.kt`.
2. تعديل ملف `AndroidManifest.xml` لدعم `usesCleartextTraffic="true"` لضمان تحميل الخريطة بسلاسة.
3. توفير ملفات بناء `build.gradle.kts` مكتملة لدعم مكتبة `osmdroid` الخاصة بالخرائط.

قم برفع هذا الملف المضغوط إلى موقع Android forge للبناء بشكل مباشر.
