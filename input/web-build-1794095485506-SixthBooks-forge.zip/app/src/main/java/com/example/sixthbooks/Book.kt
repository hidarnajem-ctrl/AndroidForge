package com.example.sixthbooks

data class Book(
    val title: String,
    val subject: String,
    val url: String,
    val sizeMb: Int
) {
    /** اسم الملف كما هو في الرابط، ويُستخدم كمعرّف فريد وكاسم للملف المحفوظ */
    val fileName: String get() = url.substringAfterLast('/')
}
