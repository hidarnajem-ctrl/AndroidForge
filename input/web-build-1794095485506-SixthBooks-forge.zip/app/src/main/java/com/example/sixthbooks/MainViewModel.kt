package com.example.sixthbooks

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = BookRepository(app)

    var books by mutableStateOf<List<Book>>(emptyList())
        private set
    var loading by mutableStateOf(true)
        private set
    var failed by mutableStateOf(false)
        private set
    var downloaded by mutableStateOf<Set<String>>(emptySet())
        private set

    /** تقدّم التحميل (0..1) لكل كتاب قيد التحميل */
    val progress = mutableStateMapOf<String, Float>()

    var message by mutableStateOf<String?>(null)
    var query by mutableStateOf("")
    var subject by mutableStateOf<String?>(null)

    private val jobs = mutableMapOf<String, Job>()

    val subjects: List<String> get() = books.map { it.subject }.filter { it.isNotBlank() }.distinct()

    val filtered: List<Book>
        get() = books.filter { b ->
            (subject == null || b.subject == subject) &&
                (query.isBlank() || b.title.contains(query.trim()))
        }

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            loading = true
            failed = false
            repo.loadBooks()
                .onSuccess {
                    books = it
                    downloaded = it.filter { b -> repo.isDownloaded(b) }.map { b -> b.fileName }.toSet()
                }
                .onFailure { failed = true }
            loading = false
        }
    }

    fun download(book: Book) {
        val key = book.fileName
        if (jobs.containsKey(key)) return
        jobs[key] = viewModelScope.launch {
            progress[key] = 0f
            try {
                repo.download(book) { progress[key] = it }
                downloaded = downloaded + key
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = "تعذّر التحميل، تأكد من اتصالك بالإنترنت وحاول مرة أخرى"
            } finally {
                progress.remove(key)
                jobs.remove(key)
            }
        }
    }

    fun cancel(book: Book) {
        jobs[book.fileName]?.cancel()
    }

    fun delete(book: Book) {
        repo.delete(book)
        downloaded = downloaded - book.fileName
    }

    fun file(book: Book): File = repo.localFile(book)
}
