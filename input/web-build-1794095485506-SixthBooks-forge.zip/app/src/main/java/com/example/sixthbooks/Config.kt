package com.example.sixthbooks

/**
 * كل الإعدادات التي تحتاج تغييرها قبل النشر موجودة هنا.
 * معرّفات الإعلانات الحالية هي معرّفات اختبار رسمية من Google، استبدلها بمعرّفاتك الحقيقية.
 * (معرّف تطبيق AdMob نفسه يوضع في app/build.gradle.kts داخل admobAppId)
 */
object Config {
    const val BOOKS_JSON_URL =
        "https://pub-ead7102558aa4f74a05896836f77c054.r2.dev/books.json"

    // معرّفات اختبار
    const val BANNER_ID = "ca-app-pub-3940256099942544/9214589741"
    const val INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"

    // يظهر إعلان بيني كل N مرة يفتح فيها المستخدم كتاباً
    const val INTERSTITIAL_EVERY_N_OPENS = 3
}
