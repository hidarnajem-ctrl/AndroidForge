package com.example.sixthbooks

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HomeScreen(vm: MainViewModel, onOpen: (Book) -> Unit) {
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) {
        val msg = vm.message
        if (msg != null) {
            snackbar.showSnackbar(msg)
            vm.message = null
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = { BannerAd(Modifier.navigationBarsPadding()) },
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0)
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
        ) {
            Header(vm)
            when {
                vm.loading -> CenterBox { CircularProgressIndicator() }
                vm.failed && vm.books.isEmpty() -> ErrorState(onRetry = vm::refresh)
                else -> BookList(vm, onOpen)
            }
        }
    }
}

@Composable
private fun CenterBox(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { content() }
}

@Composable
private fun ErrorState(onRetry: () -> Unit) {
    CenterBox {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
            Text(
                "تعذّر تحميل قائمة الكتب",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "تأكد من اتصالك بالإنترنت ثم أعد المحاولة",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = onRetry) { Text("إعادة المحاولة") }
        }
    }
}

@Composable
private fun Header(vm: MainViewModel) {
    Box(
        Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(listOf(Color(0xFF1E4DB7), Color(0xFF3F6FE0))),
                RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp)
            )
            .statusBarsPadding()
            .padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 20.dp)
    ) {
        Column {
            Text(
                "كتب الصف السادس الابتدائي",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                "المنهج العراقي • 2026 - 2027",
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 14.sp
            )
            Spacer(Modifier.height(14.dp))
            TextField(
                value = vm.query,
                onValueChange = { vm.query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                placeholder = { Text("ابحث عن كتاب...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (vm.query.isNotEmpty()) {
                        IconButton(onClick = { vm.query = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "مسح")
                        }
                    }
                },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = Color(0xFF1B1F2A),
                    unfocusedTextColor = Color(0xFF1B1F2A),
                    focusedPlaceholderColor = Color(0xFF7A8194),
                    unfocusedPlaceholderColor = Color(0xFF7A8194),
                    focusedLeadingIconColor = Color(0xFF4A5164),
                    unfocusedLeadingIconColor = Color(0xFF4A5164),
                    focusedTrailingIconColor = Color(0xFF4A5164),
                    unfocusedTrailingIconColor = Color(0xFF4A5164)
                )
            )
        }
    }
}

@Composable
private fun BookList(vm: MainViewModel, onOpen: (Book) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FilterChip(
                    selected = vm.subject == null,
                    onClick = { vm.subject = null },
                    label = { Text("الكل") }
                )
            }
            items(vm.subjects) { s ->
                FilterChip(
                    selected = vm.subject == s,
                    onClick = { vm.subject = if (vm.subject == s) null else s },
                    label = { Text(s) }
                )
            }
        }

        val list = vm.filtered
        if (list.isEmpty()) {
            CenterBox {
                Text("لا توجد نتائج", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(list, key = { it.url }) { book ->
                    BookCard(
                        book = book,
                        isDownloaded = book.fileName in vm.downloaded,
                        progress = vm.progress[book.fileName],
                        onOpen = { onOpen(book) },
                        onDownload = { vm.download(book) },
                        onCancel = { vm.cancel(book) },
                        onDelete = { vm.delete(book) }
                    )
                }
            }
        }
    }
}

private fun subjectColors(subject: String): Pair<Color, Color> = when {
    subject.contains("رياض") -> Color(0xFF1E88E5) to Color(0xFF0D47A1)
    subject.contains("علوم") -> Color(0xFF43A047) to Color(0xFF1B5E20)
    subject.contains("عربي") -> Color(0xFFE53935) to Color(0xFF8E0000)
    subject.contains("إنجليزي") || subject.contains("انجليزي") -> Color(0xFF8E24AA) to Color(0xFF4A148C)
    subject.contains("إسلام") || subject.contains("اسلام") -> Color(0xFF00897B) to Color(0xFF004D40)
    subject.contains("اجتماع") -> Color(0xFFFB8C00) to Color(0xFFE65100)
    else -> Color(0xFF546E7A) to Color(0xFF263238)
}

@Composable
private fun BookCard(
    book: Book,
    isDownloaded: Boolean,
    progress: Float?,
    onOpen: () -> Unit,
    onDownload: () -> Unit,
    onCancel: () -> Unit,
    onDelete: () -> Unit
) {
    val (c1, c2) = subjectColors(book.subject)
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(width = 68.dp, height = 88.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Brush.linearGradient(listOf(c1, c2))),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    book.subject,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(4.dp)
                )
            }

            Column(
                Modifier
                    .weight(1f)
                    .padding(start = 12.dp)
            ) {
                Text(
                    book.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    if (book.sizeMb > 0) "${book.subject} • ${book.sizeMb} ميغابايت" else book.subject,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))

                when {
                    progress != null -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp))
                            )
                            Spacer(Modifier.size(8.dp))
                            Text("${(progress * 100).toInt()}%", fontSize = 12.sp)
                            TextButton(onClick = onCancel) { Text("إلغاء") }
                        }
                    }

                    isDownloaded -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(
                                onClick = onOpen,
                                contentPadding = PaddingValues(horizontal = 22.dp, vertical = 6.dp),
                                modifier = Modifier.height(38.dp)
                            ) { Text("فتح") }
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = onDelete) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "حذف من الجهاز",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    else -> {
                        Button(
                            onClick = onDownload,
                            contentPadding = PaddingValues(horizontal = 22.dp, vertical = 6.dp),
                            modifier = Modifier.height(38.dp)
                        ) { Text("تحميل") }
                    }
                }
            }
        }
    }
}
