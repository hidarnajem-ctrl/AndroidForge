package com.example.sixthbooks

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // الشريط العلوي أزرق دائماً، فنجعل أيقوناته فاتحة
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        AdManager.init(applicationContext)

        setContent {
            AppTheme {
                // واجهة عربية بالكامل (من اليمين لليسار)
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    var openName by rememberSaveable { mutableStateOf<String?>(null) }
                    val openBook = vm.books.firstOrNull { it.fileName == openName }

                    if (openBook != null) {
                        ReaderScreen(
                            book = openBook,
                            file = vm.file(openBook),
                            onBack = { openName = null }
                        )
                    } else {
                        HomeScreen(vm) { book ->
                            AdManager.maybeShowInterstitial(this@MainActivity) {
                                openName = book.fileName
                            }
                        }
                    }
                }
            }
        }
    }
}
