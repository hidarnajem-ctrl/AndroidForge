package com.example.sixthbooks

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class BookRepository(context: Context) {

    private val booksDir = File(context.filesDir, "books").apply { mkdirs() }
    private val cacheFile = File(context.filesDir, "books.json")

    /** يحمّل قائمة الكتب من الإنترنت، وإن فشل يستخدم آخر نسخة محفوظة */
    suspend fun loadBooks(): Result<List<Book>> = withContext(Dispatchers.IO) {
        try {
            val text = httpGet(Config.BOOKS_JSON_URL)
            val books = parse(text)
            cacheFile.writeText(text)
            Result.success(books)
        } catch (e: Exception) {
            if (cacheFile.exists()) {
                try {
                    Result.success(parse(cacheFile.readText()))
                } catch (e2: Exception) {
                    Result.failure(e2)
                }
            } else {
                Result.failure(e)
            }
        }
    }

    private fun parse(text: String): List<Book> {
        val arr = JSONObject(text).getJSONArray("books")
        return List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Book(
                title = o.getString("title"),
                subject = o.optString("subject", ""),
                url = o.getString("url"),
                sizeMb = o.optInt("size_mb", 0)
            )
        }
    }

    private fun httpGet(url: String): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 20_000
        }
        try {
            if (conn.responseCode !in 200..299) throw IOException("HTTP ${conn.responseCode}")
            return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    fun localFile(book: Book): File = File(booksDir, book.fileName)

    fun isDownloaded(book: Book): Boolean = localFile(book).let { it.exists() && it.length() > 0 }

    fun delete(book: Book) {
        localFile(book).delete()
    }

    /** يحمّل الكتاب إلى ملف مؤقت ثم يعيد تسميته عند النجاح، فلا يبقى ملف ناقص */
    suspend fun download(book: Book, onProgress: (Float) -> Unit) = withContext(Dispatchers.IO) {
        val target = localFile(book)
        val tmp = File(target.path + ".part")
        val conn = (URL(book.url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 30_000
        }
        try {
            if (conn.responseCode !in 200..299) throw IOException("HTTP ${conn.responseCode}")
            val total = conn.contentLengthLong
            conn.inputStream.use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(32 * 1024)
                    var read = 0L
                    var lastReported = 0f
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        read += n
                        ensureActive()
                        if (total > 0) {
                            val p = read.toFloat() / total
                            if (p - lastReported >= 0.01f) {
                                lastReported = p
                                onProgress(p)
                            }
                        }
                    }
                }
            }
            if (target.exists()) target.delete()
            if (!tmp.renameTo(target)) throw IOException("rename failed")
        } catch (e: Throwable) {
            tmp.delete()
            throw e
        } finally {
            conn.disconnect()
        }
    }
}
