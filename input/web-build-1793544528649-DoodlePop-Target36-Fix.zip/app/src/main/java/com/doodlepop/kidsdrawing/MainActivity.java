package com.doodlepop.kidsdrawing;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.webkit.RenderProcessGoneDetail;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import androidx.webkit.WebViewAssetLoader;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.RequestConfiguration;

import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private LinearLayout rootLayout;
    private FrameLayout bannerContainer;
    private AdView bannerAd;
    private InterstitialAd interstitialAd;
    private int successfulSaves = 0;
    private boolean adsInitialized = false;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/www/index.html";
    // Keep PNG decoding and MediaStore disk writes off the WebView JavaScript call.
    private final ExecutorService imageSaveExecutor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(255, 249, 240));
        getWindow().setNavigationBarColor(Color.rgb(255, 249, 240));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }

        rootLayout = new LinearLayout(this);
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setBackgroundColor(Color.rgb(255, 249, 240));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(255, 249, 240));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setTextZoom(100);
        webView.addJavascriptInterface(new DoodlePopBridge(this), "DoodlePopAndroid");
        webView.setWebChromeClient(new WebChromeClient());
        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return assetLoader.shouldInterceptRequest(Uri.parse(url));
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Never let the drawing WebView navigate away (that produced a blank page).
                String host = request.getUrl().getHost();
                if (host != null && host.equals("appassets.androidplatform.net")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, request.getUrl())); } catch (Exception ignored) {}
                return true;
            }
            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                // The renderer was killed (memory pressure after big PNGs / ads). Rebuild
                // the WebView instead of leaving a blank white screen or crashing the app.
                mainHandler.post(() -> recoverWebView());
                return true;
            }
        });
        rootLayout.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        bannerContainer = new FrameLayout(this);
        bannerContainer.setBackgroundColor(Color.rgb(255, 249, 240));
        rootLayout.addView(bannerContainer, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // Targeting API 35+ forces edge-to-edge: keep content clear of system bars/cutouts.
        rootLayout.setOnApplyWindowInsetsListener((v, insets) -> {
            int left, top, right, bottom;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                android.graphics.Insets bars = insets.getInsets(
                        android.view.WindowInsets.Type.systemBars() | android.view.WindowInsets.Type.displayCutout());
                left = bars.left; top = bars.top; right = bars.right; bottom = bars.bottom;
            } else {
                left = insets.getSystemWindowInsetLeft(); top = insets.getSystemWindowInsetTop();
                right = insets.getSystemWindowInsetRight(); bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(left, top, right, bottom);
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.R ? android.view.WindowInsets.CONSUMED : insets.consumeSystemWindowInsets();
        });

        setContentView(rootLayout);
        webView.loadUrl(APP_URL);
        initializeAds(bannerContainer);
    }

    private void initializeAds(FrameLayout bannerContainer) {
        RequestConfiguration configuration = new RequestConfiguration.Builder()
                .setTagForChildDirectedTreatment(RequestConfiguration.TAG_FOR_CHILD_DIRECTED_TREATMENT_TRUE)
                .setMaxAdContentRating(RequestConfiguration.MAX_AD_CONTENT_RATING_G)
                .build();
        MobileAds.setRequestConfiguration(configuration);
        new Thread(() -> MobileAds.initialize(this, initializationStatus ->
            runOnUiThread(() -> {
                adsInitialized = true;
                loadBanner(bannerContainer);
                loadInterstitial();
            })
        )).start();
    }

    private AdRequest childSafeAdRequest() {
        return new AdRequest.Builder().build();
    }

    private void loadBanner(FrameLayout container) {
        if (isFinishing() || isDestroyed()) return;
        if (bannerAd != null) {
            container.removeView(bannerAd);
            bannerAd.destroy();
        }
        bannerAd = new AdView(this);
        bannerAd.setAdUnitId(BuildConfig.ADMOB_BANNER_ID);
        bannerAd.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(
                this, (int) (getResources().getDisplayMetrics().widthPixels /
                getResources().getDisplayMetrics().density)));
        container.addView(bannerAd, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));
        bannerAd.loadAd(childSafeAdRequest());
    }

    private void loadInterstitial() {
        if (!adsInitialized || isFinishing() || isDestroyed()) return;
        InterstitialAd.load(this, BuildConfig.ADMOB_INTERSTITIAL_ID, childSafeAdRequest(),
                new InterstitialAdLoadCallback() {
                    @Override public void onAdLoaded(InterstitialAd ad) {
                        interstitialAd = ad;
                        interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                            @Override public void onAdDismissedFullScreenContent() {
                                interstitialAd = null;
                                // Restore the banner without changing the WebView's reserved layout space.
                                setBannerVisible(true);
                                loadInterstitial();
                            }
                            @Override public void onAdFailedToShowFullScreenContent(AdError error) {
                                interstitialAd = null;
                                setBannerVisible(true);
                                loadInterstitial();
                            }
                        });
                    }
                    @Override public void onAdFailedToLoad(LoadAdError error) {
                        interstitialAd = null;
                        // Retry later; without this a single failed load meant no interstitial ever.
                        mainHandler.postDelayed(() -> { if (interstitialAd == null) loadInterstitial(); }, 30000);
                    }
                });
    }

    private static final int SAVES_BEFORE_INTERSTITIAL = 4;

    private void onDrawingSaved() {
        successfulSaves++;
        // Show after every 4th user-initiated save, never on app launch.
        if (successfulSaves < SAVES_BEFORE_INTERSTITIAL) return;
        if (interstitialAd == null) {
            // Ad not ready yet: keep the counter so it shows on the next save, and retry loading.
            loadInterstitial();
            return;
        }
        if (isFinishing() || isDestroyed()) return;
        successfulSaves = 0;
        final InterstitialAd ad = interstitialAd;
        interstitialAd = null;
        // Wait for the WebView to finish painting the toast/confetti before the ad covers the activity.
        mainHandler.postDelayed(() -> {
            if (isFinishing() || isDestroyed()) return;
            // INVISIBLE keeps the banner's layout space so the WebView does not resize.
            setBannerVisible(false);
            try {
                ad.show(MainActivity.this);
            } catch (RuntimeException showError) {
                setBannerVisible(true);
                loadInterstitial();
            }
        }, 1500);
    }

    private void enqueueImageSave(String dataUrl, String requestedFileName) {
        if (dataUrl == null || !dataUrl.startsWith("data:image/png;base64,")) {
            Toast.makeText(this, "Could not save drawing", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            imageSaveExecutor.execute(() -> {
                Uri imageUri = null;
                try {
                    byte[] imageBytes = Base64.decode(dataUrl.substring(dataUrl.indexOf(',') + 1), Base64.DEFAULT);
                    if (imageBytes.length == 0) throw new IllegalArgumentException("Drawing is empty");

                    String fileName = requestedFileName == null ? "DoodlePop-Masterpiece.png" : requestedFileName;
                    fileName = fileName.replaceAll("[^A-Za-z0-9._-]", "_");
                    if (!fileName.toLowerCase().endsWith(".png")) fileName += ".png";

                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/DoodlePop");
                    values.put(MediaStore.Images.Media.IS_PENDING, 1);
                    imageUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (imageUri == null) throw new IllegalStateException("Could not create image file");

                    try (OutputStream output = getContentResolver().openOutputStream(imageUri)) {
                        if (output == null) throw new IllegalStateException("Image output stream unavailable");
                        output.write(imageBytes);
                        output.flush();
                    }

                    ContentValues completed = new ContentValues();
                    completed.put(MediaStore.Images.Media.IS_PENDING, 0);
                    getContentResolver().update(imageUri, completed, null, null);

                    runOnUiThread(() -> {
                        if (isFinishing() || isDestroyed()) return;
                        Toast.makeText(MainActivity.this, "Saved to Pictures/DoodlePop", Toast.LENGTH_SHORT).show();
                        onDrawingSaved();
                    });
                } catch (Exception error) {
                    if (imageUri != null) {
                        try { getContentResolver().delete(imageUri, null, null); } catch (Exception ignored) {}
                    }
                    runOnUiThread(() -> {
                        if (!isFinishing() && !isDestroyed()) {
                            Toast.makeText(MainActivity.this, "Unable to save drawing", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            });
        } catch (RuntimeException executorError) {
            Toast.makeText(this, "Unable to save drawing", Toast.LENGTH_SHORT).show();
        }
    }

    private void openPrivacyPolicy() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://hidarnajem-ctrl.github.io/doodlepop-privacy-policy/"));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Could not open privacy policy", Toast.LENGTH_SHORT).show();
        }
    }


    private void setBannerVisible(boolean visible) {
        if (bannerAd == null || bannerContainer == null) return;
        // INVISIBLE rather than GONE preserves the banner's measured height and
        // avoids resizing the WebView drawing area during ad transitions.
        bannerAd.setVisibility(visible ? View.VISIBLE : View.INVISIBLE);
        bannerContainer.setVisibility(View.VISIBLE);
    }

    private void recoverWebView() {
        if (isFinishing() || isDestroyed() || rootLayout == null) return;
        try {
            if (webView != null) {
                rootLayout.removeView(webView);
                webView.removeJavascriptInterface("DoodlePopAndroid");
                webView.destroy();
                webView = null;
            }
        } catch (Exception ignored) {}
        // Re-running onCreate-style setup is the simplest way to get a clean WebView.
        recreate();
    }

    private void notifyWebViewResumed() {
        if (webView == null) return;
        webView.onResume();
        webView.resumeTimers();
        webView.requestLayout();
        webView.invalidate();
        // Let the page re-measure the canvas and re-apply its drawing transform.
        webView.evaluateJavascript(
            "window.dispatchEvent(new Event('doodlepop-native-resume'));window.dispatchEvent(new Event('resize'));", null);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onPause() {
        if (webView != null) webView.onPause();
        if (bannerAd != null) bannerAd.pause();
        super.onPause();
    }
    @Override protected void onResume() {
        super.onResume();
        if (bannerAd != null) bannerAd.resume();
        notifyWebViewResumed();
        // Run again once the ad activity's transition has fully finished.
        mainHandler.postDelayed(this::notifyWebViewResumed, 400);
    }
    @Override protected void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);
        if (webView != null) {
            webView.removeJavascriptInterface("DoodlePopAndroid");
            webView.destroy();
            webView = null;
        }
        if (bannerAd != null) { bannerAd.destroy(); bannerAd = null; }
        imageSaveExecutor.shutdown();
        super.onDestroy();
    }

    private static class DoodlePopBridge {
        private final MainActivity activity;
        DoodlePopBridge(MainActivity activity) { this.activity = activity; }

        @JavascriptInterface public void saveImage(String dataUrl, String requestedFileName) {
            // Return immediately to JavaScript; PNG decoding and file writes happen asynchronously.
            activity.enqueueImageSave(dataUrl, requestedFileName);
        }
        @JavascriptInterface public void openPrivacyPolicy() {
            activity.runOnUiThread(activity::openPrivacyPolicy);
        }
    }
}
