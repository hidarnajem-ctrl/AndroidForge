import React, { useRef, useEffect, useCallback, useImperativeHandle, forwardRef, useState } from 'react';
import {
  ToolType,
  BrushSize,
  ColorOption,
  StampOption,
  ShapeOption,
  ShapeFillMode,
  BRUSH_SIZES,
} from '../types/drawing';
import { drawColoringTemplate } from '../utils/templateDrawers';

export interface CanvasHandle {
  undo: () => void;
  redo: () => void;
  clear: () => void;
  canUndo: boolean;
  canRedo: boolean;
  exportImage: (backgroundHex: string) => string;
  loadDrawing: (dataUrl: string) => void;
  loadTemplate: (templateId: string) => void;
}

interface CanvasProps {
  tool: ToolType;
  selectedColor: ColorOption;
  brushSize: BrushSize;
  selectedStamp: StampOption;
  selectedShape: ShapeOption;
  shapeFillMode: ShapeFillMode;
  backgroundColor: string;
  onStrokeStart?: () => void;
  onStrokeEnd?: () => void;
  onStampPlaced?: () => void;
  onShapePlaced?: () => void;
  onHistoryChange?: (canUndo: boolean, canRedo: boolean) => void;
}

interface Point {
  x: number;
  y: number;
}

export const Canvas = forwardRef<CanvasHandle, CanvasProps>(({
  tool,
  selectedColor,
  brushSize,
  selectedStamp,
  selectedShape,
  shapeFillMode,
  backgroundColor,
  onStrokeStart,
  onStrokeEnd,
  onStampPlaced,
  onShapePlaced,
  onHistoryChange,
}, ref) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  
  // History stacks
  const historyRef = useRef<string[]>([]);
  const redoRef = useRef<string[]>([]);
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);

  // Drawing state
  const isDrawingRef = useRef(false);
  const pointsRef = useRef<Point[]>([]);
  const rainbowHueRef = useRef<number>(0);
  const currentDprRef = useRef<number>(1);

  // Sync history state to parent
  const updateHistoryState = useCallback(() => {
    const undoable = historyRef.current.length > 0;
    const redoable = redoRef.current.length > 0;
    setCanUndo(undoable);
    setCanRedo(redoable);
    onHistoryChange?.(undoable, redoable);
  }, [onHistoryChange]);

  // Save current canvas snapshot to history
  const saveSnapshot = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    try {
      const dataUrl = canvas.toDataURL('image/png');
      historyRef.current.push(dataUrl);
      if (historyRef.current.length > 30) {
        historyRef.current.shift(); // Keep memory lean
      }
      redoRef.current = []; // Clear redo on new action
      updateHistoryState();
    } catch {
      // ignore
    }
  }, [updateHistoryState]);

  // Restore snapshot onto canvas
  const restoreSnapshot = useCallback((dataUrl: string, callback?: () => void) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.onload = () => {
      ctx.save();
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      ctx.restore();
      callback?.();
    };
    img.src = dataUrl;
  }, []);

  // Canvas imperative controls
  useImperativeHandle(ref, () => ({
    canUndo,
    canRedo,
    undo: () => {
      if (historyRef.current.length === 0) return;
      const canvas = canvasRef.current;
      if (!canvas) return;

      const currentSnapshot = canvas.toDataURL('image/png');
      redoRef.current.push(currentSnapshot);

      const previousSnapshot = historyRef.current.pop();
      if (previousSnapshot) {
        restoreSnapshot(previousSnapshot, () => {
          updateHistoryState();
        });
      } else {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.save();
          ctx.setTransform(1, 0, 0, 1, 0, 0);
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          ctx.restore();
        }
        updateHistoryState();
      }
    },
    redo: () => {
      if (redoRef.current.length === 0) return;
      const canvas = canvasRef.current;
      if (!canvas) return;

      const currentSnapshot = canvas.toDataURL('image/png');
      historyRef.current.push(currentSnapshot);

      const nextSnapshot = redoRef.current.pop();
      if (nextSnapshot) {
        restoreSnapshot(nextSnapshot, () => {
          updateHistoryState();
        });
      }
    },
    clear: () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      saveSnapshot();
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.save();
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.restore();
      }
    },
    exportImage: (bgHex: string) => {
      const canvas = canvasRef.current;
      if (!canvas) return '';

      // Create an offscreen canvas to merge background + artwork
      const exportCanvas = document.createElement('canvas');
      exportCanvas.width = canvas.width;
      exportCanvas.height = canvas.height;
      const exportCtx = exportCanvas.getContext('2d');
      if (!exportCtx) return canvas.toDataURL('image/png');

      // Fill background
      exportCtx.fillStyle = bgHex;
      exportCtx.fillRect(0, 0, exportCanvas.width, exportCanvas.height);

      // Draw artwork
      exportCtx.drawImage(canvas, 0, 0);

      // Return PNG data
      return exportCanvas.toDataURL('image/png');
    },
    loadDrawing: (dataUrl: string) => {
      saveSnapshot();
      restoreSnapshot(dataUrl, () => {
        updateHistoryState();
      });
    },
    loadTemplate: (templateId: string) => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      saveSnapshot();

      const dpr = currentDprRef.current || 1;
      const cssW = canvas.width / dpr;
      const cssH = canvas.height / dpr;

      ctx.save();
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.scale(dpr, dpr);
      drawColoringTemplate(templateId, ctx, cssW, cssH);
      ctx.restore();

      updateHistoryState();
    },
  }), [canUndo, canRedo, saveSnapshot, restoreSnapshot, updateHistoryState]);

  // Resize canvas with devicePixelRatio
  const resizeCanvas = useCallback(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    const rect = container.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return;

    const dpr = window.devicePixelRatio || 1;
    const nextWidth = Math.round(rect.width * dpr);
    const nextHeight = Math.round(rect.height * dpr);
    currentDprRef.current = dpr;

    // A full-screen ad can cause several focus/layout notifications even when the
    // actual WebView size has not changed. Do not reset the canvas backing bitmap
    // unless its physical dimensions really changed; repeated resets look like flicker.
    const dimensionsChanged = canvas.width !== nextWidth || canvas.height !== nextHeight;
    const cssSizeChanged = canvas.style.width !== `${rect.width}px` || canvas.style.height !== `${rect.height}px`;
    if (!dimensionsChanged && !cssSizeChanged) return;

    let oldData: string | null = null;
    if (canvas.width > 0 && canvas.height > 0) {
      try { oldData = canvas.toDataURL('image/png'); } catch { /* ignore */ }
    }

    if (dimensionsChanged) {
      canvas.width = nextWidth;
      canvas.height = nextHeight;
    }
    canvas.style.width = `${rect.width}px`;
    canvas.style.height = `${rect.height}px`;

    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
    }

    if (oldData && dimensionsChanged) restoreSnapshot(oldData);
  }, [restoreSnapshot]);

  // ResizeObserver for reliable dimension calculation
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    resizeCanvas();

    const resizeObserver = new ResizeObserver(() => {
      resizeCanvas();
    });
    resizeObserver.observe(container);

    window.addEventListener('resize', resizeCanvas);
    window.addEventListener('orientationchange', resizeCanvas);

    return () => {
      resizeObserver.disconnect();
      window.removeEventListener('resize', resizeCanvas);
      window.removeEventListener('orientationchange', resizeCanvas);
    };
  }, [resizeCanvas]);

  // Coordinate helper: takes touch/pointer event and returns { x, y } in CSS pixels relative to canvas
  const getCoordinates = (e: MouseEvent | Touch): Point => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
  };

  // Stamp drawing helper
  const drawStamp = (point: Point) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    saveSnapshot();

    ctx.save();
    ctx.globalCompositeOperation = 'source-over';

    const stampPixelSizes = {
      small: 42,
      medium: 70,
      large: 110,
    };
    const fontSize = stampPixelSizes[brushSize] || 70;

    ctx.font = `${fontSize}px "Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji", sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    // Soft drop shadow for stamps
    ctx.shadowColor = 'rgba(0, 0, 0, 0.15)';
    ctx.shadowBlur = 8;
    ctx.shadowOffsetY = 4;

    ctx.fillText(selectedStamp.emoji, point.x, point.y);
    ctx.restore();

    onStampPlaced?.();
  };

  // Shape drawing helper
  const drawShape = (point: Point) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    saveSnapshot();

    ctx.save();
    ctx.globalCompositeOperation = 'source-over';
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    const radiusSizes = {
      small: 26,
      medium: 50,
      large: 84,
    };
    const r = radiusSizes[brushSize] || 50;

    // Setup stroke or fill style
    let style: string | CanvasGradient = selectedColor.hex;
    if (selectedColor.isRainbow) {
      const grad = ctx.createLinearGradient(point.x - r, point.y - r, point.x + r, point.y + r);
      grad.addColorStop(0, '#ef4444');
      grad.addColorStop(0.2, '#f97316');
      grad.addColorStop(0.4, '#eab308');
      grad.addColorStop(0.6, '#22c55e');
      grad.addColorStop(0.8, '#3b82f6');
      grad.addColorStop(1, '#a855f7');
      style = grad;
    }

    const strokeWidth = Math.max(4, BRUSH_SIZES[brushSize].size);
    ctx.lineWidth = strokeWidth;
    ctx.strokeStyle = style;
    ctx.fillStyle = style;

    // Define shape geometry centered at point
    ctx.beginPath();
    switch (selectedShape.id) {
      case 'circle': {
        ctx.arc(point.x, point.y, r, 0, Math.PI * 2);
        break;
      }
      case 'square': {
        const side = r * 1.8;
        const corner = Math.min(14, side * 0.14);
        if (typeof ctx.roundRect === 'function') {
          ctx.roundRect(point.x - side / 2, point.y - side / 2, side, side, corner);
        } else {
          ctx.rect(point.x - side / 2, point.y - side / 2, side, side);
        }
        break;
      }
      case 'triangle': {
        const h = r * 1.9;
        const halfW = h / Math.sqrt(3);
        const top = point.y - h * 0.55;
        const bottom = point.y + h * 0.45;
        ctx.moveTo(point.x, top);
        ctx.lineTo(point.x + halfW, bottom);
        ctx.lineTo(point.x - halfW, bottom);
        ctx.closePath();
        break;
      }
      case 'star': {
        const outerR = r * 1.15;
        const innerR = outerR * 0.48;
        for (let i = 0; i < 10; i++) {
          const rad = i % 2 === 0 ? outerR : innerR;
          const angle = (i * Math.PI) / 5 - Math.PI / 2;
          const sx = point.x + Math.cos(angle) * rad;
          const sy = point.y + Math.sin(angle) * rad;
          if (i === 0) ctx.moveTo(sx, sy);
          else ctx.lineTo(sx, sy);
        }
        ctx.closePath();
        break;
      }
      case 'diamond': {
        const w = r * 1.05;
        const h = r * 1.35;
        ctx.moveTo(point.x, point.y - h);
        ctx.lineTo(point.x + w, point.y);
        ctx.lineTo(point.x, point.y + h);
        ctx.lineTo(point.x - w, point.y);
        ctx.closePath();
        break;
      }
      case 'heart': {
        const s = r * 1.1;
        ctx.moveTo(point.x, point.y + s * 0.4);
        ctx.bezierCurveTo(point.x - s * 0.9, point.y - s * 0.5, point.x - s * 0.5, point.y - s * 1.1, point.x, point.y - s * 0.35);
        ctx.bezierCurveTo(point.x + s * 0.5, point.y - s * 1.1, point.x + s * 0.9, point.y - s * 0.5, point.x, point.y + s * 0.4);
        ctx.closePath();
        break;
      }
    }

    if (shapeFillMode === 'fill') {
      ctx.fill();
      // Subtle neat edge for kids artwork definition
      ctx.save();
      ctx.lineWidth = Math.max(2.5, strokeWidth * 0.4);
      ctx.strokeStyle = 'rgba(0, 0, 0, 0.15)';
      ctx.stroke();
      ctx.restore();
    } else {
      ctx.stroke();
    }

    ctx.restore();
    onShapePlaced?.();
  };

  // Touch & Pointer event handlers
  const handleTouchStart = (e: TouchEvent) => {
    e.preventDefault(); // Stop scrolling, pinch zoom, refresh
    if (e.touches.length === 0) return;
    const touch = e.touches[0];
    const point = getCoordinates(touch);

    if (tool === 'stamp') {
      drawStamp(point);
      return;
    }

    if (tool === 'shape') {
      drawShape(point);
      return;
    }

    startDrawing(point);
  };

  const handleTouchMove = (e: TouchEvent) => {
    e.preventDefault();
    if (!isDrawingRef.current || e.touches.length === 0) return;
    const touch = e.touches[0];
    const point = getCoordinates(touch);
    continueDrawing(point);
  };

  const handleTouchEnd = (e: TouchEvent) => {
    e.preventDefault();
    finishDrawing();
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (e.pointerType === 'touch') return;
    const point = getCoordinates(e.nativeEvent);

    if (tool === 'stamp') {
      drawStamp(point);
      return;
    }

    if (tool === 'shape') {
      drawShape(point);
      return;
    }

    startDrawing(point);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (e.pointerType === 'touch') return;
    if (!isDrawingRef.current) return;
    const point = getCoordinates(e.nativeEvent);
    continueDrawing(point);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (e.pointerType === 'touch') return;
    finishDrawing();
  };

  // Core Drawing logic
  const startDrawing = (point: Point) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Save snapshot before stroke
    saveSnapshot();

    isDrawingRef.current = true;
    pointsRef.current = [point];

    onStrokeStart?.();

    // Prepare style
    const sizeConfig = BRUSH_SIZES[brushSize];
    const lineWidth = sizeConfig.size;

    ctx.save();
    ctx.lineWidth = lineWidth;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (tool === 'eraser') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.strokeStyle = 'rgba(0,0,0,1)';
      ctx.fillStyle = 'rgba(0,0,0,1)';
    } else {
      ctx.globalCompositeOperation = 'source-over';
      if (selectedColor.isRainbow) {
        rainbowHueRef.current = (rainbowHueRef.current + 15) % 360;
        ctx.strokeStyle = `hsl(${rainbowHueRef.current}, 95%, 52%)`;
        ctx.fillStyle = `hsl(${rainbowHueRef.current}, 95%, 52%)`;
      } else {
        ctx.strokeStyle = selectedColor.hex;
        ctx.fillStyle = selectedColor.hex;
      }
    }

    // Draw initial dot for taps
    ctx.beginPath();
    ctx.arc(point.x, point.y, lineWidth / 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  };

  const continueDrawing = (point: Point) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const points = pointsRef.current;
    points.push(point);

    if (points.length < 2) return;

    const p1 = points[points.length - 2];
    const p2 = points[points.length - 1];
    const midPoint = {
      x: (p1.x + p2.x) / 2,
      y: (p1.y + p2.y) / 2,
    };

    const sizeConfig = BRUSH_SIZES[brushSize];
    const lineWidth = sizeConfig.size;

    ctx.save();
    ctx.lineWidth = lineWidth;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (tool === 'eraser') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.strokeStyle = 'rgba(0,0,0,1)';
    } else {
      ctx.globalCompositeOperation = 'source-over';
      if (selectedColor.isRainbow) {
        rainbowHueRef.current = (rainbowHueRef.current + 6) % 360;
        ctx.strokeStyle = `hsl(${rainbowHueRef.current}, 95%, 52%)`;
      } else {
        ctx.strokeStyle = selectedColor.hex;
      }
    }

    ctx.beginPath();
    // Smooth quadratic curve interpolation
    if (points.length === 2) {
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(midPoint.x, midPoint.y);
    } else {
      const p0 = points[points.length - 3];
      const prevMid = {
        x: (p0.x + p1.x) / 2,
        y: (p0.y + p1.y) / 2,
      };
      ctx.moveTo(prevMid.x, prevMid.y);
      ctx.quadraticCurveTo(p1.x, p1.y, midPoint.x, midPoint.y);
    }
    ctx.stroke();
    ctx.restore();
  };

  const finishDrawing = () => {
    if (!isDrawingRef.current) return;
    isDrawingRef.current = false;
    pointsRef.current = [];
    onStrokeEnd?.();
  };

  // Attach non-passive touch listeners directly to DOM element
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const opts: AddEventListenerOptions = { passive: false };

    canvas.addEventListener('touchstart', handleTouchStart, opts);
    canvas.addEventListener('touchmove', handleTouchMove, opts);
    canvas.addEventListener('touchend', handleTouchEnd, opts);
    canvas.addEventListener('touchcancel', handleTouchEnd, opts);

    return () => {
      canvas.removeEventListener('touchstart', handleTouchStart);
      canvas.removeEventListener('touchmove', handleTouchMove);
      canvas.removeEventListener('touchend', handleTouchEnd);
      canvas.removeEventListener('touchcancel', handleTouchEnd);
    };
  }, [tool, selectedColor, brushSize, selectedStamp, selectedShape, shapeFillMode]);

  return (
    <div
      ref={containerRef}
      className="relative flex-1 w-full h-full overflow-hidden rounded-3xl shadow-inner border-4 border-amber-200/80 transition-colors duration-300"
      style={{ backgroundColor }}
    >
      <canvas
        ref={canvasRef}
        className="drawing-canvas absolute inset-0 w-full h-full block cursor-crosshair"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
      />
    </div>
  );
});

Canvas.displayName = 'Canvas';
