package com.hidarnajem.firstbooks

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/** أيام الدوام في العراق */
val SCHOOL_DAYS = listOf("الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس")
const val PERIODS = 6

data class Exam(val id: Long, val subject: String, val epochDay: Long, val done: Boolean)

data class Note(val id: Long, val title: String, val body: String, val updated: Long)

/**
 * بيانات الجدول والامتحانات والملاحظات.
 * تُحفظ على الجهاز فقط (SharedPreferences) ولا تُرسل إلى أي مكان.
 */
class ToolsStore(context: Context) {

    private val prefs = context.getSharedPreferences("tools", Context.MODE_PRIVATE)

    var schedule by mutableStateOf(loadSchedule())
        private set
    var exams by mutableStateOf(loadExams())
        private set
    var notes by mutableStateOf(loadNotes())
        private set

    // ---------------- الجدول الأسبوعي ----------------

    fun setPeriod(day: Int, period: Int, subject: String) {
        schedule = schedule.mapIndexed { d, list ->
            if (d != day) list else list.mapIndexed { p, s -> if (p == period) subject.trim() else s }
        }
        prefs.edit().putString("schedule", JSONArray(schedule.map { JSONArray(it) }).toString()).apply()
    }

    private fun loadSchedule(): List<List<String>> {
        val empty = List(SCHOOL_DAYS.size) { List(PERIODS) { "" } }
        val raw = prefs.getString("schedule", null) ?: return empty
        return runCatching {
            val arr = JSONArray(raw)
            List(SCHOOL_DAYS.size) { d ->
                val day = arr.optJSONArray(d)
                List(PERIODS) { p -> day?.optString(p, "") ?: "" }
            }
        }.getOrDefault(empty)
    }

    // ---------------- الامتحانات ----------------

    fun addExam(subject: String, epochDay: Long) {
        saveExams(exams + Exam(System.currentTimeMillis(), subject.trim(), epochDay, false))
    }

    fun toggleExam(id: Long) {
        saveExams(exams.map { if (it.id == id) it.copy(done = !it.done) else it })
    }

    fun deleteExam(id: Long) {
        saveExams(exams.filterNot { it.id == id })
    }

    private fun saveExams(list: List<Exam>) {
        exams = list
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("s", it.subject).put("d", it.epochDay).put("done", it.done))
        }
        prefs.edit().putString("exams", arr.toString()).apply()
    }

    private fun loadExams(): List<Exam> = runCatching {
        val arr = JSONArray(prefs.getString("exams", "[]"))
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Exam(o.getLong("id"), o.getString("s"), o.getLong("d"), o.optBoolean("done"))
        }
    }.getOrDefault(emptyList())

    // ---------------- الملاحظات ----------------

    /** يحفظ الملاحظة ويعيد معرّفها (يُنشئ واحدة جديدة إن كان id = null) */
    fun saveNote(id: Long?, title: String, body: String): Long {
        val now = System.currentTimeMillis()
        val newId = id ?: now
        val note = Note(newId, title, body, now)
        val others = notes.filterNot { it.id == newId }
        saveNotes(listOf(note) + others)
        return newId
    }

    fun deleteNote(id: Long) {
        saveNotes(notes.filterNot { it.id == id })
    }

    private fun saveNotes(list: List<Note>) {
        notes = list
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("t", it.title).put("b", it.body).put("u", it.updated))
        }
        prefs.edit().putString("notes", arr.toString()).apply()
    }

    private fun loadNotes(): List<Note> = runCatching {
        val arr = JSONArray(prefs.getString("notes", "[]"))
        List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Note(o.getLong("id"), o.optString("t"), o.optString("b"), o.optLong("u"))
        }
    }.getOrDefault(emptyList())
}
