package com.hidarnajem.firstbooks

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.DayOfWeek
import java.time.LocalDate

// ألوان مشتركة لثيم المكتبة (خشب، قماش أخضر، ذهبي، ورق)
val UiGold = Color(0xFFFFD27A)
val UiGoldDeep = Color(0xFFE0A53A)
val UiWoodDark = Color(0xFF2A1405)
val UiPaper = Color(0xFFFBF5E9)
val UiInk = Color(0xFF2B1A0E)
val UiInkMuted = Color(0xFF7A6250)
val UiPaperLine = Color(0xFFD9C9B0)
val UiChalk = Color(0xFFF7F3E8)
val UiTextShadow = Shadow(Color(0xCC000000), Offset(0f, 3f), 6f)

/** لافتة خشبية صغيرة بإطار ذهبي */
@Composable
fun Plaque(text: String, modifier: Modifier = Modifier, fontSize: Int = 15) {
    Surface(
        shape = RoundedCornerShape(50),
        color = Color(0xCC2A1405),
        border = BorderStroke(1.5.dp, UiGoldDeep),
        shadowElevation = 4.dp,
        modifier = modifier
    ) {
        Text(
            text,
            color = UiGold,
            fontWeight = FontWeight.Bold,
            fontSize = fontSize.sp,
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp)
        )
    }
}

/** لوح من القماش الأخضر بإطار ذهبي، مثل لوح الصف */
@Composable
fun FeltBoard(
    modifier: Modifier = Modifier,
    corner: Dp = 18.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(corner)
    Box(
        modifier
            .shadow(10.dp, shape)
            .clip(shape)
            .border(BorderStroke(4.dp, Brush.verticalGradient(listOf(UiGold, Color(0xFF8A4B12)))), shape)
    ) {
        Image(
            painter = painterResource(R.drawable.bg_felt),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.matchParentSize()
        )
        content()
    }
}

/** بطاقة ورقية بلون الكريم */
@Composable
fun PaperCard(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier
            .shadow(6.dp, shape)
            .clip(shape)
            .background(UiPaper)
            .border(1.dp, UiPaperLine, shape),
        content = content
    )
}

fun arabicDayName(date: LocalDate): String = when (date.dayOfWeek) {
    DayOfWeek.SUNDAY -> "الأحد"
    DayOfWeek.MONDAY -> "الاثنين"
    DayOfWeek.TUESDAY -> "الثلاثاء"
    DayOfWeek.WEDNESDAY -> "الأربعاء"
    DayOfWeek.THURSDAY -> "الخميس"
    DayOfWeek.FRIDAY -> "الجمعة"
    else -> "السبت"
}

/** أسماء المواد المقترحة في الجدول والامتحانات */
fun subjectSuggestions(shelves: List<String>): List<String> =
    (shelves + listOf("التربية الفنية", "التربية الرياضية")).distinct()
