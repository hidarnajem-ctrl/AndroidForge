package com.hidarnajem.firstbooks

/**
 * صور الأغلفة المضمّنة في التطبيق، مربوطة باسم ملف الكتاب في books.json.
 * إن أضفت كتاباً جديداً: ضع صورة غلافه في res/drawable-nodpi وأضف سطراً هنا.
 * الكتاب الذي ليس له غلاف هنا يظهر بغلاف عام يحمل عنوانه.
 */
object Covers {
    private val map: Map<String, Int> = mapOf(
        "islamic.pdf" to R.drawable.cover_islamic,
        "reading-1.pdf" to R.drawable.cover_reading_1,
        "reading-2.pdf" to R.drawable.cover_reading_2,
        "math-1.pdf" to R.drawable.cover_math_1,
        "math-2.pdf" to R.drawable.cover_math_2,
        "sciences.pdf" to R.drawable.cover_sciences,
        "sciences-activity.pdf" to R.drawable.cover_sciences_activity,
        "english.pdf" to R.drawable.cover_english,
        "english-activity.pdf" to R.drawable.cover_english_activity
    )

    fun of(book: Book): Int? = map[book.fileName]
}
