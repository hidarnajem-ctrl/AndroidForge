package com.hidarnajem.firstbooks

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF1E4DB7),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE6FF),
    onPrimaryContainer = Color(0xFF0A2463),
    secondary = Color(0xFF00897B),
    background = Color(0xFFF6F8FC),
    onBackground = Color(0xFF1B1F2A),
    surface = Color.White,
    onSurface = Color(0xFF1B1F2A),
    surfaceVariant = Color(0xFFE9EEF8),
    onSurfaceVariant = Color(0xFF4A5164)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9DB7FF),
    onPrimary = Color(0xFF0A2463),
    primaryContainer = Color(0xFF2B3F73),
    onPrimaryContainer = Color(0xFFDCE6FF),
    secondary = Color(0xFF4DB6AC),
    background = Color(0xFF10131A),
    onBackground = Color(0xFFE6E9F2),
    surface = Color(0xFF1A1E27),
    onSurface = Color(0xFFE6E9F2),
    surfaceVariant = Color(0xFF262B38),
    onSurfaceVariant = Color(0xFFB9BFD0)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content
    )
}
