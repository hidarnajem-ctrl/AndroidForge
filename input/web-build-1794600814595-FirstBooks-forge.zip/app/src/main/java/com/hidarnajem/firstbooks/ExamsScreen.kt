package com.hidarnajem.firstbooks

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

private fun countdown(epochDay: Long): Pair<String, Color> {
    val days = epochDay - LocalDate.now().toEpochDay()
    return when {
        days < 0 -> "انتهى" to Color(0xFF8D8D8D)
        days == 0L -> "اليوم!" to Color(0xFFC62828)
        days == 1L -> "غداً" to Color(0xFFE65100)
        days == 2L -> "بعد يومين" to Color(0xFFE65100)
        days <= 10 -> "بعد $days أيام" to Color(0xFF2E7D32)
        else -> "بعد $days يوماً" to Color(0xFF2E7D32)
    }
}

@Composable
fun ExamsScreen(store: ToolsStore, subjects: List<String>) {
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Exam?>(null) }
    // القادمة أولاً حسب التاريخ، ثم المنجزة
    val list = store.exams.sortedWith(compareBy<Exam>({ it.done }, { it.epochDay }))

    Box(Modifier.fillMaxSize()) {
        if (list.isEmpty()) {
            FeltBoard(
                Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "لا توجد امتحانات بعد",
                        style = TextStyle(color = UiChalk, fontSize = 20.sp, fontWeight = FontWeight.Bold, shadow = UiTextShadow)
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "أضف مواعيد امتحاناتك ليظهر لك كم يوماً بقي على كل امتحان",
                        color = UiGold,
                        textAlign = TextAlign.Center,
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item { Plaque("جدول الامتحانات", Modifier.padding(bottom = 2.dp)) }
                items(list, key = { it.id }) { exam ->
                    ExamCard(
                        exam = exam,
                        onToggle = { store.toggleExam(exam.id) },
                        onDelete = { deleting = exam }
                    )
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = { adding = true },
            icon = { Icon(Icons.Default.Add, contentDescription = null) },
            text = { Text("إضافة امتحان", fontWeight = FontWeight.Bold) },
            containerColor = UiGoldDeep,
            contentColor = UiWoodDark,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        )
    }

    if (adding) {
        AddExamDialog(
            subjects = subjects,
            onDismiss = { adding = false },
            onSave = { s, d ->
                store.addExam(s, d)
                adding = false
            }
        )
    }

    deleting?.let { exam ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("حذف الامتحان؟") },
            text = { Text("سيُحذف امتحان ${exam.subject} من الجدول.") },
            confirmButton = {
                TextButton(onClick = {
                    store.deleteExam(exam.id)
                    deleting = null
                }) { Text("حذف", color = Color(0xFFB3261E)) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun ExamCard(exam: Exam, onToggle: () -> Unit, onDelete: () -> Unit) {
    val date = LocalDate.ofEpochDay(exam.epochDay)
    val (left, leftColor) = countdown(exam.epochDay)
    PaperCard(
        Modifier
            .fillMaxWidth()
            .alpha(if (exam.done) 0.7f else 1f)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // شارة التاريخ
            Column(
                Modifier
                    .width(64.dp)
                    .background(Color(0xFF0F5A1C), RoundedCornerShape(10.dp))
                    .border(1.5.dp, UiGoldDeep, RoundedCornerShape(10.dp))
                    .padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(arabicDayName(date), color = UiGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("${date.dayOfMonth}", color = UiChalk, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("${date.monthValue}/${date.year}", color = UiChalk, fontSize = 11.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    exam.subject,
                    color = UiInk,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    textDecoration = if (exam.done) TextDecoration.LineThrough else null
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    if (exam.done) "تم ✓" else left,
                    color = if (exam.done) Color(0xFF2E7D32) else leftColor,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            // زر "تم"
            Box(
                Modifier
                    .size(34.dp)
                    .background(if (exam.done) Color(0xFF2E7D32) else Color.Transparent, CircleShape)
                    .border(2.dp, if (exam.done) Color(0xFF2E7D32) else UiInkMuted, CircleShape)
                    .clickable(onClick = onToggle),
                contentAlignment = Alignment.Center
            ) {
                if (exam.done) Icon(Icons.Default.Check, contentDescription = "تم", tint = Color.White)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "حذف", tint = UiInkMuted)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddExamDialog(
    subjects: List<String>,
    onDismiss: () -> Unit,
    onSave: (String, Long) -> Unit
) {
    var subject by remember { mutableStateOf("") }
    var epochDay by remember { mutableStateOf<Long?>(null) }
    var pickingDate by remember { mutableStateOf(false) }
    var pickingSubject by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("امتحان جديد", fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("المادة", fontWeight = FontWeight.Bold, color = UiInkMuted, fontSize = 13.sp)
                OutlinedButton(onClick = { pickingSubject = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(subject.ifBlank { "اختر المادة" })
                }
                Spacer(Modifier.height(10.dp))
                Text("التاريخ", fontWeight = FontWeight.Bold, color = UiInkMuted, fontSize = 13.sp)
                OutlinedButton(onClick = { pickingDate = true }, modifier = Modifier.fillMaxWidth()) {
                    val d = epochDay?.let { LocalDate.ofEpochDay(it) }
                    Text(if (d == null) "اختر التاريخ" else "${arabicDayName(d)} ${d.dayOfMonth}/${d.monthValue}/${d.year}")
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onSave(subject, epochDay!!) },
                enabled = subject.isNotBlank() && epochDay != null
            ) { Text("حفظ", fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )

    if (pickingSubject) {
        SubjectPickerDialog(
            title = "اختر المادة",
            current = subject,
            suggestions = subjects,
            allowClear = false,
            onDismiss = { pickingSubject = false },
            onSave = {
                subject = it.trim()
                pickingSubject = false
            }
        )
    }

    if (pickingDate) {
        val state = rememberDatePickerState(
            initialSelectedDateMillis = (epochDay ?: LocalDate.now().toEpochDay()) * 86_400_000L
        )
        DatePickerDialog(
            onDismissRequest = { pickingDate = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let {
                        epochDay = Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate().toEpochDay()
                    }
                    pickingDate = false
                }) { Text("تم") }
            },
            dismissButton = { TextButton(onClick = { pickingDate = false }) { Text("إلغاء") } }
        ) {
            DatePicker(state = state)
        }
    }
}
