rootProject.name = "domino-engine"
