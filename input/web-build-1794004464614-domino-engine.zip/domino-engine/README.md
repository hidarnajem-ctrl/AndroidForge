# Domino Classic – Engine (Stage 2)
Pure Kotlin/JVM module: rules, scoring, match flow, AI (Easy/Medium/Expert), unit tests.
Run: `gradle test` (JDK 17). Will be moved into the Android project as the `:engine` module.
Scoring: going out = opponent's pips; blocked = pip difference to the lower hand; tie = 0.
Opening (round 1): highest double, else highest tile. Later rounds: previous winner leads any tile.
