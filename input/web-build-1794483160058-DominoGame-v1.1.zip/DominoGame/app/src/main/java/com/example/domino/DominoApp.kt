package com.example.domino

import android.app.Application
import android.util.Log
import com.tiktok.TikTokBusinessSdk

/**
 * يبدأ مكتبة TikTok عند تشغيل اللعبة، فتسجّل التثبيت وفتح اللعبة تلقائياً.
 * مكتبة Meta تبدأ وحدها من إعدادات AndroidManifest.
 */
class DominoApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val ttAppId = getString(R.string.tiktok_app_id)
        val ttToken = getString(R.string.tiktok_access_token)
        if (ttAppId.startsWith("FILL_") || ttToken.startsWith("FILL_")) return
        try {
            val config = TikTokBusinessSdk.TTConfig(this, ttToken)
                .setAppId(packageName)
                .setTTAppId(ttAppId)
            TikTokBusinessSdk.initializeSdk(config, object : TikTokBusinessSdk.TTInitCallback {
                override fun success() {}
                override fun fail(code: Int, msg: String?) {
                    Log.w("DominoApp", "TikTok SDK init failed: $code $msg")
                }
            })
            TikTokBusinessSdk.startTrack()
        } catch (t: Throwable) {
            Log.w("DominoApp", "TikTok SDK init error", t)
        }
    }
}
