import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.domino"
    compileSdk = 36

    // توقيع نسخة النشر (مفتاح الرفع إلى Google Play)
    val keyProps = Properties().apply {
        val f = rootProject.file("keystore.properties")
        if (f.exists()) f.inputStream().use { load(it) }
    }
    signingConfigs {
        create("release") {
            storeFile = file(keyProps.getProperty("storeFile", "crowndomino-upload.jks"))
            storePassword = keyProps.getProperty("storePassword")
            keyAlias = keyProps.getProperty("keyAlias")
            keyPassword = keyProps.getProperty("keyPassword")
        }
    }

    defaultConfig {
        applicationId = "com.crowndomino.game"
        minSdk = 24
        targetSdk = 36
        versionCode = 3
        versionName = "1.1"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    val bom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(bom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("com.google.android.gms:play-services-ads:23.5.0")
    implementation(platform("com.google.firebase:firebase-bom:33.5.1"))
    implementation("com.google.firebase:firebase-database")
    implementation("com.google.firebase:firebase-auth")

    // قياس التثبيتات لإعلانات Meta وTikTok
    implementation("com.facebook.android:facebook-core:19.0.1")
    implementation("com.github.tiktok:tiktok-business-android-sdk:1.7.1")
    implementation("com.android.installreferrer:installreferrer:2.2")
}

// عند بناء Release (assembleRelease) يُبنى ملف AAB موقّع تلقائياً أيضاً
// في مكانه المعتاد: app/build/outputs/bundle/release/app-release.aab
afterEvaluate {
    tasks.named("assembleRelease") { finalizedBy("bundleRelease") }
}
