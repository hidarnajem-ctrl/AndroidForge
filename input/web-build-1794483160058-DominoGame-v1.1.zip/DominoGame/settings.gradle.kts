pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google(); mavenCentral()
        // مكتبة TikTok للإعلانات منشورة على JitPack
        maven("https://jitpack.io")
    }
}
rootProject.name = "DominoGame"
include(":app")
