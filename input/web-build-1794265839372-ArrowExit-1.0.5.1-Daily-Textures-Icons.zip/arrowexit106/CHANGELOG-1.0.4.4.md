# Arrow Exit 1.0.4.4 — Cosmetic Apply Fix

- Rewarded ads now unlock a cosmetic without automatically equipping it.
- Owned cosmetics display an enabled Apply button until selected.
- Purchased cosmetics are unlocked first; the player chooses when to apply them.
- Premium backgrounds now change the actual board and app color variables.
- Arrow palettes now update the actual arrow drawing colors.
- Added localized confirmation messages in all eight supported languages.
- Preserved existing AdMob rewarded flow, economy, worlds, levels, and saves.

Build verification: JavaScript syntax checked with Node.js. APK build was not run in this environment.
