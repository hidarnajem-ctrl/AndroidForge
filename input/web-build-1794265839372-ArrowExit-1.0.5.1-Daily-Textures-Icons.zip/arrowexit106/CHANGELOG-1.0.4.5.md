# Arrow Exit 1.0.4.5 — Board-only cosmetics

- Separated premium background themes and arrow palettes from global app theme variables.
- Premium background selection now changes only the playable board silhouette, board dots, and in-board visual palette.
- App background, home screen, dialogs, settings, world map, shop chrome, and buttons retain the base app skin.
- Arrow palette changes are scoped to arrows drawn on the game board.
- Preserved ownership, rewarded-ad unlock, coin purchase, equipped appearance persistence, and existing AdMob integration.
- Updated Android versionName to 1.0.4.5 and versionCode to 9.
