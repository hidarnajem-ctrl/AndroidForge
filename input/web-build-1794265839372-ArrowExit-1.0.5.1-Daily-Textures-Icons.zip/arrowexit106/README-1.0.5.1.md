Arrow Exit 1.0.5.1 — Daily Reward, Premium Boards & Shortcut Icons

Based on the tested 1.0.5.0 project. Build with the project's existing Android Gradle setup and JDK 17.

The daily reward action requests an interstitial after the Done button closes the reward dialog. If an ad is not available, the native ad manager returns control without blocking the game.

Five local WebP textures are stored under app/src/main/assets/backgrounds and are drawn only inside the board silhouette. Existing cosmetics and AdMob integration are preserved.
