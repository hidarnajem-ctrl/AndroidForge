# Arrow Exit 1.0.4.5

This update scopes cosmetic backgrounds and arrow palettes to the game board only. App-wide UI colors remain controlled by the normal app skin/theme.

Build using the project's existing Gradle wrapper and Android Studio. The APK build has not been run in this environment.
