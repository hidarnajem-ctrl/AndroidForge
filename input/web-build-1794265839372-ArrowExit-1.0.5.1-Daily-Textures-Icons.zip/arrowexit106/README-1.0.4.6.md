# Arrow Exit 1.0.4.6

This update removes only the Settings > Color theme selector. The Cosmetic Shop remains on the home screen beside Worlds. Board backgrounds and arrow palettes remain available in the Cosmetic Shop and are intended to affect the game board only.

Build with the project's configured Gradle wrapper and Android SDK.
