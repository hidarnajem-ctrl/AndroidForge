# Arrow Exit 1.0.4.6

- Removed the app-wide color theme selector from Settings to prevent it from recoloring the entire application.
- Kept the Cosmetic Shop shortcut on the home screen beside Worlds; it was not moved into Settings.
- Kept board backgrounds and arrow palettes in the Cosmetic Shop, scoped to the game board.
- Preserved language, arrow-color mode, sound, vibration, ads, worlds, rewards, coins, and progress systems.
