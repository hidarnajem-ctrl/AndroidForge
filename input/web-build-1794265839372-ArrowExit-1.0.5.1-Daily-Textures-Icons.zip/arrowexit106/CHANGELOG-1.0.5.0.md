# Arrow Exit 1.0.5.0 — Gameplay polish

- Added subtle staggered entrance animations to world cards.
- Added a gentle floating effect to unlocked world markers.
- Highlighted claimable world chests with a restrained pulse and shine.
- Refined victory overlay entrance and title feedback while retaining existing stars and confetti.
- Respects the device Reduce Motion preference.
- No changes to level rules, coin economy, rewarded ads, cosmetics ownership, or app-wide colors.
