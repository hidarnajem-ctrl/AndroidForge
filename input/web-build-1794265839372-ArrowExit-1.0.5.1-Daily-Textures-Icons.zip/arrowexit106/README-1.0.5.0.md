# Arrow Exit 1.0.5.0

Gameplay feedback polish based on 1.0.4.6. This update is visual-only: world cards, ready chests, and victory overlay animations are refined. Core game logic, economy, AdMob integration, cosmetic shop, language support, and saved progress are retained.

Build with Java 17 and the Gradle wrapper included in the project.
