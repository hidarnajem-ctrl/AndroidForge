# Arrow Exit 1.0.5.1

- Daily reward button now reads Daily Reward; the daily reward dialog has one Done action and then requests an interstitial ad.
- Added five premium board-only textures supplied by the user: golden marble, mahogany wood, emerald velvet, electric blue, and black leather.
- Retained existing cosmetic themes and arrow palettes.
- Replaced the home Worlds and Backgrounds shortcut emoji with clean inline vector icons.
- Kept all textures clipped to the puzzle board; app chrome, menus, and home screen colors remain unchanged.
- Existing AdMob native bridge and rewarded-ad flow retained.
