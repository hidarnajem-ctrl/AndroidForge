# Arrow Exit 1.0.4.4

This update fixes cosmetic ownership and application. After purchasing or unlocking a background/arrow palette through a rewarded ad, return to its card and tap **Apply**. The selected background/palette is saved and reflected in the board.

Build the Android project with the existing Gradle wrapper and Java 17. Test rewarded ads using AdMob test ads.
