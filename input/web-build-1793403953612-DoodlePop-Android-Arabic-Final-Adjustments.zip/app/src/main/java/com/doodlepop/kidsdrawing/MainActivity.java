package com.doodlepop.kidsdrawing;

import android.app.Activity;
import android.content.ContentValues;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import androidx.webkit.WebViewAssetLoader;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.Toast;


import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(255, 249, 240));
        getWindow().setNavigationBarColor(Color.rgb(255, 249, 240));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(255, 249, 240));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(255, 249, 240));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        // Serve bundled web assets from a secure HTTPS-like origin so modern
        // JavaScript ES modules load correctly in Android WebView.
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setTextZoom(100);
        webView.addJavascriptInterface(new DoodlePopBridge(this), "DoodlePopAndroid");
        webView.setWebChromeClient(new WebChromeClient());
        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return assetLoader.shouldInterceptRequest(Uri.parse(url));
            }
        });
        root.addView(webView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html");


    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }
    @Override protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }
    @Override protected void onDestroy() {
        if (webView != null) { webView.removeJavascriptInterface("DoodlePopAndroid"); webView.destroy(); webView = null; }
        super.onDestroy();
    }

    private static class DoodlePopBridge {
        private final MainActivity activity;
        DoodlePopBridge(MainActivity activity) { this.activity = activity; }
        @JavascriptInterface public boolean saveImage(String dataUrl, String requestedFileName) {
            Uri imageUri = null;
            try {
                if (dataUrl == null || !dataUrl.startsWith("data:image/png;base64,")) { showMessage("Could not save drawing"); return false; }
                byte[] imageBytes = Base64.decode(dataUrl.substring(dataUrl.indexOf(',') + 1), Base64.DEFAULT);
                if (imageBytes.length == 0) { showMessage("Drawing is empty"); return false; }
                String fileName = requestedFileName == null ? "DoodlePop-Masterpiece.png" : requestedFileName;
                fileName = fileName.replaceAll("[^A-Za-z0-9._-]", "_");
                if (!fileName.toLowerCase().endsWith(".png")) fileName += ".png";
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/DoodlePop");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
                imageUri = activity.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (imageUri == null) { showMessage("Could not create image file"); return false; }
                try (OutputStream output = activity.getContentResolver().openOutputStream(imageUri)) {
                    if (output == null) throw new IllegalStateException("Image output stream unavailable");
                    output.write(imageBytes); output.flush();
                }
                ContentValues completed = new ContentValues(); completed.put(MediaStore.Images.Media.IS_PENDING, 0);
                activity.getContentResolver().update(imageUri, completed, null, null);
                showMessage("Saved to Pictures/DoodlePop"); return true;
            } catch (Exception error) {
                if (imageUri != null) { try { activity.getContentResolver().delete(imageUri, null, null); } catch (Exception ignored) {} }
                showMessage("Unable to save drawing"); return false;
            }
        }
        private void showMessage(final String message) { activity.runOnUiThread(() -> Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()); }
    }
}
