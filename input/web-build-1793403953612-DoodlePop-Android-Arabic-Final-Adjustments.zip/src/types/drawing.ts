export type ToolType = 'brush' | 'eraser' | 'stamp' | 'shape';

export type BrushSize = 'small' | 'medium' | 'large';

export type ShapeId = 'circle' | 'square' | 'triangle' | 'star' | 'diamond' | 'heart';

export type ShapeFillMode = 'fill' | 'outline';

export interface ShapeOption {
  id: ShapeId;
  name: string;
  iconName: string;
}

export interface ColorOption {
  id: string;
  name: string;
  hex: string;
  isRainbow?: boolean;
}

export interface StampOption {
  id: string;
  name: string;
  emoji: string;
  iconName: string;
}

export interface BackgroundColorOption {
  id: string;
  name: string;
  color: string;
  textColor: string;
}

export interface SavedArtwork {
  id: string;
  title: string;
  createdAt: number;
  dataUrl: string;
  backgroundColor: string;
}

export interface ColoringTemplate {
  id: string;
  name: string;
  emoji: string;
  description: string;
}

export const BRUSH_SIZES: Record<BrushSize, { size: number; label: string; dotClass: string }> = {
  small: { size: 6, label: 'Small', dotClass: 'w-2.5 h-2.5' },
  medium: { size: 16, label: 'Medium', dotClass: 'w-5 h-5' },
  large: { size: 32, label: 'Large', dotClass: 'w-8 h-8' },
};

export const COLOR_PALETTE: ColorOption[] = [
  { id: 'red', name: 'أحمر كرزي', hex: '#EF4444' },
  { id: 'orange', name: 'برتقالي مشمس', hex: '#F97316' },
  { id: 'yellow', name: 'أصفر موزي', hex: '#EAB308' },
  { id: 'green', name: 'أخضر عشبي', hex: '#22C55E' },
  { id: 'blue', name: 'أزرق المحيط', hex: '#3B82F6' },
  { id: 'purple', name: 'بنفسجي', hex: '#A855F7' },
  { id: 'pink', name: 'وردي', hex: '#EC4899' },
  { id: 'black', name: 'أسود', hex: '#1E293B' },
  { id: 'white', name: 'أبيض', hex: '#FFFFFF' },
  { id: 'rainbow', name: 'قوس قزح سحري', hex: 'linear-gradient(135deg, #f87171, #fbbf24, #34d399, #60a5fa, #c084fc)', isRainbow: true },
];

export const STAMP_LIST: StampOption[] = [
  { id: 'star', name: 'نجمة', emoji: '⭐', iconName: 'Star' },
  { id: 'heart', name: 'قلب', emoji: '❤️', iconName: 'Heart' },
  { id: 'smile', name: 'وجه مبتسم', emoji: '😄', iconName: 'Smile' },
  { id: 'sun', name: 'شمس', emoji: '☀️', iconName: 'Sun' },
  { id: 'flower', name: 'زهرة', emoji: '🌸', iconName: 'Flower' },
  { id: 'butterfly', name: 'فراشة', emoji: '🦋', iconName: 'Bug' },
  { id: 'paw', name: 'أثر مخلب', emoji: '🐾', iconName: 'Footprints' },
  { id: 'crown', name: 'تاج', emoji: '👑', iconName: 'Crown' },
];

export const SHAPES_LIST: ShapeOption[] = [
  { id: 'circle', name: 'دائرة', iconName: 'Circle' },
  { id: 'square', name: 'مربع', iconName: 'Square' },
  { id: 'triangle', name: 'مثلث', iconName: 'Triangle' },
  { id: 'star', name: 'نجمة', iconName: 'Star' },
  { id: 'diamond', name: 'معيّن', iconName: 'Diamond' },
  { id: 'heart', name: 'قلب', iconName: 'Heart' },
];

export const BACKGROUND_OPTIONS: BackgroundColorOption[] = [
  { id: 'white', name: 'ورق أبيض', color: '#FFFFFF', textColor: '#1E293B' },
  { id: 'cream', name: 'كريمي دافئ', color: '#FFFBEB', textColor: '#1E293B' },
  { id: 'blackboard', name: 'سبورة', color: '#1E293B', textColor: '#F8FAFC' },
  { id: 'night', name: 'سماء الليل', color: '#0F172A', textColor: '#F8FAFC' },
];

export const COLORING_TEMPLATES: ColoringTemplate[] = [
  { id: 'dino', name: 'ديناصور لطيف', emoji: '🦖', description: 'ديناصور صغير وودود' },
  { id: 'rocket', name: 'صاروخ فضائي', emoji: '🚀', description: 'انطلق نحو النجوم' },
  { id: 'puppy', name: 'جرو سعيد', emoji: '🐶', description: 'جرو صغير مرح ولطيف' },
  { id: 'butterfly', name: 'حديقة الفراشات', emoji: '🦋', description: 'أجنحة جميلة لتلوينها' },
  { id: 'robot', name: 'روبوت ودود', emoji: '🤖', description: 'صديق آلي لطيف' },
  { id: 'flower', name: 'زهرة مشرقة', emoji: '🌸', description: 'بتلات كبيرة وأوراق زاهية' },
];
