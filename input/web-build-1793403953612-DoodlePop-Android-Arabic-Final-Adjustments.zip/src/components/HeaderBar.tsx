import React, { useState } from 'react';
import { Undo2, Redo2, Trash2, Download, Volume2, VolumeX, Maximize2, Minimize2, Palette, Images, BookOpen, Info } from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';

interface HeaderBarProps {
  canUndo: boolean; canRedo: boolean; soundEnabled: boolean; savedCount: number;
  onUndo: () => void; onRedo: () => void; onClearClick: () => void; onSaveClick: () => void;
  onOpenGallery: () => void; onOpenTemplates: () => void; onToggleSound: () => void;
  onOpenInfo: () => void; onTapSound?: () => void;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({
  canUndo, canRedo, soundEnabled, savedCount, onUndo, onRedo, onClearClick, onSaveClick,
  onOpenGallery, onOpenTemplates, onToggleSound, onOpenInfo, onTapSound,
}) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const toggleFullscreen = () => {
    onTapSound?.();
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen?.().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.().catch(() => {});
      setIsFullscreen(false);
    }
  };
  const actionBase = 'kid-btn h-9 sm:h-11 px-1.5 sm:px-3 rounded-xl sm:rounded-2xl flex items-center justify-center gap-1 font-extrabold shrink-0 border-2 text-[10px] sm:text-sm';
  return (
    <header dir="rtl" className="w-full bg-white/95 backdrop-blur-md px-2 py-1.5 sm:px-4 sm:py-2.5 rounded-2xl sm:rounded-3xl shadow-md border-2 border-amber-200/90 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-1.5 sm:gap-2 shrink-0">
      <div className="flex items-center justify-between gap-2 sm:gap-3 shrink-0">
        <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
          <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-br from-rose-500 to-amber-500 text-white flex items-center justify-center shadow-[0_3px_0_#be123c] border border-rose-300 shrink-0"><Palette className="w-5 h-5 sm:w-6 sm:h-6 stroke-[2.5]" /></div>
          <div className="min-w-0">
            <h1 className="text-base sm:text-xl font-bold tracking-tight text-slate-900 leading-none whitespace-nowrap"><span>Doodle</span><span className="text-rose-500">Pop</span></h1>
          </div>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <button onClick={() => { onTapSound?.(); onOpenInfo(); }} className="kid-btn w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-sky-50 text-sky-700 border-2 border-sky-200 flex items-center justify-center" aria-label="معلومات التطبيق" title="من نحن وسياسة الخصوصية"><Info className="w-4 h-4 sm:w-5 sm:h-5" /></button>
          <button onClick={() => { onTapSound?.(); onToggleSound(); }} className="kid-btn w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-amber-100 text-amber-800 border-2 border-amber-300 flex items-center justify-center" aria-label="الصوت" title={soundEnabled ? 'إيقاف الصوت' : 'تشغيل الصوت'}>{soundEnabled ? <Volume2 className="w-4 h-4 sm:w-5 sm:h-5" /> : <VolumeX className="w-4 h-4 sm:w-5 sm:h-5" />}</button>
          <div className="hidden sm:block"><PWAInstallButton onTapSound={onTapSound} /></div>
          <button onClick={toggleFullscreen} className="kid-btn hidden sm:flex w-9 h-9 rounded-xl bg-amber-100 text-amber-800 border-2 border-amber-300 items-center justify-center" aria-label="ملء الشاشة" title={isFullscreen ? 'إغلاق ملء الشاشة' : 'ملء الشاشة'}>{isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}</button>
        </div>
      </div>
      <div className="flex w-full sm:w-auto items-center justify-between sm:justify-start gap-1 sm:gap-1.5 overflow-x-auto no-scrollbar py-0.5">
        <button onClick={() => { if (canUndo) { onTapSound?.(); onUndo(); } }} disabled={!canUndo} className={`${actionBase} ${canUndo ? 'bg-sky-100 text-sky-700 border-sky-300 shadow-[0_2px_0_#0284c7]' : 'bg-slate-100 text-slate-300 border-slate-200 opacity-50'}`} aria-label="تراجع" title="تراجع"><Undo2 className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" /><span>تراجع</span></button>
        <button onClick={() => { if (canRedo) { onTapSound?.(); onRedo(); } }} disabled={!canRedo} className={`${actionBase} ${canRedo ? 'bg-sky-100 text-sky-700 border-sky-300 shadow-[0_2px_0_#0284c7]' : 'bg-slate-100 text-slate-300 border-slate-200 opacity-50'}`} aria-label="إعادة" title="إعادة"><Redo2 className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" /><span>إعادة</span></button>
        <button onClick={() => { onTapSound?.(); onClearClick(); }} className={`${actionBase} bg-rose-100 text-rose-600 border-rose-300 shadow-[0_2px_0_#e11d48]`} aria-label="مسح" title="مسح الرسم"><Trash2 className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" /><span>مسح</span></button>
        <button onClick={() => { onTapSound?.(); onOpenGallery(); }} className={`${actionBase} bg-amber-100 text-amber-900 border-amber-300 shadow-[0_2px_0_#d97706]`} aria-label="المعرض" title="معرض رسوماتي"><Images className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" /><span>المعرض</span>{savedCount > 0 && <span className="rounded-full bg-amber-600 text-white text-[9px] min-w-4 h-4 px-1 flex items-center justify-center">{savedCount}</span>}</button>
        <button onClick={() => { onTapSound?.(); onOpenTemplates(); }} className={`${actionBase} bg-pink-100 text-pink-900 border-pink-300 shadow-[0_2px_0_#db2777]`} aria-label="تلوين" title="قوالب التلوين"><BookOpen className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" /><span>تلوين</span></button>
        <button onClick={() => { onTapSound?.(); onSaveClick(); }} className={`${actionBase} bg-gradient-to-r from-emerald-500 to-teal-500 text-white border-emerald-600 shadow-[0_2px_0_#047857]`} aria-label="حفظ" title="حفظ الرسمة"><Download className="w-4 h-4 sm:w-5 sm:h-5 shrink-0" /><span>حفظ</span></button>
      </div>
    </header>
  );
};
