import React, { useState } from 'react';
import {
  Pencil,
  Eraser,
  Sparkles,
  Layers,
  ChevronDown,
  Shapes,
  Circle,
  Square,
  Triangle,
  Star,
  Diamond,
  Heart,
  Check,
} from 'lucide-react';
import {
  ToolType,
  BrushSize,
  ColorOption,
  StampOption,
  ShapeOption,
  ShapeFillMode,
  BRUSH_SIZES,
  STAMP_LIST,
  SHAPES_LIST,
  BACKGROUND_OPTIONS,
} from '../types/drawing';

interface ToolBarProps {
  tool: ToolType;
  brushSize: BrushSize;
  selectedColor: ColorOption;
  selectedStamp: StampOption;
  selectedShape: ShapeOption;
  shapeFillMode: ShapeFillMode;
  backgroundColor: string;
  onSelectTool: (tool: ToolType) => void;
  onSelectBrushSize: (size: BrushSize) => void;
  onSelectStamp: (stamp: StampOption) => void;
  onSelectShape: (shape: ShapeOption) => void;
  onSelectShapeFillMode: (mode: ShapeFillMode) => void;
  onSelectBackground: (bgColor: string) => void;
  onTapSound?: () => void;
  onMagicSound?: () => void;
}

export const ToolBar: React.FC<ToolBarProps> = ({
  tool,
  brushSize,
  selectedColor,
  selectedStamp,
  selectedShape,
  shapeFillMode,
  backgroundColor,
  onSelectTool,
  onSelectBrushSize,
  onSelectStamp,
  onSelectShape,
  onSelectShapeFillMode,
  onSelectBackground,
  onTapSound,
  onMagicSound,
}) => {
  const [showStampsModal, setShowStampsModal] = useState(false);
  const [showShapesModal, setShowShapesModal] = useState(false);
  const [showBgModal, setShowBgModal] = useState(false);

  // Helper to render the corresponding Lucide shape icon
  const renderShapeIcon = (shapeId: string, className = 'w-5 h-5') => {
    switch (shapeId) {
      case 'circle':
        return <Circle className={className} />;
      case 'square':
        return <Square className={className} />;
      case 'triangle':
        return <Triangle className={className} />;
      case 'star':
        return <Star className={className} />;
      case 'diamond':
        return <Diamond className={className} />;
      case 'heart':
        return <Heart className={className} />;
      default:
        return <Shapes className={className} />;
    }
  };

  return (
    <>
      <div className="w-full bg-white/95 backdrop-blur-md px-2 py-2 sm:px-4 sm:py-2.5 rounded-2xl sm:rounded-3xl shadow-lg border-2 border-amber-200/90 flex items-center justify-between gap-1 sm:gap-3 shrink-0">
        {/* Left: Tools (Pen, Eraser, Shapes, Stamps) */}
        <div className="flex items-center gap-1 sm:gap-2 overflow-x-auto no-scrollbar py-0.5">
          {/* Pen / Brush Button */}
          <button
            onClick={() => {
              onTapSound?.();
              onSelectTool('brush');
            }}
            className={`kid-btn h-11 sm:h-13 px-2 sm:px-3.5 rounded-2xl flex items-center gap-1 font-bold transition-all shrink-0 ${
              tool === 'brush'
                ? 'bg-rose-500 text-white shadow-[0_3px_0_#be123c] ring-2 ring-rose-400 border-2 border-rose-600 scale-105'
                : 'bg-rose-50 hover:bg-rose-100 text-rose-700 border-2 border-rose-200 shadow-[0_2px_0_#f43f5e]'
            }`}
            title="قلم الرسم"
            aria-label="أداة الرسم"
          >
            <Pencil className="w-5 h-5 stroke-[2.5]" />
            <span className="text-xs sm:text-sm font-extrabold hidden xxs:inline">قلم</span>
          </button>

          {/* Eraser Button */}
          <button
            onClick={() => {
              onTapSound?.();
              onSelectTool('eraser');
            }}
            className={`kid-btn h-11 sm:h-13 px-2 sm:px-3.5 rounded-2xl flex items-center gap-1 font-bold transition-all shrink-0 ${
              tool === 'eraser'
                ? 'bg-amber-500 text-white shadow-[0_3px_0_#b45309] ring-2 ring-amber-400 border-2 border-amber-600 scale-105'
                : 'bg-amber-50 hover:bg-amber-100 text-amber-800 border-2 border-amber-200 shadow-[0_2px_0_#f59e0b]'
            }`}
            title="الممحاة"
            aria-label="أداة الممحاة"
          >
            <Eraser className="w-5 h-5 stroke-[2.5]" />
            <span className="text-xs sm:text-sm font-extrabold hidden xxs:inline">ممحاة</span>
          </button>

          {/* NEW: Shapes Button */}
          <button
            onClick={() => {
              onMagicSound?.();
              setShowShapesModal(true);
            }}
            className={`kid-btn h-11 sm:h-13 px-2 sm:px-3 rounded-2xl flex items-center gap-1 font-bold transition-all shrink-0 ${
              tool === 'shape'
                ? 'bg-indigo-600 text-white shadow-[0_3px_0_#4338ca] ring-2 ring-indigo-400 border-2 border-indigo-700 scale-105'
                : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border-2 border-indigo-200 shadow-[0_2px_0_#6366f1]'
            }`}
            title="أداة الأشكال"
            aria-label="أداة الأشكال"
          >
            {renderShapeIcon(selectedShape.id, 'w-5 h-5 stroke-[2.6]')}
            <span className="text-xs sm:text-sm font-extrabold hidden xxs:inline">أشكال</span>
            <ChevronDown className="w-3.5 h-3.5 opacity-70" />
          </button>

          {/* Stamps Button */}
          <button
            onClick={() => {
              onMagicSound?.();
              setShowStampsModal(true);
            }}
            className={`kid-btn h-11 sm:h-13 px-2 sm:px-3 rounded-2xl flex items-center gap-1 font-bold transition-all shrink-0 ${
              tool === 'stamp'
                ? 'bg-purple-600 text-white shadow-[0_3px_0_#7e22ce] ring-2 ring-purple-400 border-2 border-purple-700 scale-105'
                : 'bg-purple-50 hover:bg-purple-100 text-purple-700 border-2 border-purple-200 shadow-[0_2px_0_#a855f7]'
            }`}
            title="Stamps"
            aria-label="Stamps Tool"
          >
            <span className="text-lg leading-none">{selectedStamp.emoji}</span>
            <span className="text-xs sm:text-sm font-extrabold hidden xs:inline">ملصقات</span>
            <ChevronDown className="w-3.5 h-3.5 opacity-70" />
          </button>
        </div>

        {/* Center: Brush Size Selection (Small, Medium, Large dots) */}
        <div className="flex items-center gap-1 sm:gap-2 bg-amber-50/80 p-1 sm:p-1.5 rounded-2xl border border-amber-200 shrink-0">
          {(['small', 'medium', 'large'] as BrushSize[]).map((sizeKey) => {
            const isSelected = brushSize === sizeKey;
            const sizeData = BRUSH_SIZES[sizeKey];

            return (
              <button
                key={sizeKey}
                onClick={() => {
                  onTapSound?.();
                  onSelectBrushSize(sizeKey);
                }}
                className={`kid-btn w-9 h-9 sm:w-11 sm:h-11 rounded-xl flex items-center justify-center transition-all ${
                  isSelected
                    ? 'bg-white shadow-[0_2px_0_#d97706] ring-3 ring-amber-500 scale-108'
                    : 'hover:bg-white/60 opacity-70'
                }`}
                title={`Brush size: ${sizeData.label}`}
                aria-label={`Select ${sizeData.label} Brush Size`}
              >
                <span
                  className={`rounded-full block transition-transform ${sizeData.dotClass} ${
                    tool === 'eraser'
                      ? 'bg-amber-600'
                      : tool === 'shape'
                      ? 'bg-indigo-600'
                      : selectedColor.isRainbow
                      ? 'bg-purple-500'
                      : ''
                  }`}
                  style={{
                    backgroundColor:
                      tool === 'eraser'
                        ? '#d97706'
                        : tool === 'shape'
                        ? '#4f46e5'
                        : selectedColor.isRainbow
                        ? undefined
                        : selectedColor.hex,
                  }}
                />
              </button>
            );
          })}
        </div>

        {/* Right: Background Paper Selector */}
        <div className="flex items-center shrink-0">
          <button
            onClick={() => {
              onTapSound?.();
              setShowBgModal(true);
            }}
            className="kid-btn h-11 sm:h-13 px-2 sm:px-3 rounded-2xl bg-teal-50 hover:bg-teal-100 text-teal-800 border-2 border-teal-200 shadow-[0_2px_0_#0d9488] flex items-center gap-1.5"
            title="لون خلفية الورقة"
            aria-label="Canvas Background Color"
          >
            <Layers className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2.2] text-teal-600" />
            <div
              className="w-5 h-5 rounded-lg border border-teal-400 shadow-inner"
              style={{ backgroundColor }}
            />
          </button>
        </div>
      </div>

      {/* Shapes Modal */}
      {showShapesModal && (
        <div dir="rtl" className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-kid-pop">
          <div className="w-full max-w-xs sm:max-w-sm rounded-3xl bg-white p-5 shadow-2xl border-4 border-indigo-400 text-center">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Shapes className="w-6 h-6 text-indigo-600" />
                <h3 className="text-xl font-bold text-slate-800">اختر شكلاً</h3>
              </div>
              <button
                onClick={() => setShowShapesModal(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 font-bold flex items-center justify-center"
                aria-label="Close"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-500 mb-3">
              اختر شكلاً، ثم المس أي مكان على الورقة لوضعه.
            </p>

            {/* Shape Style Option: Filled vs Outline */}
            <div className="flex items-center justify-center gap-2 mb-4 bg-indigo-50/80 p-1.5 rounded-2xl border border-indigo-200">
              <button
                onClick={() => {
                  onTapSound?.();
                  onSelectShapeFillMode('fill');
                }}
                className={`kid-btn flex-1 py-1.5 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  shapeFillMode === 'fill'
                    ? 'bg-indigo-600 text-white shadow-[0_2px_0_#3730a3]'
                    : 'text-indigo-700 hover:bg-indigo-100'
                }`}
              >
                <div className="w-3.5 h-3.5 rounded bg-current opacity-90" />
                <span>تعبئة كاملة</span>
              </button>

              <button
                onClick={() => {
                  onTapSound?.();
                  onSelectShapeFillMode('outline');
                }}
                className={`kid-btn flex-1 py-1.5 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                  shapeFillMode === 'outline'
                    ? 'bg-indigo-600 text-white shadow-[0_2px_0_#3730a3]'
                    : 'text-indigo-700 hover:bg-indigo-100'
                }`}
              >
                <div className="w-3.5 h-3.5 rounded border-2 border-current" />
                <span>حدود فقط</span>
              </button>
            </div>

            {/* Shape Grid */}
            <div className="grid grid-cols-3 gap-2.5">
              {SHAPES_LIST.map((shape) => {
                const isSelected = tool === 'shape' && selectedShape.id === shape.id;
                return (
                  <button
                    key={shape.id}
                    onClick={() => {
                      onMagicSound?.();
                      onSelectShape(shape);
                      onSelectTool('shape');
                      setShowShapesModal(false);
                    }}
                    className={`kid-btn aspect-square rounded-2xl flex flex-col items-center justify-center gap-1.5 border-2 transition ${
                      isSelected
                        ? 'bg-indigo-100 border-indigo-500 ring-4 ring-indigo-300 scale-105'
                        : 'bg-indigo-50 hover:bg-indigo-100 border-indigo-200'
                    }`}
                  >
                    <div className="text-indigo-600">
                      {renderShapeIcon(shape.id, 'w-8 h-8 stroke-[2.4]')}
                    </div>
                    <span className="text-xs font-bold text-indigo-900">{shape.name}</span>
                    {isSelected && (
                      <span className="w-4 h-4 rounded-full bg-indigo-600 text-white flex items-center justify-center text-[9px] -mt-0.5">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Stamps Modal */}
      {showStampsModal && (
        <div dir="rtl" className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-kid-pop">
          <div className="w-full max-w-xs sm:max-w-sm rounded-3xl bg-white p-5 shadow-2xl border-4 border-purple-400 text-center">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-purple-600 animate-spin" />
                <h3 className="text-xl font-bold text-slate-800">اختر ملصقاً</h3>
              </div>
              <button
                onClick={() => setShowStampsModal(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 font-bold flex items-center justify-center"
                aria-label="Close"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-500 mb-4">
              اختر ملصقاً، ثم المس أي مكان على اللوحة لإضافته.
            </p>

            <div className="grid grid-cols-4 gap-2.5">
              {STAMP_LIST.map((stamp) => {
                const isSelected = tool === 'stamp' && selectedStamp.id === stamp.id;
                return (
                  <button
                    key={stamp.id}
                    onClick={() => {
                      onMagicSound?.();
                      onSelectStamp(stamp);
                      onSelectTool('stamp');
                      setShowStampsModal(false);
                    }}
                    className={`kid-btn aspect-square rounded-2xl flex flex-col items-center justify-center gap-1 border-2 transition ${
                      isSelected
                        ? 'bg-purple-100 border-purple-500 ring-4 ring-purple-300 scale-105'
                        : 'bg-purple-50 hover:bg-purple-100 border-purple-200'
                    }`}
                  >
                    <span className="text-3xl">{stamp.emoji}</span>
                    <span className="text-[10px] font-bold text-purple-800">{stamp.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Background Selector Modal */}
      {showBgModal && (
        <div dir="rtl" className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-kid-pop">
          <div className="w-full max-w-xs sm:max-w-sm rounded-3xl bg-white p-5 shadow-2xl border-4 border-teal-400 text-center">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Layers className="w-6 h-6 text-teal-600" />
                <h3 className="text-xl font-bold text-slate-800">خلفية الورقة</h3>
              </div>
              <button
                onClick={() => setShowBgModal(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 font-bold flex items-center justify-center"
                aria-label="Close"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-500 mb-4">
              اختر خلفية الورقة التي تفضل الرسم عليها.
            </p>

            <div className="grid grid-cols-2 gap-3">
              {BACKGROUND_OPTIONS.map((bg) => {
                const isSelected = backgroundColor === bg.color;
                return (
                  <button
                    key={bg.id}
                    onClick={() => {
                      onTapSound?.();
                      onSelectBackground(bg.color);
                      setShowBgModal(false);
                    }}
                    className={`kid-btn p-3 rounded-2xl border-3 flex flex-col items-center gap-2 transition ${
                      isSelected
                        ? 'border-teal-500 ring-4 ring-teal-200 scale-102'
                        : 'border-slate-200 hover:border-teal-300'
                    }`}
                    style={{ backgroundColor: bg.color }}
                  >
                    <div
                      className="w-8 h-8 rounded-full border-2 border-black/20 flex items-center justify-center text-sm font-bold"
                      style={{ color: bg.textColor }}
                    >
                      ✏️
                    </div>
                    <span
                      className="text-xs font-bold"
                      style={{ color: bg.textColor }}
                    >
                      {bg.name}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
