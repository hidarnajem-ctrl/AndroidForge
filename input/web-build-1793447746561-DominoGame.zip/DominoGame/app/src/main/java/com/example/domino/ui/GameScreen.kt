package com.example.domino.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.domino.model.Status
import com.example.domino.model.Turn
import com.example.domino.model.Winner
import com.example.domino.sound.SoundManager
import com.example.domino.viewmodel.GameViewModel

@Composable
private fun RoundIconButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0x99000000))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun GameScreen(vm: GameViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    val sound = remember { SoundManager(context) }
    var muted by remember { mutableStateOf(false) }

    DisposableEffect(Unit) { onDispose { sound.release() } }
    LaunchedEffect(muted) { sound.enabled = !muted }
    LaunchedEffect(vm) { vm.sounds.collect { sound.play(it) } }

    val myTurn = state.status == Status.PLAYING && state.turn == Turn.PLAYER
    val playableIds = remember(state.playerHand, state.board) {
        state.playerMoves.map { it.tile.id }.toSet()
    }

    val wood = Brush.verticalGradient(listOf(Color(0xFF4A2E17), Color(0xFF2B1A0C)))
    val felt = Brush.radialGradient(listOf(Color(0xFF1F7A45), Color(0xFF0B3A20)))

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(
            Modifier
                .fillMaxSize()
                .background(wood)
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(10.dp)
        ) {
            ScoreBoard(state.playerScore, state.aiScore, state.boneyard.size, state.turn)
            Spacer(Modifier.height(8.dp))
            AiHandView(state.aiHand.size)
            Spacer(Modifier.height(8.dp))

            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(felt)
                    .border(4.dp, Color(0xFF7A4A24), RoundedCornerShape(24.dp))
            ) {
                BoardView(
                    board = state.board,
                    startTileId = state.startTileId,
                    lastPlacedId = state.lastPlacedId,
                    selectableSides = state.selectableSides,
                    onSideClick = vm::onSideSelected,
                    modifier = Modifier.fillMaxSize()
                )
                Box(Modifier.align(Alignment.TopStart).padding(10.dp)) {
                    RoundIconButton(if (muted) "🔇" else "🔊") { muted = !muted }
                }
            }

            Spacer(Modifier.height(8.dp))
            Text(
                state.message,
                color = Color(0xFFFFE9A8),
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Box(Modifier.fillMaxWidth().height(48.dp), contentAlignment = Alignment.Center) {
                if (state.canPlayerDraw) {
                    Button(onClick = vm::onDrawClicked) {
                        Text("اسحب من المكدس (${state.boneyard.size})")
                    }
                }
            }
            HandView(
                hand = state.playerHand,
                playableIds = playableIds,
                selectedId = state.selectedTileId,
                myTurn = myTurn,
                onTileClick = vm::onTileClicked,
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (state.status == Status.ROUND_OVER) {
            val r = state.result
            AlertDialog(
                onDismissRequest = {},
                confirmButton = { Button(onClick = vm::startNewRound) { Text("جولة جديدة") } },
                title = {
                    Text(
                        when (r?.winner) {
                            Winner.PLAYER -> "🎉 فزت بالجولة!"
                            Winner.AI -> "خسرت الجولة"
                            else -> "تعادل"
                        }
                    )
                },
                text = {
                    Text(
                        (if (r?.blocked == true) "اللعبة مغلقة (Block) — الفوز لصاحب النقاط الأقل.\n" else "") +
                                "النقاط المكتسبة: ${r?.points ?: 0}\n" +
                                "أنت ${state.playerScore}  |  الكمبيوتر ${state.aiScore}"
                    )
                }
            )
        }
    }
}
