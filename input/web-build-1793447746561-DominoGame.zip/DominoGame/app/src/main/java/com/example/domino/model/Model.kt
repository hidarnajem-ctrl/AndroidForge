package com.example.domino.model

import kotlin.random.Random

/** حجر دومينو: left/right هما قيمتا الطرفين بحسب اتجاه العرض الحالي (التدوير = flipped). */
data class DominoTile(val id: Int, val left: Int, val right: Int) {
    val pips: Int get() = left + right
    val isDouble: Boolean get() = left == right
    fun has(n: Int) = left == n || right == n
    fun flipped() = DominoTile(id, right, left)
}

enum class Side { LEFT, RIGHT }
enum class Turn { PLAYER, AI }
enum class Status { PLAYING, ROUND_OVER }
enum class Winner { PLAYER, AI, DRAW }

data class Move(val tile: DominoTile, val side: Side)
data class RoundResult(val winner: Winner, val points: Int, val blocked: Boolean)

/** منطق اللعبة الصرف (بدون واجهة) — سهل الاختبار. */
object GameEngine {

    /** 28 حجراً من 0-0 إلى 6-6 */
    fun fullSet(): List<DominoTile> {
        var id = 0
        return buildList { for (a in 0..6) for (b in a..6) add(DominoTile(id++, a, b)) }
    }

    /** الأطراف المسموحة لوضع الحجر (تحقق صارم من المطابقة). */
    fun legalSides(tile: DominoTile, board: List<DominoTile>): Set<Side> {
        if (board.isEmpty()) return setOf(Side.RIGHT)
        val sides = mutableSetOf<Side>()
        if (tile.has(board.first().left)) sides += Side.LEFT
        if (tile.has(board.last().right)) sides += Side.RIGHT
        return sides
    }

    /** يضع الحجر مع تدويره تلقائياً ليتصل بالرقم المطابق. السلسلة دائماً: right(i) == left(i+1) */
    fun place(board: List<DominoTile>, tile: DominoTile, side: Side): List<DominoTile> {
        if (board.isEmpty()) return listOf(tile)
        return when (side) {
            Side.LEFT -> {
                val t = if (tile.right == board.first().left) tile else tile.flipped()
                listOf(t) + board
            }
            Side.RIGHT -> {
                val t = if (tile.left == board.last().right) tile else tile.flipped()
                board + t
            }
        }
    }

    fun possibleMoves(hand: List<DominoTile>, board: List<DominoTile>): List<Move> =
        hand.flatMap { t -> legalSides(t, board).map { Move(t, it) } }

    fun pips(hand: List<DominoTile>) = hand.sumOf { it.pips }

    /** ذكاء بسيط: يفضّل الأحجار الثقيلة والدبل، ويُبقي أطرافاً يملك أحجاراً تطابقها. */
    fun chooseAiMove(hand: List<DominoTile>, board: List<DominoTile>): Move? =
        possibleMoves(hand, board).maxByOrNull { m ->
            val nb = place(board, m.tile, m.side)
            val ends = listOf(nb.first().left, nb.last().right)
            val keep = (hand - m.tile).count { r -> ends.any { r.has(it) } }
            m.tile.pips + (if (m.tile.isDouble) 3 else 0) + keep * 3 + Random.nextFloat()
        }
}

/** أحداث صوتية يصدرها الـ ViewModel وتشغّلها الواجهة. */
enum class GameSound { SELECT, PLACE, DRAW, INVALID, WIN, LOSE }
