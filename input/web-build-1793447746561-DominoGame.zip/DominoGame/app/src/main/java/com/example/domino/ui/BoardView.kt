package com.example.domino.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domino.model.DominoTile
import com.example.domino.model.Side
import kotlin.math.roundToInt

private val GhostGold = Color(0xFFFFD54F)

// ════════════════ التخطيط (بوحدة «خلية» = الضلع القصير للحجر) ════════════════

/** عنصر على اللوحة. tile بقيم العرض (left/right كما تُرسم). ghost != null = مكان فارغ قابل للضغط. */
internal data class PlacedItem(
    val tile: DominoTile,
    val cx: Float,
    val cy: Float,
    val horizontal: Boolean,
    val ghost: Side? = null
)

private class ArmItem(
    val tile: DominoTile, // left = القيمة الأقرب للمركز، right = الأبعد
    val cx: Float, val cy: Float,
    val dx: Int, val dy: Int,
    val perpendicular: Boolean
)

/**
 * يمدّ ذراعاً من نقطة البداية: أفقياً (شرقاً/غرباً) ثم ينعطف للأسفل بحجرين (زاوية) ويعود بالاتجاه المعاكس.
 * الأحجار أفقية في الصفوف وعمودية عند الزوايا، والدبل عمودي (متعامد) في الصف.
 */
private fun layoutArm(tiles: List<DominoTile>, startX: Float, limit: Float): List<ArmItem> {
    val out = ArrayList<ArmItem>()
    var px = startX
    var py = 0f
    var dir = 1
    var pendingCorner = false
    for (t in tiles) {
        if (pendingCorner) {
            // الزاوية الثانية: من الاتجاه جنوباً إلى الاتجاه المعاكس
            out += ArmItem(t, px - 0.5f * dir, py + 0.5f, -dir, 0, false)
            px -= 1.5f * dir
            py += 0.5f
            dir = -dir
            pendingCorner = false
        } else {
            val need = if (t.isDouble) 1f else 2f
            if (dir * (px + dir * need) <= limit) {
                if (t.isDouble) {
                    out += ArmItem(t, px + dir * 0.5f, py, dir, 0, true)
                    px += dir
                } else {
                    out += ArmItem(t, px + dir * 1f, py, dir, 0, false)
                    px += 2f * dir
                }
            } else {
                // الزاوية الأولى: من الاتجاه الأفقي إلى الأسفل
                out += ArmItem(t, px + 0.5f * dir, py + 0.5f, 0, 1, false)
                px += 0.5f * dir
                py += 1.5f
                pendingCorner = true
            }
        }
    }
    return out
}

private fun toPlaced(a: ArmItem, rotate: Boolean): PlacedItem {
    val sg = if (rotate) -1 else 1
    val dx = a.dx * sg
    val dy = a.dy * sg
    val cx = a.cx * sg
    val cy = a.cy * sg
    val ghost = when (a.tile.id) { -1 -> Side.RIGHT; -2 -> Side.LEFT; else -> null }
    val t = a.tile
    return when {
        a.perpendicular -> PlacedItem(t, cx, cy, false, ghost)
        dx != 0 -> PlacedItem(if (dx > 0) t else t.flipped(), cx, cy, true, ghost)
        else -> PlacedItem(if (dy > 0) t else t.flipped(), cx, cy, false, ghost)
    }
}

private fun buildItems(
    board: List<DominoTile>, startId: Int, ghostL: Boolean, ghostR: Boolean, limit: Float
): List<PlacedItem> {
    if (board.isEmpty()) return emptyList()
    val s = board.indexOfFirst { it.id == startId }.coerceAtLeast(0)
    val start = board[s]
    val half = if (start.isDouble) 0.5f else 1f
    val right = board.subList(s + 1, board.size) + (if (ghostR) listOf(DominoTile(-1, 0, 1)) else emptyList())
    val left = board.subList(0, s).reversed().map { it.flipped() } +
            (if (ghostL) listOf(DominoTile(-2, 0, 1)) else emptyList())

    val items = ArrayList<PlacedItem>()
    items += PlacedItem(start, 0f, 0f, !start.isDouble)
    layoutArm(right, half, limit).forEach { items += toPlaced(it, rotate = false) }
    layoutArm(left, half, limit).forEach { items += toPlaced(it, rotate = true) }
    return items
}

internal class FittedLayout(val items: List<PlacedItem>, val cellPx: Float, val centerX: Float, val centerY: Float)

/** يجرّب عدة أطوال للصف ويختار الأكبر حجماً بحيث تبقى كل الأحجار داخل الطاولة. */
internal fun fitLayout(
    board: List<DominoTile>, startId: Int, ghostL: Boolean, ghostR: Boolean,
    wPx: Float, hPx: Float, maxCellPx: Float
): FittedLayout {
    var best: FittedLayout? = null
    var limit = 3f
    while (limit <= 16f) {
        val items = buildItems(board, startId, ghostL, ghostR, limit)
        if (items.isNotEmpty()) {
            fun w(i: PlacedItem) = if (i.horizontal) 2f else 1f
            fun h(i: PlacedItem) = if (i.horizontal) 1f else 2f
            val minX = items.minOf { it.cx - w(it) / 2 }
            val maxX = items.maxOf { it.cx + w(it) / 2 }
            val minY = items.minOf { it.cy - h(it) / 2 }
            val maxY = items.maxOf { it.cy + h(it) / 2 }
            val scale = minOf(wPx / (maxX - minX), hPx / (maxY - minY))
            val eff = minOf(scale, maxCellPx)
            val b = best
            if (b == null || eff >= b.cellPx - 0.01f) {
                best = FittedLayout(items, eff, (minX + maxX) / 2, (minY + maxY) / 2)
            }
        }
        limit += 1f
    }
    return best ?: FittedLayout(emptyList(), maxCellPx, 0f, 0f)
}

// ════════════════ الواجهة ════════════════

@Composable
private fun AppearTile(content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    AnimatedVisibility(
        visible = shown,
        enter = scaleIn(spring(dampingRatio = 0.55f, stiffness = 320f), initialScale = 0.3f) + fadeIn()
    ) { content() }
}

@Composable
private fun GhostSlot(cell: Dp, horizontal: Boolean, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "pulse")
    val a by t.animateFloat(0.35f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "alpha")
    Box(
        Modifier
            .size(if (horizontal) cell * 2 else cell, if (horizontal) cell else cell * 2)
            .graphicsLayer { alpha = a }
            .border(2.dp, GhostGold, RoundedCornerShape(cell * 0.2f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text("+", color = GhostGold, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun PlacedTile(
    item: PlacedItem, tx: Float, ty: Float, cellPx: Float,
    highlighted: Boolean, onGhostClick: () -> Unit
) {
    val spec = spring<Float>(dampingRatio = 0.8f, stiffness = 250f)
    val x by animateFloatAsState(tx, spec, label = "x")
    val y by animateFloatAsState(ty, spec, label = "y")
    val c by animateFloatAsState(cellPx, spec, label = "cell")
    val density = LocalDensity.current
    val wPx = c * (if (item.horizontal) 2f else 1f)
    val hPx = c * (if (item.horizontal) 1f else 2f)
    val cellDp = with(density) { c.toDp() }

    Box(Modifier.offset { IntOffset((x - wPx / 2).roundToInt(), (y - hPx / 2).roundToInt()) }) {
        if (item.ghost != null) {
            GhostSlot(cellDp, item.horizontal, onGhostClick)
        } else {
            AppearTile {
                TileView(item.tile, horizontal = item.horizontal, cell = cellDp, highlighted = highlighted)
            }
        }
    }
}

/**
 * لوحة «ثعبانية»: تمتد الأحجار أفقياً ثم تنعطف عمودياً وتعود، ويُضبط الحجم تلقائياً
 * فتبقى كل الأحجار داخل الطاولة الخضراء دائماً.
 */
@Composable
fun BoardView(
    board: List<DominoTile>,
    startTileId: Int,
    lastPlacedId: Int?,
    selectableSides: Set<Side>,
    onSideClick: (Side) -> Unit,
    modifier: Modifier = Modifier
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        BoxWithConstraints(modifier) {
            val density = LocalDensity.current
            val wPx = with(density) { (maxWidth - 24.dp).toPx() }
            val hPx = with(density) { (maxHeight - 24.dp).toPx() }
            val maxCellPx = with(density) { 46.dp.toPx() }

            val fitted = remember(board, startTileId, selectableSides, wPx, hPx) {
                fitLayout(
                    board, startTileId,
                    Side.LEFT in selectableSides, Side.RIGHT in selectableSides,
                    wPx, hPx, maxCellPx
                )
            }
            val ox = constraints.maxWidth / 2f
            val oy = constraints.maxHeight / 2f

            fitted.items.forEach { item ->
                key(item.tile.id) {
                    PlacedTile(
                        item = item,
                        tx = ox + (item.cx - fitted.centerX) * fitted.cellPx,
                        ty = oy + (item.cy - fitted.centerY) * fitted.cellPx,
                        cellPx = fitted.cellPx,
                        highlighted = item.tile.id == lastPlacedId,
                        onGhostClick = { item.ghost?.let(onSideClick) }
                    )
                }
            }
        }
    }
}
