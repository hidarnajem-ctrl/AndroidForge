package com.example.domino.sound

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import com.example.domino.R
import com.example.domino.model.GameSound

class SoundManager(context: Context) {
    var enabled: Boolean = true

    private val pool = SoundPool.Builder()
        .setMaxStreams(4)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        ).build()

    private val ids: Map<GameSound, Int> = mapOf(
        GameSound.SELECT to pool.load(context, R.raw.sfx_select, 1),
        GameSound.PLACE to pool.load(context, R.raw.sfx_place, 1),
        GameSound.DRAW to pool.load(context, R.raw.sfx_draw, 1),
        GameSound.INVALID to pool.load(context, R.raw.sfx_invalid, 1),
        GameSound.WIN to pool.load(context, R.raw.sfx_win, 1),
        GameSound.LOSE to pool.load(context, R.raw.sfx_lose, 1)
    )

    fun play(sound: GameSound) {
        if (!enabled) return
        ids[sound]?.let { pool.play(it, 1f, 1f, 1, 0, 1f) }
    }

    fun release() = pool.release()
}
