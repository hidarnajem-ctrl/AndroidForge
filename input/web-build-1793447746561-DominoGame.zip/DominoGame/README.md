# لعبة دومينو (Kotlin + Jetpack Compose + MVVM)

مشروع Gradle كامل؛ افتحه في Android Studio أو ارفعه كما هو لموقع البناء.

## ما الجديد
- لوحة ثعبانية: الأحجار تمتد أفقياً ثم تنعطف عمودياً وتعود، ويُضبط الحجم تلقائياً فلا يخرج أي حجر من الطاولة.
- علامة «+» نابضة تحدد مكان الحجر التالي عند وجود طرفين ممكنين.
- أصوات: اختيار حجر، وضع حجر، سحب، حركة غير صالحة/تمرير، فوز، خسارة (ملفات WAV في res/raw)، وزر 🔊/🔇 لكتم الصوت.

## الهيكلة
model/Model.kt · viewmodel/GameViewModel.kt · sound/SoundManager.kt
ui/{TileView+HandView+ScoreBoard (Components.kt), BoardView.kt, GameScreen.kt}
