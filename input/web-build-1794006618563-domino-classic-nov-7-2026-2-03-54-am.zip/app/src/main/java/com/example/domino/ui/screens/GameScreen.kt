package com.example.domino.ui.screens

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.domino.ads.AdMobManager
import com.example.domino.audio.AudioService
import com.example.domino.data.GamePreferences
import com.example.domino.data.ShopCatalog
import com.example.domino.engine.AIDifficulty
import com.example.domino.engine.BoardEnd
import com.example.domino.engine.DominoGameState
import com.example.domino.engine.DominoRules
import com.example.domino.engine.DominoTile
import com.example.domino.engine.PlayerTurn
import com.example.domino.engine.RoundEndReason
import com.example.domino.ui.components.DominoTileBackView
import com.example.domino.ui.components.DominoTileView
import com.example.domino.ui.components.LuxuryButton
import com.example.domino.ui.components.PlayerAvatarBadge
import kotlinx.coroutines.delay

@Composable
fun GameScreen(
    gameState: DominoGameState,
    playerData: GamePreferences.PlayerData,
    audioService: AudioService,
    adMobManager: AdMobManager,
    onSelectTile: (DominoTile?) -> Unit,
    onPlayTileEnd: (tile: DominoTile, end: BoardEnd) -> Unit,
    onDraw: () -> Unit,
    onPass: () -> Unit,
    onExecuteAITurn: () -> Unit,
    onProceedNextRound: () -> Unit,
    onSurrenderAndExit: () -> Unit,
    onRestartMatch: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    var showPauseDialog by remember { mutableStateOf(false) }

    // Intercept hardware / gesture back button to show pause dialog
    BackHandler {
        showPauseDialog = true
    }

    val boardScrollState = rememberScrollState()
    val tableTheme = ShopCatalog.getBoardTheme(playerData.boardThemeId)

    // Trigger AI turn after brief natural thinking delay
    LaunchedEffect(gameState.currentTurn, gameState.isRoundOver) {
        if (gameState.currentTurn == PlayerTurn.OPPONENT && !gameState.isRoundOver) {
            delay(900)
            onExecuteAITurn()
        }
    }

    // Audio cues on round end
    LaunchedEffect(gameState.isRoundOver) {
        if (gameState.isRoundOver) {
            if (gameState.roundResult?.winner == PlayerTurn.PLAYER) {
                audioService.playWinChime()
            } else {
                audioService.playPassSound()
            }
        }
    }

    // Auto-scroll to center or ends when new tile is placed
    LaunchedEffect(gameState.boardTiles.size) {
        if (gameState.boardTiles.isNotEmpty()) {
            boardScrollState.animateScrollTo(boardScrollState.maxValue / 2)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Table Background
        Image(
            painter = painterResource(id = R.drawable.bg_emerald_felt),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Overlay with Board Theme Tint
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(tableTheme.primaryColor.copy(alpha = 0.55f))
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            // Top Bar: Opponent Info, Score Header, Pause Button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Opponent Info
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PlayerAvatarBadge(
                        avatarId = "avatar_ace",
                        level = when (gameState.aiDifficulty) {
                            AIDifficulty.EASY -> 2
                            AIDifficulty.MEDIUM -> 5
                            AIDifficulty.EXPERT -> 10
                        },
                        size = 42.dp,
                        isOnline = false
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = when (gameState.aiDifficulty) {
                                AIDifficulty.EASY -> "الكمبيوتر (سهل)"
                                AIDifficulty.MEDIUM -> "الكمبيوتر (متوسط)"
                                AIDifficulty.EXPERT -> "خبير الدومينو"
                            },
                            color = Color(0xFFF5FAF7),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        // Opponent Hand Hidden Tiles Representation
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "🀄 ${gameState.opponentHandCount} قطع",
                                color = Color(0xFFA6C9B9),
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                // Match Score Board
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF07271B).copy(alpha = 0.85f)),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(Color(0xFFFFD700), Color(0xFF104230))))
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = stringResource(R.string.game_round, gameState.currentRound),
                            color = Color(0xFFA6C9B9),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${gameState.playerScore}",
                                color = Color(0xFFFFD700),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 17.sp
                            )
                            Text(
                                text = " : ",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "${gameState.opponentScore}",
                                color = Color(0xFFE2E8F0),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 17.sp
                            )
                        }
                        Text(
                            text = stringResource(R.string.game_target_score, gameState.targetScore),
                            color = Color(0xFFFFD700).copy(alpha = 0.8f),
                            fontSize = 9.sp
                        )
                    }
                }

                // Pause Button
                IconButton(
                    onClick = { showPauseDialog = true },
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF07271B).copy(alpha = 0.7f))
                        .testTag("btn_game_pause")
                ) {
                    Icon(
                        imageVector = Icons.Default.Pause,
                        contentDescription = stringResource(R.string.btn_pause),
                        tint = Color(0xFFFFD700),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Central Domino Chain Play Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                if (gameState.boardTiles.isEmpty()) {
                    // Empty Board State with guide
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF07271B).copy(alpha = 0.7f)),
                        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.verticalGradient(listOf(Color(0xFFFFD700).copy(alpha = 0.5f), Color.Transparent)))
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "طاولة الدومينو الملكية",
                                color = Color(0xFFFFD700),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (gameState.currentTurn == PlayerTurn.PLAYER)
                                    "اختر قطعة من يدك لبدء الجولة"
                                else
                                    "الخصم يضع القطعة الأولى...",
                                color = Color(0xFFA6C9B9),
                                fontSize = 13.sp
                            )
                        }
                    }
                } else {
                    // Domino Chain Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(boardScrollState)
                            .padding(vertical = 16.dp, horizontal = 24.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        // Left End Play Target if tile selected
                        if (gameState.selectedTile != null && gameState.eligibleEndsForSelectedTile.contains(BoardEnd.LEFT)) {
                            EndPlacementButton(
                                label = "ضع يساراً [${gameState.leftEndValue}]",
                                onClick = {
                                    audioService.playTileClack()
                                    onPlayTileEnd(gameState.selectedTile, BoardEnd.LEFT)
                                },
                                testTag = "place_left_end_btn"
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                        }

                        // Placed Tiles in the Chain
                        for (placed in gameState.boardTiles) {
                            DominoTileView(
                                tile = placed.tile,
                                skinId = playerData.tileSkinId,
                                isVertical = placed.isVertical,
                                width = 36.dp,
                                height = 72.dp,
                                modifier = Modifier.padding(horizontal = 2.dp)
                            )
                        }

                        // Right End Play Target if tile selected
                        if (gameState.selectedTile != null && gameState.eligibleEndsForSelectedTile.contains(BoardEnd.RIGHT)) {
                            Spacer(modifier = Modifier.width(8.dp))
                            EndPlacementButton(
                                label = "ضع يميناً [${gameState.rightEndValue}]",
                                onClick = {
                                    audioService.playTileClack()
                                    onPlayTileEnd(gameState.selectedTile, BoardEnd.RIGHT)
                                },
                                testTag = "place_right_end_btn"
                            )
                        }
                    }
                }
            }

            // Turn Indicator Banner
            TurnIndicatorPill(
                currentTurn = gameState.currentTurn,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(bottom = 6.dp)
            )

            // Player Bottom Hand and Actions Area
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF041911).copy(alpha = 0.94f),
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(Color(0xFFFFD700).copy(alpha = 0.6f), Color(0xFF0A3424))))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    // Actions Bar: Boneyard Draw / Pass buttons
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "يدك (${gameState.playerHand.size} قطع) | البنك: ${gameState.boneyardCount}",
                            color = Color(0xFFA6C9B9),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            // Draw Button
                            if (gameState.canPlayerDraw) {
                                LuxuryButton(
                                    text = stringResource(R.string.game_draw) + " (${gameState.boneyardCount})",
                                    onClick = {
                                        audioService.playTileDraw()
                                        onDraw()
                                    },
                                    isSecondary = false,
                                    enabled = true,
                                    modifier = Modifier.height(38.dp),
                                    testTag = "btn_game_draw"
                                )
                            }

                            // Pass Button
                            if (gameState.canPlayerPass) {
                                LuxuryButton(
                                    text = stringResource(R.string.game_pass),
                                    onClick = {
                                        audioService.playPassSound()
                                        onPass()
                                    },
                                    isSecondary = true,
                                    enabled = true,
                                    modifier = Modifier.height(38.dp),
                                    testTag = "btn_game_pass"
                                )
                            }
                        }
                    }

                    // Player Tiles Hand Row
                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(106.dp)
                            .testTag("player_hand_row"),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        items(gameState.playerHand, key = { it.id }) { tile ->
                            val canPlay = gameState.boardTiles.isEmpty() ||
                                    tile.canMatch(gameState.leftEndValue ?: -1) ||
                                    tile.canMatch(gameState.rightEndValue ?: -1)

                            DominoTileView(
                                tile = tile,
                                skinId = playerData.tileSkinId,
                                isVertical = true,
                                isSelected = gameState.selectedTile?.id == tile.id,
                                isPlayable = canPlay && gameState.currentTurn == PlayerTurn.PLAYER,
                                width = 46.dp,
                                height = 92.dp,
                                onClick = {
                                    if (gameState.currentTurn == PlayerTurn.PLAYER) {
                                        audioService.playTileClack()
                                        onSelectTile(if (gameState.selectedTile?.id == tile.id) null else tile)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }

        // Round Over / Match Over Modal Dialog
        if (gameState.isRoundOver) {
            val result = gameState.roundResult
            val isPlayerWinner = result?.winner == PlayerTurn.PLAYER
            val isTie = result?.winner == null

            Dialog(onDismissRequest = { /* Must click action button */ }) {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = Color(0xFF07271B),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.verticalGradient(listOf(Color(0xFFFFD700), Color(0xFF0A3424)))),
                    modifier = Modifier.padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = when {
                                gameState.isMatchOver && isPlayerWinner -> "🏆 " + stringResource(R.string.match_won_title)
                                gameState.isMatchOver && !isPlayerWinner -> "💔 " + stringResource(R.string.match_lost_title)
                                isPlayerWinner -> "✨ " + stringResource(R.string.game_domino_title)
                                isTie -> "⚖️ " + stringResource(R.string.round_tie)
                                else -> "⚠️ " + stringResource(R.string.round_winner_opponent, result?.pointsAwarded ?: 0)
                            },
                            color = if (isPlayerWinner) Color(0xFFFFD700) else Color(0xFFF5FAF7),
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 20.sp,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = when (result?.reason) {
                                RoundEndReason.DOMINO -> stringResource(R.string.game_domino_msg)
                                RoundEndReason.BLOCKED -> stringResource(R.string.game_blocked_msg)
                                else -> ""
                            },
                            color = Color(0xFFA6C9B9),
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Points and Pips breakdown
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0D3828)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("نقاط يدك المتبقية:", color = Color(0xFFA6C9B9), fontSize = 12.sp)
                                    Text("${result?.playerHandPips ?: 0}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("نقاط يد الخصم المتبقية:", color = Color(0xFFA6C9B9), fontSize = 12.sp)
                                    Text("${result?.opponentHandPips ?: 0}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("النقاط المكتسبة بالجولة:", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("+${result?.pointsAwarded ?: 0}", color = Color(0xFFFFD700), fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // Next Round / Rematch Button (triggers interstitial check!)
                        LuxuryButton(
                            text = if (gameState.isMatchOver) stringResource(R.string.btn_play_again) else stringResource(R.string.btn_resume),
                            onClick = {
                                adMobManager.onRoundCompleted(activity) {
                                    onProceedNextRound()
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "btn_next_round_modal"
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        LuxuryButton(
                            text = stringResource(R.string.btn_main_menu),
                            onClick = onSurrenderAndExit,
                            isSecondary = true,
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "btn_exit_to_home"
                        )
                    }
                }
            }
        }

        // Pause Menu Dialog
        if (showPauseDialog) {
            Dialog(onDismissRequest = { showPauseDialog = false }) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF07271B),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.verticalGradient(listOf(Color(0xFFFFD700), Color(0xFF0A3424)))),
                    modifier = Modifier.padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = stringResource(R.string.btn_pause),
                            color = Color(0xFFFFD700),
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        LuxuryButton(
                            text = stringResource(R.string.btn_resume),
                            onClick = { showPauseDialog = false },
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "btn_pause_resume"
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        LuxuryButton(
                            text = stringResource(R.string.btn_play_again),
                            onClick = {
                                showPauseDialog = false
                                onRestartMatch()
                            },
                            isSecondary = true,
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "btn_pause_restart"
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        LuxuryButton(
                            text = stringResource(R.string.btn_surrender),
                            onClick = {
                                showPauseDialog = false
                                onSurrenderAndExit()
                            },
                            isSecondary = true,
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "btn_pause_surrender"
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EndPlacementButton(
    label: String,
    onClick: () -> Unit,
    testTag: String
) {
    Box(
        modifier = Modifier
            .testTag(testTag)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFFFFD700))
            .border(1.5.dp, Color.White, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = Color(0xFF07271B),
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun TurnIndicatorPill(
    currentTurn: PlayerTurn,
    modifier: Modifier = Modifier
) {
    val isPlayer = currentTurn == PlayerTurn.PLAYER
    val bgColors = if (isPlayer) {
        listOf(Color(0xFF22C55E).copy(alpha = 0.85f), Color(0xFF15803D).copy(alpha = 0.85f))
    } else {
        listOf(Color(0xFFEAB308).copy(alpha = 0.85f), Color(0xFFCA8A04).copy(alpha = 0.85f))
    }

    Box(
        modifier = modifier
            .shadow(4.dp, RoundedCornerShape(20.dp))
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.horizontalGradient(bgColors))
            .border(1.dp, Color.White.copy(alpha = 0.7f), RoundedCornerShape(20.dp))
            .padding(horizontal = 14.dp, vertical = 5.dp)
    ) {
        Text(
            text = if (isPlayer) stringResource(R.string.game_your_turn) else stringResource(R.string.game_opponent_turn),
            color = Color(0xFF041911),
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
        )
    }
}
