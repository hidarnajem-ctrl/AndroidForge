package com.example.domino.engine

/**
 * Immutable state snapshot of the active Domino match.
 */
data class DominoGameState(
    val boardTiles: List<PlacedTile> = emptyList(),
    val leftEndValue: Int? = null,
    val rightEndValue: Int? = null,
    val playerHand: List<DominoTile> = emptyList(),
    val opponentHandCount: Int = 7,
    val opponentHandTiles: List<DominoTile> = emptyList(), // Visible in debug/testing
    val boneyardCount: Int = 14,
    val currentTurn: PlayerTurn = PlayerTurn.PLAYER,
    val playerScore: Int = 0,
    val opponentScore: Int = 0,
    val targetScore: Int = 100,
    val currentRound: Int = 1,
    val variant: GameRuleVariant = GameRuleVariant.DRAW,
    val aiDifficulty: AIDifficulty = AIDifficulty.MEDIUM,
    val isRoundOver: Boolean = false,
    val isMatchOver: Boolean = false,
    val roundResult: DominoRules.RoundResult? = null,
    val matchWinner: PlayerTurn? = null,
    val selectedTile: DominoTile? = null,
    val eligibleEndsForSelectedTile: List<BoardEnd> = emptyList(),
    val canPlayerDraw: Boolean = false,
    val canPlayerPass: Boolean = false,
    val lastActionDescription: String = "",
    val roundCountForAds: Int = 0
)
