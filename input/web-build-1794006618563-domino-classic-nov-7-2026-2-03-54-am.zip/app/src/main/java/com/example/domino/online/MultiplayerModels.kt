package com.example.domino.online

import com.example.domino.engine.BoardEnd
import com.example.domino.engine.DominoTile
import com.example.domino.engine.GameRuleVariant

enum class RoomStatus {
    IDLE,
    WAITING_FOR_OPPONENT,
    SEARCHING_MATCHMAKING,
    OPPONENT_JOINED,
    PLAYING,
    DISCONNECTED,
    MATCH_OVER
}

data class PlayerInfo(
    val uid: String,
    val name: String,
    val avatarId: String,
    val level: Int,
    val isHost: Boolean,
    val isReady: Boolean = true,
    val isOnline: Boolean = true
)

data class MultiplayerRoom(
    val roomId: String,
    val roomCode: String,
    val hostPlayer: PlayerInfo,
    val guestPlayer: PlayerInfo? = null,
    val status: RoomStatus = RoomStatus.WAITING_FOR_OPPONENT,
    val ruleVariant: GameRuleVariant = GameRuleVariant.DRAW,
    val targetScore: Int = 100,
    val currentTurnUid: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class MovePayload(
    val moveId: String,
    val playerUid: String,
    val tileId: Int,
    val placedEnd: BoardEnd,
    val timestamp: Long = System.currentTimeMillis()
)
