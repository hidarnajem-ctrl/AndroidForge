package com.example.domino.engine

import kotlin.random.Random

/**
 * AI engine for Domino Classic with Easy, Medium, and Expert algorithms.
 */
class DominoAI(
    private val difficulty: AIDifficulty = AIDifficulty.MEDIUM,
    private val random: Random = Random.Default
) {
    data class AIMove(
        val tile: DominoTile,
        val targetEnd: BoardEnd
    )

    // Tracks numbers that the opponent was unable to play on (passed turns)
    private val opponentMissingValues = mutableSetOf<Int>()

    fun resetMemory() {
        opponentMissingValues.clear()
    }

    /**
     * Records that the opponent passed on the current open ends.
     */
    fun recordOpponentPass(leftEnd: Int?, rightEnd: Int?) {
        leftEnd?.let { opponentMissingValues.add(it) }
        rightEnd?.let { opponentMissingValues.add(it) }
    }

    /**
     * Chooses the best legal move given the board and current hand.
     * Returns null if no legal move is possible.
     */
    fun decideMove(board: DominoBoard, hand: List<DominoTile>): AIMove? {
        if (hand.isEmpty()) return null

        // Collect all legal moves
        val legalMoves = mutableListOf<AIMove>()
        if (board.isEmpty) {
            // First move: any tile
            for (tile in hand) {
                legalMoves.add(AIMove(tile, BoardEnd.LEFT))
            }
        } else {
            for (tile in hand) {
                val ends = board.getLegalEnds(tile)
                for (end in ends) {
                    legalMoves.add(AIMove(tile, end))
                }
            }
        }

        if (legalMoves.isEmpty()) return null

        return when (difficulty) {
            AIDifficulty.EASY -> chooseEasyMove(legalMoves)
            AIDifficulty.MEDIUM -> chooseMediumMove(board, legalMoves)
            AIDifficulty.EXPERT -> chooseExpertMove(board, hand, legalMoves)
        }
    }

    private fun chooseEasyMove(moves: List<AIMove>): AIMove {
        // Casual / random legal choice
        return moves.random(random)
    }

    private fun chooseMediumMove(board: DominoBoard, moves: List<AIMove>): AIMove {
        // Medium: prioritize doubles, then highest pip count
        val doubleMove = moves.firstOrNull { it.tile.isDouble }
        if (doubleMove != null) {
            return doubleMove
        }
        return moves.maxByOrNull { it.tile.pipTotal } ?: moves.first()
    }

    private fun chooseExpertMove(
        board: DominoBoard,
        hand: List<DominoTile>,
        moves: List<AIMove>
    ): AIMove {
        if (board.isEmpty) {
            // First move: play highest double if available, else tile with most suit synergy
            val double = hand.filter { it.isDouble }.maxByOrNull { it.pipTotal }
            if (double != null) {
                return AIMove(double, BoardEnd.LEFT)
            }
            return moves.maxByOrNull { it.tile.pipTotal } ?: moves.first()
        }

        // Score each candidate move based on multiple strategic heuristics
        var bestMove = moves.first()
        var bestScore = Int.MIN_VALUE

        for (move in moves) {
            var score = 0
            val tile = move.tile

            // 1. Hand pip risk reduction: Higher pips are scored higher to dump early
            score += tile.pipTotal * 2

            // 2. Doubles priority: Doubles only have one suit and are harder to play later
            if (tile.isDouble) {
                score += 15
            }

            // 3. New resulting exposed end calculation:
            val currentLeft = board.leftEndValue
            val currentRight = board.rightEndValue

            val newExposedEnd = when (move.targetEnd) {
                BoardEnd.LEFT -> {
                    if (tile.right == currentLeft) tile.left else tile.right
                }
                BoardEnd.RIGHT -> {
                    if (tile.left == currentRight) tile.right else tile.left
                }
            }

            // 4. Blocking Opponent: If new open end matches a value opponent cannot play, huge bonus!
            if (opponentMissingValues.contains(newExposedEnd)) {
                score += 35
            }

            // 5. Suit synergy: How many other tiles in our remaining hand match this new open end?
            val matchingInHand = hand.count { it.id != tile.id && (it.left == newExposedEnd || it.right == newExposedEnd) }
            score += matchingInHand * 8

            // 6. Avoid creating an end value where we have zero matching backups
            if (matchingInHand == 0 && hand.size > 2) {
                score -= 10
            }

            if (score > bestScore) {
                bestScore = score
                bestMove = move
            }
        }

        return bestMove
    }
}
