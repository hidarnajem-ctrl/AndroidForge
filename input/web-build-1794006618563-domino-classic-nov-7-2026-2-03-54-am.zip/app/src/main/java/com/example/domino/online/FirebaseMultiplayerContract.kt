package com.example.domino.online

import kotlinx.coroutines.flow.StateFlow

/**
 * Interface contract connecting the native Domino Game Engine with
 * Firebase Firestore or Firebase Realtime Database for online play.
 */
interface MultiplayerRepository {
    val currentRoom: StateFlow<MultiplayerRoom?>

    suspend fun createPrivateRoom(host: PlayerInfo): Result<MultiplayerRoom>
    suspend fun joinRoomByCode(code: String, guest: PlayerInfo): Result<MultiplayerRoom>
    suspend fun startMatchmaking(player: PlayerInfo): Result<Unit>
    suspend fun cancelMatchmaking(playerUid: String): Result<Unit>
    suspend fun submitMove(roomId: String, move: MovePayload): Result<Unit>
    suspend fun leaveRoom(roomId: String, playerUid: String): Result<Unit>
}

/**
 * Reference Firebase configuration and schema definition.
 * Used for deployment on Firebase Firestore or Firebase Realtime Database.
 */
object FirebaseConfigDocs {
    const val FIRESTORE_SCHEMA = """
    Collections:
    1. 'domino_rooms' (document = roomId)
       - roomId: String
       - roomCode: String (6 digits, unique index)
       - hostUid: String
       - hostName: String
       - guestUid: String
       - guestName: String
       - status: String ('WAITING', 'PLAYING', 'FINISHED')
       - ruleVariant: String ('DRAW', 'BLOCK')
       - targetScore: Number
       - currentTurnUid: String
       - updatedAt: Timestamp
       
    2. 'domino_rooms/{roomId}/moves' (document = moveIndex)
       - moveIndex: Number
       - playerUid: String
       - tileId: Number (0..27)
       - placedEnd: String ('LEFT', 'RIGHT')
       - timestamp: Timestamp

    3. 'matchmaking_queue' (document = playerUid)
       - playerUid: String
       - ratingLevel: Number
       - queuedAt: Timestamp
    """

    const val SECURITY_RULES_RECOMMENDATION = """
    rules_version = '2';
    service cloud.firestore {
      match /databases/{database}/documents {
        match /domino_rooms/{roomId} {
          allow read: if request.auth != null;
          allow create: if request.auth != null;
          allow update: if request.auth != null && (
            request.auth.uid == resource.data.hostUid || 
            request.auth.uid == resource.data.guestUid ||
            resource.data.guestUid == null
          );
          
          match /moves/{moveId} {
            allow read, create: if request.auth != null;
          }
        }
        match /matchmaking_queue/{uid} {
          allow read, write: if request.auth != null && request.auth.uid == uid;
        }
      }
    }
    """
}
