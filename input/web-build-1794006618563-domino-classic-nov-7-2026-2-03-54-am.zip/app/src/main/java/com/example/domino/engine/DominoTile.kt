package com.example.domino.engine

/**
 * Represents a single Double-Six Domino tile with two pip ends (left and right).
 * There are 28 unique tiles in a standard double-six set, from [0|0] to [6|6].
 */
data class DominoTile(
    val id: Int,
    val left: Int,
    val right: Int
) {
    val isDouble: Boolean get() = left == right
    val pipTotal: Int get() = left + right

    fun canMatch(value: Int): Boolean = left == value || right == value

    fun flipped(): DominoTile = DominoTile(id = id, left = right, right = left)

    fun hasPip(value: Int): Boolean = left == value || right == value

    override fun toString(): String = "[$left|$right]"

    companion object {
        /**
         * Generates the standard complete 28-tile double-six domino set.
         */
        fun generateFullSet(): List<DominoTile> {
            val tiles = mutableListOf<DominoTile>()
            var id = 0
            for (i in 0..6) {
                for (j in i..6) {
                    tiles.add(DominoTile(id = id++, left = i, right = j))
                }
            }
            return tiles
        }
    }
}

enum class BoardEnd {
    LEFT,
    RIGHT
}

/**
 * Representation of a tile placed in the playing chain.
 */
data class PlacedTile(
    val tile: DominoTile,
    val placedAtEnd: BoardEnd,
    val exposedLeft: Int,
    val exposedRight: Int,
    val isVertical: Boolean = tile.isDouble,
    val sequenceIndex: Int = 0
)

enum class GameRuleVariant {
    DRAW,   // Must draw from boneyard if no legal move until playable or empty
    BLOCK   // No drawing; pass immediately if no legal move
}

enum class AIDifficulty {
    EASY,
    MEDIUM,
    EXPERT
}

enum class PlayerTurn {
    PLAYER,
    OPPONENT
}

enum class RoundEndReason {
    DOMINO,     // Player or opponent emptied their hand
    BLOCKED,    // Board is locked; neither player can make a move
    SURRENDER   // Player surrendered the game
}
