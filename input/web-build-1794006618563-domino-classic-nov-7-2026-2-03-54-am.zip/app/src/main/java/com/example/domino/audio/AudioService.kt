package com.example.domino.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * High-performance, zero-latency synthesizer for Domino tile clicks,
 * shuffles, victory chimes and haptic feedback.
 */
class AudioService(private val context: Context) {
    private val scope = CoroutineScope(Dispatchers.Default)

    var soundEnabled: Boolean = true
    var vibrationEnabled: Boolean = true

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        manager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    /**
     * Plays the authentic acoustic "clack" of two heavy domino bone tiles snapping together.
     */
    fun playTileClack() {
        if (vibrationEnabled) {
            triggerHaptic(HapticType.LIGHT_CLICK)
        }
        if (!soundEnabled) return

        scope.launch {
            // Dual frequency transient impulse with exponential decay to mimic wood/ivory collision
            val sampleRate = 44100
            val durationMs = 60
            val numSamples = (sampleRate * durationMs) / 1000
            val buffer = ShortArray(numSamples)

            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                val envelope = exp(-t * 90.0)
                // Fundamental 1250Hz + resonant secondary 2400Hz
                val wave1 = sin(2.0 * PI * 1250.0 * t)
                val wave2 = sin(2.0 * PI * 2400.0 * t) * 0.4
                val sample = ((wave1 + wave2) * envelope * 24000.0).toInt().coerceIn(-32767, 32767)
                buffer[i] = sample.toShort()
            }
            playPcmBuffer(buffer, sampleRate)
        }
    }

    /**
     * Sound played when drawing a tile from the boneyard.
     */
    fun playTileDraw() {
        if (vibrationEnabled) {
            triggerHaptic(HapticType.TICK)
        }
        if (!soundEnabled) return

        scope.launch {
            val sampleRate = 44100
            val durationMs = 80
            val numSamples = (sampleRate * durationMs) / 1000
            val buffer = ShortArray(numSamples)

            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                val envelope = exp(-t * 45.0)
                val wave = sin(2.0 * PI * (600.0 + 400.0 * (1 - t / 0.08)) * t)
                val sample = (wave * envelope * 18000.0).toInt().coerceIn(-32767, 32767)
                buffer[i] = sample.toShort()
            }
            playPcmBuffer(buffer, sampleRate)
        }
    }

    /**
     * Sound played on passing turn or blocked game.
     */
    fun playPassSound() {
        if (!soundEnabled) return

        scope.launch {
            val sampleRate = 44100
            val durationMs = 120
            val numSamples = (sampleRate * durationMs) / 1000
            val buffer = ShortArray(numSamples)

            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                val envelope = exp(-t * 20.0)
                val wave = sin(2.0 * PI * 320.0 * t)
                val sample = (wave * envelope * 16000.0).toInt().coerceIn(-32767, 32767)
                buffer[i] = sample.toShort()
            }
            playPcmBuffer(buffer, sampleRate)
        }
    }

    /**
     * Victory fanfare chime when winning a round or match.
     */
    fun playWinChime() {
        if (vibrationEnabled) {
            triggerHaptic(HapticType.SUCCESS)
        }
        if (!soundEnabled) return

        scope.launch {
            // Ascending major chord (C5, E5, G5, C6)
            val sampleRate = 44100
            val frequencies = listOf(523.25, 659.25, 783.99, 1046.50)
            val noteDuration = 0.12
            val totalDuration = noteDuration * frequencies.size + 0.3
            val numSamples = (sampleRate * totalDuration).toInt()
            val buffer = ShortArray(numSamples)

            for ((index, freq) in frequencies.withIndex()) {
                val startSample = (index * noteDuration * sampleRate).toInt()
                val noteSamples = ((noteDuration + 0.25) * sampleRate).toInt()

                for (i in 0 until noteSamples) {
                    val pos = startSample + i
                    if (pos >= numSamples) break
                    val t = i.toDouble() / sampleRate
                    val envelope = exp(-t * 6.0)
                    val wave = sin(2.0 * PI * freq * t) + 0.3 * sin(2.0 * PI * freq * 2 * t)
                    val sample = (wave * envelope * 14000.0).toInt()
                    val currentVal = buffer[pos].toInt()
                    buffer[pos] = (currentVal + sample).coerceIn(-32767, 32767).toShort()
                }
            }
            playPcmBuffer(buffer, sampleRate)
        }
    }

    private fun playPcmBuffer(buffer: ShortArray, sampleRate: Int) {
        try {
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(buffer, 0, buffer.size)
            track.play()
            track.setNotificationMarkerPosition(buffer.size)
            track.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
                override fun onMarkerReached(t: AudioTrack?) {
                    t?.release()
                }
                override fun onPeriodicNotification(t: AudioTrack?) {}
            })
        } catch (_: Exception) {
            // Audio fallback
        }
    }

    enum class HapticType {
        LIGHT_CLICK,
        TICK,
        SUCCESS
    }

    private fun triggerHaptic(type: HapticType) {
        val vib = vibrator ?: return
        if (!vib.hasVibrator()) return

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val effect = when (type) {
                    HapticType.LIGHT_CLICK -> VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
                    HapticType.TICK -> VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK)
                    HapticType.SUCCESS -> VibrationEffect.createWaveform(longArrayOf(0, 40, 60, 80), -1)
                }
                vib.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                when (type) {
                    HapticType.LIGHT_CLICK -> vib.vibrate(25)
                    HapticType.TICK -> vib.vibrate(15)
                    HapticType.SUCCESS -> vib.vibrate(longArrayOf(0, 40, 60, 80), -1)
                }
            }
        } catch (_: Exception) {}
    }
}
