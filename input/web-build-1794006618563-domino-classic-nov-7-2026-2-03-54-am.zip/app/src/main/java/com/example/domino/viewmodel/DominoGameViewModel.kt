package com.example.domino.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.domino.ads.AdMobManager
import com.example.domino.audio.AudioService
import com.example.domino.data.GamePreferences
import com.example.domino.engine.AIDifficulty
import com.example.domino.engine.BoardEnd
import com.example.domino.engine.DominoGameState
import com.example.domino.engine.DominoMatchController
import com.example.domino.engine.DominoTile
import com.example.domino.engine.GameRuleVariant
import com.example.domino.engine.PlayerTurn
import com.example.domino.online.MultiplayerManager
import com.example.domino.ui.navigation.DominoScreen
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class DominoGameViewModel(application: Application) : AndroidViewModel(application) {
    val prefs = GamePreferences(application)
    val audioService = AudioService(application)
    val adMobManager = AdMobManager(application)
    val multiplayerManager = MultiplayerManager(viewModelScope)

    private val controller = DominoMatchController(
        variant = prefs.data.value.defaultRule,
        aiDifficulty = prefs.data.value.aiDifficulty,
        targetScore = prefs.data.value.targetScore
    )

    val gameState: StateFlow<DominoGameState> = controller.gameState
    val playerData: StateFlow<GamePreferences.PlayerData> = prefs.data

    private val _currentScreen = MutableStateFlow(DominoScreen.HOME)
    val currentScreen: StateFlow<DominoScreen> = _currentScreen.asStateFlow()

    init {
        // Synchronize audio preferences
        audioService.soundEnabled = prefs.data.value.soundEnabled
        audioService.vibrationEnabled = prefs.data.value.vibrationEnabled

        // Monitor match finish to record progression stats and coins
        viewModelScope.launch {
            gameState.collect { state ->
                if (state.isMatchOver && state.matchWinner != null) {
                    val playerWon = state.matchWinner == PlayerTurn.PLAYER
                    prefs.recordMatchFinished(won = playerWon, pointsScored = state.playerScore)
                }
            }
        }
    }

    fun navigateTo(screen: DominoScreen) {
        _currentScreen.value = screen
    }

    fun startComputerMatch(difficulty: AIDifficulty) {
        controller.configureSettings(
            newVariant = prefs.data.value.defaultRule,
            newDifficulty = difficulty,
            newTargetScore = prefs.data.value.targetScore
        )
        controller.startNewMatch()
        _currentScreen.value = DominoScreen.GAME
    }

    fun startFriendOrOnlineMatch() {
        controller.configureSettings(
            newVariant = prefs.data.value.defaultRule,
            newDifficulty = AIDifficulty.EXPERT,
            newTargetScore = prefs.data.value.targetScore
        )
        controller.startNewMatch()
        _currentScreen.value = DominoScreen.GAME
    }

    fun selectTile(tile: DominoTile?) {
        controller.selectTile(tile)
    }

    fun playTileAtEnd(tile: DominoTile, end: BoardEnd) {
        controller.playPlayerTile(tile, end)
    }

    fun drawTile() {
        controller.playerDraw()
    }

    fun passTurn() {
        controller.playerPass()
    }

    fun executeAITurn() {
        controller.executeAITurn()
    }

    fun proceedNextRound() {
        controller.proceedToNextRound()
    }

    fun restartMatch() {
        controller.startNewMatch()
    }

    fun surrenderMatch() {
        controller.startNewMatch()
        _currentScreen.value = DominoScreen.HOME
    }

    // Progression & Shop Actions
    fun claimDailyReward(multiplier: Int) {
        prefs.claimDailyReward(multiplier)
    }

    fun claimMission(missionId: String, rewardCoins: Int) {
        val completed = prefs.data.value.completedMissions + missionId
        prefs.addCoins(rewardCoins)
        prefs.addXp(40)
    }

    fun purchaseItem(itemId: String, cost: Int) {
        prefs.purchaseItem(itemId, cost)
    }

    fun equipTileSkin(skinId: String) {
        prefs.setEquippedTileSkin(skinId)
    }

    fun equipBoardTheme(boardId: String) {
        prefs.setEquippedBoardTheme(boardId)
    }

    fun equipAvatar(avatarId: String) {
        prefs.setEquippedAvatar(avatarId)
    }

    fun updatePlayerName(name: String) {
        prefs.setPlayerName(name)
    }

    // Settings Actions
    fun setLanguage(lang: String) {
        prefs.setLanguage(lang)
    }

    fun setSoundEnabled(enabled: Boolean) {
        audioService.soundEnabled = enabled
        prefs.setSoundEnabled(enabled)
    }

    fun setVibrationEnabled(enabled: Boolean) {
        audioService.vibrationEnabled = enabled
        prefs.setVibrationEnabled(enabled)
    }

    fun setAnimationsEnabled(enabled: Boolean) {
        prefs.setAnimationsEnabled(enabled)
    }

    fun setTargetScore(target: Int) {
        prefs.setTargetScore(target)
        controller.configureSettings(newTargetScore = target)
    }

    fun setDefaultRule(rule: GameRuleVariant) {
        prefs.setDefaultRule(rule)
        controller.configureSettings(newVariant = rule)
    }
}
