package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DominoDarkColorScheme = darkColorScheme(
    primary = GoldAccent,
    onPrimary = EmeraldDark,
    primaryContainer = EmeraldPrimary,
    onPrimaryContainer = GoldBright,
    secondary = EmeraldBright,
    onSecondary = EmeraldDark,
    secondaryContainer = EmeraldCard,
    onSecondaryContainer = TextPrimary,
    tertiary = GoldLight,
    onTertiary = EmeraldDark,
    background = EmeraldDark,
    onBackground = TextPrimary,
    surface = EmeraldSurface,
    onSurface = TextPrimary,
    surfaceVariant = EmeraldCard,
    onSurfaceVariant = TextSecondary,
    outline = GoldAccent.copy(alpha = 0.5f),
    outlineVariant = EmeraldPrimary
)

private val DominoLightColorScheme = lightColorScheme(
    primary = EmeraldPrimary,
    onPrimary = Color.White,
    primaryContainer = EmeraldSurface,
    onPrimaryContainer = GoldLight,
    secondary = GoldDark,
    onSecondary = Color.White,
    background = EmeraldMidnight,
    onBackground = TextPrimary,
    surface = EmeraldSurface,
    onSurface = TextPrimary,
    surfaceVariant = EmeraldCard,
    onSurfaceVariant = TextSecondary
)

@Composable
fun DominoTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DominoDarkColorScheme else DominoLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    DominoTheme(darkTheme = true, content = content)
}
