package com.example.domino.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.domino.data.GamePreferences
import com.example.domino.online.MultiplayerManager
import com.example.domino.online.RoomStatus
import com.example.domino.ui.components.LuxuryButton
import com.example.domino.ui.components.PlayerAvatarBadge

@Composable
fun MultiplayerScreen(
    playerData: GamePreferences.PlayerData,
    multiplayerManager: MultiplayerManager,
    initialTab: Int = 0,
    onStartGame: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = {
        multiplayerManager.cancelSearch()
        onBack()
    })

    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(initialTab) }
    val roomState by multiplayerManager.roomState.collectAsState()
    val statusMsg by multiplayerManager.statusMessage.collectAsState()

    var inputCode by remember { mutableStateOf("") }
    var codeError by remember { mutableStateOf<String?>(null) }
    var generatedRoomCode by remember { mutableStateOf<String?>(null) }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "radarPulse"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF041911), Color(0xFF07271B), Color(0xFF0A3424))
                )
            )
            .statusBarsPadding()
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    multiplayerManager.cancelSearch()
                    onBack()
                },
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF093322))
                    .testTag("multiplayer_back_btn")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color(0xFFFFD700)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = stringResource(R.string.multiplayer_title),
                color = Color(0xFFFFD700),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 19.sp
            )
        }

        // Tabs: Play with Friend (0) | Online Random Matchmaking (1)
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color(0xFF07271B),
            contentColor = Color(0xFFFFD700),
            edgePadding = 16.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text(stringResource(R.string.menu_vs_friend), fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text(stringResource(R.string.menu_online), fontWeight = FontWeight.Bold) }
            )
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            if (selectedTab == 0) {
                // Friend Room Tab
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Create Room Section
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0C3827)),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = Brush.verticalGradient(listOf(Color(0xFFFFD700), Color(0xFF104230)))
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "👑 " + stringResource(R.string.create_room),
                                color = Color(0xFFFFD700),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            if (generatedRoomCode == null) {
                                LuxuryButton(
                                    text = stringResource(R.string.create_room),
                                    onClick = {
                                        generatedRoomCode = multiplayerManager.createPrivateRoom(
                                            playerData.playerName,
                                            playerData.avatarId,
                                            playerData.level
                                        )
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    testTag = "btn_generate_room"
                                )
                            } else {
                                // Display Generated Code
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = stringResource(R.string.room_code_label),
                                        color = Color(0xFFA6C9B9),
                                        fontSize = 12.sp
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = generatedRoomCode ?: "",
                                        color = Color(0xFFFFD700),
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 32.sp,
                                        letterSpacing = 4.sp
                                    )

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        LuxuryButton(
                                            text = stringResource(R.string.btn_share_code),
                                            icon = Icons.Default.Share,
                                            onClick = {
                                                val sendIntent = Intent().apply {
                                                    action = Intent.ACTION_SEND
                                                    putExtra(
                                                        Intent.EXTRA_TEXT,
                                                        "انضم إلي في لعبة دومينو كلاسيك! رمز الغرفة: $generatedRoomCode"
                                                    )
                                                    type = "text/plain"
                                                }
                                                context.startActivity(Intent.createChooser(sendIntent, "مشاركة رمز الغرفة"))
                                            },
                                            modifier = Modifier.weight(1f)
                                        )

                                        LuxuryButton(
                                            text = "بدء اللعب",
                                            onClick = onStartGame,
                                            isSecondary = true,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Join Room Section
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0C3827)),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = Brush.verticalGradient(listOf(Color(0xFF2EA77A), Color(0xFF104230)))
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "🔑 " + stringResource(R.string.join_room),
                                color = Color(0xFF2EA77A),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = inputCode,
                                onValueChange = {
                                    if (it.length <= 6 && it.all { char -> char.isDigit() }) {
                                        inputCode = it
                                        codeError = null
                                    }
                                },
                                placeholder = { Text("أدخل رمز الغرفة (6 أرقام)", color = Color.Gray) },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFFFFD700),
                                    unfocusedBorderColor = Color(0xFF1E5C43),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("room_code_input")
                            )

                            if (codeError != null) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = codeError ?: "", color = Color(0xFFFF5252), fontSize = 12.sp)
                            }

                            if (statusMsg != null) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(modifier = Modifier.size(14.dp), color = Color(0xFFFFD700))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(text = statusMsg ?: "", color = Color(0xFFFFD700), fontSize = 12.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            LuxuryButton(
                                text = stringResource(R.string.join_room),
                                onClick = {
                                    multiplayerManager.joinRoomWithCode(
                                        code = inputCode,
                                        playerName = playerData.playerName,
                                        avatarId = playerData.avatarId,
                                        level = playerData.level,
                                        onSuccess = onStartGame,
                                        onError = { codeError = it }
                                    )
                                },
                                modifier = Modifier.fillMaxWidth(),
                                isSecondary = true,
                                testTag = "btn_join_room"
                            )
                        }
                    }

                    // Firebase Backend Info Note
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF07271B)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "☁️ " + stringResource(R.string.server_sync_status),
                                color = Color(0xFFFFD700),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = stringResource(R.string.firebase_architecture_info),
                                color = Color(0xFFA6C9B9),
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            } else {
                // Online Matchmaking Tab
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    val isSearching = roomState?.status == RoomStatus.SEARCHING_MATCHMAKING

                    if (isSearching) {
                        // Radar pulse animation
                        Box(
                            modifier = Modifier
                                .size(130.dp)
                                .scale(pulseScale)
                                .clip(CircleShape)
                                .background(Color(0xFF2EA77A).copy(alpha = 0.25f))
                                .border(2.dp, Color(0xFFFFD700), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Public,
                                contentDescription = null,
                                tint = Color(0xFFFFD700),
                                modifier = Modifier.size(54.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Text(
                            text = stringResource(R.string.searching_opponent),
                            color = Color(0xFFF5FAF7),
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        LuxuryButton(
                            text = stringResource(R.string.cancel_search),
                            onClick = { multiplayerManager.cancelSearch() },
                            isSecondary = true,
                            modifier = Modifier.width(180.dp),
                            testTag = "btn_cancel_search"
                        )
                    } else {
                        PlayerAvatarBadge(
                            avatarId = playerData.avatarId,
                            level = playerData.level,
                            size = 80.dp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = stringResource(R.string.online_matchmaking_title),
                            color = Color(0xFFFFD700),
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "ابحث عن خصم عشوائي بمستوى مساوٍ لك في العالم وتنافس في مباراة كلاسيكية حقيقية",
                            color = Color(0xFFA6C9B9),
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )

                        Spacer(modifier = Modifier.height(28.dp))

                        LuxuryButton(
                            text = "بدء البحث عن خصم 🔍",
                            onClick = {
                                multiplayerManager.startOnlineMatchmaking(
                                    playerName = playerData.playerName,
                                    avatarId = playerData.avatarId,
                                    level = playerData.level,
                                    onMatchFound = onStartGame
                                )
                            },
                            modifier = Modifier.fillMaxWidth(0.85f),
                            testTag = "btn_start_matchmaking"
                        )
                    }
                }
            }
        }
    }
}
