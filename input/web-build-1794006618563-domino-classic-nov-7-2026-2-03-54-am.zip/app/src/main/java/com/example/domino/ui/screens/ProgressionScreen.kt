package com.example.domino.ui.screens

import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.domino.ads.AdMobManager
import com.example.domino.data.GamePreferences
import com.example.domino.ui.components.CoinBalanceBadge
import com.example.domino.ui.components.LuxuryButton

@Composable
fun ProgressionScreen(
    playerData: GamePreferences.PlayerData,
    adMobManager: AdMobManager,
    onClaimDailyReward: (multiplier: Int) -> Unit,
    onClaimMission: (missionId: String, coinReward: Int) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val activity = context as? Activity
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf(
        stringResource(R.string.daily_reward_title),
        stringResource(R.string.missions_title),
        stringResource(R.string.achievements_title)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF041911), Color(0xFF07271B), Color(0xFF0A3424))
                )
            )
            .statusBarsPadding()
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF093322))
                        .testTag("progression_back_btn")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color(0xFFFFD700)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = stringResource(R.string.menu_missions),
                    color = Color(0xFFFFD700),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp
                )
            }

            CoinBalanceBadge(coins = playerData.coins)
        }

        // Tab Selector
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color(0xFF07271B),
            contentColor = Color(0xFFFFD700),
            edgePadding = 16.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 14.sp
                        )
                    }
                )
            }
        }

        // Body Content
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            when (selectedTab) {
                0 -> {
                    // Daily Login Rewards
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0B3828)),
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = Brush.verticalGradient(listOf(Color(0xFFFFD700), Color(0xFF104230)))
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(18.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "🎁 " + stringResource(R.string.daily_reward_title),
                                    color = Color(0xFFFFD700),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 18.sp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = stringResource(R.string.daily_reward_desc),
                                    color = Color(0xFFA6C9B9),
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                // Days 1 to 7 horizontal cards
                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    items((1..7).toList()) { day ->
                                        val isCurrent = day == playerData.dailyStreak
                                        val isPast = day < playerData.dailyStreak
                                        val rewardCoins = day * 50

                                        Card(
                                            shape = RoundedCornerShape(12.dp),
                                            colors = CardDefaults.cardColors(
                                                containerColor = when {
                                                    isCurrent -> Color(0xFF1B6A4C)
                                                    isPast -> Color(0xFF062218)
                                                    else -> Color(0xFF092E20)
                                                }
                                            ),
                                            border = CardDefaults.outlinedCardBorder().copy(
                                                brush = Brush.verticalGradient(
                                                    if (isCurrent) listOf(Color(0xFFFFD700), Color(0xFFD4AF37))
                                                    else listOf(Color(0xFF144D37), Color.Transparent)
                                                )
                                            ),
                                            modifier = Modifier.width(62.dp)
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(8.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally
                                            ) {
                                                Text(
                                                    text = stringResource(R.string.day_format, day),
                                                    color = if (isCurrent) Color(0xFFFFD700) else Color(0xFFA6C9B9),
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Spacer(modifier = Modifier.height(6.dp))
                                                Text(text = "🪙", fontSize = 18.sp)
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = "+$rewardCoins",
                                                    color = Color.White,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(20.dp))

                                val canClaim = playerData.lastClaimDate != "today_claimed" // canClaimDailyReward check

                                if (canClaim) {
                                    LuxuryButton(
                                        text = stringResource(R.string.btn_claim) + " (+${playerData.dailyStreak * 50} 🪙)",
                                        onClick = {
                                            onClaimDailyReward(1)
                                            Toast.makeText(context, R.string.btn_claimed, Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        testTag = "btn_claim_daily"
                                    )

                                    Spacer(modifier = Modifier.height(10.dp))

                                    // Watch Rewarded Ad for 2X Button!
                                    LuxuryButton(
                                        text = stringResource(R.string.btn_watch_ad_double) + " 🎬",
                                        onClick = {
                                            adMobManager.showRewardedAd(
                                                activity = activity,
                                                onRewarded = { _ ->
                                                    onClaimDailyReward(2)
                                                    Toast.makeText(context, "تمت مضاعفة المكافأة 2X بنجاح!", Toast.LENGTH_LONG).show()
                                                },
                                                onFailedOrDismissed = {
                                                    Toast.makeText(context, R.string.ad_not_ready, Toast.LENGTH_SHORT).show()
                                                }
                                            )
                                        },
                                        isSecondary = true,
                                        modifier = Modifier.fillMaxWidth(),
                                        testTag = "btn_watch_ad_double"
                                    )
                                } else {
                                    Text(
                                        text = stringResource(R.string.btn_claimed) + " ✓",
                                        color = Color(0xFFFFD700),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                }
                            }
                        }
                    }
                }
                1 -> {
                    // Daily Missions
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        item {
                            MissionCard(
                                title = stringResource(R.string.mission_play_3),
                                progress = minOf(playerData.matchesPlayed, 3),
                                maxProgress = 3,
                                rewardCoins = 60,
                                isCompleted = playerData.completedMissions.contains("mission_play_3"),
                                onClaim = { onClaimMission("mission_play_3", 60) }
                            )
                        }
                        item {
                            MissionCard(
                                title = stringResource(R.string.mission_win_1),
                                progress = minOf(playerData.wins, 1),
                                maxProgress = 1,
                                rewardCoins = 80,
                                isCompleted = playerData.completedMissions.contains("mission_win_1"),
                                onClaim = { onClaimMission("mission_win_1", 80) }
                            )
                        }
                        item {
                            MissionCard(
                                title = stringResource(R.string.mission_score_50),
                                progress = minOf(playerData.totalScoreEarned, 50),
                                maxProgress = 50,
                                rewardCoins = 100,
                                isCompleted = playerData.completedMissions.contains("mission_score_50"),
                                onClaim = { onClaimMission("mission_score_50", 100) }
                            )
                        }
                    }
                }
                2 -> {
                    // Achievements
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        item {
                            AchievementCard(
                                title = stringResource(R.string.achieve_first_win),
                                subtitle = "حقق انتصارك الأول في اللعبة",
                                badgeEmoji = "🥇",
                                isUnlocked = playerData.wins >= 1
                            )
                        }
                        item {
                            AchievementCard(
                                title = stringResource(R.string.achieve_streak_3),
                                subtitle = "حقق 3 انتصارات متتالية",
                                badgeEmoji = "🔥",
                                isUnlocked = playerData.bestStreak >= 3
                            )
                        }
                        item {
                            AchievementCard(
                                title = stringResource(R.string.achieve_master_10),
                                subtitle = "فز بـ 10 مباريات دومينو",
                                badgeEmoji = "👑",
                                isUnlocked = playerData.wins >= 10
                            )
                        }
                        item {
                            AchievementCard(
                                title = stringResource(R.string.achieve_rich),
                                subtitle = "اجمع رصيد 1000 عملة ذهبية",
                                badgeEmoji = "💎",
                                isUnlocked = playerData.coins >= 1000
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MissionCard(
    title: String,
    progress: Int,
    maxProgress: Int,
    rewardCoins: Int,
    isCompleted: Boolean,
    onClaim: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0C3827)),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.verticalGradient(listOf(Color(0xFF1E5C43), Color.Transparent))
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = Color(0xFFF5FAF7),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { (progress.toFloat() / maxProgress.toFloat()).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = Color(0xFFFFD700),
                    trackColor = Color(0xFF07271B)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "$progress / $maxProgress | جائزة: +$rewardCoins 🪙",
                    color = Color(0xFFA6C9B9),
                    fontSize = 11.sp
                )
            }

            if (isCompleted) {
                Text(text = "مكتمل ✓", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            } else if (progress >= maxProgress) {
                LuxuryButton(
                    text = "استلام",
                    onClick = onClaim,
                    modifier = Modifier.height(36.dp)
                )
            } else {
                Text(text = "قيد التقدم", color = Color.Gray, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun AchievementCard(
    title: String,
    subtitle: String,
    badgeEmoji: String,
    isUnlocked: Boolean
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = if (isUnlocked) Color(0xFF0E4330) else Color(0xFF082218)),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.verticalGradient(
                if (isUnlocked) listOf(Color(0xFFFFD700), Color(0xFFD4AF37))
                else listOf(Color(0xFF144D37), Color.Transparent)
            )
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(if (isUnlocked) Color(0xFF07271B) else Color.DarkGray)
                    .border(1.5.dp, if (isUnlocked) Color(0xFFFFD700) else Color.Transparent, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(text = if (isUnlocked) badgeEmoji else "🔒", fontSize = 22.sp)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = title,
                    color = if (isUnlocked) Color(0xFFFFD700) else Color.LightGray,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = subtitle,
                    color = Color(0xFFA6C9B9),
                    fontSize = 11.sp
                )
            }
        }
    }
}
