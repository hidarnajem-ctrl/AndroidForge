package com.example.domino.data

import android.content.Context
import android.content.SharedPreferences
import com.example.domino.engine.AIDifficulty
import com.example.domino.engine.GameRuleVariant
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Handles persistent game settings, player stats, progression, coins, and unlocks.
 */
class GamePreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("domino_classic_prefs", Context.MODE_PRIVATE)

    data class PlayerData(
        val language: String = "ar", // "ar" is default language
        val soundEnabled: Boolean = true,
        val vibrationEnabled: Boolean = true,
        val animationsEnabled: Boolean = true,
        val targetScore: Int = 100,
        val defaultRule: GameRuleVariant = GameRuleVariant.DRAW,
        val aiDifficulty: AIDifficulty = AIDifficulty.MEDIUM,
        val playerName: String = "Emerald Master",
        val avatarId: String = "avatar_emperor",
        val tileSkinId: String = "skin_ivory",
        val boardThemeId: String = "board_emerald",
        val coins: Int = 300,
        val level: Int = 1,
        val xp: Int = 0,
        val matchesPlayed: Int = 0,
        val wins: Int = 0,
        val losses: Int = 0,
        val currentStreak: Int = 0,
        val bestStreak: Int = 0,
        val totalScoreEarned: Int = 0,
        val dailyStreak: Int = 1,
        val lastClaimDate: String = "",
        val unlockedItems: Set<String> = setOf("skin_ivory", "board_emerald", "avatar_emperor"),
        val completedMissions: Set<String> = emptySet(),
        val unlockedAchievements: Set<String> = emptySet()
    ) {
        val winRate: Int
            get() = if (matchesPlayed > 0) (wins * 100) / matchesPlayed else 0

        val xpForNextLevel: Int
            get() = level * 150
    }

    private val _data = MutableStateFlow(loadData())
    val data: StateFlow<PlayerData> = _data.asStateFlow()

    private fun loadData(): PlayerData {
        val unlocked = prefs.getStringSet("unlocked_items", setOf("skin_ivory", "board_emerald", "avatar_emperor"))
            ?: setOf("skin_ivory", "board_emerald", "avatar_emperor")
        val missions = prefs.getStringSet("completed_missions", emptySet()) ?: emptySet()
        val achievements = prefs.getStringSet("unlocked_achievements", emptySet()) ?: emptySet()

        return PlayerData(
            language = prefs.getString("language", "ar") ?: "ar",
            soundEnabled = prefs.getBoolean("sound_enabled", true),
            vibrationEnabled = prefs.getBoolean("vibration_enabled", true),
            animationsEnabled = prefs.getBoolean("animations_enabled", true),
            targetScore = prefs.getInt("target_score", 100),
            defaultRule = try {
                GameRuleVariant.valueOf(prefs.getString("default_rule", GameRuleVariant.DRAW.name)!!)
            } catch (_: Exception) { GameRuleVariant.DRAW },
            aiDifficulty = try {
                AIDifficulty.valueOf(prefs.getString("ai_difficulty", AIDifficulty.MEDIUM.name)!!)
            } catch (_: Exception) { AIDifficulty.MEDIUM },
            playerName = prefs.getString("player_name", "Emerald Master") ?: "Emerald Master",
            avatarId = prefs.getString("avatar_id", "avatar_emperor") ?: "avatar_emperor",
            tileSkinId = prefs.getString("tile_skin_id", "skin_ivory") ?: "skin_ivory",
            boardThemeId = prefs.getString("board_theme_id", "board_emerald") ?: "board_emerald",
            coins = prefs.getInt("coins", 350),
            level = prefs.getInt("level", 1),
            xp = prefs.getInt("xp", 45),
            matchesPlayed = prefs.getInt("matches_played", 0),
            wins = prefs.getInt("wins", 0),
            losses = prefs.getInt("losses", 0),
            currentStreak = prefs.getInt("current_streak", 0),
            bestStreak = prefs.getInt("best_streak", 0),
            totalScoreEarned = prefs.getInt("total_score_earned", 0),
            dailyStreak = prefs.getInt("daily_streak", 1),
            lastClaimDate = prefs.getString("last_claim_date", "") ?: "",
            unlockedItems = unlocked,
            completedMissions = missions,
            unlockedAchievements = achievements
        )
    }

    fun setLanguage(lang: String) {
        prefs.edit().putString("language", lang).apply()
        _data.value = _data.value.copy(language = lang)
    }

    fun setSoundEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("sound_enabled", enabled).apply()
        _data.value = _data.value.copy(soundEnabled = enabled)
    }

    fun setVibrationEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("vibration_enabled", enabled).apply()
        _data.value = _data.value.copy(vibrationEnabled = enabled)
    }

    fun setAnimationsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("animations_enabled", enabled).apply()
        _data.value = _data.value.copy(animationsEnabled = enabled)
    }

    fun setTargetScore(target: Int) {
        prefs.edit().putInt("target_score", target).apply()
        _data.value = _data.value.copy(targetScore = target)
    }

    fun setDefaultRule(rule: GameRuleVariant) {
        prefs.edit().putString("default_rule", rule.name).apply()
        _data.value = _data.value.copy(defaultRule = rule)
    }

    fun setAiDifficulty(diff: AIDifficulty) {
        prefs.edit().putString("ai_difficulty", diff.name).apply()
        _data.value = _data.value.copy(aiDifficulty = diff)
    }

    fun setPlayerName(name: String) {
        prefs.edit().putString("player_name", name).apply()
        _data.value = _data.value.copy(playerName = name)
    }

    fun setEquippedTileSkin(skinId: String) {
        prefs.edit().putString("tile_skin_id", skinId).apply()
        _data.value = _data.value.copy(tileSkinId = skinId)
    }

    fun setEquippedBoardTheme(boardId: String) {
        prefs.edit().putString("board_theme_id", boardId).apply()
        _data.value = _data.value.copy(boardThemeId = boardId)
    }

    fun setEquippedAvatar(avatarId: String) {
        prefs.edit().putString("avatar_id", avatarId).apply()
        _data.value = _data.value.copy(avatarId = avatarId)
    }

    fun addCoins(amount: Int) {
        val newCoins = (_data.value.coins + amount).coerceAtLeast(0)
        prefs.edit().putInt("coins", newCoins).apply()
        _data.value = _data.value.copy(coins = newCoins)
    }

    fun addXp(amount: Int) {
        var currentXp = _data.value.xp + amount
        var currentLevel = _data.value.level
        var xpNeeded = currentLevel * 150

        while (currentXp >= xpNeeded) {
            currentXp -= xpNeeded
            currentLevel++
            xpNeeded = currentLevel * 150
            // Level up reward: +100 bonus coins
            addCoins(100)
        }

        prefs.edit()
            .putInt("xp", currentXp)
            .putInt("level", currentLevel)
            .apply()
        _data.value = _data.value.copy(xp = currentXp, level = currentLevel)
    }

    fun recordMatchFinished(won: Boolean, pointsScored: Int) {
        val matches = _data.value.matchesPlayed + 1
        val wins = if (won) _data.value.wins + 1 else _data.value.wins
        val losses = if (!won) _data.value.losses + 1 else _data.value.losses
        val streak = if (won) _data.value.currentStreak + 1 else 0
        val bestStreak = maxOf(_data.value.bestStreak, streak)
        val totalPoints = _data.value.totalScoreEarned + pointsScored

        prefs.edit()
            .putInt("matches_played", matches)
            .putInt("wins", wins)
            .putInt("losses", losses)
            .putInt("current_streak", streak)
            .putInt("best_streak", bestStreak)
            .putInt("total_score_earned", totalPoints)
            .apply()

        _data.value = _data.value.copy(
            matchesPlayed = matches,
            wins = wins,
            losses = losses,
            currentStreak = streak,
            bestStreak = bestStreak,
            totalScoreEarned = totalPoints
        )

        // Award match coins & XP
        if (won) {
            addCoins(100)
            addXp(75)
        } else {
            addCoins(30)
            addXp(25)
        }
    }

    fun canClaimDailyReward(): Boolean {
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        return _data.value.lastClaimDate != today
    }

    fun claimDailyReward(multiplier: Int = 1): Int {
        val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val streak = _data.value.dailyStreak
        val baseReward = streak * 50
        val totalReward = baseReward * multiplier

        val nextStreak = if (streak >= 7) 1 else streak + 1

        prefs.edit()
            .putString("last_claim_date", today)
            .putInt("daily_streak", nextStreak)
            .apply()

        addCoins(totalReward)
        addXp(30 * multiplier)

        _data.value = _data.value.copy(
            lastClaimDate = today,
            dailyStreak = nextStreak
        )
        return totalReward
    }

    fun purchaseItem(itemId: String, cost: Int): Boolean {
        if (_data.value.coins < cost) return false
        if (_data.value.unlockedItems.contains(itemId)) return true

        val newSet = _data.value.unlockedItems + itemId
        prefs.edit().putStringSet("unlocked_items", newSet).apply()
        addCoins(-cost)
        _data.value = _data.value.copy(unlockedItems = newSet)
        return true
    }
}
