package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Domino Classic Emerald & Gold Palette
val EmeraldDark = Color(0xFF041911)
val EmeraldMidnight = Color(0xFF07271B)
val EmeraldSurface = Color(0xFF0B3324)
val EmeraldCard = Color(0xFF104230)
val EmeraldPrimary = Color(0xFF186649)
val EmeraldLight = Color(0xFF279970)
val EmeraldBright = Color(0xFF38C794)

val GoldAccent = Color(0xFFD4AF37)
val GoldBright = Color(0xFFFFD700)
val GoldLight = Color(0xFFF5DE88)
val GoldDark = Color(0xFF9A7B1C)

val BoneIvory = Color(0xFFFDFBF7)
val BoneTileBg = Color(0xFFF4EDE2)
val BoneTileShadow = Color(0xFFDCD2C0)
val PipDark = Color(0xFF1C1B1A)
val PipGold = Color(0xFFD4AF37)

val TextPrimary = Color(0xFFF5FAF7)
val TextSecondary = Color(0xFFA6C9B9)
val TextGold = Color(0xFFF6D97F)
val ErrorRed = Color(0xFFE53935)
val SuccessGreen = Color(0xFF43A047)
