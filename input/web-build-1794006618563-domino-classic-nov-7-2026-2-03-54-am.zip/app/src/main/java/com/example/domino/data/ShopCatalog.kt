package com.example.domino.data

import androidx.compose.ui.graphics.Color
import com.example.R

data class TileSkin(
    val id: String,
    val nameRes: Int,
    val cost: Int,
    val surfaceColor: Color,
    val pipColor: Color,
    val borderColor: Color,
    val dividerColor: Color
)

data class BoardTheme(
    val id: String,
    val nameRes: Int,
    val cost: Int,
    val primaryColor: Color,
    val secondaryColor: Color,
    val feltColor: Color,
    val borderColor: Color
)

data class AvatarItem(
    val id: String,
    val name: String,
    val iconEmoji: String,
    val cost: Int
)

object ShopCatalog {
    val tileSkins = listOf(
        TileSkin(
            id = "skin_ivory",
            nameRes = R.string.skin_ivory_name,
            cost = 0,
            surfaceColor = Color(0xFFF9F5EC),
            pipColor = Color(0xFF1E1E1E),
            borderColor = Color(0xFFD8CEB9),
            dividerColor = Color(0xFFB5A790)
        ),
        TileSkin(
            id = "skin_emerald",
            nameRes = R.string.skin_emerald_name,
            cost = 250,
            surfaceColor = Color(0xFF093322),
            pipColor = Color(0xFFFFD700),
            borderColor = Color(0xFFD4AF37),
            dividerColor = Color(0xFFB8972E)
        ),
        TileSkin(
            id = "skin_obsidian",
            nameRes = R.string.skin_obsidian_name,
            cost = 500,
            surfaceColor = Color(0xFF141416),
            pipColor = Color(0xFFF0CA57),
            borderColor = Color(0xFF555555),
            dividerColor = Color(0xFF6E6E6E)
        ),
        TileSkin(
            id = "skin_pearl",
            nameRes = R.string.skin_pearl_name,
            cost = 800,
            surfaceColor = Color(0xFFFFF9EE),
            pipColor = Color(0xFFB71C1C),
            borderColor = Color(0xFFE8C86A),
            dividerColor = Color(0xFFD4AF37)
        )
    )

    val boardThemes = listOf(
        BoardTheme(
            id = "board_emerald",
            nameRes = R.string.board_emerald_name,
            cost = 0,
            primaryColor = Color(0xFF0A3D2E),
            secondaryColor = Color(0xFF06281E),
            feltColor = Color(0xFF0D4E3A),
            borderColor = Color(0xFFD4AF37)
        ),
        BoardTheme(
            id = "board_midnight",
            nameRes = R.string.board_midnight_name,
            cost = 300,
            primaryColor = Color(0xFF1F120E),
            secondaryColor = Color(0xFF120A08),
            feltColor = Color(0xFF2B1812),
            borderColor = Color(0xFFC49A45)
        ),
        BoardTheme(
            id = "board_ruby",
            nameRes = R.string.board_ruby_name,
            cost = 600,
            primaryColor = Color(0xFF380B15),
            secondaryColor = Color(0xFF22060C),
            feltColor = Color(0xFF4C0E1C),
            borderColor = Color(0xFFE5B55A)
        ),
        BoardTheme(
            id = "board_sapphire",
            nameRes = R.string.board_sapphire_name,
            cost = 900,
            primaryColor = Color(0xFF0A223B),
            secondaryColor = Color(0xFF051322),
            feltColor = Color(0xFF0F3256),
            borderColor = Color(0xFF60A5FA)
        )
    )

    val avatars = listOf(
        AvatarItem("avatar_emperor", "King Domino", "👑", 0),
        AvatarItem("avatar_ace", "Emerald Tactician", "🀄", 200),
        AvatarItem("avatar_falcon", "Royal Falcon", "🦅", 450),
        AvatarItem("avatar_lion", "Golden Lion", "🦁", 750)
    )

    fun getTileSkin(id: String): TileSkin =
        tileSkins.find { it.id == id } ?: tileSkins.first()

    fun getBoardTheme(id: String): BoardTheme =
        boardThemes.find { it.id == id } ?: boardThemes.first()

    fun getAvatar(id: String): AvatarItem =
        avatars.find { it.id == id } ?: avatars.first()
}
