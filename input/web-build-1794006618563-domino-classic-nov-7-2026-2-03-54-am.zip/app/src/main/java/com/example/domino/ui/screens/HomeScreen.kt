package com.example.domino.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.domino.data.GamePreferences
import com.example.domino.engine.AIDifficulty
import com.example.domino.ui.components.AdMobBannerView
import com.example.domino.ui.components.CoinBalanceBadge
import com.example.domino.ui.components.LuxuryButton
import com.example.domino.ui.components.PlayerAvatarBadge

@Composable
fun HomeScreen(
    playerData: GamePreferences.PlayerData,
    onPlayComputer: (difficulty: AIDifficulty) -> Unit,
    onPlayFriend: () -> Unit,
    onPlayOnline: () -> Unit,
    onOpenDailyRewards: () -> Unit,
    onOpenMissions: () -> Unit,
    onOpenShop: () -> Unit,
    onOpenStats: () -> Unit,
    onOpenSettings: () -> Unit
) {
    var showDifficultyDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF041911),
                        Color(0xFF07271B),
                        Color(0xFF0A3424)
                    )
                )
            )
            .statusBarsPadding()
    ) {
        // Scrollable content
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Top Bar: Player Profile snippet & Coin Balance
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable(onClick = onOpenStats)
                        .testTag("home_profile_click")
                ) {
                    PlayerAvatarBadge(
                        avatarId = playerData.avatarId,
                        level = playerData.level,
                        size = 52.dp,
                        isOnline = true
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = playerData.playerName,
                            color = Color(0xFFF5FAF7),
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = stringResource(R.string.level_format, playerData.level),
                                color = Color(0xFFFFD700),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            LinearProgressIndicator(
                                progress = { (playerData.xp.toFloat() / playerData.xpForNextLevel.toFloat()).coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .width(70.dp)
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = Color(0xFFFFD700),
                                trackColor = Color(0xFF0A3D2E)
                            )
                        }
                    }
                }

                CoinBalanceBadge(
                    coins = playerData.coins,
                    onClick = onOpenShop
                )
            }

            // Hero Play with Computer Banner Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .shadow(10.dp, RoundedCornerShape(20.dp))
                    .testTag("hero_play_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0B3828)),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(Color(0xFFFFD700), Color(0xFFD4AF37))))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Color(0xFF144D37), Color(0xFF07271B))
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text(
                                    text = stringResource(R.string.app_name),
                                    color = Color(0xFFFFD700),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 22.sp
                                )
                                Text(
                                    text = stringResource(R.string.tagline),
                                    color = Color(0xFFA6C9B9),
                                    fontSize = 12.sp
                                )
                            }
                            Text(
                                text = "🀄",
                                fontSize = 38.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Large Play vs Computer Button
                        LuxuryButton(
                            text = stringResource(R.string.menu_vs_computer),
                            onClick = { showDifficultyDialog = true },
                            modifier = Modifier.fillMaxWidth(),
                            icon = Icons.Default.PlayArrow,
                            testTag = "play_vs_computer_btn"
                        )
                    }
                }
            }

            // Multiplayer Options Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MenuQuickCard(
                    title = stringResource(R.string.menu_vs_friend),
                    subtitle = "غرفة خاصة / Private",
                    icon = Icons.Default.Group,
                    accentColor = Color(0xFF2EA77A),
                    modifier = Modifier.weight(1f),
                    onClick = onPlayFriend,
                    testTag = "btn_play_friend"
                )

                MenuQuickCard(
                    title = stringResource(R.string.menu_online),
                    subtitle = "مطابقة سريعة / Radar",
                    icon = Icons.Default.Public,
                    accentColor = Color(0xFF38BDF8),
                    modifier = Modifier.weight(1f),
                    onClick = onPlayOnline,
                    testTag = "btn_play_online"
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Grid for Hub Features
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MenuHubButton(
                    title = stringResource(R.string.menu_daily_rewards),
                    icon = Icons.Default.CardGiftcard,
                    hasNotification = true,
                    modifier = Modifier.weight(1f),
                    onClick = onOpenDailyRewards,
                    testTag = "btn_daily_rewards"
                )

                MenuHubButton(
                    title = stringResource(R.string.menu_missions),
                    icon = Icons.Default.EmojiEvents,
                    hasNotification = false,
                    modifier = Modifier.weight(1f),
                    onClick = onOpenMissions,
                    testTag = "btn_missions"
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MenuHubButton(
                    title = stringResource(R.string.menu_shop),
                    icon = Icons.Default.Storefront,
                    hasNotification = false,
                    modifier = Modifier.weight(1f),
                    onClick = onOpenShop,
                    testTag = "btn_shop"
                )

                MenuHubButton(
                    title = stringResource(R.string.menu_stats),
                    icon = Icons.Default.Leaderboard,
                    hasNotification = false,
                    modifier = Modifier.weight(1f),
                    onClick = onOpenStats,
                    testTag = "btn_stats"
                )

                MenuHubButton(
                    title = stringResource(R.string.menu_settings),
                    icon = Icons.Default.Settings,
                    hasNotification = false,
                    modifier = Modifier.weight(1f),
                    onClick = onOpenSettings,
                    testTag = "btn_settings"
                )
            }

            Spacer(modifier = Modifier.height(14.dp))
        }

        // Bottom AdMob Banner
        AdMobBannerView(
            modifier = Modifier.testTag("home_admob_banner")
        )
    }

    // Difficulty Selection Dialog
    if (showDifficultyDialog) {
        Dialog(onDismissRequest = { showDifficultyDialog = false }) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = Color(0xFF0A3424),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.verticalGradient(listOf(Color(0xFFFFD700), Color(0xFF07271B)))),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = stringResource(R.string.select_difficulty),
                        color = Color(0xFFFFD700),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    LuxuryButton(
                        text = stringResource(R.string.difficulty_easy) + " ⭐",
                        onClick = {
                            showDifficultyDialog = false
                            onPlayComputer(AIDifficulty.EASY)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        isSecondary = true,
                        testTag = "diff_easy_btn"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    LuxuryButton(
                        text = stringResource(R.string.difficulty_medium) + " ⭐⭐",
                        onClick = {
                            showDifficultyDialog = false
                            onPlayComputer(AIDifficulty.MEDIUM)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        isSecondary = false,
                        testTag = "diff_medium_btn"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    LuxuryButton(
                        text = stringResource(R.string.difficulty_expert) + " ⭐⭐⭐",
                        onClick = {
                            showDifficultyDialog = false
                            onPlayComputer(AIDifficulty.EXPERT)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        isSecondary = true,
                        testTag = "diff_expert_btn"
                    )
                }
            }
        }
    }
}

@Composable
private fun MenuQuickCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    testTag: String
) {
    Card(
        modifier = modifier
            .testTag(testTag)
            .height(90.dp)
            .shadow(6.dp, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0D3E2C)),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.verticalGradient(listOf(accentColor.copy(alpha = 0.7f), Color.Transparent)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(24.dp)
            )
            Column {
                Text(
                    text = title,
                    color = Color(0xFFF5FAF7),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = subtitle,
                    color = Color(0xFFA6C9B9),
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun MenuHubButton(
    title: String,
    icon: ImageVector,
    hasNotification: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    testTag: String
) {
    Card(
        modifier = modifier
            .testTag(testTag)
            .height(82.dp)
            .shadow(4.dp, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF092E20)),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.verticalGradient(listOf(Color(0xFFD4AF37).copy(alpha = 0.4f), Color.Transparent)))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color(0xFFFFD700),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = title,
                    color = Color(0xFFF5FAF7),
                    fontWeight = FontWeight.Medium,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
            }

            if (hasNotification) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFF3366))
                )
            }
        }
    }
}
