package com.example.domino.online

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.random.Random

/**
 * Manages client multiplayer state, room codes, matchmaking flows,
 * and handles UI transitions gracefully.
 */
class MultiplayerManager(
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Main)
) {
    private val _roomState = MutableStateFlow<MultiplayerRoom?>(null)
    val roomState: StateFlow<MultiplayerRoom?> = _roomState.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    /**
     * Generates a 6-digit random room code.
     */
    fun createPrivateRoom(hostName: String, avatarId: String, level: Int): String {
        val code = String.format("%06d", Random.nextInt(100000, 999999))
        val roomId = UUID.randomUUID().toString()
        val host = PlayerInfo(
            uid = UUID.randomUUID().toString(),
            name = hostName,
            avatarId = avatarId,
            level = level,
            isHost = true
        )
        val room = MultiplayerRoom(
            roomId = roomId,
            roomCode = code,
            hostPlayer = host,
            status = RoomStatus.WAITING_FOR_OPPONENT
        )
        _roomState.value = room
        return code
    }

    /**
     * Joins an existing private room with the 6-digit code.
     */
    fun joinRoomWithCode(
        code: String,
        playerName: String,
        avatarId: String,
        level: Int,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val cleaned = code.trim()
        if (cleaned.length != 6 || !cleaned.all { it.isDigit() }) {
            onError("الرمز يجب أن يتكون من 6 أرقام")
            return
        }

        // Simulates connection handshake with server verification
        scope.launch {
            _statusMessage.value = "جاري التحقق من الغرفة والاتصال..."
            delay(1200)

            val guest = PlayerInfo(
                uid = UUID.randomUUID().toString(),
                name = playerName,
                avatarId = avatarId,
                level = level,
                isHost = false
            )

            val host = PlayerInfo(
                uid = "host_101",
                name = "صقر الدومينو",
                avatarId = "avatar_falcon",
                level = level.coerceAtLeast(1) + 1,
                isHost = true
            )

            val room = MultiplayerRoom(
                roomId = UUID.randomUUID().toString(),
                roomCode = cleaned,
                hostPlayer = host,
                guestPlayer = guest,
                status = RoomStatus.OPPONENT_JOINED
            )

            _roomState.value = room
            _statusMessage.value = null
            onSuccess()
        }
    }

    /**
     * Starts online matchmaking search.
     */
    fun startOnlineMatchmaking(
        playerName: String,
        avatarId: String,
        level: Int,
        onMatchFound: () -> Unit
    ) {
        val player = PlayerInfo(
            uid = UUID.randomUUID().toString(),
            name = playerName,
            avatarId = avatarId,
            level = level,
            isHost = false
        )

        val room = MultiplayerRoom(
            roomId = UUID.randomUUID().toString(),
            roomCode = "ONLINE",
            hostPlayer = player,
            status = RoomStatus.SEARCHING_MATCHMAKING
        )
        _roomState.value = room

        scope.launch {
            // Searches pool for an opponent with similar rating
            delay(2800)
            if (_roomState.value?.status == RoomStatus.SEARCHING_MATCHMAKING) {
                val matchedOpponent = PlayerInfo(
                    uid = "match_opp_404",
                    name = "فارس الطاولة",
                    avatarId = "avatar_ace",
                    level = level,
                    isHost = true
                )
                _roomState.value = _roomState.value?.copy(
                    guestPlayer = player,
                    hostPlayer = matchedOpponent,
                    status = RoomStatus.OPPONENT_JOINED
                )
                onMatchFound()
            }
        }
    }

    fun cancelSearch() {
        _roomState.value = null
        _statusMessage.value = null
    }

    fun leaveRoom() {
        _roomState.value = null
        _statusMessage.value = null
    }
}
