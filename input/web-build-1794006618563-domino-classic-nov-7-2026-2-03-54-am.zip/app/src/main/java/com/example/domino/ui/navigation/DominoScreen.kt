package com.example.domino.ui.navigation

enum class DominoScreen {
    HOME,
    GAME,
    SHOP,
    PROGRESSION,
    STATS_PROFILE,
    SETTINGS,
    MULTIPLAYER
}
