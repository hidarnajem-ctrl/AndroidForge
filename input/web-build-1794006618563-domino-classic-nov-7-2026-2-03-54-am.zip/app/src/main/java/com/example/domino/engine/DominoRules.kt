package com.example.domino.engine

/**
 * Handles complete rules, scoring, and state transitions for Double-Six Domino.
 */
object DominoRules {

    /**
     * Determines whether the player has any legal moves in hand.
     */
    fun hasLegalMove(board: DominoBoard, hand: List<DominoTile>): Boolean {
        if (board.isEmpty) return hand.isNotEmpty()
        return hand.any { board.canPlayTile(it) }
    }

    /**
     * Finds the tile that should play first in the very first round.
     * Highest double plays first; if no doubles in hands, highest pip tile.
     */
    fun determineFirstPlayer(
        playerHand: List<DominoTile>,
        opponentHand: List<DominoTile>
    ): PlayerTurn {
        val playerDoubles = playerHand.filter { it.isDouble }.sortedByDescending { it.pipTotal }
        val opponentDoubles = opponentHand.filter { it.isDouble }.sortedByDescending { it.pipTotal }

        return when {
            playerDoubles.isNotEmpty() && opponentDoubles.isNotEmpty() -> {
                if (playerDoubles.first().pipTotal >= opponentDoubles.first().pipTotal) {
                    PlayerTurn.PLAYER
                } else {
                    PlayerTurn.OPPONENT
                }
            }
            playerDoubles.isNotEmpty() -> PlayerTurn.PLAYER
            opponentDoubles.isNotEmpty() -> PlayerTurn.OPPONENT
            else -> {
                val maxPlayer = playerHand.maxByOrNull { it.pipTotal }?.pipTotal ?: 0
                val maxOpponent = opponentHand.maxByOrNull { it.pipTotal }?.pipTotal ?: 0
                if (maxPlayer >= maxOpponent) PlayerTurn.PLAYER else PlayerTurn.OPPONENT
            }
        }
    }

    /**
     * Calculates pip sum of a hand.
     */
    fun calculateHandPips(hand: List<DominoTile>): Int {
        return hand.sumOf { it.pipTotal }
    }

    /**
     * Detects if the game is blocked (neither player can make a legal move
     * and boneyard is empty or variant is BLOCK).
     */
    fun isGameBlocked(
        board: DominoBoard,
        playerHand: List<DominoTile>,
        opponentHand: List<DominoTile>,
        boneyard: List<DominoTile>,
        variant: GameRuleVariant
    ): Boolean {
        if (board.isEmpty) return false
        val playerHasMove = hasLegalMove(board, playerHand)
        val opponentHasMove = hasLegalMove(board, opponentHand)

        if (playerHasMove || opponentHasMove) return false

        return when (variant) {
            GameRuleVariant.BLOCK -> true
            GameRuleVariant.DRAW -> boneyard.isEmpty()
        }
    }

    /**
     * Result of a finished round including winner, points awarded, and reason.
     */
    data class RoundResult(
        val winner: PlayerTurn?,  // null if tie
        val reason: RoundEndReason,
        val pointsAwarded: Int,
        val playerHandPips: Int,
        val opponentHandPips: Int,
        val winningTile: DominoTile? = null
    )

    /**
     * Evaluates round end conditions and calculates score.
     */
    fun evaluateRoundResult(
        board: DominoBoard,
        playerHand: List<DominoTile>,
        opponentHand: List<DominoTile>,
        boneyard: List<DominoTile>,
        variant: GameRuleVariant,
        lastPlayedTile: DominoTile?,
        lastPlayer: PlayerTurn?
    ): RoundResult? {
        // Condition 1: Player hand is empty -> Domino!
        if (playerHand.isEmpty()) {
            val oppPips = calculateHandPips(opponentHand)
            return RoundResult(
                winner = PlayerTurn.PLAYER,
                reason = RoundEndReason.DOMINO,
                pointsAwarded = oppPips,
                playerHandPips = 0,
                opponentHandPips = oppPips,
                winningTile = lastPlayedTile
            )
        }

        // Condition 2: Opponent hand is empty -> Domino!
        if (opponentHand.isEmpty()) {
            val playerPips = calculateHandPips(playerHand)
            return RoundResult(
                winner = PlayerTurn.OPPONENT,
                reason = RoundEndReason.DOMINO,
                pointsAwarded = playerPips,
                playerHandPips = playerPips,
                opponentHandPips = 0,
                winningTile = lastPlayedTile
            )
        }

        // Condition 3: Blocked game
        if (isGameBlocked(board, playerHand, opponentHand, boneyard, variant)) {
            val playerPips = calculateHandPips(playerHand)
            val oppPips = calculateHandPips(opponentHand)

            return when {
                playerPips < oppPips -> {
                    // Player has fewer pips -> Player wins difference or opponent pips
                    RoundResult(
                        winner = PlayerTurn.PLAYER,
                        reason = RoundEndReason.BLOCKED,
                        pointsAwarded = oppPips - playerPips,
                        playerHandPips = playerPips,
                        opponentHandPips = oppPips,
                        winningTile = lastPlayedTile
                    )
                }
                oppPips < playerPips -> {
                    // Opponent has fewer pips -> Opponent wins
                    RoundResult(
                        winner = PlayerTurn.OPPONENT,
                        reason = RoundEndReason.BLOCKED,
                        pointsAwarded = playerPips - oppPips,
                        playerHandPips = playerPips,
                        opponentHandPips = oppPips,
                        winningTile = lastPlayedTile
                    )
                }
                else -> {
                    // Tie! Neither scores points
                    RoundResult(
                        winner = null,
                        reason = RoundEndReason.BLOCKED,
                        pointsAwarded = 0,
                        playerHandPips = playerPips,
                        opponentHandPips = oppPips,
                        winningTile = null
                    )
                }
            }
        }

        return null // Round not ended yet
    }
}
