package com.example.domino.engine

/**
 * Manages the chain of domino tiles placed on the table.
 * A two-ended domino chain has a left open end and a right open end.
 */
class DominoBoard {
    private val _tiles = mutableListOf<PlacedTile>()
    val tiles: List<PlacedTile> get() = _tiles

    var leftEndValue: Int? = null
        private set
    var rightEndValue: Int? = null
        private set

    val isEmpty: Boolean get() = _tiles.isEmpty()

    fun reset() {
        _tiles.clear()
        leftEndValue = null
        rightEndValue = null
    }

    /**
     * Determines which board ends the given tile can legally connect to.
     */
    fun getLegalEnds(tile: DominoTile): List<BoardEnd> {
        if (isEmpty) {
            // First tile can be placed on either end (conventionally LEFT)
            return listOf(BoardEnd.LEFT)
        }
        val ends = mutableListOf<BoardEnd>()
        val l = leftEndValue
        val r = rightEndValue
        if (l != null && tile.canMatch(l)) {
            ends.add(BoardEnd.LEFT)
        }
        if (r != null && tile.canMatch(r)) {
            // If both ends have the same open value, we only add RIGHT if distinct or both valid
            if (!ends.contains(BoardEnd.RIGHT)) {
                ends.add(BoardEnd.RIGHT)
            }
        }
        return ends
    }

    fun canPlayTile(tile: DominoTile): Boolean {
        if (isEmpty) return true
        val l = leftEndValue ?: return true
        val r = rightEndValue ?: return true
        return tile.canMatch(l) || tile.canMatch(r)
    }

    /**
     * Plays a tile at the specified end of the board.
     * Returns true if placement was successful.
     */
    fun playTile(tile: DominoTile, end: BoardEnd): Boolean {
        if (isEmpty) {
            // First tile on board
            leftEndValue = tile.left
            rightEndValue = tile.right
            val placed = PlacedTile(
                tile = tile,
                placedAtEnd = BoardEnd.LEFT,
                exposedLeft = tile.left,
                exposedRight = tile.right,
                isVertical = tile.isDouble,
                sequenceIndex = 0
            )
            _tiles.add(placed)
            return true
        }

        return when (end) {
            BoardEnd.LEFT -> {
                val currentLeft = leftEndValue ?: return false
                val orientedTile = when {
                    tile.right == currentLeft -> tile
                    tile.left == currentLeft -> tile.flipped()
                    else -> return false
                }
                leftEndValue = orientedTile.left
                val placed = PlacedTile(
                    tile = orientedTile,
                    placedAtEnd = BoardEnd.LEFT,
                    exposedLeft = orientedTile.left,
                    exposedRight = orientedTile.right,
                    isVertical = orientedTile.isDouble,
                    sequenceIndex = _tiles.size
                )
                _tiles.add(0, placed)
                true
            }
            BoardEnd.RIGHT -> {
                val currentRight = rightEndValue ?: return false
                val orientedTile = when {
                    tile.left == currentRight -> tile
                    tile.right == currentRight -> tile.flipped()
                    else -> return false
                }
                rightEndValue = orientedTile.right
                val placed = PlacedTile(
                    tile = orientedTile,
                    placedAtEnd = BoardEnd.RIGHT,
                    exposedLeft = orientedTile.left,
                    exposedRight = orientedTile.right,
                    isVertical = orientedTile.isDouble,
                    sequenceIndex = _tiles.size
                )
                _tiles.add(placed)
                true
            }
        }
    }
}
