package com.example.domino.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.domino.data.ShopCatalog
import com.example.domino.data.TileSkin
import com.example.domino.engine.DominoTile

/**
 * Renders a tactile, premium Double-Six domino tile with authentic pip layouts,
 * custom skin colors, metallic divider, and 3D bevel lighting.
 */
@Composable
fun DominoTileView(
    tile: DominoTile,
    modifier: Modifier = Modifier,
    skinId: String = "skin_ivory",
    isVertical: Boolean = true,
    isSelected: Boolean = false,
    isPlayable: Boolean = false,
    width: Dp = 48.dp,
    height: Dp = 96.dp,
    onClick: (() -> Unit)? = null
) {
    val skin = ShopCatalog.getTileSkin(skinId)

    val elevation by animateDpAsState(
        targetValue = when {
            isSelected -> 12.dp
            isPlayable -> 6.dp
            else -> 3.dp
        },
        label = "tileElevation"
    )

    val yOffset by animateDpAsState(
        targetValue = if (isSelected) (-8).dp else 0.dp,
        label = "tileOffset"
    )

    val borderWidth by animateDpAsState(
        targetValue = when {
            isSelected -> 2.5.dp
            isPlayable -> 1.5.dp
            else -> 1.dp
        },
        label = "tileBorder"
    )

    val effectiveBorderColor = when {
        isSelected -> Color(0xFFFFD700)
        isPlayable -> Color(0xFF68D391)
        else -> skin.borderColor
    }

    val tileWidth = if (isVertical) width else height
    val tileHeight = if (isVertical) height else width

    Box(
        modifier = modifier
            .testTag("domino_tile_${tile.left}_${tile.right}")
            .size(width = tileWidth, height = tileHeight)
            .offset(y = yOffset)
            .shadow(elevation = elevation, shape = RoundedCornerShape(7.dp))
            .clip(RoundedCornerShape(7.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        skin.surfaceColor,
                        skin.surfaceColor.copy(alpha = 0.92f)
                    )
                )
            )
            .border(width = borderWidth, color = effectiveBorderColor, shape = RoundedCornerShape(7.dp))
            .then(
                if (onClick != null) {
                    Modifier.clickable(onClick = onClick)
                } else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(3.dp)) {
            val w = size.width
            val h = size.height

            if (isVertical) {
                // Divider line across middle
                val midY = h / 2f
                drawLine(
                    color = skin.dividerColor,
                    start = Offset(4f, midY),
                    end = Offset(w - 4f, midY),
                    strokeWidth = 2.5f
                )

                // Brass center pin dot
                drawCircle(
                    color = Color(0xFFD4AF37),
                    radius = 2.5f,
                    center = Offset(w / 2f, midY)
                )

                // Top Half: tile.left pips
                drawPips(
                    pips = tile.left,
                    color = skin.pipColor,
                    area = Size(w, midY),
                    offset = Offset.Zero
                )

                // Bottom Half: tile.right pips
                drawPips(
                    pips = tile.right,
                    color = skin.pipColor,
                    area = Size(w, midY),
                    offset = Offset(0f, midY)
                )
            } else {
                // Horizontal divider
                val midX = w / 2f
                drawLine(
                    color = skin.dividerColor,
                    start = Offset(midX, 4f),
                    end = Offset(midX, h - 4f),
                    strokeWidth = 2.5f
                )

                // Brass center pin
                drawCircle(
                    color = Color(0xFFD4AF37),
                    radius = 2.5f,
                    center = Offset(midX, h / 2f)
                )

                // Left Half: tile.left
                drawPips(
                    pips = tile.left,
                    color = skin.pipColor,
                    area = Size(midX, h),
                    offset = Offset.Zero
                )

                // Right Half: tile.right
                drawPips(
                    pips = tile.right,
                    color = skin.pipColor,
                    area = Size(midX, h),
                    offset = Offset(midX, 0f)
                )
            }
        }
    }
}

/**
 * Draws domino tile face down (back of tile).
 */
@Composable
fun DominoTileBackView(
    modifier: Modifier = Modifier,
    isVertical: Boolean = true,
    width: Dp = 32.dp,
    height: Dp = 64.dp
) {
    val tileWidth = if (isVertical) width else height
    val tileHeight = if (isVertical) height else width

    Box(
        modifier = modifier
            .size(width = tileWidth, height = tileHeight)
            .shadow(elevation = 3.dp, shape = RoundedCornerShape(6.dp))
            .clip(RoundedCornerShape(6.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF0F3E2F),
                        Color(0xFF07271B)
                    )
                )
            )
            .border(1.dp, Color(0xFFD4AF37).copy(alpha = 0.6f), RoundedCornerShape(6.dp)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(4.dp)) {
            // Subtle diamond pattern or gold crest outline
            val w = size.width
            val h = size.height
            drawCircle(
                color = Color(0xFFD4AF37).copy(alpha = 0.35f),
                radius = minOf(w, h) * 0.22f,
                center = Offset(w / 2f, h / 2f)
            )
        }
    }
}

/**
 * Helper function for standard double-six domino pip placement in Canvas.
 */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawPips(
    pips: Int,
    color: Color,
    area: Size,
    offset: Offset
) {
    if (pips == 0) return

    val pipRadius = minOf(area.width, area.height) * 0.10f
    val cx = offset.x + area.width / 2f
    val cy = offset.y + area.height / 2f

    val xLeft = offset.x + area.width * 0.28f
    val xRight = offset.x + area.width * 0.72f
    val yTop = offset.y + area.height * 0.28f
    val yBottom = offset.y + area.height * 0.72f

    fun drawPip(x: Float, y: Float) {
        drawCircle(
            color = color,
            radius = pipRadius,
            center = Offset(x, y)
        )
    }

    when (pips) {
        1 -> {
            drawPip(cx, cy)
        }
        2 -> {
            drawPip(xLeft, yTop)
            drawPip(xRight, yBottom)
        }
        3 -> {
            drawPip(xLeft, yTop)
            drawPip(cx, cy)
            drawPip(xRight, yBottom)
        }
        4 -> {
            drawPip(xLeft, yTop)
            drawPip(xRight, yTop)
            drawPip(xLeft, yBottom)
            drawPip(xRight, yBottom)
        }
        5 -> {
            drawPip(xLeft, yTop)
            drawPip(xRight, yTop)
            drawPip(cx, cy)
            drawPip(xLeft, yBottom)
            drawPip(xRight, yBottom)
        }
        6 -> {
            drawPip(xLeft, yTop)
            drawPip(xRight, yTop)
            drawPip(xLeft, cy)
            drawPip(xRight, cy)
            drawPip(xLeft, yBottom)
            drawPip(xRight, yBottom)
        }
    }
}
