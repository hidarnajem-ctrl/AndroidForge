package com.example.domino.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Manages Google AdMob banner, interstitial and rewarded ads.
 * Follows strict frequency limits:
 * - Interstitials shown strictly every 3 completed rounds, between rounds or on game over.
 * - Never interrupts active gameplay.
 * - If ad is not ready, gameplay proceeds without blocking.
 */
class AdMobManager(private val context: Context) {
    companion object {
        private const val TAG = "DominoAdMob"

        // Official Google Sample/Test Ad Unit IDs:
        // Replace with production ad unit IDs before release
        const val TEST_BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111"
        const val TEST_INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712"
        const val TEST_REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"

        private val isInitialized = AtomicBoolean(false)
    }

    private var interstitialAd: InterstitialAd? = null
    private var isInterstitialLoading = false

    private var rewardedAd: RewardedAd? = null
    private var isRewardedLoading = false

    // Track completed rounds for interstitial scheduling
    private var completedRoundsSinceLastAd = 0

    init {
        initializeSdk()
    }

    private fun initializeSdk() {
        if (isInitialized.compareAndSet(false, true)) {
            try {
                MobileAds.initialize(context) { status ->
                    Log.d(TAG, "AdMob MobileAds initialized: ${status.adapterStatusMap}")
                    preloadInterstitial()
                    preloadRewarded()
                }
            } catch (e: Exception) {
                Log.w(TAG, "AdMob initialization deferred: ${e.message}")
            }
        } else {
            preloadInterstitial()
            preloadRewarded()
        }
    }

    fun preloadInterstitial() {
        if (interstitialAd != null || isInterstitialLoading) return
        isInterstitialLoading = true

        try {
            val request = AdRequest.Builder().build()
            InterstitialAd.load(
                context,
                TEST_INTERSTITIAL_AD_UNIT_ID,
                request,
                object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(ad: InterstitialAd) {
                        interstitialAd = ad
                        isInterstitialLoading = false
                        Log.d(TAG, "Interstitial loaded successfully")
                    }

                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        interstitialAd = null
                        isInterstitialLoading = false
                        Log.d(TAG, "Interstitial load failed: ${loadAdError.message}")
                    }
                }
            )
        } catch (e: Exception) {
            isInterstitialLoading = false
            Log.w(TAG, "Interstitial load caught: ${e.message}")
        }
    }

    fun preloadRewarded() {
        if (rewardedAd != null || isRewardedLoading) return
        isRewardedLoading = true

        try {
            val request = AdRequest.Builder().build()
            RewardedAd.load(
                context,
                TEST_REWARDED_AD_UNIT_ID,
                request,
                object : RewardedAdLoadCallback() {
                    override fun onAdLoaded(ad: RewardedAd) {
                        rewardedAd = ad
                        isRewardedLoading = false
                        Log.d(TAG, "Rewarded ad loaded successfully")
                    }

                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        rewardedAd = null
                        isRewardedLoading = false
                        Log.d(TAG, "Rewarded load failed: ${loadAdError.message}")
                    }
                }
            )
        } catch (e: Exception) {
            isRewardedLoading = false
            Log.w(TAG, "Rewarded load caught: ${e.message}")
        }
    }

    /**
     * Called whenever a round completes.
     * Every 3 completed rounds, if an ad is ready, displays between rounds.
     * Never interrupts active gameplay!
     */
    fun onRoundCompleted(activity: Activity?, onDismiss: () -> Unit) {
        completedRoundsSinceLastAd++
        Log.d(TAG, "Completed rounds counter: $completedRoundsSinceLastAd")

        if (completedRoundsSinceLastAd >= 3) {
            val ad = interstitialAd
            if (ad != null && activity != null) {
                ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        interstitialAd = null
                        completedRoundsSinceLastAd = 0
                        preloadInterstitial()
                        onDismiss()
                    }

                    override fun onAdFailedToShowFullScreenContent(error: AdError) {
                        interstitialAd = null
                        preloadInterstitial()
                        onDismiss()
                    }
                }
                ad.show(activity)
            } else {
                // Ad was not ready, continue seamlessly without blocking
                preloadInterstitial()
                onDismiss()
            }
        } else {
            onDismiss()
        }
    }

    /**
     * Shows a rewarded ad for bonus coins or daily reward double.
     */
    fun showRewardedAd(
        activity: Activity?,
        onRewarded: (rewardAmount: Int) -> Unit,
        onFailedOrDismissed: () -> Unit
    ) {
        val ad = rewardedAd
        if (ad != null && activity != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    preloadRewarded()
                    onFailedOrDismissed()
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    rewardedAd = null
                    preloadRewarded()
                    onFailedOrDismissed()
                }
            }
            ad.show(activity) { rewardItem ->
                val amount = rewardItem.amount.coerceAtLeast(100)
                Log.d(TAG, "User earned reward: $amount")
                onRewarded(amount)
            }
        } else {
            preloadRewarded()
            onFailedOrDismissed()
        }
    }

    val isRewardedAdReady: Boolean
        get() = rewardedAd != null
}
