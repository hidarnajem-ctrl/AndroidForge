package com.example.domino.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.domino.data.GamePreferences
import com.example.domino.data.ShopCatalog
import com.example.domino.engine.DominoTile
import com.example.domino.ui.components.CoinBalanceBadge
import com.example.domino.ui.components.DominoTileView
import com.example.domino.ui.components.LuxuryButton

@Composable
fun ShopScreen(
    playerData: GamePreferences.PlayerData,
    onPurchaseItem: (itemId: String, cost: Int) -> Unit,
    onEquipTileSkin: (skinId: String) -> Unit,
    onEquipBoardTheme: (boardId: String) -> Unit,
    onEquipAvatar: (avatarId: String) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf(
        stringResource(R.string.tab_tiles),
        stringResource(R.string.tab_boards),
        stringResource(R.string.tab_avatars)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF041911), Color(0xFF07271B), Color(0xFF0A3424))
                )
            )
            .statusBarsPadding()
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF093322))
                        .testTag("shop_back_btn")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color(0xFFFFD700)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = stringResource(R.string.shop_title),
                    color = Color(0xFFFFD700),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp
                )
            }

            CoinBalanceBadge(coins = playerData.coins)
        }

        // Category Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color(0xFF07271B),
            contentColor = Color(0xFFFFD700),
            edgePadding = 16.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 14.sp
                        )
                    }
                )
            }
        }

        // Catalog Content
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            when (selectedTab) {
                0 -> {
                    // Tile Skins
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(ShopCatalog.tileSkins, key = { it.id }) { skin ->
                            val isUnlocked = skin.cost == 0 || playerData.unlockedItems.contains(skin.id)
                            val isEquipped = playerData.tileSkinId == skin.id

                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF0C3827)),
                                border = CardDefaults.outlinedCardBorder().copy(
                                    brush = Brush.verticalGradient(
                                        if (isEquipped) listOf(Color(0xFFFFD700), Color(0xFFD4AF37))
                                        else listOf(Color(0xFF1E5C43), Color.Transparent)
                                    )
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .shadow(4.dp, RoundedCornerShape(16.dp))
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    // Tile Preview
                                    DominoTileView(
                                        tile = DominoTile(id = 99, left = 6, right = 6),
                                        skinId = skin.id,
                                        isVertical = true,
                                        width = 40.dp,
                                        height = 80.dp
                                    )

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Text(
                                        text = stringResource(id = skin.nameRes),
                                        color = Color(0xFFF5FAF7),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        textAlign = TextAlign.Center,
                                        maxLines = 1
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    when {
                                        isEquipped -> {
                                            Text(
                                                text = stringResource(R.string.btn_equipped) + " ✓",
                                                color = Color(0xFFFFD700),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            )
                                        }
                                        isUnlocked -> {
                                            LuxuryButton(
                                                text = stringResource(R.string.btn_equip),
                                                onClick = { onEquipTileSkin(skin.id) },
                                                isSecondary = true,
                                                modifier = Modifier.fillMaxWidth().height(36.dp)
                                            )
                                        }
                                        else -> {
                                            LuxuryButton(
                                                text = stringResource(R.string.btn_buy, skin.cost),
                                                onClick = {
                                                    if (playerData.coins >= skin.cost) {
                                                        onPurchaseItem(skin.id, skin.cost)
                                                    } else {
                                                        Toast.makeText(context, R.string.not_enough_coins, Toast.LENGTH_SHORT).show()
                                                    }
                                                },
                                                modifier = Modifier.fillMaxWidth().height(36.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> {
                    // Board Themes
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(ShopCatalog.boardThemes, key = { it.id }) { board ->
                            val isUnlocked = board.cost == 0 || playerData.unlockedItems.contains(board.id)
                            val isEquipped = playerData.boardThemeId == board.id

                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF0C3827)),
                                border = CardDefaults.outlinedCardBorder().copy(
                                    brush = Brush.verticalGradient(
                                        if (isEquipped) listOf(Color(0xFFFFD700), Color(0xFFD4AF37))
                                        else listOf(Color(0xFF1E5C43), Color.Transparent)
                                    )
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .shadow(4.dp, RoundedCornerShape(16.dp))
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    // Board Swatch
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(60.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(
                                                Brush.radialGradient(
                                                    listOf(board.feltColor, board.primaryColor)
                                                )
                                            )
                                            .border(1.5.dp, board.borderColor, RoundedCornerShape(10.dp))
                                    )

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Text(
                                        text = stringResource(id = board.nameRes),
                                        color = Color(0xFFF5FAF7),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        textAlign = TextAlign.Center,
                                        maxLines = 1
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    when {
                                        isEquipped -> {
                                            Text(
                                                text = stringResource(R.string.btn_equipped) + " ✓",
                                                color = Color(0xFFFFD700),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            )
                                        }
                                        isUnlocked -> {
                                            LuxuryButton(
                                                text = stringResource(R.string.btn_equip),
                                                onClick = { onEquipBoardTheme(board.id) },
                                                isSecondary = true,
                                                modifier = Modifier.fillMaxWidth().height(36.dp)
                                            )
                                        }
                                        else -> {
                                            LuxuryButton(
                                                text = stringResource(R.string.btn_buy, board.cost),
                                                onClick = {
                                                    if (playerData.coins >= board.cost) {
                                                        onPurchaseItem(board.id, board.cost)
                                                    } else {
                                                        Toast.makeText(context, R.string.not_enough_coins, Toast.LENGTH_SHORT).show()
                                                    }
                                                },
                                                modifier = Modifier.fillMaxWidth().height(36.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    // Avatars
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(ShopCatalog.avatars, key = { it.id }) { avatar ->
                            val isUnlocked = avatar.cost == 0 || playerData.unlockedItems.contains(avatar.id)
                            val isEquipped = playerData.avatarId == avatar.id

                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF0C3827)),
                                border = CardDefaults.outlinedCardBorder().copy(
                                    brush = Brush.verticalGradient(
                                        if (isEquipped) listOf(Color(0xFFFFD700), Color(0xFFD4AF37))
                                        else listOf(Color(0xFF1E5C43), Color.Transparent)
                                    )
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .shadow(4.dp, RoundedCornerShape(16.dp))
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(64.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF07271B))
                                            .border(2.dp, Color(0xFFFFD700), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(text = avatar.iconEmoji, fontSize = 32.sp)
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Text(
                                        text = avatar.name,
                                        color = Color(0xFFF5FAF7),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        textAlign = TextAlign.Center
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    when {
                                        isEquipped -> {
                                            Text(
                                                text = stringResource(R.string.btn_equipped) + " ✓",
                                                color = Color(0xFFFFD700),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            )
                                        }
                                        isUnlocked -> {
                                            LuxuryButton(
                                                text = stringResource(R.string.btn_equip),
                                                onClick = { onEquipAvatar(avatar.id) },
                                                isSecondary = true,
                                                modifier = Modifier.fillMaxWidth().height(36.dp)
                                            )
                                        }
                                        else -> {
                                            LuxuryButton(
                                                text = stringResource(R.string.btn_buy, avatar.cost),
                                                onClick = {
                                                    if (playerData.coins >= avatar.cost) {
                                                        onPurchaseItem(avatar.id, avatar.cost)
                                                    } else {
                                                        Toast.makeText(context, R.string.not_enough_coins, Toast.LENGTH_SHORT).show()
                                                    }
                                                },
                                                modifier = Modifier.fillMaxWidth().height(36.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
