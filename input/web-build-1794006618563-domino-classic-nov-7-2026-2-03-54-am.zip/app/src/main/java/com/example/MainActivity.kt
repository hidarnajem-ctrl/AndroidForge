package com.example

import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import com.example.domino.ui.navigation.DominoScreen
import com.example.domino.ui.screens.GameScreen
import com.example.domino.ui.screens.HomeScreen
import com.example.domino.ui.screens.MultiplayerScreen
import com.example.domino.ui.screens.ProgressionScreen
import com.example.domino.ui.screens.SettingsScreen
import com.example.domino.ui.screens.ShopScreen
import com.example.domino.ui.screens.StatsProfileScreen
import com.example.ui.theme.DominoTheme
import com.example.domino.viewmodel.DominoGameViewModel
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val viewModel: DominoGameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val playerData by viewModel.playerData.collectAsState()
            val gameState by viewModel.gameState.collectAsState()
            val currentScreen by viewModel.currentScreen.collectAsState()

            // Dynamic Localization Configuration for Arabic (RTL), English (LTR), and Spanish (LTR)
            val currentLocale = when (playerData.language) {
                "en" -> Locale("en")
                "es" -> Locale("es")
                else -> Locale("ar") // Arabic is default
            }

            val configuration = Configuration(LocalConfiguration.current).apply {
                setLocale(currentLocale)
                setLayoutDirection(currentLocale)
            }

            val localizedContext = LocalContext.current.createConfigurationContext(configuration)
            val layoutDirection = if (playerData.language == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr

            CompositionLocalProvider(
                LocalConfiguration provides configuration,
                LocalContext provides localizedContext,
                LocalLayoutDirection provides layoutDirection
            ) {
                DominoTheme {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        AnimatedContent(
                            targetState = currentScreen,
                            transitionSpec = { fadeIn() togetherWith fadeOut() },
                            label = "screen_transition"
                        ) { screen ->
                            when (screen) {
                                DominoScreen.HOME -> {
                                    HomeScreen(
                                        playerData = playerData,
                                        onPlayComputer = { difficulty ->
                                            viewModel.startComputerMatch(difficulty)
                                        },
                                        onPlayFriend = {
                                            viewModel.navigateTo(DominoScreen.MULTIPLAYER)
                                        },
                                        onPlayOnline = {
                                            viewModel.navigateTo(DominoScreen.MULTIPLAYER)
                                        },
                                        onOpenDailyRewards = {
                                            viewModel.navigateTo(DominoScreen.PROGRESSION)
                                        },
                                        onOpenMissions = {
                                            viewModel.navigateTo(DominoScreen.PROGRESSION)
                                        },
                                        onOpenShop = {
                                            viewModel.navigateTo(DominoScreen.SHOP)
                                        },
                                        onOpenStats = {
                                            viewModel.navigateTo(DominoScreen.STATS_PROFILE)
                                        },
                                        onOpenSettings = {
                                            viewModel.navigateTo(DominoScreen.SETTINGS)
                                        }
                                    )
                                }

                                DominoScreen.GAME -> {
                                    GameScreen(
                                        gameState = gameState,
                                        playerData = playerData,
                                        audioService = viewModel.audioService,
                                        adMobManager = viewModel.adMobManager,
                                        onSelectTile = { tile ->
                                            viewModel.selectTile(tile)
                                        },
                                        onPlayTileEnd = { tile, end ->
                                            viewModel.playTileAtEnd(tile, end)
                                        },
                                        onDraw = {
                                            viewModel.drawTile()
                                        },
                                        onPass = {
                                            viewModel.passTurn()
                                        },
                                        onExecuteAITurn = {
                                            viewModel.executeAITurn()
                                        },
                                        onProceedNextRound = {
                                            viewModel.proceedNextRound()
                                        },
                                        onSurrenderAndExit = {
                                            viewModel.surrenderMatch()
                                        },
                                        onRestartMatch = {
                                            viewModel.restartMatch()
                                        }
                                    )
                                }

                                DominoScreen.SHOP -> {
                                    ShopScreen(
                                        playerData = playerData,
                                        onPurchaseItem = { itemId, cost ->
                                            viewModel.purchaseItem(itemId, cost)
                                        },
                                        onEquipTileSkin = { skinId ->
                                            viewModel.equipTileSkin(skinId)
                                        },
                                        onEquipBoardTheme = { boardId ->
                                            viewModel.equipBoardTheme(boardId)
                                        },
                                        onEquipAvatar = { avatarId ->
                                            viewModel.equipAvatar(avatarId)
                                        },
                                        onBack = {
                                            viewModel.navigateTo(DominoScreen.HOME)
                                        }
                                    )
                                }

                                DominoScreen.PROGRESSION -> {
                                    ProgressionScreen(
                                        playerData = playerData,
                                        adMobManager = viewModel.adMobManager,
                                        onClaimDailyReward = { multiplier ->
                                            viewModel.claimDailyReward(multiplier)
                                        },
                                        onClaimMission = { missionId, coins ->
                                            viewModel.claimMission(missionId, coins)
                                        },
                                        onBack = {
                                            viewModel.navigateTo(DominoScreen.HOME)
                                        }
                                    )
                                }

                                DominoScreen.STATS_PROFILE -> {
                                    StatsProfileScreen(
                                        playerData = playerData,
                                        onUpdatePlayerName = { name ->
                                            viewModel.updatePlayerName(name)
                                        },
                                        onBack = {
                                            viewModel.navigateTo(DominoScreen.HOME)
                                        }
                                    )
                                }

                                DominoScreen.SETTINGS -> {
                                    SettingsScreen(
                                        playerData = playerData,
                                        onLanguageChange = { lang ->
                                            viewModel.setLanguage(lang)
                                        },
                                        onSoundToggle = { enabled ->
                                            viewModel.setSoundEnabled(enabled)
                                        },
                                        onVibrationToggle = { enabled ->
                                            viewModel.setVibrationEnabled(enabled)
                                        },
                                        onAnimationsToggle = { enabled ->
                                            viewModel.setAnimationsEnabled(enabled)
                                        },
                                        onTargetScoreChange = { target ->
                                            viewModel.setTargetScore(target)
                                        },
                                        onDefaultRuleChange = { rule ->
                                            viewModel.setDefaultRule(rule)
                                        },
                                        onBack = {
                                            viewModel.navigateTo(DominoScreen.HOME)
                                        }
                                    )
                                }

                                DominoScreen.MULTIPLAYER -> {
                                    MultiplayerScreen(
                                        playerData = playerData,
                                        multiplayerManager = viewModel.multiplayerManager,
                                        onStartGame = {
                                            viewModel.startFriendOrOnlineMatch()
                                        },
                                        onBack = {
                                            viewModel.navigateTo(DominoScreen.HOME)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
