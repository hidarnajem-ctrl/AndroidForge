package com.example.domino.ui.components

import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import com.example.domino.ads.AdMobManager
import com.example.domino.data.ShopCatalog
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView

/**
 * Luxury styled button with gold metallic gradient and emerald shadow.
 */
@Composable
fun LuxuryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    isSecondary: Boolean = false,
    enabled: Boolean = true,
    testTag: String = "luxury_button"
) {
    val gradientColors = if (isSecondary) {
        listOf(Color(0xFF104230), Color(0xFF07271B))
    } else {
        listOf(Color(0xFFFFD700), Color(0xFFD4AF37), Color(0xFFA5801B))
    }

    val textColor = if (isSecondary) Color(0xFFF5FAF7) else Color(0xFF07271B)
    val borderColor = if (isSecondary) Color(0xFFD4AF37).copy(alpha = 0.5f) else Color(0xFFFFF3B0)

    Box(
        modifier = modifier
            .testTag(testTag)
            .defaultMinSize(minHeight = 48.dp)
            .shadow(
                elevation = if (enabled) 6.dp else 1.dp,
                shape = RoundedCornerShape(14.dp)
            )
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.horizontalGradient(
                    colors = if (enabled) gradientColors else listOf(Color(0xFF334A3E), Color(0xFF24362D))
                )
            )
            .border(
                width = 1.5.dp,
                color = if (enabled) borderColor else Color.Transparent,
                shape = RoundedCornerShape(14.dp)
            )
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (enabled) textColor else Color.Gray,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                color = if (enabled) textColor else Color.LightGray,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

/**
 * Avatar with circular level badge and optional active green online dot.
 */
@Composable
fun PlayerAvatarBadge(
    avatarId: String,
    level: Int,
    modifier: Modifier = Modifier,
    size: Dp = 54.dp,
    showOnline: Boolean = true,
    isOnline: Boolean = true,
    onClick: (() -> Unit)? = null
) {
    val avatar = ShopCatalog.getAvatar(avatarId)

    Box(
        modifier = modifier
            .size(size)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        // Main Avatar circle
        Box(
            modifier = Modifier
                .size(size)
                .shadow(4.dp, CircleShape)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF1E6347), Color(0xFF09291D))
                    )
                )
                .border(2.dp, Color(0xFFFFD700), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = avatar.iconEmoji,
                fontSize = (size.value * 0.45f).sp
            )
        }

        // Level Badge at bottom-end
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .size((size.value * 0.38f).dp)
                .shadow(2.dp, CircleShape)
                .clip(CircleShape)
                .background(Color(0xFFD4AF37))
                .border(1.dp, Color(0xFF07271B), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "$level",
                color = Color(0xFF07271B),
                fontWeight = FontWeight.ExtraBold,
                fontSize = (size.value * 0.20f).sp
            )
        }

        // Online status dot at top-start
        if (showOnline) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .size((size.value * 0.25f).dp)
                    .shadow(2.dp, CircleShape)
                    .clip(CircleShape)
                    .background(if (isOnline) Color(0xFF22C55E) else Color.Gray)
                    .border(1.dp, Color(0xFF07271B), CircleShape)
            )
        }
    }
}

/**
 * Displays user's current coins balance with gold coin emblem.
 */
@Composable
fun CoinBalanceBadge(
    coins: Int,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Box(
        modifier = modifier
            .testTag("coin_balance_badge")
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF0B3324))
            .border(1.dp, Color(0xFFFFD700).copy(alpha = 0.7f), RoundedCornerShape(20.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text(text = "🪙", fontSize = 16.sp)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "$coins",
                color = Color(0xFFFFD700),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }
    }
}

/**
 * AdMob Banner View hosting test banner ad with robust error handling,
 * lifecycle disposal and fallback display.
 */
@SuppressLint("MissingPermission")
@Composable
fun AdMobBannerView(
    modifier: Modifier = Modifier,
    adUnitId: String = AdMobManager.TEST_BANNER_AD_UNIT_ID
) {
    var isAdLoaded by remember { mutableStateOf(false) }
    var adFailed by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 50.dp)
            .padding(vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        if (!adFailed) {
            AndroidView(
                modifier = Modifier.fillMaxWidth(),
                factory = { ctx ->
                    AdView(ctx).apply {
                        setAdSize(AdSize.BANNER)
                        this.adUnitId = adUnitId
                        adListener = object : com.google.android.gms.ads.AdListener() {
                            override fun onAdLoaded() {
                                isAdLoaded = true
                                adFailed = false
                            }

                            override fun onAdFailedToLoad(loadAdError: com.google.android.gms.ads.LoadAdError) {
                                isAdLoaded = false
                                adFailed = true
                            }
                        }
                        try {
                            loadAd(AdRequest.Builder().build())
                        } catch (_: Exception) {
                            adFailed = true
                        }
                    }
                },
                update = { view ->
                    // View updated
                }
            )
        }

        // Elegant fallback banner when ad is loading, failed, or on AOSP emulator without Play Services
        if (adFailed || !isAdLoaded) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFF07271B), Color(0xFF0F4733), Color(0xFF07271B))
                        )
                    )
                    .border(1.dp, Color(0xFFFFD700).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(text = "👑", fontSize = 16.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "دومينو كلاسيك | تجربة ألعاب ملكية أصلية",
                        color = Color(0xFFFFD700),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}
