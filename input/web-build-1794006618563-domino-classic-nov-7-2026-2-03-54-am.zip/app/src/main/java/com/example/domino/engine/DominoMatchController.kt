package com.example.domino.engine

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.random.Random

/**
 * Game session manager driving double-six matches, AI turns, rounds and scoring.
 */
class DominoMatchController(
    private var variant: GameRuleVariant = GameRuleVariant.DRAW,
    private var aiDifficulty: AIDifficulty = AIDifficulty.MEDIUM,
    private var targetScore: Int = 100,
    private val random: Random = Random.Default
) {
    private val board = DominoBoard()
    private val ai = DominoAI(aiDifficulty, random)

    private val playerHand = mutableListOf<DominoTile>()
    private val opponentHand = mutableListOf<DominoTile>()
    private val boneyard = mutableListOf<DominoTile>()

    private var playerScore = 0
    private var opponentScore = 0
    private var currentRound = 1
    private var completedRoundsCount = 0

    private var currentTurn = PlayerTurn.PLAYER
    private var lastPlayedTile: DominoTile? = null
    private var consecutivePasses = 0

    private val _gameState = MutableStateFlow(DominoGameState())
    val gameState: StateFlow<DominoGameState> = _gameState.asStateFlow()

    init {
        startNewMatch()
    }

    fun configureSettings(
        newVariant: GameRuleVariant = variant,
        newDifficulty: AIDifficulty = aiDifficulty,
        newTargetScore: Int = targetScore
    ) {
        variant = newVariant
        aiDifficulty = newDifficulty
        targetScore = newTargetScore
    }

    fun startNewMatch() {
        playerScore = 0
        opponentScore = 0
        currentRound = 1
        completedRoundsCount = 0
        startNewRound()
    }

    fun startNewRound() {
        board.reset()
        ai.resetMemory()
        lastPlayedTile = null
        consecutivePasses = 0

        // Deal full 28 tile set shuffled
        val fullSet = DominoTile.generateFullSet().shuffled(random).toMutableList()

        playerHand.clear()
        opponentHand.clear()
        boneyard.clear()

        // 7 tiles each
        repeat(7) {
            playerHand.add(fullSet.removeAt(0))
            opponentHand.add(fullSet.removeAt(0))
        }
        boneyard.addAll(fullSet)

        // First round decides who goes first
        currentTurn = if (currentRound == 1) {
            DominoRules.determineFirstPlayer(playerHand, opponentHand)
        } else {
            // Alternates or round winner begins
            if (currentRound % 2 == 1) PlayerTurn.PLAYER else PlayerTurn.OPPONENT
        }

        updateState()
    }

    fun selectTile(tile: DominoTile?) {
        if (currentTurn != PlayerTurn.PLAYER) return

        if (tile == null) {
            _gameState.update {
                it.copy(selectedTile = null, eligibleEndsForSelectedTile = emptyList())
            }
            return
        }

        val legalEnds = board.getLegalEnds(tile)
        if (legalEnds.isEmpty()) {
            _gameState.update {
                it.copy(selectedTile = null, eligibleEndsForSelectedTile = emptyList())
            }
            return
        }

        if (legalEnds.size == 1) {
            // Automatically play if only one legal end
            playPlayerTile(tile, legalEnds.first())
        } else {
            // Tile can be played on BOTH ends: ask player to pick end
            _gameState.update {
                it.copy(selectedTile = tile, eligibleEndsForSelectedTile = legalEnds)
            }
        }
    }

    fun playPlayerTile(tile: DominoTile, end: BoardEnd): Boolean {
        if (currentTurn != PlayerTurn.PLAYER) return false
        if (!playerHand.contains(tile)) return false

        val success = board.playTile(tile, end)
        if (!success) return false

        playerHand.remove(tile)
        lastPlayedTile = tile
        consecutivePasses = 0

        // Check for round end
        val roundResult = DominoRules.evaluateRoundResult(
            board = board,
            playerHand = playerHand,
            opponentHand = opponentHand,
            boneyard = boneyard,
            variant = variant,
            lastPlayedTile = lastPlayedTile,
            lastPlayer = PlayerTurn.PLAYER
        )

        if (roundResult != null) {
            handleRoundEnd(roundResult)
            return true
        }

        currentTurn = PlayerTurn.OPPONENT
        updateState()
        return true
    }

    /**
     * Player draws a tile from the boneyard if allowed.
     */
    fun playerDraw(): DominoTile? {
        if (currentTurn != PlayerTurn.PLAYER) return null
        if (variant != GameRuleVariant.DRAW) return null
        if (boneyard.isEmpty()) return null

        val tile = boneyard.removeAt(0)
        playerHand.add(tile)
        consecutivePasses = 0

        updateState()
        return tile
    }

    /**
     * Player passes their turn when legally allowed.
     */
    fun playerPass(): Boolean {
        if (currentTurn != PlayerTurn.PLAYER) return false
        if (DominoRules.hasLegalMove(board, playerHand)) return false

        // In Draw mode, can only pass if boneyard is empty
        if (variant == GameRuleVariant.DRAW && boneyard.isNotEmpty()) return false

        ai.recordOpponentPass(board.leftEndValue, board.rightEndValue)
        consecutivePasses++

        // If both passed consecutively and boneyard is empty (or Block mode), board is blocked
        if (consecutivePasses >= 2) {
            val blockedResult = DominoRules.evaluateRoundResult(
                board = board,
                playerHand = playerHand,
                opponentHand = opponentHand,
                boneyard = boneyard,
                variant = variant,
                lastPlayedTile = lastPlayedTile,
                lastPlayer = PlayerTurn.PLAYER
            )
            if (blockedResult != null) {
                handleRoundEnd(blockedResult)
                return true
            }
        }

        currentTurn = PlayerTurn.OPPONENT
        updateState()
        return true
    }

    /**
     * Performs AI opponent move.
     * Returns true if turn resulted in round end.
     */
    fun executeAITurn(): Boolean {
        if (currentTurn != PlayerTurn.OPPONENT) return false

        var move = ai.decideMove(board, opponentHand)

        // If no legal move in Draw mode, AI must draw until move available or boneyard empty
        if (move == null && variant == GameRuleVariant.DRAW) {
            while (boneyard.isNotEmpty() && move == null) {
                val drawn = boneyard.removeAt(0)
                opponentHand.add(drawn)
                move = ai.decideMove(board, opponentHand)
            }
        }

        if (move != null) {
            val played = board.playTile(move.tile, move.targetEnd)
            if (played) {
                opponentHand.remove(move.tile)
                lastPlayedTile = move.tile
                consecutivePasses = 0
            }
        } else {
            // AI passes
            consecutivePasses++
        }

        // Evaluate round outcome
        val result = DominoRules.evaluateRoundResult(
            board = board,
            playerHand = playerHand,
            opponentHand = opponentHand,
            boneyard = boneyard,
            variant = variant,
            lastPlayedTile = lastPlayedTile,
            lastPlayer = PlayerTurn.OPPONENT
        )

        if (result != null) {
            handleRoundEnd(result)
            return true
        }

        currentTurn = PlayerTurn.PLAYER
        updateState()
        return false
    }

    private fun handleRoundEnd(result: DominoRules.RoundResult) {
        completedRoundsCount++

        when (result.winner) {
            PlayerTurn.PLAYER -> playerScore += result.pointsAwarded
            PlayerTurn.OPPONENT -> opponentScore += result.pointsAwarded
            null -> Unit // Tie
        }

        val matchWinner = when {
            playerScore >= targetScore -> PlayerTurn.PLAYER
            opponentScore >= targetScore -> PlayerTurn.OPPONENT
            else -> null
        }

        _gameState.update {
            it.copy(
                boardTiles = board.tiles.toList(),
                leftEndValue = board.leftEndValue,
                rightEndValue = board.rightEndValue,
                playerHand = playerHand.toList(),
                opponentHandCount = opponentHand.size,
                opponentHandTiles = opponentHand.toList(),
                boneyardCount = boneyard.size,
                playerScore = playerScore,
                opponentScore = opponentScore,
                targetScore = targetScore,
                currentRound = currentRound,
                isRoundOver = true,
                isMatchOver = matchWinner != null,
                roundResult = result,
                matchWinner = matchWinner,
                roundCountForAds = completedRoundsCount,
                selectedTile = null,
                eligibleEndsForSelectedTile = emptyList(),
                canPlayerDraw = false,
                canPlayerPass = false
            )
        }
    }

    fun proceedToNextRound() {
        if (_gameState.value.isMatchOver) {
            startNewMatch()
        } else {
            currentRound++
            startNewRound()
        }
    }

    private fun updateState() {
        val playerHasMove = DominoRules.hasLegalMove(board, playerHand)
        val canDraw = currentTurn == PlayerTurn.PLAYER &&
                variant == GameRuleVariant.DRAW &&
                !playerHasMove &&
                boneyard.isNotEmpty()

        val canPass = currentTurn == PlayerTurn.PLAYER &&
                !playerHasMove &&
                (variant == GameRuleVariant.BLOCK || boneyard.isEmpty())

        _gameState.update {
            it.copy(
                boardTiles = board.tiles.toList(),
                leftEndValue = board.leftEndValue,
                rightEndValue = board.rightEndValue,
                playerHand = playerHand.toList(),
                opponentHandCount = opponentHand.size,
                opponentHandTiles = opponentHand.toList(),
                boneyardCount = boneyard.size,
                currentTurn = currentTurn,
                playerScore = playerScore,
                opponentScore = opponentScore,
                targetScore = targetScore,
                currentRound = currentRound,
                variant = variant,
                aiDifficulty = aiDifficulty,
                isRoundOver = false,
                isMatchOver = false,
                roundResult = null,
                matchWinner = null,
                selectedTile = null,
                eligibleEndsForSelectedTile = emptyList(),
                canPlayerDraw = canDraw,
                canPlayerPass = canPass,
                roundCountForAds = completedRoundsCount
            )
        }
    }
}
