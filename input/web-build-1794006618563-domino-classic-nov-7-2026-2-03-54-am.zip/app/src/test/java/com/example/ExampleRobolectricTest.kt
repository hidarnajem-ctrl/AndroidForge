package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import com.example.domino.data.ShopCatalog

class ExampleRobolectricTest {

  @Test
  fun testAppCatalogLoaded() {
    val skins = ShopCatalog.tileSkins
    assertNotNull(skins)
    assertEquals(4, skins.size)
  }
}
