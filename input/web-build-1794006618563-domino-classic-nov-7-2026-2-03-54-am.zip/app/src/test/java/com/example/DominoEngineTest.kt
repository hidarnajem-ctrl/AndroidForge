package com.example

import com.example.domino.engine.AIDifficulty
import com.example.domino.engine.BoardEnd
import com.example.domino.engine.DominoAI
import com.example.domino.engine.DominoBoard
import com.example.domino.engine.DominoRules
import com.example.domino.engine.DominoTile
import com.example.domino.engine.GameRuleVariant
import com.example.domino.engine.PlayerTurn
import com.example.domino.engine.RoundEndReason
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DominoEngineTest {

    @Test
    fun testGenerateFullSet_hasExact28UniqueTiles() {
        val fullSet = DominoTile.generateFullSet()
        assertEquals(28, fullSet.size)

        // Ensure all combinations (0..6, i..6) exist uniquely
        val distinctPairs = fullSet.map { minOf(it.left, it.right) to maxOf(it.left, it.right) }.toSet()
        assertEquals(28, distinctPairs.size)

        // Exactly 7 doubles ([0|0] through [6|6])
        val doubles = fullSet.filter { it.isDouble }
        assertEquals(7, doubles.size)
    }

    @Test
    fun testDominoBoard_emptyBoardPlacement() {
        val board = DominoBoard()
        assertTrue(board.isEmpty)

        val tile66 = DominoTile(id = 0, left = 6, right = 6)
        val success = board.playTile(tile66, BoardEnd.LEFT)

        assertTrue(success)
        assertFalse(board.isEmpty)
        assertEquals(6, board.leftEndValue)
        assertEquals(6, board.rightEndValue)
        assertEquals(1, board.tiles.size)
    }

    @Test
    fun testDominoBoard_chainPlacementAndFlipping() {
        val board = DominoBoard()
        val tile65 = DominoTile(id = 1, left = 6, right = 5)
        board.playTile(tile65, BoardEnd.LEFT)
        // Left is 6, Right is 5

        // Play [5|3] at RIGHT end
        val tile53 = DominoTile(id = 2, left = 5, right = 3)
        val playRightSuccess = board.playTile(tile53, BoardEnd.RIGHT)
        assertTrue(playRightSuccess)
        assertEquals(3, board.rightEndValue)
        assertEquals(6, board.leftEndValue)

        // Play [6|2] at LEFT end
        val tile62 = DominoTile(id = 3, left = 6, right = 2)
        val playLeftSuccess = board.playTile(tile62, BoardEnd.LEFT)
        assertTrue(playLeftSuccess)
        assertEquals(2, board.leftEndValue)
        assertEquals(3, board.rightEndValue)

        assertEquals(3, board.tiles.size)
    }

    @Test
    fun testDominoRules_determineFirstPlayer() {
        val playerHand = listOf(
            DominoTile(0, 2, 3),
            DominoTile(1, 4, 4), // Double 4
            DominoTile(2, 1, 0)
        )
        val opponentHand = listOf(
            DominoTile(3, 5, 5), // Double 5 (higher)
            DominoTile(4, 1, 2),
            DominoTile(5, 0, 0)
        )

        val firstPlayer = DominoRules.determineFirstPlayer(playerHand, opponentHand)
        assertEquals(PlayerTurn.OPPONENT, firstPlayer)
    }

    @Test
    fun testDominoRules_evaluateRoundResult_dominoWin() {
        val board = DominoBoard()
        board.playTile(DominoTile(0, 3, 3), BoardEnd.LEFT)

        val playerHand = emptyList<DominoTile>() // Emptied hand!
        val opponentHand = listOf(
            DominoTile(1, 5, 2), // 7 pips
            DominoTile(2, 6, 4)  // 10 pips
        )
        val boneyard = emptyList<DominoTile>()

        val result = DominoRules.evaluateRoundResult(
            board = board,
            playerHand = playerHand,
            opponentHand = opponentHand,
            boneyard = boneyard,
            variant = GameRuleVariant.DRAW,
            lastPlayedTile = DominoTile(0, 3, 3),
            lastPlayer = PlayerTurn.PLAYER
        )

        assertNotNull(result)
        assertEquals(PlayerTurn.PLAYER, result?.winner)
        assertEquals(RoundEndReason.DOMINO, result?.reason)
        assertEquals(17, result?.pointsAwarded) // 7 + 10 = 17 pips
    }

    @Test
    fun testDominoRules_evaluateRoundResult_blockedGame() {
        val board = DominoBoard()
        board.playTile(DominoTile(0, 1, 2), BoardEnd.LEFT)
        // Left end = 1, Right end = 2

        // Player hand has tiles with 4s and 5s (cannot play on 1 or 2)
        val playerHand = listOf(
            DominoTile(1, 4, 5) // 9 pips
        )
        // Opponent hand has tiles with 6s (cannot play on 1 or 2)
        val opponentHand = listOf(
            DominoTile(2, 6, 6) // 12 pips
        )
        val boneyard = emptyList<DominoTile>()

        val result = DominoRules.evaluateRoundResult(
            board = board,
            playerHand = playerHand,
            opponentHand = opponentHand,
            boneyard = boneyard,
            variant = GameRuleVariant.DRAW,
            lastPlayedTile = DominoTile(0, 1, 2),
            lastPlayer = PlayerTurn.PLAYER
        )

        assertNotNull(result)
        assertEquals(PlayerTurn.PLAYER, result?.winner) // 9 < 12, player has fewer pips
        assertEquals(RoundEndReason.BLOCKED, result?.reason)
        assertEquals(3, result?.pointsAwarded) // 12 - 9 = 3 difference
    }

    @Test
    fun testDominoAI_decideMove_selectsLegalPlacement() {
        val board = DominoBoard()
        board.playTile(DominoTile(0, 4, 2), BoardEnd.LEFT) // ends are 4 and 2

        val ai = DominoAI(difficulty = AIDifficulty.MEDIUM)
        val hand = listOf(
            DominoTile(1, 6, 5), // illegal
            DominoTile(2, 2, 2), // legal on 2 (double!)
            DominoTile(3, 4, 1)  // legal on 4
        )

        val move = ai.decideMove(board, hand)
        assertNotNull(move)
        // Medium prefers double [2|2]
        assertEquals(2, move?.tile?.left)
        assertEquals(2, move?.tile?.right)
        assertEquals(BoardEnd.RIGHT, move?.targetEnd)
    }
}
