# Domino Classic – Premium Android Game 🀄👑

**Domino Classic** is an original, production-grade native Android game built with Kotlin and Jetpack Compose. It features authentic Double-Six domino rules, a rich emerald and gold luxury aesthetic, offline intelligent AI opponents, progression, and multi-language support (Arabic default, English, Spanish).

---

## 🌟 Key Features

1. **Domino Game Engine (Double-Six)**:
   - Full 28-tile double-six domino set (`[0|0]` through `[6|6]`).
   - 2-player match engine with 7 initial hand tiles and a 14-tile boneyard (draw pile).
   - Dynamic chain evaluation with correct tile orientation, doubles alignment, and multi-end choices.
   - **Two Rule Variants**:
     - **Draw Domino**: When having no legal move, players draw from the boneyard until finding a match or exhausting the draw pile.
     - **Block Domino**: No draw pile; turns immediately pass if no legal tile exists.
   - Exact blocked-game detection, pip difference calculation, and target score matches (50, 100, 150 points).

2. **Multilingual & RTL Support**:
   - **Arabic (Default)**: Full RTL layout alignment, bespoke Arabic typography and localized game phrasing.
   - **English**: LTR layout with authentic domino terminology.
   - **Spanish**: LTR layout with classic Latin American / European domino rules (Dominó por Robo y Dominó Trancado).
   - Live in-game language switcher that switches UI and layout direction instantly.

3. **Smart AI Opponent**:
   - **Easy**: Casual, accessible play style.
   - **Medium**: Evaluates hand value, prioritizes double tiles and highest pip dumps.
   - **Expert**: Tracks public table history, remembers player passed suits, executes tactical blocks, and optimizes suit synergy.

4. **Visual Design & Audio**:
   - Deep emerald green velvet felt table background (`#0A3D2E`, `#07271B`) with gold borders (`#FFD700`, `#D4AF37`).
   - Tactile 2D/3D domino tiles with metallic brass divider pins and authentic pip layouts.
   - Zero-latency synthesized wooden tile clacks, draw shuffle effects, victory chimes, and haptic feedback.

5. **Progression & Customization**:
   - XP, player levels, and coin balance.
   - 7-day daily login reward calendar.
   - Daily missions and achievements.
   - In-game luxury shop:
     - Tile skins: Royal Ivory, Midnight Emerald, Luxury Obsidian, Golden Pearl.
     - Table themes: Emerald Felt, Mahogany Wood, Velvet Crimson, Sapphire Gem.
     - Avatars: King Domino, Emerald Tactician, Royal Falcon, Golden Lion.

---

## 📱 Google AdMob Integration & Production Setup

The app is integrated with the official Google Mobile Ads SDK (`play-services-ads:23.6.0`).

### Test Ad Unit IDs (Currently Active)
During development and emulator testing, Google's public test IDs are configured:
- **App ID** (`AndroidManifest.xml`): `ca-app-pub-3940256099942544~3347511713`
- **Banner Ad**: `ca-app-pub-3940256099942544/6300978111`
- **Interstitial Ad**: `ca-app-pub-3940256099942544/1033173712`
- **Rewarded Ad**: `ca-app-pub-3940256099942544/5224354917`

### Production Release Instructions
1. Register your app in your [Google AdMob Console](https://admob.google.com/).
2. In `app/src/main/AndroidManifest.xml`, update the `APPLICATION_ID` meta-data value:
   ```xml
   <meta-data
       android:name="com.google.android.gms.ads.APPLICATION_ID"
       android:value="ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY" />
   ```
3. In `app/src/main/java/com/example/domino/ads/AdMobManager.kt`, update the constant IDs:
   ```kotlin
   const val TEST_BANNER_AD_UNIT_ID = "ca-app-pub-XXXXXXXXXXXXXXXX/ZZZZZZZZZZ"
   const val TEST_INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-XXXXXXXXXXXXXXXX/WWWWWWWWWW"
   const val TEST_REWARDED_AD_UNIT_ID = "ca-app-pub-XXXXXXXXXXXXXXXX/VVVVVVVVVV"
   ```

### Interstitial Ad Frequency Policy
- Interstitials trigger strictly **every 3 completed rounds** between rounds or upon game over.
- Interstitials **never** interrupt an active game turn.
- If an interstitial is still loading, gameplay proceeds without blocking the player.

---

## ☁️ Firebase Cloud Multiplayer Backend Configuration

The client contains complete state machines and repository interfaces in `com.example.domino.online`.

### Firestore Schema Setup
To link with a live Firebase project:
1. **Provision Firebase**:
   Add `google-services.json` to the `/app/` directory and enable Firebase Auth (Google Sign-In) and Cloud Firestore.
2. **Firestore Collections**:
   - `domino_rooms/{roomId}`:
     - `roomId` (String)
     - `roomCode` (String, 6 digits)
     - `hostUid` (String)
     - `guestUid` (String)
     - `status` ("WAITING", "PLAYING", "FINISHED")
     - `ruleVariant` ("DRAW", "BLOCK")
     - `targetScore` (100)
     - `currentTurnUid` (String)
   - `domino_rooms/{roomId}/moves/{moveId}`:
     - `tileId` (0..27)
     - `placedEnd` ("LEFT", "RIGHT")
     - `playerUid` (String)
     - `timestamp` (Timestamp)
   - `matchmaking_queue/{playerUid}`:
     - `ratingLevel` (Number)
     - `queuedAt` (Timestamp)
3. **Security Rules**:
   See `com/example/domino/online/FirebaseMultiplayerContract.kt` for production zero-trust Firestore rules.

---

## 🧪 Testing

Run JVM unit tests for game rules, legal moves, board chain logic, AI algorithms, and scoring:
```bash
gradle :app:testDebugUnitTest
```
