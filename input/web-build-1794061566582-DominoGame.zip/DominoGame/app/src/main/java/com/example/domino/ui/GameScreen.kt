package com.example.domino.ui

import androidx.activity.compose.BackHandler
import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.paint
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.domino.R
import com.example.domino.ads.BannerAd
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domino.model.*
import com.example.domino.viewmodel.GameViewModel
import com.example.domino.viewmodel.ProgressViewModel

@Composable
private fun RoundIconButton(@DrawableRes res: Int, onClick: () -> Unit) {
    Box(
        Modifier.size(42.dp).clip(CircleShape)
            .background(Color(0x99000000)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Image(painterResource(res), null, Modifier.size(26.dp)) }
}

/**
 * زر قدرة: إن كان لديك رصيد منها تُستعمل مباشرة،
 * وإلا تظهر مقفلة بشارة الإعلان وتُفتح بمشاهدة إعلان بمكافأة (لهذه القدرة وحدها).
 */
@Composable
private fun RewardLine(@DrawableRes icon: Int, text: String, bold: Boolean = false) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(icon), null, Modifier.size(26.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun PowerUpButton(
    @DrawableRes res: Int,
    count: Int,
    usableNow: Boolean,
    adReady: Boolean,
    onClick: () -> Unit
) {
    val locked = count <= 0
    val active = usableNow && (!locked || adReady)
    Box(
        Modifier.size(56.dp)
            .graphicsLayer { alpha = if (active) 1f else 0.45f }
            .clickable(enabled = active, onClick = onClick)
    ) {
        Box(
            Modifier.align(Alignment.Center).size(50.dp).clip(CircleShape)
                .background(Color(0xB3000000)),
            contentAlignment = Alignment.Center
        ) { Image(painterResource(res), null, Modifier.size(32.dp)) }
        if (locked) {
            Image(
                painterResource(R.drawable.icon_lock), null,
                Modifier.align(Alignment.BottomStart).size(width = 16.dp, height = 21.dp)
            )
            Image(
                painterResource(R.drawable.badge_ad), null,
                Modifier.align(Alignment.TopEnd).size(22.dp)
            )
        } else {
            Box(
                Modifier.align(Alignment.TopEnd).size(20.dp).clip(CircleShape).background(Palette.gold),
                contentAlignment = Alignment.Center
            ) { Text("$count", color = Palette.goldDark, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
fun GameScreen(
    vm: GameViewModel,
    progressVm: ProgressViewModel,
    adReady: Boolean,
    muted: Boolean,
    onToggleMute: () -> Unit,
    onWatchAdForDouble: () -> Unit,
    onWatchAd: (onReward: () -> Unit) -> Unit,
    onRoundContinue: (action: () -> Unit) -> Unit,
    onExit: () -> Unit
) {
    val state by vm.state.collectAsState()
    val progress by progressVm.state.collectAsState()
    var confirmExit by remember { mutableStateOf(false) }
    BackHandler { confirmExit = true }

    val myTurn = state.status == Status.PLAYING && state.turn == Turn.PLAYER
    val playableIds = remember(state.playerHand, state.board) {
        state.playerMoves.map { it.tile.id }.toSet()
    }
    /** رصيد موجود → استعمال مباشر؛ مقفلة → إعلان ثم استعمال فوري. */
    fun usePower(kind: PowerUp, action: () -> Boolean) {
        if (progress.powerCount(kind) > 0) {
            if (action()) progressVm.consume(kind)
        } else {
            // إن تغيّرت حالة اللعب أثناء الإعلان تُحفظ القدرة في الرصيد ولا تضيع
            onWatchAd { if (!action()) progressVm.addPower(kind) }
        }
    }

    val wood = Brush.verticalGradient(listOf(Color(0xFF4A2E17), Color(0xFF2B1A0C)))
    val felt = Brush.radialGradient(listOf(Color(0xFF1F7A45), Color(0xFF0B3A20)))

    Column(
        Modifier.fillMaxSize().paint(painterResource(R.drawable.bg_wood), contentScale = ContentScale.Crop).statusBarsPadding().navigationBarsPadding().padding(10.dp)
    ) {
        ScoreBoard(
            state.playerScore, state.aiScore, state.boneyard.size, state.turn,
            playerName = progress.name, playerAvatar = progress.avatar
        )
        Text(
            "الجولة ${state.round}  •  الهدف $TARGET_SCORE نقطة",
            color = Palette.text, fontSize = 12.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 4.dp)
        )
        Spacer(Modifier.height(6.dp))
        AiHandView(state.aiHand.size, reveal = if (state.revealAi) state.aiHand else null)
        Spacer(Modifier.height(8.dp))

        Box(
            Modifier.weight(1f).fillMaxWidth()
                .clip(RoundedCornerShape(24.dp)).paint(painterResource(R.drawable.bg_felt), contentScale = ContentScale.Crop)
                .border(4.dp, Color(0xFF7A4A24), RoundedCornerShape(24.dp))
        ) {
            BoardView(
                board = state.board,
                startTileId = state.startTileId,
                lastPlacedId = state.lastPlacedId,
                selectableSides = state.selectableSides,
                onSideClick = vm::onSideSelected,
                modifier = Modifier.fillMaxSize()
            )
            Row(
                Modifier.align(Alignment.TopStart).padding(10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                RoundIconButton(R.drawable.nav_home) { confirmExit = true }
                RoundIconButton(if (muted) R.drawable.sound_off else R.drawable.sound_on, onToggleMute)
            }

            androidx.compose.animation.AnimatedVisibility(
                visible = state.canPlayerDraw,
                enter = androidx.compose.animation.slideInVertically { it / 3 } +
                        androidx.compose.animation.fadeIn(),
                exit = androidx.compose.animation.fadeOut() +
                        androidx.compose.animation.scaleOut(targetScale = 0.9f),
                modifier = Modifier.align(Alignment.Center)
            ) {
                BoneyardPicker(
                    boneyard = state.boneyard,
                    openEnds = if (state.board.isEmpty()) emptyList()
                    else listOf(state.board.first().left, state.board.last().right),
                    onPick = { vm.onDrawTile(it.id) }
                )
            }
        }

        Spacer(Modifier.height(8.dp))
        Text(
            state.message, color = Color(0xFFFFE9A8), fontSize = 15.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        val playing = state.status == Status.PLAYING

        Row(
            Modifier.fillMaxWidth().height(60.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PowerUpButton(R.drawable.reward_hint, progress.hints, myTurn && state.playerMoves.isNotEmpty(), adReady) {
                usePower(PowerUp.HINT, vm::useHint)
            }
            PowerUpButton(R.drawable.reward_reveal, progress.reveals, playing && !state.revealAi, adReady) {
                usePower(PowerUp.REVEAL, vm::useReveal)
            }
            PowerUpButton(R.drawable.reward_luck, progress.lucks, state.canPlayerDraw, adReady) {
                usePower(PowerUp.LUCK, vm::useLuck)
            }
            PowerUpButton(R.drawable.reward_redo, progress.redos, playing, adReady) {
                usePower(PowerUp.REDO, vm::useRedo)
            }
        }
        HandView(
            hand = state.playerHand,
            playableIds = playableIds,
            selectedId = state.selectedTileId,
            myTurn = myTurn,
            hintId = state.hintTileId,
            onTileClick = vm::onTileClicked,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(6.dp))
        BannerAd()
    }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("الخروج إلى الرئيسية؟") },
            text = { Text("ستنتهي المباراة الحالية.") },
            confirmButton = { TextButton(onClick = { confirmExit = false; progressVm.clearReward(); onExit() }) { Text("خروج") } },
            dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("متابعة اللعب") } }
        )
    }

    if (state.status == Status.ROUND_OVER) {
        val r = state.result
        val rw = progress.reward
        val matchOver = state.matchWinner != null
        val resultImage = when {
            state.matchWinner == Winner.PLAYER -> R.drawable.icon_trophy
            state.matchWinner == Winner.AI -> R.drawable.result_lose_big
            r?.winner == Winner.PLAYER -> R.drawable.result_win
            r?.winner == Winner.AI -> R.drawable.result_lose
            else -> R.drawable.result_draw
        }
        val resultSize = if (matchOver) 96.dp else 64.dp
        val trophyIcon: @Composable () -> Unit = {
            Image(painterResource(resultImage), null, Modifier.size(resultSize))
        }
        AlertDialog(
            onDismissRequest = {},
            icon = trophyIcon,
            confirmButton = {
                Button(onClick = { onRoundContinue { progressVm.clearReward(); vm.nextRound() } }) {
                    Text(if (matchOver) "مباراة جديدة" else "الجولة التالية")
                }
            },
            dismissButton = {
                TextButton(onClick = { onRoundContinue { progressVm.clearReward(); onExit() } }) { Text("الرئيسية") }
            },
            title = {
                Text(
                    when {
                        state.matchWinner == Winner.PLAYER -> "فزت بالمباراة!"
                        state.matchWinner == Winner.AI -> "خسرت المباراة"
                        r?.winner == Winner.PLAYER -> "فزت بالجولة!"
                        r?.winner == Winner.AI -> "خسرت الجولة"
                        else -> "تعادل"
                    }
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (r?.blocked == true) Text("اللعبة مغلقة (Block) — يفوز صاحب النقاط الأقل.")
                    Text("نقاط الجولة: ${r?.points ?: 0}")
                    Text("أنت ${state.playerScore}  |  الكمبيوتر ${state.aiScore}  (الهدف $TARGET_SCORE)")
                    if (rw != null) {
                        RewardLine(
                            R.drawable.icon_coin,
                            "+${rw.coins} عملة" + if (rw.doubled) "  (×2)" else "",
                            bold = true
                        )
                        RewardLine(R.drawable.icon_xp, "+${rw.xp} خبرة")
                        rw.levelUp?.let { RewardLine(R.drawable.icon_level_up, "ترقّيت إلى المستوى $it!", bold = true) }
                        if (!rw.doubled && adReady) {
                            Button(onClick = onWatchAdForDouble, modifier = Modifier.fillMaxWidth()) {
                                Image(painterResource(R.drawable.badge_ad), null, Modifier.size(22.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("ضاعف العملات")
                            }
                        }
                    }
                }
            }
        )
    }
}
