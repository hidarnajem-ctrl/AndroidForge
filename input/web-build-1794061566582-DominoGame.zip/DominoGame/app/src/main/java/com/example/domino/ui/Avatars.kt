package com.example.domino.ui

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.domino.R
import java.io.File

/** صور اللاعب الجاهزة. أضف هنا الصور الجديدة (avatar_m1 ... avatar_f4) عند وصولها. */
object Avatars {
    data class Option(val key: String, @DrawableRes val res: Int)

    val all = listOf(
        Option("m1", R.drawable.avatar_m1),
        Option("m2", R.drawable.avatar_m2),
        Option("m3", R.drawable.avatar_m3),
        Option("m4", R.drawable.avatar_m4),
        Option("f1", R.drawable.avatar_f1),
        Option("f2", R.drawable.avatar_f2),
        Option("f3", R.drawable.avatar_f3),
        Option("f4", R.drawable.avatar_f4),
        Option("default", R.drawable.avatar_default)
    )

    const val CUSTOM_FILE = "avatar_custom.jpg"
    fun resOf(key: String) = all.firstOrNull { it.key == key }?.res ?: R.drawable.avatar_default
}

/** صورة اللاعب: جاهزة من القائمة، أو صورة من الهاتف (المفتاح يبدأ بـ custom:). */
@Composable
fun PlayerAvatar(key: String, size: Dp, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    if (key.startsWith("custom")) {
        val bitmap = remember(key) {
            val f = File(context.filesDir, Avatars.CUSTOM_FILE)
            if (f.exists()) BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap() else null
        }
        if (bitmap != null) {
            Image(
                bitmap, null,
                modifier.size(size).clip(CircleShape).border(3.dp, Palette.gold, CircleShape),
                contentScale = ContentScale.Crop
            )
            return
        }
    }
    Image(painterResource(Avatars.resOf(key)), null, modifier.size(size))
}

@Composable
fun AvatarPickerDialog(
    selected: String,
    onSelect: (String) -> Unit,
    onPhotoPicked: (Uri) -> Unit,
    onDismiss: () -> Unit
) {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) { onPhotoPicked(uri); onDismiss() }
    }
    Dialog(onDismissRequest = onDismiss) {
        Panel(Modifier.fillMaxWidth()) {
            Text(
                "اختر صورتك", color = Palette.gold, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(12.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.heightIn(max = 300.dp)
            ) {
                items(Avatars.all, key = { it.key }) { opt ->
                    Box(
                        Modifier.aspectRatio(1f).clickable { onSelect(opt.key); onDismiss() },
                        contentAlignment = Alignment.Center
                    ) {
                        Image(painterResource(opt.res), null, Modifier.fillMaxSize())
                        if (opt.key == selected) {
                            Image(
                                painterResource(R.drawable.result_win), null,
                                Modifier.align(Alignment.TopEnd).size(22.dp)
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            GoldButton("صورة من الهاتف", green = true, icon = R.drawable.icon_edit) {
                launcher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }
            Spacer(Modifier.height(10.dp))
            GoldButton("إغلاق", onClick = onDismiss)
        }
    }
}
