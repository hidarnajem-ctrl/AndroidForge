package com.baghdadroad.app

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker

class MainActivity : AppCompatActivity() {
    private lateinit var map: MapView
    private lateinit var statusText: TextView

    private val locationPermission = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.any { it }) {
            showCurrentLocation()
        } else {
            showStatus("لم يتم منح إذن الموقع. يمكنك استخدام الخريطة دون تحديد موقعك.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize osmdroid preferences and user agent before creating MapView.
        Configuration.getInstance().load(
            applicationContext,
            android.preference.PreferenceManager.getDefaultSharedPreferences(applicationContext)
        )
        Configuration.getInstance().userAgentValue = packageName

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF5F7F6.toInt())
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(12))
            setBackgroundColor(0xFF176B5B.toInt())
        }

        val title = TextView(this).apply {
            text = "Baghdad Road"
            textSize = 23f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "دليلك لاستكشاف شوارع بغداد"
            textSize = 14f
            setTextColor(0xFFE5F2EF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(3), 0, 0)
        }
        header.addView(title)
        header.addView(subtitle)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }

        val locateButton = Button(this).apply {
            text = "📍 موقعي الحالي"
            isAllCaps = false
            setOnClickListener { requestLocation() }
        }

        statusText = TextView(this).apply {
            text = "الخريطة متمركزة على بغداد. تحتاج الخرائط إلى اتصال بالإنترنت."
            textSize = 13f
            setTextColor(0xFF374741.toInt())
            setPadding(dp(4), dp(3), dp(4), dp(3))
        }

        controls.addView(locateButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        controls.addView(statusText)

        map = MapView(this).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(12.0)
            controller.setCenter(GeoPoint(33.3152, 44.3661))
            setUseDataConnection(true)
            contentDescription = "خريطة بغداد"
        }

        root.addView(header)
        root.addView(controls)
        root.addView(map, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)

        map.setOnClickListener { showStatus("حرّك الخريطة أو كبّرها بإصبعين لاستكشاف بغداد.") }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun hasLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestLocation() {
        if (hasLocationPermission()) {
            showCurrentLocation()
        } else {
            locationPermission.launch(arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ))
        }
    }

    @Suppress("MissingPermission")
    private fun showCurrentLocation() {
        val manager = getSystemService(LOCATION_SERVICE) as LocationManager
        val providers = try {
            manager.getProviders(true)
        } catch (_: Exception) {
            emptyList()
        }

        var bestLocation: Location? = null
        for (provider in providers) {
            val location = try {
                manager.getLastKnownLocation(provider)
            } catch (_: SecurityException) {
                null
            } catch (_: Exception) {
                null
            }

            if (location != null && (
                bestLocation == null || location.accuracy < bestLocation!!.accuracy
            )) {
                bestLocation = location
            }
        }

        val location = bestLocation
        if (location == null) {
            showStatus("لم يُعثر على موقع حديث. فعّل GPS وانتقل إلى مكان مفتوح ثم جرّب مجددًا.")
            Toast.makeText(this, "تعذر تحديد الموقع الحالي", Toast.LENGTH_LONG).show()
            return
        }

        val point = GeoPoint(location.latitude, location.longitude)
        map.controller.animateTo(point)
        map.controller.setZoom(16.0)

        map.overlays.removeAll { it is Marker && it.title == "موقعي الحالي" }
        val marker = Marker(map).apply {
            position = point
            title = "موقعي الحالي"
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        }
        map.overlays.add(marker)
        map.invalidate()
        showStatus("تم تحديد موقعك على الخريطة.")
    }

    private fun showStatus(message: String) {
        if (::statusText.isInitialized) statusText.text = message
    }

    override fun onResume() {
        super.onResume()
        if (::map.isInitialized) map.onResume()
    }

    override fun onPause() {
        if (::map.isInitialized) map.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        if (::map.isInitialized) map.onDetach()
        super.onDestroy()
    }
}
