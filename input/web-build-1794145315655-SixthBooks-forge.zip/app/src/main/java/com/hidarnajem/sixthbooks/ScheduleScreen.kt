package com.hidarnajem.sixthbooks

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.DayOfWeek
import java.time.LocalDate

private val PERIOD_NAMES = listOf("الأولى", "الثانية", "الثالثة", "الرابعة", "الخامسة", "السادسة")

/** يوم الدراسة الحالي (الأحد = 0 ... الخميس = 4)، وفي الجمعة والسبت يعرض الأحد */
private fun todayIndex(): Int = when (LocalDate.now().dayOfWeek) {
    DayOfWeek.SUNDAY -> 0
    DayOfWeek.MONDAY -> 1
    DayOfWeek.TUESDAY -> 2
    DayOfWeek.WEDNESDAY -> 3
    DayOfWeek.THURSDAY -> 4
    else -> 0
}

@Composable
fun ScheduleScreen(store: ToolsStore, subjects: List<String>) {
    var day by rememberSaveable { mutableIntStateOf(todayIndex()) }
    var editing by remember { mutableStateOf<Int?>(null) }
    val today = remember { todayIndex() }
    val isSchoolDay = remember { LocalDate.now().dayOfWeek.let { it != DayOfWeek.FRIDAY && it != DayOfWeek.SATURDAY } }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 16.dp)
    ) {
        // أيام الأسبوع
        LazyRow(
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(SCHOOL_DAYS) { i, name ->
                DayChip(
                    name = name,
                    selected = i == day,
                    isToday = isSchoolDay && i == today,
                    onClick = { day = i }
                )
            }
        }

        // لوح الحصص لليوم المختار
        FeltBoard(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp)
        ) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
                Text(
                    "دروس يوم ${SCHOOL_DAYS[day]}",
                    style = TextStyle(
                        color = UiChalk,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        shadow = UiTextShadow
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(8.dp))
                store.schedule[day].forEachIndexed { p, subject ->
                    if (p > 0) HorizontalDivider(color = Color(0x33FFFFFF))
                    PeriodRow(index = p, subject = subject, onClick = { editing = p })
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Text(
            "اضغط على أي حصة لكتابة الدرس أو تغييره",
            color = Color(0xFFF1E4D3),
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }

    editing?.let { p ->
        SubjectPickerDialog(
            title = "${SCHOOL_DAYS[day]} • الحصة ${PERIOD_NAMES[p]}",
            current = store.schedule[day][p],
            suggestions = subjects,
            allowClear = true,
            onDismiss = { editing = null },
            onSave = {
                store.setPeriod(day, p, it)
                editing = null
            }
        )
    }
}

@Composable
private fun DayChip(name: String, selected: Boolean, isToday: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(50),
        color = if (selected) UiGoldDeep else Color(0xCC2A1405),
        border = BorderStroke(1.5.dp, if (isToday) UiChalk else UiGoldDeep),
        shadowElevation = 4.dp
    ) {
        Column(
            Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                name,
                color = if (selected) UiWoodDark else UiGold,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
            if (isToday) {
                Text("اليوم", color = if (selected) UiWoodDark else UiChalk, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun PeriodRow(index: Int, subject: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(34.dp)
                .background(UiGoldDeep, CircleShape)
                .border(1.5.dp, UiGold, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text("${index + 1}", color = UiWoodDark, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("الحصة ${PERIOD_NAMES[index]}", color = UiGold, fontSize = 12.sp)
            Text(
                subject.ifBlank { "اضغط لإضافة درس" },
                style = TextStyle(
                    color = if (subject.isBlank()) Color(0x99F7F3E8) else UiChalk,
                    fontSize = 18.sp,
                    fontWeight = if (subject.isBlank()) FontWeight.Normal else FontWeight.Bold,
                    shadow = UiTextShadow
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/** نافذة اختيار المادة: مواد مقترحة أو كتابة اسم آخر */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SubjectPickerDialog(
    title: String,
    current: String,
    suggestions: List<String>,
    allowClear: Boolean,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var text by remember { mutableStateOf(current) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    suggestions.forEach { s ->
                        FilterChip(
                            selected = text == s,
                            onClick = { text = s },
                            label = { Text(s) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = UiGold,
                                selectedLabelColor = UiWoodDark
                            )
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("أو اكتب اسم المادة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(text) }, enabled = allowClear || text.isNotBlank()) {
                Text("حفظ", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Row {
                if (allowClear && current.isNotBlank()) {
                    TextButton(onClick = { onSave("") }) { Text("مسح", color = Color(0xFFB3261E)) }
                }
                TextButton(onClick = onDismiss) { Text("إلغاء") }
            }
        }
    )
}
