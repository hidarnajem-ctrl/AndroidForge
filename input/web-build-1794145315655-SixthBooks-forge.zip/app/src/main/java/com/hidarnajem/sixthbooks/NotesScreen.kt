package com.hidarnajem.sixthbooks

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Instant
import java.time.ZoneId

private val NOTE_MARGIN = Color(0xFFE57373)
private val LINE_HEIGHT = 32.sp

private fun formatDate(millis: Long): String {
    val d = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate()
    return "${arabicDayName(d)} ${d.dayOfMonth}/${d.monthValue}/${d.year}"
}

/** يرسم سطور الدفتر والهامش الأحمر خلف المحتوى */
private fun Modifier.notebookLines(lineHeightPx: Float, topPx: Float): Modifier = drawBehind {
    var y = topPx + lineHeightPx
    while (y < size.height) {
        drawLine(UiPaperLine, Offset(0f, y), Offset(size.width, y), strokeWidth = 2f)
        y += lineHeightPx
    }
    // الهامش على الجهة اليمنى (بداية السطر بالعربية)
    val x = size.width - 28.dp.toPx()
    drawLine(NOTE_MARGIN, Offset(x, 0f), Offset(x, size.height), strokeWidth = 3f)
}

@Composable
fun NotesScreen(store: ToolsStore) {
    // null = قائمة الملاحظات، -1 = ملاحظة جديدة، غير ذلك = تعديل ملاحظة
    var openId by rememberSaveable { mutableStateOf<Long?>(null) }

    val id = openId
    if (id != null) {
        NoteEditor(
            note = store.notes.firstOrNull { it.id == id },
            store = store,
            onClose = { openId = null }
        )
        return
    }

    Box(Modifier.fillMaxSize()) {
        if (store.notes.isEmpty()) {
            FeltBoard(
                Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "دفتر ملاحظاتك فارغ",
                        style = TextStyle(color = UiChalk, fontSize = 20.sp, fontWeight = FontWeight.Bold, shadow = UiTextShadow)
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "اكتب الواجبات وما تريد تذكّره من الدروس",
                        color = UiGold,
                        textAlign = TextAlign.Center,
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 90.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(store.notes, key = { it.id }) { note ->
                    NoteCard(note) { openId = note.id }
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = { openId = -1L },
            icon = { Icon(Icons.Default.Add, contentDescription = null) },
            text = { Text("ملاحظة جديدة", fontWeight = FontWeight.Bold) },
            containerColor = UiGoldDeep,
            contentColor = UiWoodDark,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        )
    }
}

@Composable
private fun NoteCard(note: Note, onClick: () -> Unit) {
    val density = LocalDensity.current
    val linePx = with(density) { 22.sp.toPx() }
    val topPx = with(density) { 36.dp.toPx() }
    PaperCard(
        Modifier
            .fillMaxWidth()
            .height(170.dp)
            .clickable(onClick = onClick)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .notebookLines(linePx, topPx)
                .padding(start = 10.dp, end = 36.dp, top = 10.dp, bottom = 8.dp)
        ) {
            Text(
                note.title.ifBlank { "بدون عنوان" },
                color = UiInk,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(4.dp))
            Text(
                note.body,
                color = UiInkMuted,
                fontSize = 13.sp,
                lineHeight = 22.sp,
                maxLines = 4,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Text(formatDate(note.updated), color = UiInkMuted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun NoteEditor(note: Note?, store: ToolsStore, onClose: () -> Unit) {
    var noteId by remember { mutableStateOf(note?.id) }
    var title by remember { mutableStateOf(note?.title ?: "") }
    var body by remember { mutableStateOf(note?.body ?: "") }
    var confirmDelete by remember { mutableStateOf(false) }

    fun save() {
        if (title.isBlank() && body.isBlank()) {
            noteId?.let { store.deleteNote(it) }
            noteId = null
        } else {
            noteId = store.saveNote(noteId, title, body)
        }
    }

    fun close() {
        save()
        onClose()
    }

    BackHandler { close() }

    val density = LocalDensity.current
    val linePx = with(density) { LINE_HEIGHT.toPx() }
    val topPx = with(density) { 64.dp.toPx() }

    Column(
        Modifier
            .fillMaxSize()
            .imePadding()
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { close() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "حفظ ورجوع", tint = UiGold)
            }
            Plaque(if (note == null && noteId == null) "ملاحظة جديدة" else "تعديل الملاحظة")
            Spacer(Modifier.weight(1f))
            if (noteId != null) {
                IconButton(onClick = { confirmDelete = true }) {
                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = UiGold)
                }
            }
        }
        Spacer(Modifier.height(6.dp))

        PaperCard(
            Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .notebookLines(linePx, topPx)
                    .padding(start = 14.dp, end = 40.dp, top = 14.dp, bottom = 14.dp)
            ) {
                BasicTextField(
                    value = title,
                    onValueChange = {
                        title = it
                        save()
                    },
                    singleLine = true,
                    textStyle = TextStyle(color = UiInk, fontSize = 20.sp, fontWeight = FontWeight.Bold),
                    cursorBrush = SolidColor(UiGoldDeep),
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { inner ->
                        if (title.isEmpty()) Text("العنوان", color = UiInkMuted, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        inner()
                    }
                )
                Spacer(Modifier.height(14.dp))
                BasicTextField(
                    value = body,
                    onValueChange = {
                        body = it
                        save()
                    },
                    textStyle = TextStyle(color = UiInk, fontSize = 17.sp, lineHeight = LINE_HEIGHT),
                    cursorBrush = SolidColor(UiGoldDeep),
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Transparent),
                    decorationBox = { inner ->
                        if (body.isEmpty()) {
                            Text("اكتب ملاحظتك هنا...", color = UiInkMuted, fontSize = 17.sp, lineHeight = LINE_HEIGHT)
                        }
                        inner()
                    }
                )
                Spacer(Modifier.height(200.dp))
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("حذف الملاحظة؟") },
            text = { Text("لا يمكن التراجع عن الحذف.") },
            confirmButton = {
                TextButton(onClick = {
                    noteId?.let { store.deleteNote(it) }
                    confirmDelete = false
                    onClose()
                }) { Text("حذف", color = Color(0xFFB3261E)) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("إلغاء") } }
        )
    }
}
