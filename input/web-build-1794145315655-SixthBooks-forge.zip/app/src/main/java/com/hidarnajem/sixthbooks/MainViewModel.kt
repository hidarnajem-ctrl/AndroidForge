package com.hidarnajem.sixthbooks

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = BookRepository(app)

    /** الجدول الأسبوعي والامتحانات والملاحظات (محفوظة على الجهاز فقط) */
    val tools = ToolsStore(app)

    var books by mutableStateOf<List<Book>>(emptyList())
        private set
    var loading by mutableStateOf(true)
        private set
    var failed by mutableStateOf(false)
        private set
    var downloaded by mutableStateOf<Set<String>>(emptySet())
        private set

    /** تقدّم التحميل (0..1) لكل كتاب قيد التحميل */
    val progress = mutableStateMapOf<String, Float>()

    var message by mutableStateOf<String?>(null)

    /** آخر كتاب اكتمل تحميله، ليفتحه التطبيق تلقائياً */
    var justDownloaded by mutableStateOf<String?>(null)

    /** الرفوف بنفس ترتيب ظهور الكتب في books.json */
    val shelves: List<Pair<String, List<Book>>>
        get() = books.groupBy { it.shelf }.toList()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            loading = true
            failed = false
            repo.loadBooks()
                .onSuccess {
                    books = it
                    downloaded = it.filter { b -> repo.isDownloaded(b) }.map { b -> b.fileName }.toSet()
                }
                .onFailure { failed = true }
            loading = false
        }
    }

    fun isDownloaded(book: Book) = book.fileName in downloaded

    fun isDownloading(book: Book) = progress.containsKey(book.fileName)

    fun download(book: Book) {
        val key = book.fileName
        if (progress.containsKey(key)) return
        progress[key] = 0f
        viewModelScope.launch {
            try {
                repo.download(book) { progress[key] = it }
                downloaded = downloaded + key
                justDownloaded = key
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = "تعذّر تحميل الكتاب، تأكد من اتصالك بالإنترنت وحاول مرة أخرى" +
                    (e.message?.let { "\n($it)" } ?: "")
            } finally {
                progress.remove(key)
            }
        }
    }

    fun file(book: Book): File = repo.localFile(book)
}
