import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    // اسم الحزمة: لا يمكن تغييره بعد أول نشر على Google Play
    namespace = "com.hidarnajem.sixthbooks"

    compileSdk = 36

    defaultConfig {
        // اسم حزمة التطبيق المنشور على Google Play («كتب صف سادس ابتدائي منهج عراقي»)
        applicationId = "com.saf.sadas"
        minSdk = 26
        targetSdk = 36
        // يجب أن يكون أكبر من آخر إصدار منشور، وزِده بواحد مع كل تحديث
        versionCode = 100
        versionName = "2.0"

        // معرّف تطبيق AdMob
        manifestPlaceholders["admobAppId"] = "ca-app-pub-1341061237626351~7822218579"
    }

    // مفتاح الرفع (Upload key) لتوقيع ملف النشر. بياناته في keystore.properties بجانب settings.gradle.kts
    val keystoreFile = rootProject.file("keystore.properties")
    val keystoreProps = Properties().apply {
        if (keystoreFile.exists()) keystoreFile.inputStream().use { load(it) }
    }
    signingConfigs {
        if (keystoreFile.exists()) {
            create("release") {
                storeFile = file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        release {
            if (keystoreFile.exists()) signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")

    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")

    implementation("com.google.android.gms:play-services-ads:23.6.0")
    implementation("com.google.android.play:review-ktx:2.0.1")

    debugImplementation("androidx.compose.ui:ui-tooling")
}

// عند اختيار release في Android Forge يُشغَّل assembleRelease (يبني APK فقط)،
// فنجعله يبني معه ملف AAB الموقّع في مكانه المعتاد: app/build/outputs/bundle/release/app-release.aab
tasks.matching { it.name == "assembleRelease" }.configureEach {
    dependsOn("bundleRelease")
}
