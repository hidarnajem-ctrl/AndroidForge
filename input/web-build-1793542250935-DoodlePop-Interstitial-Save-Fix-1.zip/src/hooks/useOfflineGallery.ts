import { useState, useEffect, useCallback, useRef } from 'react';
import { SavedArtwork } from '../types/drawing';

// Artwork images are large Base64 strings. localStorage is synchronous and has a
// small quota, so repeatedly serializing the whole gallery can freeze the WebView.
// IndexedDB is asynchronous and is designed for larger offline records.
const DB_NAME = 'doodlepop_gallery_db';
const DB_VERSION = 1;
const STORE_NAME = 'artworks';
const LEGACY_STORAGE_KEY = 'doodlepop_offline_artworks';
const MAX_ARTWORKS = 24;

type GalleryDatabase = {
  db: IDBDatabase;
  initialArtworks: SavedArtwork[];
};

let databasePromise: Promise<GalleryDatabase> | null = null;

function sortNewestFirst(items: SavedArtwork[]): SavedArtwork[] {
  return [...items].sort((a, b) => b.createdAt - a.createdAt).slice(0, MAX_ARTWORKS);
}

function openGalleryDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) {
      reject(new Error('IndexedDB is not available in this WebView'));
      return;
    }

    const request = window.indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Could not open drawing gallery'));
    request.onblocked = () => reject(new Error('Drawing gallery upgrade is blocked'));
  });
}

function transactionComplete(transaction: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error || new Error('Gallery transaction failed'));
    transaction.onabort = () => reject(transaction.error || new Error('Gallery transaction was aborted'));
  });
}

function requestResult<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Gallery request failed'));
  });
}

async function initializeGallery(): Promise<GalleryDatabase> {
  const db = await openGalleryDatabase();
  const readTransaction = db.transaction(STORE_NAME, 'readonly');
  const readDone = transactionComplete(readTransaction);
  const current = await requestResult(readTransaction.objectStore(STORE_NAME).getAll() as IDBRequest<SavedArtwork[]>);
  await readDone;

  if (current.length > 0) {
    // Remove the old synchronous copy once the IndexedDB copy is established.
    try { window.localStorage.removeItem(LEGACY_STORAGE_KEY); } catch { /* storage may be unavailable */ }
    return { db, initialArtworks: sortNewestFirst(current) };
  }

  // One-time migration for drawings saved by older versions of DoodlePop.
  let legacy: SavedArtwork[] = [];
  try {
    const raw = window.localStorage.getItem(LEGACY_STORAGE_KEY);
    if (raw) {
      const parsed: unknown = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        legacy = sortNewestFirst(parsed.filter((item): item is SavedArtwork =>
          !!item && typeof item.id === 'string' &&
          typeof item.title === 'string' && typeof item.createdAt === 'number' &&
          typeof item.dataUrl === 'string' && typeof item.backgroundColor === 'string'
        ));
      }
    }
  } catch {
    legacy = [];
  }

  if (legacy.length > 0) {
    const migration = db.transaction(STORE_NAME, 'readwrite');
    const done = transactionComplete(migration);
    const store = migration.objectStore(STORE_NAME);
    legacy.forEach((artwork) => store.put(artwork));
    await done;
    try { window.localStorage.removeItem(LEGACY_STORAGE_KEY); } catch { /* migration is already safe in IndexedDB */ }
  } else {
    // Drop an empty or malformed legacy value so it cannot keep consuming quota.
    try { window.localStorage.removeItem(LEGACY_STORAGE_KEY); } catch { /* storage may be unavailable */ }
  }

  return { db, initialArtworks: legacy };
}

function getDatabase(): Promise<GalleryDatabase> {
  if (!databasePromise) {
    databasePromise = initializeGallery().catch((error) => {
      // Let a later user action retry if IndexedDB was temporarily unavailable.
      databasePromise = null;
      throw error;
    });
  }
  return databasePromise;
}

async function persistArtwork(db: IDBDatabase, artwork: SavedArtwork): Promise<void> {
  const transaction = db.transaction(STORE_NAME, 'readwrite');
  const done = transactionComplete(transaction);
  const store = transaction.objectStore(STORE_NAME);
  store.put(artwork);
  const allRequest = store.getAll();
  allRequest.onsuccess = () => {
    const all = [...(allRequest.result as SavedArtwork[])].sort((a, b) => b.createdAt - a.createdAt);
    all.slice(MAX_ARTWORKS).forEach((oldArtwork) => store.delete(oldArtwork.id));
  };
  await done;
}

async function removeArtworkFromDatabase(db: IDBDatabase, id: string): Promise<void> {
  const transaction = db.transaction(STORE_NAME, 'readwrite');
  const done = transactionComplete(transaction);
  transaction.objectStore(STORE_NAME).delete(id);
  await done;
}

export function useOfflineGallery() {
  const [artworks, setArtworks] = useState<SavedArtwork[]>([]);
  const initializationRef = useRef<Promise<GalleryDatabase> | null>(null);
  const userChangedRef = useRef(false);
  const persistQueueRef = useRef<Promise<void>>(Promise.resolve());

  const ensureInitialized = useCallback(() => {
    if (!initializationRef.current) {
      initializationRef.current = getDatabase().catch((error) => {
        initializationRef.current = null;
        throw error;
      });
    }
    return initializationRef.current;
  }, []);

  useEffect(() => {
    let active = true;
    ensureInitialized()
      .then(({ initialArtworks }) => {
        if (active && !userChangedRef.current) setArtworks(initialArtworks);
      })
      .catch(() => {
        // The drawing app remains usable in memory even if browser storage is unavailable.
      });
    return () => { active = false; };
  }, [ensureInitialized]);

  const saveArtwork = useCallback((dataUrl: string, backgroundColor: string, customTitle?: string): SavedArtwork => {
    const newArtwork: SavedArtwork = {
      id: 'art_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      title: customTitle || `رسمتي #${artworks.length + 1}`,
      createdAt: Date.now(),
      dataUrl,
      backgroundColor,
    };

    userChangedRef.current = true;
    setArtworks((prev) => [newArtwork, ...prev].slice(0, MAX_ARTWORKS));
    persistQueueRef.current = persistQueueRef.current
      .then(() => ensureInitialized())
      .then(({ db }) => persistArtwork(db, newArtwork))
      .catch(() => {
        // Keep the just-saved drawing in the native Pictures/DoodlePop folder;
        // a temporary gallery database failure must not block drawing or saving.
      });

    return newArtwork;
  }, [artworks.length, ensureInitialized]);

  const deleteArtwork = useCallback((id: string) => {
    userChangedRef.current = true;
    setArtworks((prev) => prev.filter((item) => item.id !== id));
    persistQueueRef.current = persistQueueRef.current
      .then(() => ensureInitialized())
      .then(({ db }) => removeArtworkFromDatabase(db, id))
      .catch(() => {
        // The UI deletion still takes effect for this session if storage is unavailable.
      });
  }, [ensureInitialized]);

  return { artworks, saveArtwork, deleteArtwork };
}
