/** Clean, offline vector line-art for the coloring pages. Each independent detail
 * gets its own path so Canvas never draws accidental lines between circles. */
export function drawColoringTemplate(
  templateId: string,
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number
) {
  ctx.save();
  ctx.strokeStyle = '#1E293B';
  ctx.fillStyle = '#FFFFFF';
  ctx.lineWidth = Math.max(3, Math.min(width, height) * 0.0075);
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  const cx = width / 2;
  const cy = height / 2;
  const r = Math.min(width, height) * 0.29;
  const path = (draw: () => void) => { ctx.beginPath(); draw(); ctx.stroke(); };
  const circle = (x: number, y: number, radius: number, fill = false) => {
    ctx.beginPath(); ctx.arc(x, y, radius, 0, Math.PI * 2);
    if (fill) ctx.fill(); else ctx.stroke();
  };
  const ellipse = (x: number, y: number, rx: number, ry: number, fill = false) => {
    ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
    if (fill) ctx.fill(); else ctx.stroke();
  };

  switch (templateId) {
    case 'dino': {
      // One simple, closed dinosaur silhouette with separate facial details.
      path(() => {
        ctx.moveTo(cx-r*.82,cy+r*.72); ctx.lineTo(cx-r*.72,cy+r*.12);
        ctx.quadraticCurveTo(cx-r*.76,cy-r*.18,cx-r*.43,cy-r*.36);
        ctx.quadraticCurveTo(cx-r*.34,cy-r*.9,cx+r*.1,cy-r*.88);
        ctx.quadraticCurveTo(cx+r*.42,cy-r*.86,cx+r*.43,cy-r*.53);
        ctx.lineTo(cx+r*.86,cy-r*.37); ctx.quadraticCurveTo(cx+r*1.02,cy-r*.31,cx+r*.91,cy-r*.15);
        ctx.quadraticCurveTo(cx+r*.84,cy-r*.06,cx+r*.64,cy-r*.1);
        ctx.lineTo(cx+r*.35,cy-r*.17); ctx.quadraticCurveTo(cx+r*.22,cy+r*.08,cx+r*.43,cy+r*.28);
        ctx.quadraticCurveTo(cx+r*.62,cy+r*.48,cx+r*.9,cy+r*.55);
        ctx.quadraticCurveTo(cx+r*.55,cy+r*.7,cx+r*.08,cy+r*.55);
        ctx.lineTo(cx+r*.08,cy+r*.8); ctx.lineTo(cx-r*.13,cy+r*.8); ctx.lineTo(cx-r*.2,cy+r*.49);
        ctx.quadraticCurveTo(cx-r*.36,cy+r*.62,cx-r*.49,cy+r*.8); ctx.lineTo(cx-r*.82,cy+r*.8); ctx.closePath();
      });
      circle(cx+r*.28,cy-r*.55,r*.07); circle(cx+r*.3,cy-r*.55,r*.025,true);
      path(()=>{ctx.moveTo(cx+r*.55,cy-r*.23);ctx.quadraticCurveTo(cx+r*.68,cy-r*.18,cx+r*.8,cy-r*.22);});
      // Back spikes are separate triangles and do not cross the body.
      [[-.54,-.37],[-.62,-.14],[-.65,.08]].forEach(([x,y])=>path(()=>{ctx.moveTo(cx+r*x,cy+r*y);ctx.lineTo(cx+r*(x-.15),cy+r*(y-.13));ctx.lineTo(cx+r*(x-.04),cy+r*(y+.08));}));
      path(()=>{ctx.moveTo(cx-r*.42,cy+r*.35);ctx.quadraticCurveTo(cx-r*.2,cy+r*.43,cx+r*.02,cy+r*.37);});
      break;
    }
    case 'rocket': {
      path(()=>{ctx.moveTo(cx,cy-r*1.12);ctx.quadraticCurveTo(cx+r*.62,cy-r*.52,cx+r*.42,cy+r*.48);ctx.lineTo(cx-r*.42,cy+r*.48);ctx.quadraticCurveTo(cx-r*.62,cy-r*.52,cx,cy-r*1.12);ctx.closePath();});
      path(()=>{ctx.moveTo(cx-r*.28,cy-r*.53);ctx.quadraticCurveTo(cx,cy-r*.68,cx+r*.28,cy-r*.53);});
      circle(cx,cy-r*.12,r*.19); circle(cx,cy-r*.12,r*.1);
      path(()=>{ctx.moveTo(cx-r*.4,cy+r*.15);ctx.quadraticCurveTo(cx-r*.82,cy+r*.4,cx-r*.62,cy+r*.68);ctx.lineTo(cx-r*.3,cy+r*.47);});
      path(()=>{ctx.moveTo(cx+r*.4,cy+r*.15);ctx.quadraticCurveTo(cx+r*.82,cy+r*.4,cx+r*.62,cy+r*.68);ctx.lineTo(cx+r*.3,cy+r*.47);});
      path(()=>{ctx.moveTo(cx-r*.19,cy+r*.49);ctx.lineTo(cx-r*.22,cy+r*.77);ctx.lineTo(cx,cy+r*1.02);ctx.lineTo(cx+r*.22,cy+r*.77);ctx.lineTo(cx+r*.19,cy+r*.49);});
      break;
    }
    case 'puppy': {
      // Round puppy head, separate floppy ears, eyes and muzzle.
      path(()=>{ctx.arc(cx,cy,r*.72,0,Math.PI*2);});
      path(()=>{ctx.moveTo(cx-r*.48,cy-r*.38);ctx.bezierCurveTo(cx-r*.98,cy-r*.55,cx-r*1.02,cy+r*.38,cx-r*.55,cy+r*.3);});
      path(()=>{ctx.moveTo(cx+r*.48,cy-r*.38);ctx.bezierCurveTo(cx+r*.98,cy-r*.55,cx+r*1.02,cy+r*.38,cx+r*.55,cy+r*.3);});
      circle(cx-r*.25,cy-r*.12,r*.07); circle(cx+r*.25,cy-r*.12,r*.07);
      circle(cx-r*.25,cy-r*.12,r*.025,true); circle(cx+r*.25,cy-r*.12,r*.025,true);
      ellipse(cx,cy+r*.13,r*.18,r*.12,true);
      path(()=>{ctx.moveTo(cx,cy+r*.23);ctx.lineTo(cx,cy+r*.39);ctx.quadraticCurveTo(cx-r*.16,cy+r*.53,cx-r*.25,cy+r*.38);});
      path(()=>{ctx.moveTo(cx,cy+r*.39);ctx.quadraticCurveTo(cx+r*.16,cy+r*.53,cx+r*.25,cy+r*.38);});
      path(()=>{ctx.arc(cx,cy+r*.45,r*.12,0,Math.PI);});
      break;
    }
    case 'butterfly': {
      // Each wing is a closed outline. Decorative circles are separate paths.
      path(()=>{ctx.moveTo(cx-r*.08,cy-r*.12);ctx.bezierCurveTo(cx-r*.28,cy-r*.78,cx-r*1.02,cy-r*.86,cx-r*.9,cy-r*.25);ctx.bezierCurveTo(cx-r*.86,cy-r*.02,cx-r*.48,cy+r*.02,cx-r*.08,cy+r*.06);ctx.closePath();});
      path(()=>{ctx.moveTo(cx+r*.08,cy-r*.12);ctx.bezierCurveTo(cx+r*.28,cy-r*.78,cx+r*1.02,cy-r*.86,cx+r*.9,cy-r*.25);ctx.bezierCurveTo(cx+r*.86,cy-r*.02,cx+r*.48,cy+r*.02,cx+r*.08,cy+r*.06);ctx.closePath();});
      path(()=>{ctx.moveTo(cx-r*.08,cy+r*.08);ctx.bezierCurveTo(cx-r*.55,cy+r*.02,cx-r*.88,cy+r*.38,cx-r*.68,cy+r*.68);ctx.bezierCurveTo(cx-r*.5,cy+r*.92,cx-r*.18,cy+r*.56,cx-r*.08,cy+r*.28);ctx.closePath();});
      path(()=>{ctx.moveTo(cx+r*.08,cy+r*.08);ctx.bezierCurveTo(cx+r*.55,cy+r*.02,cx+r*.88,cy+r*.38,cx+r*.68,cy+r*.68);ctx.bezierCurveTo(cx+r*.5,cy+r*.92,cx+r*.18,cy+r*.56,cx+r*.08,cy+r*.28);ctx.closePath();});
      ellipse(cx,cy+r*.05,r*.075,r*.42);
      circle(cx,cy-r*.43,r*.105);
      path(()=>{ctx.moveTo(cx-r*.04,cy-r*.5);ctx.quadraticCurveTo(cx-r*.25,cy-r*.82,cx-r*.33,cy-r*.72);});
      path(()=>{ctx.moveTo(cx+r*.04,cy-r*.5);ctx.quadraticCurveTo(cx+r*.25,cy-r*.82,cx+r*.33,cy-r*.72);});
      circle(cx-r*.53,cy-r*.33,r*.11); circle(cx+r*.53,cy-r*.33,r*.11);
      circle(cx-r*.45,cy+r*.42,r*.08); circle(cx+r*.45,cy+r*.42,r*.08);
      break;
    }
    case 'robot': {
      path(()=>{ctx.roundRect(cx-r*.47,cy-r*.82,r*.94,r*.64,r*.12);});
      path(()=>{ctx.moveTo(cx,cy-r*.82);ctx.lineTo(cx,cy-r*1.02);}); circle(cx,cy-r*1.08,r*.07);
      circle(cx-r*.2,cy-r*.56,r*.095); circle(cx+r*.2,cy-r*.56,r*.095);
      path(()=>{ctx.roundRect(cx-r*.22,cy-r*.38,r*.44,r*.09,r*.035);});
      path(()=>{ctx.moveTo(cx-r*.12,cy-r*.18);ctx.lineTo(cx-r*.12,cy-r*.08);ctx.lineTo(cx+r*.12,cy-r*.08);ctx.lineTo(cx+r*.12,cy-r*.18);});
      path(()=>{ctx.roundRect(cx-r*.58,cy-r*.08,r*1.16,r*.78,r*.14);});
      path(()=>{ctx.roundRect(cx-r*.34,cy+r*.08,r*.68,r*.34,r*.07);});
      circle(cx-r*.17,cy+r*.25,r*.055); circle(cx,cy+r*.25,r*.055); circle(cx+r*.17,cy+r*.25,r*.055);
      path(()=>{ctx.moveTo(cx-r*.58,cy+r*.04);ctx.lineTo(cx-r*.84,cy+r*.28);}); circle(cx-r*.89,cy+r*.32,r*.07);
      path(()=>{ctx.moveTo(cx+r*.58,cy+r*.04);ctx.lineTo(cx+r*.84,cy+r*.28);}); circle(cx+r*.89,cy+r*.32,r*.07);
      break;
    }
    case 'flower': {
      // Petals each use their own path to avoid lines connecting the circles.
      const fx=cx, fy=cy-r*.28, pr=r*.2, spread=r*.42;
      for(let i=0;i<8;i++){const a=i*Math.PI/4;circle(fx+Math.cos(a)*spread,fy+Math.sin(a)*spread,pr);}
      circle(fx,fy,r*.23);
      path(()=>{ctx.moveTo(cx,cy+r*.03);ctx.quadraticCurveTo(cx-r*.12,cy+r*.5,cx,cy+r*1.02);});
      path(()=>{ctx.moveTo(cx-r*.04,cy+r*.48);ctx.quadraticCurveTo(cx-r*.58,cy+r*.24,cx-r*.58,cy+r*.52);ctx.quadraticCurveTo(cx-r*.34,cy+r*.72,cx-r*.04,cy+r*.55);});
      path(()=>{ctx.moveTo(cx+r*.02,cy+r*.65);ctx.quadraticCurveTo(cx+r*.5,cy+r*.4,cx+r*.55,cy+r*.68);ctx.quadraticCurveTo(cx+r*.3,cy+r*.83,cx+r*.02,cy+r*.65);});
      break;
    }
    case 'cat': {
      // Cat face with triangular ears kept outside the face outline.
      path(()=>{ctx.moveTo(cx-r*.58,cy-r*.28);ctx.lineTo(cx-r*.68,cy-r*.83);ctx.lineTo(cx-r*.2,cy-r*.58);ctx.quadraticCurveTo(cx,cy-r*.68,cx+r*.2,cy-r*.58);ctx.lineTo(cx+r*.68,cy-r*.83);ctx.lineTo(cx+r*.58,cy-r*.28);ctx.arc(cx,cy+r*.02,r*.62,-.2,Math.PI+0.2);ctx.closePath();});
      circle(cx-r*.23,cy-r*.12,r*.06); circle(cx+r*.23,cy-r*.12,r*.06);
      path(()=>{ctx.moveTo(cx,cy+r*.03);ctx.lineTo(cx-r*.07,cy+r*.12);ctx.lineTo(cx+r*.07,cy+r*.12);ctx.closePath();});
      path(()=>{ctx.moveTo(cx,cy+r*.12);ctx.quadraticCurveTo(cx-r*.1,cy+r*.28,cx-r*.22,cy+r*.18);});
      path(()=>{ctx.moveTo(cx,cy+r*.12);ctx.quadraticCurveTo(cx+r*.1,cy+r*.28,cx+r*.22,cy+r*.18);});
      [-1,1].forEach(side=>{path(()=>{ctx.moveTo(cx+side*r*.2,cy+r*.1);ctx.lineTo(cx+side*r*.52,cy+r*.04);});path(()=>{ctx.moveTo(cx+side*r*.2,cy+r*.2);ctx.lineTo(cx+side*r*.52,cy+r*.25);});});
      break;
    }
    case 'fish': {
      path(()=>{ctx.ellipse(cx-r*.1,cy,r*.67,r*.43,0,0,Math.PI*2);});
      path(()=>{ctx.moveTo(cx+r*.5,cy);ctx.lineTo(cx+r*.98,cy-r*.35);ctx.lineTo(cx+r*.98,cy+r*.35);ctx.closePath();});
      circle(cx-r*.38,cy-r*.1,r*.07); circle(cx-r*.38,cy-r*.1,r*.025,true);
      path(()=>{ctx.arc(cx-r*.56,cy+r*.04,r*.1,-.2,Math.PI*.65);});
      path(()=>{ctx.moveTo(cx-r*.05,cy-r*.4);ctx.quadraticCurveTo(cx+r*.08,cy-r*.12,cx-r*.05,cy);});
      path(()=>{ctx.moveTo(cx-r*.05,cy);ctx.quadraticCurveTo(cx+r*.1,cy+r*.18,cx-r*.05,cy+r*.4);});
      circle(cx+r*.18,cy-r*.18,r*.09);
      break;
    }
    case 'apple': {
      path(()=>{ctx.moveTo(cx,cy-r*.55);ctx.bezierCurveTo(cx-r*.55,cy-r*.9,cx-r*.95,cy-r*.35,cx-r*.78,cy+r*.18);ctx.bezierCurveTo(cx-r*.65,cy+r*.7,cx-r*.22,cy+r*.84,cx,cy+r*.64);ctx.bezierCurveTo(cx+r*.22,cy+r*.84,cx+r*.65,cy+r*.7,cx+r*.78,cy+r*.18);ctx.bezierCurveTo(cx+r*.95,cy-r*.35,cx+r*.55,cy-r*.9,cx,cy-r*.55);ctx.closePath();});
      path(()=>{ctx.moveTo(cx,cy-r*.53);ctx.quadraticCurveTo(cx-r*.05,cy-r*.78,cx+r*.05,cy-r*.92);});
      path(()=>{ctx.moveTo(cx+r*.04,cy-r*.72);ctx.quadraticCurveTo(cx+r*.42,cy-r*.9,cx+r*.48,cy-r*.63);ctx.quadraticCurveTo(cx+r*.25,cy-r*.5,cx+r*.04,cy-r*.72);});
      break;
    }
    case 'house': {
      path(()=>{ctx.moveTo(cx-r*.82,cy-r*.1);ctx.lineTo(cx,cy-r*.8);ctx.lineTo(cx+r*.82,cy-r*.1);});
      path(()=>{ctx.rect(cx-r*.62,cy-r*.1,r*1.24,r*.95);});
      path(()=>{ctx.rect(cx-r*.16,cy+r*.34,r*.32,r*.51);});
      path(()=>{ctx.rect(cx-r*.46,cy+r*.02,r*.22,r*.22);});
      path(()=>{ctx.rect(cx+r*.24,cy+r*.02,r*.22,r*.22);});
      break;
    }
    case 'car': {
      path(()=>{ctx.moveTo(cx-r*.88,cy+r*.25);ctx.lineTo(cx-r*.75,cy-r*.05);ctx.lineTo(cx-r*.35,cy-r*.12);ctx.lineTo(cx-r*.08,cy-r*.48);ctx.lineTo(cx+r*.42,cy-r*.48);ctx.lineTo(cx+r*.72,cy-r*.08);ctx.lineTo(cx+r*.86,cy+r*.02);ctx.lineTo(cx+r*.88,cy+r*.3);ctx.lineTo(cx-r*.88,cy+r*.3);ctx.closePath();});
      path(()=>{ctx.moveTo(cx-r*.22,cy-r*.1);ctx.lineTo(cx-r*.05,cy-r*.37);ctx.lineTo(cx+r*.32,cy-r*.37);ctx.lineTo(cx+r*.53,cy-r*.08);});
      circle(cx-r*.5,cy+r*.32,r*.16); circle(cx+r*.5,cy+r*.32,r*.16);
      break;
    }
    case 'rainbow': {
      for(let i=0;i<5;i++){
        const rr=r*(1.0-i*.13);
        path(()=>{ctx.arc(cx,cy+r*.38,rr,Math.PI,Math.PI*2);});
      }
      path(()=>{ctx.moveTo(cx-r,cy+r*.38);ctx.lineTo(cx-r,cy+r*.55);ctx.lineTo(cx+r,cy+r*.55);ctx.lineTo(cx+r,cy+r*.38);});
      // Friendly clouds at both ends.
      path(()=>{ctx.moveTo(cx-r*1.05,cy+r*.36);ctx.arc(cx-r*.93,cy+r*.27,r*.14,Math.PI*.5,Math.PI*1.5);ctx.arc(cx-r*.76,cy+r*.2,r*.18,Math.PI,Math.PI*1.9);ctx.arc(cx-r*.6,cy+r*.29,r*.13,Math.PI*1.3,Math.PI*2);ctx.lineTo(cx-r*.5,cy+r*.4);});
      path(()=>{ctx.moveTo(cx+r*.5,cy+r*.4);ctx.arc(cx+r*.6,cy+r*.29,r*.13,Math.PI,Math.PI*1.7);ctx.arc(cx+r*.77,cy+r*.2,r*.18,Math.PI*1.1,Math.PI*2);ctx.arc(cx+r*.93,cy+r*.27,r*.14,Math.PI*1.5,Math.PI*.5);});
      break;
    }
    default: {
      // Safe fallback: a simple smiling sun.
      circle(cx,cy,r*.43);
      circle(cx-r*.16,cy-r*.08,r*.045); circle(cx+r*.16,cy-r*.08,r*.045);
      path(()=>{ctx.arc(cx,cy+r*.02,r*.2,0,Math.PI);});
      for(let i=0;i<8;i++){const a=i*Math.PI/4;path(()=>{ctx.moveTo(cx+Math.cos(a)*r*.56,cy+Math.sin(a)*r*.56);ctx.lineTo(cx+Math.cos(a)*r*.75,cy+Math.sin(a)*r*.75);});}
    }
  }
  ctx.restore();
}
