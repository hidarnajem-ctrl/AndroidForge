
(()=>{
const $=id=>document.getElementById(id);
/* ---------- languages ---------- */
const LANGS=['en','ar','es','pt','id','tr','ru','fr'];
const LANG_NAMES={en:'English',ar:'العربية',es:'Español',pt:'Português (Brasil)',id:'Bahasa Indonesia',tr:'Türkçe',ru:'Русский',fr:'Français'};
const LOCALE={en:'en-US',ar:'ar-EG',es:'es-ES',pt:'pt-BR',id:'id-ID',tr:'tr-TR',ru:'ru-RU',fr:'fr-FR'};
const TX={"brand":["Arrow Exit","مَخرَج","Arrow Exit","Arrow Exit","Arrow Exit","Arrow Exit","Arrow Exit","Arrow Exit"],"tagline":["Get every arrow off the board, in the right order.","أخرِج كل سهم من اللوحة، بالترتيب الصحيح.","Saca cada flecha del tablero, en el orden correcto.","Tire cada seta do tabuleiro, na ordem certa.","Keluarkan setiap panah dari papan, dengan urutan yang tepat.","Her oku tahtadan doğru sırayla çıkar.","Выведи каждую стрелку с поля в правильном порядке.","Fais sortir chaque flèche du plateau, dans le bon ordre."],"play":["Play","العب","Jugar","Jogar","Main","Oyna","Играть","Jouer"],"levelN":["Level {n}","المرحلة {n}","Nivel {n}","Fase {n}","Level {n}","Bölüm {n}","Уровень {n}","Niveau {n}"],"level":["Level","المرحلة","Nivel","Fase","Level","Bölüm","Уровень","Niveau"],"daily":["Daily challenge","تحدّي اليوم","Reto diario","Desafio diário","Tantangan harian","Günlük görev","Задание дня","Défi du jour"],"dailyNew":["New","جديد","Nuevo","Novo","Baru","Yeni","Новое","Nouveau"],"dailyDone":["Done ✓","أُنجز ✓","Hecho ✓","Feito ✓","Selesai ✓","Tamam ✓","Готово ✓","Fait ✓"],"levels":["Levels","المراحل","Niveles","Fases","Level","Bölümler","Уровни","Niveaux"],"settings":["Settings","الإعدادات","Ajustes","Configurações","Pengaturan","Ayarlar","Настройки","Réglages"],"achievements":["Achievements","الإنجازات","Logros","Conquistas","Pencapaian","Başarımlar","Достижения","Succès"],"leaderboards":["Leaderboards","الصدارة","Clasificación","Placar","Peringkat","Sıralama","Рейтинг","Classement"],"lbTitle":["Leaderboards","لوحات الصدارة","Clasificaciones","Placares","Papan peringkat","Sıralamalar","Таблицы рекордов","Classements"],"stars":["Stars","النجوم","Estrellas","Estrelas","Bintang","Yıldız","Звёзды","Étoiles"],"streak":["Day streak","سلسلة الأيام","Racha","Sequência","Beruntun","Seri","Серия дней","Série"],"chipLocal":["Play Games · saved on device","Play Games · حفظ محلي","Play Games · guardado local","Play Games · salvo no aparelho","Play Games · disimpan di perangkat","Play Games · cihazda kayıtlı","Play Games · сохранено на устройстве","Play Games · sauvegarde locale"],"back":["Back","رجوع","Atrás","Voltar","Kembali","Geri","Назад","Retour"],"legTimed":["Timed level","مرحلة موقوتة","Nivel contrarreloj","Fase cronometrada","Level berwaktu","Süreli bölüm","Уровень на время","Niveau chronométré"],"legShape":["Special board shape","لوحة بشكل خاص","Tablero con forma","Tabuleiro com formato","Papan berbentuk khusus","Özel şekilli tahta","Поле особой формы","Plateau en forme"],"lbNote":["These are your best scores. In the Android version they're sent to Google Play Games and you'll see your rank among all players.","هذه أفضل نتائجك. في نسخة أندرويد تُرسل إلى خدمات ألعاب Play ويظهر ترتيبك بين كل اللاعبين.","Estas son tus mejores marcas. En la versión de Android se envían a Google Play Juegos y verás tu posición entre todos los jugadores.","Estes são seus melhores resultados. Na versão Android, eles são enviados ao Google Play Games e você verá sua posição entre todos os jogadores.","Ini skor terbaikmu. Di versi Android, skor dikirim ke Google Play Games dan kamu akan melihat peringkatmu di antara semua pemain.","Bunlar en iyi skorların. Android sürümünde Google Play Games'e gönderilir ve tüm oyuncular arasındaki sıranı görürsün.","Это твои лучшие результаты. В версии для Android они отправляются в Google Play Игры, и ты увидишь своё место среди всех игроков.","Voici tes meilleurs scores. Dans la version Android, ils sont envoyés à Google Play Jeux et tu verras ton classement parmi tous les joueurs."],"home":["Home","الرئيسية","Inicio","Início","Beranda","Ana sayfa","Главная","Accueil"],"lives":["Lives","المحاولات","Vidas","Vidas","Nyawa","Can","Жизни","Vies"],"board":["Game board","لوحة اللعب","Tablero","Tabuleiro","Papan permainan","Oyun tahtası","Игровое поле","Plateau de jeu"],"restart":["Restart","إعادة","Reiniciar","Reiniciar","Ulangi","Yeniden","Заново","Rejouer"],"paths":["Paths","المسارات","Rutas","Rotas","Jalur","Yollar","Пути","Chemins"],"hint":["Hint","تلميح","Pista","Dica","Petunjuk","İpucu","Подсказка","Indice"],"ad":["Ad","إعلان","Anuncio","Anúncio","Iklan","Reklam","Реклама","Pub"],"bannerSlot":["Banner ad space","مساحة إعلان البانر","Espacio de banner","Espaço do banner","Ruang iklan banner","Banner reklam alanı","Место для баннера","Emplacement bannière"],"gotIt":["Got it","فهمت","Entendido","Entendi","Mengerti","Anladım","Понятно","Compris"],"theme":["Color theme","سمة الألوان","Tema de color","Tema de cores","Tema warna","Renk teması","Цветовая тема","Thème de couleurs"],"fog":["Mist","ضباب","Niebla","Névoa","Kabut","Sis","Туман","Brume"],"mint":["Mint","نعناع","Menta","Menta","Mint","Nane","Мята","Menthe"],"dusk":["Dusk","غروب","Ocaso","Crepúsculo","Senja","Gün batımı","Закат","Crépuscule"],"arrowColors":["Arrow colors","ألوان الأسهم","Color de flechas","Cor das setas","Warna panah","Ok renkleri","Цвет стрелок","Couleur des flèches"],"colorful":["Colorful","ملوّنة","Colores","Coloridas","Berwarna","Renkli","Цветные","Colorées"],"single":["One color","لون واحد","Un color","Uma cor","Satu warna","Tek renk","Один цвет","Une couleur"],"sound":["Sound","الصوت","Sonido","Som","Suara","Ses","Звук","Son"],"vib":["Vibration","الاهتزاز","Vibración","Vibração","Getar","Titreşim","Вибрация","Vibration"],"on":["On","مفعّل","Sí","Ligado","Aktif","Açık","Вкл.","Activé"],"muted":["Muted","صامت","Silencio","Mudo","Senyap","Sessiz","Выкл.","Coupé"],"off":["Off","متوقف","No","Desligado","Mati","Kapalı","Выкл.","Désactivé"],"language":["Language","اللغة","Idioma","Idioma","Bahasa","Dil","Язык","Langue"],"done":["Done","تم","Listo","Pronto","Selesai","Tamam","Готово","OK"],"testAd":["Test ad","إعلان تجريبي","Anuncio de prueba","Anúncio de teste","Iklan uji","Test reklamı","Тестовая реклама","Pub de test"],"rewardedAd":["Rewarded ad","إعلان بمكافأة","Anuncio con recompensa","Anúncio premiado","Iklan berhadiah","Ödüllü reklam","Реклама с наградой","Pub récompensée"],"rewardedSub":["A real video ad plays here in the Android version","في نسخة أندرويد يظهر هنا إعلان فيديو حقيقي","En la versión de Android aquí se muestra un anuncio de video real","Na versão Android, aqui aparece um anúncio em vídeo real","Di versi Android, iklan video asli muncul di sini","Android sürümünde burada gerçek bir video reklam oynar","В версии для Android здесь показывается настоящее видео","Dans la version Android, une vraie pub vidéo s'affiche ici"],"claim":["Get reward","احصل على المكافأة","Obtener recompensa","Pegar recompensa","Ambil hadiah","Ödülü al","Получить награду","Obtenir la récompense"],"closeNoReward":["Close without reward","إغلاق دون مكافأة","Cerrar sin recompensa","Fechar sem recompensa","Tutup tanpa hadiah","Ödülsüz kapat","Закрыть без награды","Fermer sans récompense"],"interAd":["Interstitial ad","إعلان بيني","Anuncio intersticial","Anúncio intersticial","Iklan interstisial","Geçiş reklamı","Межстраничная реклама","Pub interstitielle"],"interSub":["Shown after every two levels","يظهر بعد كل مرحلتين","Aparece cada dos niveles","Aparece a cada duas fases","Muncul setiap dua level","Her iki bölümde bir çıkar","Показывается каждые два уровня","Apparaît tous les deux niveaux"],"close":["✕ Close","✕ إغلاق","✕ Cerrar","✕ Fechar","✕ Tutup","✕ Kapat","✕ Закрыть","✕ Fermer"],"newAch":["New achievement","إنجاز جديد","Nuevo logro","Nova conquista","Pencapaian baru","Yeni başarım","Новое достижение","Nouveau succès"],"achOf":["{a} of {b}","{a} من {b}","{a} de {b}","{a} de {b}","{a} dari {b}","{a}/{b}","{a} из {b}","{a} sur {b}"],"yourBest":["Your best","أفضل نتيجة لك","Tu mejor marca","Seu melhor","Terbaikmu","En iyin","Твой рекорд","Ton record"],"days":["{n} days","{n} يوم","{n} días","{n} dias","{n} hari","{n} gün","Дней: {n}","{n} jours"],"lbStars":["Total stars","مجموع النجوم","Estrellas totales","Total de estrelas","Total bintang","Toplam yıldız","Всего звёзд","Total d'étoiles"],"lbLevels":["Levels completed","المراحل المكتملة","Niveles completados","Fases concluídas","Level selesai","Tamamlanan bölüm","Пройдено уровней","Niveaux terminés"],"lbStreak":["Longest day streak","أطول سلسلة أيام","Racha más larga","Maior sequência","Beruntun terpanjang","En uzun seri","Самая длинная серия","Plus longue série"],"lbDaily":["Fastest daily challenge","أسرع تحدٍّ يومي","Reto diario más rápido","Desafio diário mais rápido","Tantangan harian tercepat","En hızlı günlük görev","Быстрейшее задание дня","Défi du jour le plus rapide"],"left":["Arrows left: {n}","بقي {n} سهماً","Flechas restantes: {n}","Setas restantes: {n}","Sisa panah: {n}","Kalan ok: {n}","Осталось стрелок: {n}","Flèches restantes : {n}"],"time":["Time {t}","الوقت {t}","Tiempo {t}","Tempo {t}","Waktu {t}","Süre {t}","Время {t}","Temps {t}"],"mistakes":["Mistakes: {n}","الأخطاء: {n}","Errores: {n}","Erros: {n}","Kesalahan: {n}","Hata: {n}","Ошибки: {n}","Erreurs : {n}"],"lockT":["Locked arrow","سهم مقفل","Flecha bloqueada","Seta trancada","Panah terkunci","Kilitli ok","Запертая стрелка","Flèche verrouillée"],"lockD":["It stays locked until you clear the number of arrows shown on it. Tapping it while locked won't cost a life.","يبقى مقفلاً حتى تُخرج عدد الأسهم المكتوب عليه. لمسه وهو مقفل لا يكلّفك قلباً.","Sigue bloqueada hasta que saques el número de flechas que indica. Tocarla bloqueada no cuesta vidas.","Fica trancada até você tirar o número de setas indicado nela. Tocar nela trancada não custa vida.","Tetap terkunci sampai kamu mengeluarkan jumlah panah yang tertulis. Menyentuhnya saat terkunci tidak mengurangi nyawa.","Üzerindeki sayı kadar ok çıkarana kadar kilitli kalır. Kilitliyken dokunmak can kaybettirmez.","Она заперта, пока ты не уберёшь указанное на ней число стрелок. Нажатие на запертую стрелку не отнимает жизнь.","Elle reste verrouillée jusqu'à ce que tu sortes le nombre de flèches indiqué. La toucher verrouillée ne coûte pas de vie."],"twoT":["Two-way arrow","سهم باتجاهين","Flecha doble","Seta dupla","Panah dua arah","Çift yönlü ok","Двусторонняя стрелка","Flèche double"],"twoD":["It has two heads and leaves from whichever end is clear.","له رأسان، ويخرج من أي طرف يكون طريقه مفتوحاً.","Tiene dos puntas y sale por el extremo que esté libre.","Tem duas pontas e sai pelo lado que estiver livre.","Punya dua kepala dan keluar dari ujung yang jalannya terbuka.","İki ucu vardır, yolu açık olan uçtan çıkar.","У неё два наконечника, она уходит через свободный конец.","Elle a deux pointes et sort par le côté libre."],"iceT":["Frozen arrow","سهم مجمّد","Flecha congelada","Seta congelada","Panah beku","Donmuş ok","Замёрзшая стрелка","Flèche gelée"],"iceD":["The first tap cracks the ice, the second one moves it.","اللمسة الأولى تكسر الجليد، والثانية تحرّكه.","El primer toque rompe el hielo y el segundo la mueve.","O primeiro toque quebra o gelo, o segundo a move.","Sentuhan pertama memecah es, sentuhan kedua menggerakkannya.","İlk dokunuş buzu kırar, ikincisi oku hareket ettirir.","Первое нажатие раскалывает лёд, второе двигает стрелку.","Le premier toucher brise la glace, le second la déplace."],"timedD":["Clear the board before time runs out.","أفرغ اللوحة قبل انتهاء الوقت.","Vacía el tablero antes de que se acabe el tiempo.","Esvazie o tabuleiro antes que o tempo acabe.","Kosongkan papan sebelum waktu habis.","Süre bitmeden tahtayı boşalt.","Очисти поле, пока не вышло время.","Vide le plateau avant la fin du temps."],"lockToast":["Clear {n} more arrows to unlock","أخرِج {n} أسهم أخرى لفتح القفل","Saca {n} flechas más para desbloquear","Tire mais {n} setas para destrancar","Keluarkan {n} panah lagi untuk membuka","Kilidi açmak için {n} ok daha çıkar","Чтобы открыть, убери ещё стрелок: {n}","Sors encore {n} flèches pour déverrouiller"],"dailyDoneT":["Daily challenge complete","أنجزت تحدّي اليوم","¡Reto diario completado!","Desafio diário concluído","Tantangan harian selesai","Günlük görev tamam","Задание дня выполнено","Défi du jour réussi"],"streakN":["Streak: {n}","سلسلة {n} يوم","Racha: {n}","Sequência: {n}","Beruntun: {n}","Seri: {n}","Серия: {n}","Série : {n}"],"continueLevels":["Continue levels","متابعة المراحل","Seguir con los niveles","Continuar as fases","Lanjut ke level","Bölümlere devam","К уровням","Continuer les niveaux"],"perfectT":["Perfect!","حل مثالي!","¡Perfecto!","Perfeito!","Sempurna!","Mükemmel!","Идеально!","Parfait !"],"wellDone":["Well done!","أحسنت!","¡Bien hecho!","Muito bem!","Bagus!","Aferin!","Отлично!","Bravo !"],"outLives":["Out of lives","نفدت المحاولات","Sin vidas","Sem vidas","Nyawa habis","Canın bitti","Жизни закончились","Plus de vies"],"outLivesP":["Follow each arrow's direction before you tap it.","تتبّع اتجاه كل سهم قبل أن تلمسه.","Sigue la dirección de cada flecha antes de tocarla.","Siga a direção de cada seta antes de tocar.","Perhatikan arah setiap panah sebelum menyentuhnya.","Dokunmadan önce her okun yönünü takip et.","Смотри, куда направлена стрелка, прежде чем нажать.","Suis la direction de chaque flèche avant de la toucher."],"watchLife":["Watch an ad for an extra life","شاهد إعلاناً واستعد قلباً","Mira un anuncio y recupera una vida","Assista a um anúncio e ganhe uma vida","Tonton iklan untuk dapat nyawa","Reklam izle, can kazan","Смотреть рекламу за жизнь","Regarder une pub pour une vie"],"watchLifeMsg":["Watch the whole ad to get a life back and keep playing.","شاهد الإعلان كاملاً لتستعيد قلباً وتكمل المرحلة.","Mira el anuncio completo para recuperar una vida y seguir.","Assista ao anúncio inteiro para recuperar uma vida e continuar.","Tonton iklan sampai habis untuk mendapat satu nyawa dan lanjut bermain.","Bir can kazanıp devam etmek için reklamı sonuna kadar izle.","Досмотри рекламу, чтобы вернуть жизнь и продолжить.","Regarde la pub en entier pour récupérer une vie et continuer."],"gotLife":["Life restored","استعدت قلباً","Vida recuperada","Vida recuperada","Nyawa kembali","Can geri geldi","Жизнь восстановлена","Vie récupérée"],"restartLevel":["Start the level over","ابدأ المرحلة من جديد","Empezar el nivel de nuevo","Recomeçar a fase","Mulai ulang level","Bölümü baştan başlat","Начать уровень заново","Recommencer le niveau"],"timeUp":["Time's up","انتهى الوقت","Se acabó el tiempo","O tempo acabou","Waktu habis","Süre doldu","Время вышло","Temps écoulé"],"timeUpP":["Arrows left on the board: {n}","بقي {n} سهماً على اللوحة.","Flechas en el tablero: {n}","Setas no tabuleiro: {n}","Panah tersisa di papan: {n}","Tahtada kalan ok: {n}","Стрелок на поле: {n}","Flèches restantes : {n}"],"watchTime":["Watch an ad for 30 more seconds","شاهد إعلاناً واحصل على ٣٠ ثانية","Mira un anuncio y gana 30 segundos","Assista a um anúncio e ganhe 30 segundos","Tonton iklan untuk tambahan 30 detik","Reklam izle, 30 saniye kazan","Смотреть рекламу за 30 секунд","Regarder une pub pour 30 secondes"],"watchTimeMsg":["Watch the whole ad to get 30 extra seconds.","شاهد الإعلان كاملاً لتحصل على ٣٠ ثانية إضافية.","Mira el anuncio completo para obtener 30 segundos extra.","Assista ao anúncio inteiro para ganhar 30 segundos extras.","Tonton iklan sampai habis untuk mendapat 30 detik tambahan.","30 saniye ek süre için reklamı sonuna kadar izle.","Досмотри рекламу, чтобы получить ещё 30 секунд.","Regarde la pub en entier pour 30 secondes de plus."],"plus30":["+30 seconds","+٣٠ ثانية","+30 segundos","+30 segundos","+30 detik","+30 saniye","+30 секунд","+30 secondes"],"restartMsg":["Restarting the level is available after watching the whole ad.","إعادة المرحلة متاحة بعد مشاهدة الإعلان كاملاً.","Puedes reiniciar el nivel tras ver el anuncio completo.","Você pode reiniciar a fase depois de assistir ao anúncio inteiro.","Level bisa diulang setelah menonton iklan sampai habis.","Bölümü yeniden başlatmak için reklamı sonuna kadar izle.","Перезапуск уровня доступен после просмотра рекламы.","Tu peux recommencer le niveau après avoir regardé la pub en entier."],"adIncomplete":["The ad wasn't watched to the end","لم تكتمل مشاهدة الإعلان","No viste el anuncio completo","O anúncio não foi assistido até o fim","Iklan tidak ditonton sampai habis","Reklam sonuna kadar izlenmedi","Реклама не досмотрена","La pub n'a pas été regardée jusqu'au bout"],"hintsName":["hints","تلميحات","pistas","dicas","petunjuk","ipucu","подсказки","indices"],"guidesName":["path reveals","مرات لإظهار المسارات","usos de rutas","usos de rotas","penggunaan jalur","yol gösterme hakkı","показа путей","affichages des chemins"],"refillMsg":["Watch the whole ad to get 3 {what}.","شاهد الإعلان كاملاً لتحصل على ٣ {what}.","Mira el anuncio completo para obtener 3 {what}.","Assista ao anúncio inteiro para ganhar 3 {what}.","Tonton iklan sampai habis untuk mendapat 3 {what}.","3 {what} için reklamı sonuna kadar izle.","Досмотри рекламу и получи 3 {what}.","Regarde la pub en entier pour obtenir 3 {what}."],"refillToast":["+3 {what}","+٣ {what}","+3 {what}","+3 {what}","+3 {what}","+3 {what}","+3 {what}","+3 {what}"],"waitMoving":["Wait until the moving arrows are out","انتظر حتى تخرج الأسهم المتحركة","Espera a que salgan las flechas en movimiento","Espere as setas em movimento saírem","Tunggu sampai panah yang bergerak keluar","Hareket eden okların çıkmasını bekle","Подожди, пока движущиеся стрелки уйдут","Attends que les flèches en mouvement sortent"],"pathsShown":["Paths shown for 6 seconds","تظهر المسارات لمدة ٦ ثوانٍ","Rutas visibles 6 segundos","Rotas visíveis por 6 segundos","Jalur terlihat selama 6 detik","Yollar 6 saniye görünür","Пути видны 6 секунд","Chemins visibles 6 secondes"],"a_first_win":["First Exit","أول مخرج","Primera salida","Primeira saída","Jalan Keluar Pertama","İlk Çıkış","Первый выход","Première sortie"],"d_first_win":["Finish your first level.","أنهِ أول مرحلة.","Completa tu primer nivel.","Conclua sua primeira fase.","Selesaikan level pertamamu.","İlk bölümünü bitir.","Пройди первый уровень.","Termine ton premier niveau."],"a_levels_10":["On Your Way","على الطريق","En camino","No caminho","Dalam Perjalanan","Yolda","В пути","En route"],"a_levels_50":["Arrow Expert","خبير الأسهم","Experto en flechas","Especialista em setas","Ahli Panah","Ok Uzmanı","Знаток стрелок","Expert des flèches"],"a_levels_100":["Master of Exits","سيّد المخارج","Maestro de salidas","Mestre das saídas","Master Jalan Keluar","Çıkış Ustası","Мастер выходов","Maître des sorties"],"d_levels":["Finish {n} levels.","أنهِ {n} من المراحل.","Completa {n} niveles.","Conclua {n} fases.","Selesaikan {n} level.","{n} bölüm bitir.","Пройди уровней: {n}.","Termine {n} niveaux."],"a_perfect":["Flawless","حل مثالي","Impecable","Impecável","Tanpa Cela","Kusursuz","Без ошибок","Sans faute"],"d_perfect":["Finish a level without losing a life.","أنهِ مرحلة دون أن تخسر أي قلب.","Completa un nivel sin perder vidas.","Conclua uma fase sem perder vidas.","Selesaikan level tanpa kehilangan nyawa.","Can kaybetmeden bir bölüm bitir.","Пройди уровень, не потеряв жизни.","Termine un niveau sans perdre de vie."],"a_perfect_10":["Precision","دقّة عالية","Precisión","Precisão","Presisi","Hassasiyet","Точность","Précision"],"d_perfect_10":["Get 3 stars on {n} levels.","احصل على ٣ نجوم في {n} من المراحل.","Consigue 3 estrellas en {n} niveles.","Ganhe 3 estrelas em {n} fases.","Dapatkan 3 bintang di {n} level.","{n} bölümde 3 yıldız al.","Получи 3 звезды на уровнях: {n}.","Obtiens 3 étoiles sur {n} niveaux."],"a_stars_100":["Starry Sky","سماء النجوم","Cielo estrellado","Céu estrelado","Langit Berbintang","Yıldızlı Gök","Звёздное небо","Ciel étoilé"],"d_stars_100":["Collect {n} stars.","اجمع {n} نجمة.","Reúne {n} estrellas.","Junte {n} estrelas.","Kumpulkan {n} bintang.","{n} yıldız topla.","Собери звёзд: {n}.","Récolte {n} étoiles."],"a_timed_1":["Beat the Clock","سباق مع الوقت","Contra el reloj","Contra o relógio","Kalahkan Waktu","Zamana Karşı","Наперегонки со временем","Contre la montre"],"d_timed_1":["Finish a timed level.","أنهِ مرحلة موقوتة.","Completa un nivel contrarreloj.","Conclua uma fase cronometrada.","Selesaikan level berwaktu.","Süreli bir bölüm bitir.","Пройди уровень на время.","Termine un niveau chronométré."],"a_speed":["Lightning","خاطف","Relámpago","Relâmpago","Kilat","Şimşek","Молния","Éclair"],"d_speed":["Finish a level with 15+ arrows in under 20 seconds.","أنهِ مرحلة فيها ١٥ سهماً أو أكثر في أقل من ٢٠ ثانية.","Completa un nivel con 15 flechas o más en menos de 20 segundos.","Conclua uma fase com 15 setas ou mais em menos de 20 segundos.","Selesaikan level berisi 15+ panah dalam kurang dari 20 detik.","15 veya daha fazla oklu bir bölümü 20 saniyeden kısa sürede bitir.","Пройди уровень с 15+ стрелками меньше чем за 20 секунд.","Termine un niveau de 15 flèches ou plus en moins de 20 secondes."],"a_lock_1":["Lockpicker","فاتح الأقفال","Abrecerrojos","Arrombador","Pembuka Kunci","Kilit Açıcı","Взломщик","Crocheteur"],"d_lock_1":["Clear your first locked arrow.","أخرِج أول سهم مقفل.","Saca tu primera flecha bloqueada.","Tire sua primeira seta trancada.","Keluarkan panah terkunci pertamamu.","İlk kilitli okunu çıkar.","Убери первую запертую стрелку.","Sors ta première flèche verrouillée."],"a_two_1":["Both Ways","الاتجاهان","En ambos sentidos","Nos dois sentidos","Dua Arah","İki Yön","В обе стороны","Dans les deux sens"],"d_two_1":["Clear a two-way arrow.","أخرِج سهماً باتجاهين.","Saca una flecha doble.","Tire uma seta dupla.","Keluarkan panah dua arah.","Çift yönlü bir ok çıkar.","Убери двустороннюю стрелку.","Sors une flèche double."],"a_ice_10":["Icebreaker","كاسر الجليد","Rompehielos","Quebra-gelo","Pemecah Es","Buzkıran","Ледокол","Brise-glace"],"d_ice_10":["Break the ice on {n} arrows.","اكسر الجليد عن {n} من الأسهم.","Rompe el hielo de {n} flechas.","Quebre o gelo de {n} setas.","Pecahkan es di {n} panah.","{n} okun buzunu kır.","Расколи лёд на стрелках: {n}.","Brise la glace de {n} flèches."],"a_shapes_all":["Every Shape","كل الأشكال","Todas las formas","Todas as formas","Semua Bentuk","Tüm Şekiller","Все формы","Toutes les formes"],"d_shapes_all":["Finish a board of every shape: heart, circle, diamond, cross, hourglass.","أنهِ لوحة من كل شكل: قلب، دائرة، معيّن، صليب، ساعة رملية.","Completa un tablero de cada forma: corazón, círculo, rombo, cruz y reloj de arena.","Conclua um tabuleiro de cada formato: coração, círculo, losango, cruz e ampulheta.","Selesaikan papan setiap bentuk: hati, lingkaran, belah ketupat, silang, jam pasir.","Her şekilde bir tahta bitir: kalp, daire, karo, artı, kum saati.","Пройди поле каждой формы: сердце, круг, ромб, крест, песочные часы.","Termine un plateau de chaque forme : cœur, cercle, losange, croix, sablier."],"a_no_help":["No Help Needed","بلا مساعدة","Sin ayuda","Sem ajuda","Tanpa Bantuan","Yardımsız","Без помощи","Sans aide"],"d_no_help":["Finish a level from 10 on without hints or paths.","أنهِ مرحلة من العاشرة فما فوق دون تلميح أو مسارات.","Completa un nivel del 10 en adelante sin pistas ni rutas.","Conclua uma fase a partir da 10 sem dicas nem rotas.","Selesaikan level 10 ke atas tanpa petunjuk atau jalur.","10. bölüm ve sonrasında ipucu ya da yol kullanmadan bir bölüm bitir.","Пройди уровень от 10-го и выше без подсказок и путей.","Termine un niveau à partir du 10 sans indice ni chemins."],"a_daily_1":["Player of the Day","لاعب اليوم","Jugador del día","Jogador do dia","Pemain Hari Ini","Günün Oyuncusu","Игрок дня","Joueur du jour"],"d_daily_1":["Finish your first daily challenge.","أنهِ أول تحدٍّ يومي.","Completa tu primer reto diario.","Conclua seu primeiro desafio diário.","Selesaikan tantangan harian pertamamu.","İlk günlük görevini bitir.","Выполни первое задание дня.","Réussis ton premier défi du jour."],"a_streak_7":["Full Week","أسبوع كامل","Semana completa","Semana completa","Seminggu Penuh","Tam Hafta","Целая неделя","Semaine complète"],"d_streak_7":["Finish the daily challenge {n} days in a row.","أنهِ تحدّي اليوم {n} أيام متتالية.","Completa el reto diario {n} días seguidos.","Conclua o desafio diário {n} dias seguidos.","Selesaikan tantangan harian {n} hari berturut-turut.","Günlük görevi {n} gün üst üste bitir.","Выполняй задание дня {n} дней подряд.","Réussis le défi du jour {n} jours d'affilée."],"chipOn":["Play Games · signed in","Play Games · متصل","Play Games · conectado","Play Games · conectado","Play Games · masuk","Play Games · bağlı","Play Games · вход выполнен","Play Games · connecté"],"chipOff":["Play Games · tap to sign in","Play Games · اضغط لتسجيل الدخول","Play Games · toca para entrar","Play Games · toque para entrar","Play Games · ketuk untuk masuk","Play Games · giriş için dokun","Play Games · нажми, чтобы войти","Play Games · touche pour te connecter"],"adUnavailable":["No ad available right now. Try again in a moment.","لا يوجد إعلان متاح الآن. حاول بعد قليل.","No hay anuncios disponibles ahora. Inténtalo en un momento.","Nenhum anúncio disponível agora. Tente de novo em instantes.","Belum ada iklan. Coba lagi sebentar lagi.","Şu an reklam yok. Birazdan tekrar dene.","Сейчас нет рекламы. Попробуй чуть позже.","Aucune pub disponible pour l'instant. Réessaie dans un moment."],"privacy":["Privacy options","خيارات الخصوصية","Opciones de privacidad","Opções de privacidade","Opsi privasi","Gizlilik seçenekleri","Настройки конфиденциальности","Options de confidentialité"],"coinsLabel":["Coins","العملات","Monedas","Moedas","Koin","Altın","Монеты","Pièces"],"dailyReward":["Daily reward","المكافأة اليومية","Recompensa diaria","Recompensa diária","Hadiah harian","Günlük ödül","Ежедневная награда","Récompense quotidienne"],"dailyClaimLabel":["Claim","استلام","Reclamar","Resgatar","Klaim","Al","Получить","Récupérer"],"claimed":["Claimed today","استلمت مكافأة اليوم","Reclamado hoy","Resgatado hoje","Sudah diklaim","Bugün alındı","Уже получено","Déjà récupérée"],"shop":["Tool shop","متجر الأدوات","Tienda","Loja","Toko alat","Araç mağazası","Магазин","Boutique"],"buyHint":["Buy a hint · 40","شراء تلميح · ٤٠","Comprar pista · 40","Comprar dica · 40","Beli petunjuk · 40","İpucu al · 40","Купить подсказку · 40","Acheter un indice · 40"],"buyPath":["Buy paths · 40","شراء مسارات · ٤٠","Comprar rutas · 40","Comprar rotas · 40","Beli jalur · 40","Yol al · 40","Купить пути · 40","Acheter des chemins · 40"],"notEnough":["Not enough coins","عملاتك غير كافية","No tienes monedas suficientes","Moedas insuficientes","Koin tidak cukup","Yeterli altın yok","Недостаточно монет","Pas assez de pièces"],"rewardEarned":["Level reward: +{n} coins","مكافأة المرحلة: +{n} عملة","Recompensa: +{n} monedas","Recompensa: +{n} moedas","Hadiah level: +{n} koin","Bölüm ödülü: +{n} altın","Награда уровня: +{n} монет","Récompense : +{n} pièces"],"dailyEarned":["Daily reward: +{n} coins","مكافأة يومية: +{n} عملة","Recompensa diaria: +{n} monedas","Recompensa diária: +{n} moedas","Hadiah harian: +{n} koin","Günlük ödül: +{n} altın","Ежедневная награда: +{n} монет","Récompense quotidienne : +{n} pièces"],"privacyPolicy":["Privacy policy","سياسة الخصوصية","Política de privacidad","Política de privacidade","Kebijakan privasi","Gizlilik politikası","Политика конфиденциальности","Politique de confidentialité"]};
function detectLang(){
  for(const l of (navigator.languages||[navigator.language||'en'])){let c=String(l).slice(0,2).toLowerCase();if(c==='in')c='id';if(LANGS.includes(c))return c}
  return 'en';
}
let LANG='en';
function T(k,v){const row=TX[k];let s=row?(row[LANGS.indexOf(LANG)]||row[0]):k;
  if(v)for(const x in v)s=s.split('{'+x+'}').join(v[x]);return s}
const ar=n=>Number(n).toLocaleString(LOCALE[LANG]);
const dateStr=(d,o)=>d.toLocaleDateString(LOCALE[LANG],o);
const store={get(k,d){try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v)}catch(e){return d}},
             set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
const STAR='<svg class="star" viewBox="0 0 24 24"><path d="M12 2.5l2.9 6 6.6.8-4.9 4.6 1.3 6.6L12 17.3l-5.9 3.2 1.3-6.6-4.9-4.6 6.6-.8z"/></svg>';
const starSvg=on=>on?STAR:STAR.replace('class="star"','class="star off"');
const PLAY='<svg class="play" viewBox="0 0 10 10"><path d="M2 1l7 4-7 4z"/></svg>';

/* ---------- Android bridge ----------
   In the Android app, MainActivity injects window.AndroidBridge. In a browser it is absent,
   so ads are simulated and Play Games progress stays on the device. */
const NB=window.AndroidBridge||null;
const adCbs={};let adSeq=0;
window.NativeEvents={
  adDone(id,r){const f=adCbs[id];delete adCbs[id];if(f)f(r)},
  pgsState(on,enabled){Play.signedIn=!!on;Play.enabled=!!enabled;refreshChip();
    if(on){for(const id in P.ach)Play.unlock(id);checkAch(true);submitAll()}},
  cloudLoad(json){try{mergeCloud(JSON.parse(json))}catch(e){}},
  back(){
    if(!$('set').hidden){$('set').hidden=true;return true}
    if(!$('eco').hidden){closeEconomy();return true}
    if(!$('tut').hidden||!$('ov').hidden||!$('adR').hidden||!$('adI').hidden)return true;
    if(!$('game').hidden){goHome();return true}
    if(!$('home').hidden)return false;
    show('home');return true;
  },
};

/* ---------- persistent state ---------- */
const P={
  unlocked:store.get('mk_level',1), stars:store.get('mk_stars',{}),
  daily:store.get('mk_daily',{last:'',streak:0}),
  skin:store.get('mk_skin','fog'), colored:store.get('mk_colored',true),
  sound:store.get('mk_sound',true), vib:store.get('mk_vib',true),
  hints:store.get('mk_hints',3), guides:store.get('mk_guides',3),
  coins:store.get('mk_coins',0), rewardedLevels:store.get('mk_rewardedLevels',{}),
  rewardDay:store.get('mk_rewardDay',''), economyUpdatedAt:store.get('mk_economyUpdatedAt',0),
  wins:store.get('mk_wins',0), seen:store.get('mk_seen',{}),
  lang:store.get('mk_lang',null),
  ach:store.get('mk_ach',{}),                                    // {achievementId: unlock time}
  st:Object.assign({ice:0,bestStreak:0,dailyBest:0,shapes:{}},store.get('mk_st',{})),
};
const save=()=>{for(const [k,v] of Object.entries({level:P.unlocked,stars:P.stars,daily:P.daily,skin:P.skin,colored:P.colored,
  sound:P.sound,vib:P.vib,hints:P.hints,guides:P.guides,wins:P.wins,seen:P.seen,lang:P.lang,ach:P.ach,st:P.st,coins:P.coins,rewardedLevels:P.rewardedLevels,rewardDay:P.rewardDay,economyUpdatedAt:P.economyUpdatedAt}))store.set('mk_'+k,v);
  Play.saveGame()};

/* ---------- Play Games layer ----------
   Web build: everything is kept on this device.
   Android build: each method body is replaced by the Play Games Services v2 call named beside it. */
const Play={
  enabled:false, signedIn:false,                 // set by the Android app (NativeEvents.pgsState)
  signIn(){NB&&NB.pgsSignIn()},
  unlock(id){NB&&Play.signedIn&&NB.pgsUnlock(id)},
  steps(id,n){NB&&Play.signedIn&&NB.pgsSteps(id,n)},
  submit(board,value){NB&&Play.signedIn&&NB.pgsSubmit(board,Math.round(value))},
  showAchievements(){if(NB&&Play.signedIn)NB.pgsShowAchievements();else show('ach')},
  showLeaderboards(){if(NB&&Play.signedIn)NB.pgsShowLeaderboards();else show('lb')},
  saveGame(){if(!NB||!Play.signedIn)return;clearTimeout(Play._t);Play._t=setTimeout(()=>NB.pgsSave(JSON.stringify(cloudData())),2500)},
};
function cloudData(){return{v:1,unlocked:P.unlocked,stars:P.stars,daily:P.daily,hints:P.hints,guides:P.guides,wins:P.wins,seen:P.seen,ach:P.ach,st:P.st,coins:P.coins,rewardedLevels:P.rewardedLevels,rewardDay:P.rewardDay,economyUpdatedAt:P.economyUpdatedAt}}
function mergeCloud(c){
  if(!c||c.v!==1)return;
  P.unlocked=Math.max(P.unlocked,c.unlocked||1);
  for(const k in c.stars||{})P.stars[k]=Math.max(P.stars[k]||0,c.stars[k]);
  for(const k in c.ach||{})P.ach[k]=P.ach[k]?Math.min(P.ach[k],c.ach[k]):c.ach[k];
  Object.assign(P.seen,c.seen||{});
  if(c.daily&&(c.daily.last||'')>(P.daily.last||''))P.daily=c.daily;
  P.hints=Math.max(P.hints,c.hints||0);P.guides=Math.max(P.guides,c.guides||0);P.wins=Math.max(P.wins,c.wins||0);
  if((c.economyUpdatedAt||0)>P.economyUpdatedAt){P.coins=c.coins||0;P.rewardedLevels=c.rewardedLevels||{};P.rewardDay=c.rewardDay||'';P.economyUpdatedAt=c.economyUpdatedAt||0;}
  const s=c.st||{};P.st.ice=Math.max(P.st.ice,s.ice||0);P.st.bestStreak=Math.max(P.st.bestStreak,s.bestStreak||0);
  if(s.dailyBest&&(!P.st.dailyBest||s.dailyBest<P.st.dailyBest))P.st.dailyBest=s.dailyBest;
  Object.assign(P.st.shapes,s.shapes||{});
  save();checkAch(true);submitAll();if(!$('home').hidden)refreshHome();
}
function refreshChip(){
  const c=$('pgChip'),k=!NB||!Play.enabled?'chipLocal':Play.signedIn?'chipOn':'chipOff';
  c.querySelector('span').textContent=T(k);c.classList.toggle('tap',k==='chipOff');c.classList.toggle('on',k==='chipOn');
}

const ICO={
  arrow:'<path d="M4 12h14M13 6l6 6-6 6"/>',
  star:'<path d="M12 3l2.6 5.5 6 .7-4.4 4.1 1.2 6L12 16.4 6.6 19.3l1.2-6L3.4 9.2l6-.7z"/>',
  clock:'<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2 2M10 2h4"/>',
  lock:'<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  ice:'<path d="M12 2v20M3.5 7l17 10M20.5 7l-17 10"/>',
  two:'<path d="M3 12h18M7 8l-4 4 4 4M17 8l4 4-4 4"/>',
  shape:'<path d="M12 20s-7-4.3-8.8-8.6C2 8 4 5 7 5c2 0 3.4 1.1 5 3 1.6-1.9 3-3 5-3 3 0 5 3 3.8 6.4C19 15.7 12 20 12 20z"/>',
  cal:'<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M9 3v4M15 3v4"/>',
  bolt:'<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
  eye:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  flag:'<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
  trophy:'<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0z"/><path d="M7 6H4a3 3 0 0 0 3 4M17 6h3a3 3 0 0 1-3 4"/>',
};
const icon=k=>`<svg class="ico" viewBox="0 0 24 24">${ICO[k]}</svg>`;
const doneLevels=()=>P.unlocked-1;
const perfects=()=>Object.values(P.stars).filter(s=>s===3).length;
const ACH=[
  {id:'first_win', i:'flag', n:1, stat:doneLevels},
  {id:'levels_10', i:'arrow', n:10, stat:doneLevels, dk:'d_levels'},
  {id:'levels_50', i:'arrow', n:50, stat:doneLevels, dk:'d_levels'},
  {id:'levels_100',i:'trophy', n:100, stat:doneLevels, dk:'d_levels'},
  {id:'perfect',   i:'star', n:1, stat:perfects},
  {id:'perfect_10',i:'star', n:10, stat:perfects},
  {id:'stars_100', i:'star', n:100, stat:()=>totalStars()},
  {id:'timed_1',   i:'clock'},
  {id:'speed',     i:'bolt'},
  {id:'lock_1',    i:'lock'},
  {id:'two_1',     i:'two'},
  {id:'ice_10',    i:'ice', n:10, stat:()=>P.st.ice},
  {id:'shapes_all',i:'shape', n:5, stat:()=>Object.keys(P.st.shapes).length},
  {id:'no_help',   i:'eye'},
  {id:'daily_1',   i:'cal', n:1, stat:()=>P.st.bestStreak},
  {id:'streak_7',  i:'cal', n:7, stat:()=>P.st.bestStreak},
];
const achT=a=>T('a_'+a.id), achD=a=>T(a.dk||'d_'+a.id,{n:ar(a.n||1)});
const LB=[
  {id:'stars',  t:'lbStars',      i:'star',  v:()=>totalStars(), f:ar},
  {id:'levels', t:'lbLevels',   i:'arrow', v:doneLevels, f:ar},
  {id:'streak', t:'lbStreak', i:'cal', v:()=>P.st.bestStreak, f:n=>T('days',{n:ar(n)})},
  {id:'daily',  t:'lbDaily',     i:'bolt',  v:()=>P.st.dailyBest, f:n=>n?fmt(n):'—', low:true},
];

let popQ=[],popOn=false;
function popAch(a){popQ.push(a);if(!popOn)nextPop()}
function nextPop(){
  const a=popQ.shift();if(!a){popOn=false;return}popOn=true;
  $('apIco').innerHTML=icon(a.i);$('apT').textContent=achT(a);const el=$('achpop');el.classList.add('show');
  sfx('win');
  setTimeout(()=>{el.classList.remove('show');setTimeout(nextPop,500)},2600);
}
function unlock(id,silent){
  if(P.ach[id])return;const a=ACH.find(x=>x.id===id);if(!a)return;
  P.ach[id]=Date.now();store.set('mk_ach',P.ach);Play.unlock(id);if(!silent)popAch(a);
}
function checkAch(silent){
  for(const a of ACH)if(a.stat){const v=a.stat();if(a.n>1)Play.steps(a.id,Math.min(v,a.n));if(v>=a.n)unlock(a.id,silent)}
}
function submitAll(){for(const b of LB){const v=b.v();if(v)Play.submit(b.id,b.low?Math.round(v*1000):v)}}

function buildAch(){
  const got=ACH.filter(a=>P.ach[a.id]).length;
  $('achSum').textContent=T('achOf',{a:ar(got),b:ar(ACH.length)});$('achBar').style.width=(got/ACH.length*100)+'%';
  $('achList').innerHTML=ACH.map(a=>{
    const done=!!P.ach[a.id],v=a.stat?Math.min(a.stat(),a.n):0,multi=a.n>1;
    const right=done?dateStr(new Date(P.ach[a.id]),{day:'numeric',month:'short'}):multi?ar(v)+' / '+ar(a.n):'';
    return `<div class="item ${done?'done':''}"><span class="md">${icon(a.i)}</span><div><b>${achT(a)}</b><p>${achD(a)}</p></div><span class="pv">${right}</span>`+
      (multi&&!done?`<div class="pb"><i style="width:${v/a.n*100}%"></i></div>`:'')+'</div>';
  }).join('');
}
function buildLb(){
  $('lbList').innerHTML=LB.map(b=>`<div class="item lb"><span class="md">${icon(b.i)}</span><div><b>${T(b.t)}</b><p>${T('yourBest')}</p></div><span class="lbv">${b.f(b.v())}</span></div>`).join('');
}
document.documentElement.dataset.skin=P.skin;
const dayKey=(d=new Date())=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
const yesterday=()=>{const d=new Date();d.setDate(d.getDate()-1);return dayKey(d)};

/* ---------- ads (simulated here; swap bodies for AdMob calls in the Android build) ---------- */
let paused=false;
const Ads={
  banner(show){if(NB){$('banner').hidden=true;NB.setBanner(!!show)}else $('banner').hidden=!show},
  rewarded(msg,freeIfNoAd){
    // native result: 1 = watched to the end, 0 = closed early, -1 = no ad available
    if(NB)return new Promise(res=>{paused=true;const id=++adSeq;adCbs[id]=r=>{paused=false;
      if(r===-1){if(freeIfNoAd)res(true);else{toast(T('adUnavailable'));res(null)}}else res(r===1)};NB.showRewarded(id)});
    return new Promise(res=>{
    paused=true;$('adR').hidden=false;$('adRMsg').textContent=msg;const bar=$('adRBar'),claim=$('adRClaim');
    claim.disabled=true;let t=0;const D=5;bar.style.width='0';
    const iv=setInterval(()=>{t+=.1;bar.style.width=Math.min(100,t/D*100)+'%';if(t>=D){clearInterval(iv);claim.disabled=false;claim.focus()}},100);
    const done=ok=>{clearInterval(iv);$('adR').hidden=true;paused=false;res(ok)};
    claim.onclick=()=>done(true);$('adRClose').onclick=()=>done(false);
  })},
  interstitial(){
    if(NB)return new Promise(res=>{paused=true;const id=++adSeq;adCbs[id]=()=>{paused=false;res()};NB.showInterstitial(id)});
    return new Promise(res=>{
    paused=true;$('adI').hidden=false;const b=$('adIClose');let n=5;b.disabled=true;b.textContent=ar(n);
    const iv=setInterval(()=>{n--;if(n>0)b.textContent=ar(n);else{clearInterval(iv);b.disabled=false;b.textContent=T('close');b.focus()}},1000);
    b.onclick=()=>{$('adI').hidden=true;paused=false;res()};
  })},
};

/* ---------- board shapes ---------- */
const SHAPES={
  rect:()=>true,
  heart:(u,v)=>{const x=u*1.25,y=-v*1.3+.25;return Math.pow(x*x+y*y-1,3)-x*x*y*y*y<=0},
  circle:(u,v)=>u*u+v*v<=1.08,
  diamond:(u,v)=>Math.abs(u)+Math.abs(v)<=1.15,
  plus:(u,v)=>Math.abs(u)<.42||Math.abs(v)<.42,
  hourglass:(u,v)=>Math.abs(u)<=Math.abs(v)*1.05+.22,
};
const SHAPE_ORDER=['heart','circle','diamond','plus','hourglass','rect'];
function levelCfg(n){
  const shape=n<4?'rect':SHAPE_ORDER[(n-4)%SHAPE_ORDER.length];
  return {diff:n,seed:n*7919+101,shape,timed:n>=5&&n%5===0,
    lock:n>=6?.12:0,two:n>=9?.12:0,ice:n>=12?.12:0};
}

/* ---------- generation ---------- */
function rng(seed){return()=>{seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);
  t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const DIRS=[[1,0],[-1,0],[0,1],[0,-1]];
function headOf(a,rev){const c=a.cells,n=c.length;return rev?[c[0],[c[0][0]-c[1][0],c[0][1]-c[1][1]]]:[c[n-1],[c[n-1][0]-c[n-2][0],c[n-1][1]-c[n-2][1]]]}
const headDir=a=>headOf(a,false)[1];
function buildOcc(arrows,W,H,skip){
  const occ=Array.from({length:H},()=>new Array(W).fill(-1));
  arrows.forEach((a,i)=>{if(skip&&skip(a,i))return;a.cells.forEach(([x,y])=>occ[y][x]=i)});
  return occ;
}
function rayCheck(a,occ,W,H,rev){
  const [[hx,hy],[dx,dy]]=headOf(a,rev);let x=hx,y=hy,k=0;
  while(true){x+=dx;y+=dy;if(x<0||y<0||x>=W||y>=H)return -1;if(occ[y][x]!==-1)return k;k++}
}
// greedy clearing (removal only ever frees cells, so greedy decides solvability)
function greedy(arrows,W,H){
  const alive=arrows.map(()=>true),order=[];let moved=true;
  while(moved){moved=false;const occ=buildOcc(arrows,W,H,(a,i)=>!alive[i]);
    for(let i=0;i<arrows.length;i++){if(!alive[i])continue;
      if(rayCheck(arrows[i],occ,W,H)===-1||(arrows[i].two&&rayCheck(arrows[i],occ,W,H,true)===-1)){alive[i]=false;order.push(i);moved=true;break}}}
  return {order,stuck:arrows.map((a,i)=>i).filter(i=>alive[i])};
}
function generate(cfg){
  const R=rng(cfg.seed),shaped=cfg.shape!=='rect';
  const W=shaped?Math.min(7+Math.floor((cfg.diff-1)/4),11):Math.min(5+Math.floor((cfg.diff-1)/3),9);
  const H=shaped?W+1:Math.min(Math.round(W*1.45),13);
  const maxLen=Math.min(3+Math.floor(cfg.diff/2),7);
  const fn=SHAPES[cfg.shape];
  const mask=Array.from({length:H},(_,y)=>Array.from({length:W},(_,x)=>fn((x+.5)/W*2-1,(y+.5)/H*2-1)));
  const used=mask.map(r=>r.map(m=>!m));
  const cells=[];for(let y=0;y<H;y++)for(let x=0;x<W;x++)if(mask[y][x])cells.push([x,y]);
  for(let i=cells.length-1;i>0;i--){const j=Math.floor(R()*(i+1));[cells[i],cells[j]]=[cells[j],cells[i]]}
  let arrows=[];
  for(const [sx,sy] of cells){
    if(used[sy][sx])continue;
    const path=[[sx,sy]];used[sy][sx]=true;const target=2+Math.floor(R()*(maxLen-1));let last=null;
    while(path.length<target){
      const [cx,cy]=path[path.length-1];
      const opts=DIRS.filter(([dx,dy])=>{const nx=cx+dx,ny=cy+dy;return nx>=0&&ny>=0&&nx<W&&ny<H&&!used[ny][nx]});
      if(!opts.length)break;
      let d=opts[Math.floor(R()*opts.length)];
      if(last&&R()<.55&&opts.some(o=>o[0]===last[0]&&o[1]===last[1]))d=last;
      path.push([cx+d[0],cy+d[1]]);used[cy+d[1]][cx+d[0]]=true;last=d;
    }
    if(path.length>=2)arrows.push({cells:path});else used[sy][sx]=false;
  }
  for(let it=0;it<400;it++){
    const st=greedy(arrows,W,H).stuck;if(!st.length)break;
    const i=st[Math.floor(R()*st.length)];
    if(it<250)arrows[i].cells.reverse();else arrows.splice(i,1);
  }
  // special arrows (added after the board is known solvable; none can make it unsolvable)
  const order=greedy(arrows,W,H).order;
  order.forEach((ai,idx)=>{const a=arrows[ai];
    if(cfg.lock&&idx>=3&&R()<cfg.lock)a.lock=Math.max(2,Math.floor(idx*(.5+R()*.4)));
    else if(cfg.two&&R()<cfg.two)a.two=true;
    else if(cfg.ice&&R()<cfg.ice)a.ice=true;
  });
  return {W,H,mask,shape:cfg.shape,arrows:arrows.map((a,i)=>({id:i,cells:a.cells,lock:a.lock||0,two:!!a.two,ice:!!a.ice,state:'idle',t:0,c:1+Math.floor(R()*5)}))};
}

/* ---------- views ---------- */
function show(v){for(const id of ['home','levels','game','ach','lb'])$(id).hidden=id!==v;
  if(v==='game')layout();if(v==='home')refreshHome();if(v==='levels')buildLevels();if(v==='ach')buildAch();if(v==='lb')buildLb()}
const totalStars=()=>Object.values(P.stars).reduce((s,v)=>s+v,0);
function refreshHome(){
  $('hPlayLv').textContent=T('levelN',{n:ar(P.unlocked)});
  const done=P.daily.last===dayKey();
  $('hDailyTag').textContent=T(done?'dailyDone':'dailyNew');
  $('hAchN').textContent=ar(ACH.filter(a=>P.ach[a.id]).length)+'/'+ar(ACH.length);
  $('sStars').textContent=ar(totalStars());$('sDone').textContent=ar(P.unlocked-1);
  $('sStreak').textContent=ar((P.daily.last===dayKey()||P.daily.last===yesterday())?P.daily.streak:0);
  const wallet=$('coinCount');if(wallet)wallet.textContent=ar(P.coins);
  const claimBtn=$('hReward');if(claimBtn){const claimed=P.rewardDay===dayKey();claimBtn.textContent=(claimed?'✓ ':'')+T(claimed?'claimed':'dailyClaimLabel');claimBtn.disabled=claimed;}
}
const CLOCK_ICO='<svg class="ico mk" viewBox="0 0 24 24"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l2 2M10 2h4"/></svg>';
const SHAPE_ICO='<svg class="ico mk" viewBox="0 0 24 24"><path d="M12 20s-7-4.3-8.8-8.6C2 8 4 5 7 5c2 0 3.4 1.1 5 3 1.6-1.9 3-3 5-3 3 0 5 3 3.8 6.4C19 15.7 12 20 12 20z"/></svg>';
function buildLevels(){
  const g=$('lvGrid');g.innerHTML='';const n=Math.max(30,Math.ceil((P.unlocked+10)/5)*5);
  for(let i=1;i<=n;i++){
    const b=document.createElement('button');b.type='button';b.className='lv';const s=P.stars[i]||0,cf=levelCfg(i);
    const mk=cf.timed?CLOCK_ICO:cf.shape!=='rect'?SHAPE_ICO:'';
    if(i>P.unlocked){b.classList.add('lock');b.disabled=true;b.innerHTML=mk+'<svg class="ico" viewBox="0 0 24 24" style="width:16px;height:16px"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>'}
    else{if(i===P.unlocked)b.classList.add('cur');
      b.innerHTML=`${mk}<span>${ar(i)}</span><span class="st">${i<P.unlocked||s?[1,2,3].map(k=>starSvg(k<=s)).join(''):''}</span>`;
      b.onclick=()=>startGame('level',i)}
    g.appendChild(b);
  }
  g.querySelector('.cur')?.scrollIntoView({block:'center'});
}

/* ---------- game state ---------- */
const MAXH=3;
let usedHelp=false,G,cfg,mode='level',level=1,hearts,mistakes=0,hintId=-1,hintUntil=0,guideUntil=0,elapsed=0,limit=0,ended=false,parts=[],ripples=[],pendingAd=false;
function startGame(m,n){
  mode=m;level=n;ended=false;
  if(m==='daily'){const k=+dayKey().replace(/-/g,''),R=rng(k);
    cfg={diff:16,seed:k,shape:SHAPE_ORDER[Math.floor(R()*SHAPE_ORDER.length)],timed:false,lock:.12,two:.12,ice:.12};
    $('gMode').textContent=T('daily');$('gLvl').textContent=dateStr(new Date(),{day:'numeric',month:'long'})}
  else{cfg=levelCfg(n);$('gMode').textContent=T(cfg.timed?'legTimed':'level');$('gLvl').textContent=ar(n)}
  G=generate(cfg);
  hearts=MAXH;mistakes=0;hintId=-1;guideUntil=0;usedHelp=false;parts=[];ripples=[];elapsed=0;
  limit=cfg.timed?Math.ceil((G.arrows.length*2.6+15)/5)*5:0;
  $('clock').className=cfg.timed?'timed':'';
  $('ov').hidden=true;renderHearts();updateLeft();updateTools();show('game');Ads.banner(true);
  introSpecials();
}
const removed=()=>G.arrows.filter(a=>a.state==='leaving'||a.state==='gone').length;
const alive=()=>G.arrows.filter(a=>a.state==='idle'||a.state==='bump');
const locked=a=>a.lock&&removed()<a.lock;
const occNow=()=>buildOcc(G.arrows,G.W,G.H,a=>a.state==='gone'||a.state==='leaving');
function canExit(a,occ){if(rayCheck(a,occ,G.W,G.H)===-1)return{ok:true,rev:false};
  if(a.two&&rayCheck(a,occ,G.W,G.H,true)===-1)return{ok:true,rev:true};return{ok:false,k:rayCheck(a,occ,G.W,G.H)}}
function updateLeft(){$('left').textContent=T('left',{n:ar(alive().length)})}
function badge(el,n){el.className=n>0?'n':'n ad';el.innerHTML=n>0?ar(n):'<svg viewBox="0 0 10 10"><path d="M2 1l7 4-7 4z"/></svg>+'+ar(3)}
function updateTools(){badge($('hintN'),P.hints);badge($('guideN'),P.guides)}
function renderHearts(){$('hearts').innerHTML=Array.from({length:MAXH},(_,i)=>`<svg viewBox="0 0 24 24" class="${i<hearts?'':'lost'}"><path d="M12 21s-7.5-4.6-9.6-9.3C.8 8 3 4 6.8 4c2.2 0 3.7 1.2 5.2 3 1.5-1.8 3-3 5.2-3C21 4 23.2 8 21.6 11.7 19.5 16.4 12 21 12 21z"/></svg>`).join('')}
function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');clearTimeout(toast.h);toast.h=setTimeout(()=>t.classList.remove('show'),1800)}
const fmt=s=>{s=Math.max(0,Math.ceil(s));return ar(Math.floor(s/60))+':'+ar(s%60).padStart(2,ar(0))};

/* ---------- special arrow intros ---------- */
const INTRO={lock:['lockT','lockD'],two:['twoT','twoD'],ice:['iceT','iceD'],timed:['legTimed','timedD']};
function introSpecials(){
  const types=[];if(cfg.timed)types.push('timed');
  for(const k of ['lock','two','ice'])if(G.arrows.some(a=>a[k]))types.push(k);
  const fresh=types.filter(t=>!P.seen[t]);if(!fresh.length)return;
  const t=fresh[0];P.seen[t]=1;save();paused=true;
  $('tutT').textContent=T(INTRO[t][0]);$('tutP').textContent=T(INTRO[t][1]);$('tut').hidden=false;drawTut(t);
  $('tutB').onclick=()=>{$('tut').hidden=true;paused=false;introSpecials()};
}
function drawTut(t){
  const c=$('tutCv').getContext('2d');c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,440,220);
  if(t==='timed'){c.strokeStyle=C.acc;c.lineWidth=10;c.lineCap='round';c.beginPath();c.arc(220,115,70,-Math.PI/2,Math.PI*.9);c.stroke();
    c.strokeStyle=C.ink;c.lineWidth=8;c.beginPath();c.moveTo(220,115);c.lineTo(220,70);c.moveTo(220,115);c.lineTo(250,130);c.stroke();return}
  const s=60,X=x=>70+(x+.5)*s,Y=y=>20+(y+.5)*s;
  const a={cells:[[0,1],[1,1],[2,1],[3,1],[3,2]],t:0,c:2,lock:t==='lock'?3:0,two:t==='two',ice:t==='ice',state:'idle'};
  pathFor(a,5,3);drawArrow(c,a,C.a[1],false,s,X,Y,3);
}

/* ---------- sound & haptics ---------- */
let ac=null;
function sfx(kind,pitch=1){
  if(!P.sound)return;
  try{ac=ac||new (window.AudioContext||window.webkitAudioContext)();const now=ac.currentTime;
    if(kind==='whoosh'||kind==='crack'){
      const len=kind==='crack'?.12:.3,buf=ac.createBuffer(1,ac.sampleRate*len,ac.sampleRate),d=buf.getChannelData(0);
      for(let i=0;i<d.length;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/d.length,kind==='crack'?4:2);
      const s=ac.createBufferSource();s.buffer=buf;const f=ac.createBiquadFilter();f.type=kind==='crack'?'highpass':'bandpass';
      f.frequency.setValueAtTime(kind==='crack'?2500:500*pitch,now);if(kind==='whoosh')f.frequency.exponentialRampToValueAtTime(2400*pitch,now+len);f.Q.value=1.3;
      const g=ac.createGain();g.gain.value=.32;s.connect(f).connect(g).connect(ac.destination);s.start();
    }else if(kind==='win'){
      [523,659,784,1047].forEach((fq,i)=>{const o=ac.createOscillator(),g=ac.createGain();o.type='sine';o.frequency.value=fq;
        g.gain.setValueAtTime(0,now+i*.09);g.gain.linearRampToValueAtTime(.18,now+i*.09+.02);g.gain.exponentialRampToValueAtTime(.001,now+i*.09+.5);
        o.connect(g).connect(ac.destination);o.start(now+i*.09);o.stop(now+i*.09+.55)});
    }else if(kind==='tick'){
      const o=ac.createOscillator(),g=ac.createGain();o.frequency.value=1200;g.gain.setValueAtTime(.08,now);g.gain.exponentialRampToValueAtTime(.001,now+.05);
      o.connect(g).connect(ac.destination);o.start();o.stop(now+.06);
    }else{
      const o=ac.createOscillator(),g=ac.createGain();o.type='triangle';o.frequency.setValueAtTime(kind==='lock'?320:170,now);o.frequency.exponentialRampToValueAtTime(90,now+.2);
      g.gain.setValueAtTime(.25,now);g.gain.exponentialRampToValueAtTime(.001,now+.28);o.connect(g).connect(ac.destination);o.start();o.stop(now+.3);
    }
  }catch(e){}
}
function buzz(p){if(!P.vib)return;try{if(NB){NB.vibrate(Array.isArray(p)?p.reduce((a,b,i)=>i%2?a:a+b,0):p);return}navigator.vibrate&&navigator.vibrate(p)}catch(e){}}

/* ---------- drawing ---------- */
const cv=$('cv'),ctx=cv.getContext('2d');let S,OX,OY,dpr=1,CW=0,CH=0;
function layout(){
  const r=$('stage').getBoundingClientRect();if(!r.width)return;dpr=Math.min(window.devicePixelRatio||1,3);
  CW=r.width;CH=r.height;cv.width=CW*dpr;cv.height=CH*dpr;
  if(G){S=Math.floor(Math.min((CW-8)/G.W,(CH-8)/G.H));OX=(CW-S*G.W)/2;OY=(CH-S*G.H)/2}
}
const tok=n=>getComputedStyle(document.documentElement).getPropertyValue(n).trim();
let C={};function readColors(){C={ink:tok('--ink'),dot:tok('--dot'),cell:tok('--cell'),surf:tok('--surface'),acc:tok('--accent'),dan:tok('--danger'),ice:tok('--ice'),a:[1,2,3,4,5].map(i=>tok('--a'+i))}}
readColors();
const cx=x=>OX+(x+.5)*S, cy=y=>OY+(y+.5)*S;
function pathFor(a,W,H){
  if(a._path)return a._path;
  const pts=a.cells.map(c=>c.slice());const [dx,dy]=headDir(a);let [x,y]=a.cells[a.cells.length-1];
  for(let i=0;i<W+H+a.cells.length+4;i++){x+=dx;y+=dy;pts.push([x,y])}
  return a._path=pts;
}
function at(p,s){const i=Math.max(0,Math.min(p.length-2,Math.floor(s))),f=s-i;
  return[p[i][0]+(p[i+1][0]-p[i][0])*f,p[i][1]+(p[i+1][1]-p[i][1])*f]}
function head(c,x,y,dx,dy,S){
  const hx=x+dx*S*.16,hy=y+dy*S*.16,h=S*.34,w=S*.26;
  c.beginPath();c.moveTo(hx+dx*h*.55,hy+dy*h*.55);
  c.lineTo(hx-dx*h*.45-dy*w,hy-dy*h*.45+dx*w);c.lineTo(hx-dx*h*.45+dy*w,hy-dy*h*.45-dx*w);
  c.closePath();c.lineWidth=S*.06;c.fill();c.stroke();
}
function drawArrow(c,a,color,glow,S,X,Y,lockLeft){
  const p=a._path,n=a.cells.length,s0=a.t,s1=a.t+n-1;
  c.strokeStyle=color;c.fillStyle=color;c.lineWidth=S*.17;c.lineCap='round';c.lineJoin='round';
  if(glow){c.shadowColor=color;c.shadowBlur=S*.5}
  c.beginPath();let q=at(p,s0);const q0=q;c.moveTo(X(q[0]),Y(q[1]));
  for(let i=Math.floor(s0)+1;i<s1;i++)c.lineTo(X(p[i][0]),Y(p[i][1]));
  q=at(p,s1);c.lineTo(X(q[0]),Y(q[1]));c.stroke();
  let i=Math.min(p.length-2,Math.floor(s1));head(c,X(q[0]),Y(q[1]),p[i+1][0]-p[i][0],p[i+1][1]-p[i][1],S);
  if(a.two&&a.state!=='leaving'){i=Math.max(0,Math.floor(s0));head(c,X(q0[0]),Y(q0[1]),p[i][0]-p[i+1][0],p[i][1]-p[i+1][1],S)}
  c.shadowBlur=0;
  if(a.ice&&a.state!=='leaving'){
    c.save();c.globalAlpha=.55;c.fillStyle=C.ice;c.strokeStyle='#fff';c.lineWidth=Math.max(1,S*.04);
    for(let k=0;k<n;k++){const [x,y]=at(p,s0+k);c.beginPath();c.roundRect?c.roundRect(X(x)-S*.38,Y(y)-S*.38,S*.76,S*.76,S*.16):c.rect(X(x)-S*.38,Y(y)-S*.38,S*.76,S*.76);c.fill();c.globalAlpha=.9;c.stroke();c.globalAlpha=.55}
    c.restore();
  }
  if(lockLeft>0&&a.state!=='leaving'){
    const m=at(p,s0+Math.floor((n-1)/2));const r=S*.3;
    c.fillStyle=C.surf;c.strokeStyle=color;c.lineWidth=Math.max(1.5,S*.06);
    c.beginPath();c.arc(X(m[0]),Y(m[1]),r,0,7);c.fill();c.stroke();
    c.fillStyle=color;c.font=`800 ${Math.round(r*1.2)}px ${tok('--font')||'sans-serif'}`;c.textAlign='center';c.textBaseline='middle';
    c.fillText(ar(lockLeft),X(m[0]),Y(m[1])+r*.08);
  }
}
const arrowColor=a=>P.colored?C.a[(a.c-1)%5]:C.ink;

function burst(x,y,dx,dy,color,n=10,spread=1.6){
  for(let i=0;i<n;i++){const ang=Math.atan2(dy,dx)+(Math.random()-.5)*spread,sp=60+Math.random()*160;
    parts.push({x,y,vx:Math.cos(ang)*sp,vy:Math.sin(ang)*sp,life:0,max:.45+Math.random()*.35,r:1.5+Math.random()*2.5,color})}
}
function celebrate(){for(let i=0;i<70;i++){const ang=Math.random()*Math.PI*2,sp=80+Math.random()*260;
  parts.push({x:CW/2,y:CH/2,vx:Math.cos(ang)*sp,vy:Math.sin(ang)*sp-60,life:0,max:.9+Math.random()*.8,r:2+Math.random()*3,color:C.a[i%5],g:240})}}

let lastT=performance.now(),lastTick=-1;
function frame(now){
  const dt=Math.min(.05,(now-lastT)/1000);lastT=now;
  if(!$('game').hidden&&G&&S){
    if(!ended&&!paused){elapsed+=dt;
      if(limit){const left=limit-elapsed;$('clock').textContent=T('time',{t:fmt(left)});$('clock').classList.toggle('hurry',left<=10);
        if(left<=10&&Math.ceil(left)!==lastTick){lastTick=Math.ceil(left);sfx('tick')}
        if(left<=0){ended=true;timeUp()}}
      else $('clock').textContent=fmt(elapsed);
    }
    ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,CW,CH);
    // board silhouette + dots
    if(G.shape!=='rect'){ctx.fillStyle=C.cell;for(let y=0;y<G.H;y++)for(let x=0;x<G.W;x++)if(G.mask[y][x])ctx.fillRect(OX+x*S-.5,OY+y*S-.5,S+1,S+1)}
    ctx.fillStyle=C.dot;
    for(let y=0;y<G.H;y++)for(let x=0;x<G.W;x++)if(G.mask[y][x]){ctx.beginPath();ctx.arc(cx(x),cy(y),Math.max(1.5,S*.05),0,7);ctx.fill()}
    if(now<guideUntil){
      ctx.save();ctx.setLineDash([S*.12,S*.18]);ctx.lineWidth=Math.max(1,S*.05);ctx.globalAlpha=Math.min(.6,(guideUntil-now)/600);
      const occ=occNow();
      for(const a of G.arrows){if(a.state!=='idle')continue;
        for(const rev of a.two?[false,true]:[false]){const [[hx,hy],[dx,dy]]=headOf(a,rev);
          ctx.strokeStyle=!locked(a)&&rayCheck(a,occ,G.W,G.H,rev)===-1?C.acc:C.dot;
          ctx.beginPath();ctx.moveTo(cx(hx)+dx*S*.45,cy(hy)+dy*S*.45);
          ctx.lineTo(cx(dx>0?G.W-.5:dx<0?-.5:hx),cy(dy>0?G.H-.5:dy<0?-.5:hy));ctx.stroke()}}
      ctx.restore();
    }
    const rm=removed();
    for(const a of G.arrows){
      if(a.state==='gone')continue;pathFor(a,G.W,G.H);
      if(a.state==='leaving'){a.v=Math.min(28,(a.v||6)+dt*75);a.t+=a.v*dt;
        if(now-(a.trailAt||0)>75&&parts.length<260){const tp=at(a._path,a.t+a.cells.length-1);parts.push({x:cx(tp[0]),y:cy(tp[1]),vx:(Math.random()-.5)*22,vy:(Math.random()-.5)*22,life:0,max:.22+Math.random()*.16,r:1+Math.random()*1.5,color:arrowColor(a)});a.trailAt=now}
        if(!a.burst){const h=at(a._path,a.t+a.cells.length-1);
          if(h[0]<-.5||h[1]<-.5||h[0]>G.W-.5||h[1]>G.H-.5){a.burst=true;const [dx,dy]=headDir(a);burst(cx(h[0]),cy(h[1]),dx,dy,arrowColor(a))}}
        if(a.t>a.cells.length+G.W+G.H){a.state='gone';continue}}
      if(a.state==='bump'){a.bt+=dt;const T=.42;a.t=a.reach*Math.sin(Math.min(1,a.bt/T)*Math.PI);if(a.bt>=T){a.t=0;a.state='idle'}}
      let col=arrowColor(a),glow=false;
      if(a.state==='bump'||a.errUntil>now)col=C.dan;
      else if(a.id===hintId&&now<hintUntil){col=C.acc;glow=true}
      if(a.shakeUntil>now){ctx.save();ctx.translate(Math.sin(now/25)*S*.06,0)}
      drawArrow(ctx,a,col,glow,S,cx,cy,a.lock?a.lock-rm:0);
      if(a.shakeUntil>now)ctx.restore();
    }
    for(const r of ripples){r.life+=dt;const k=r.life/.4;ctx.globalAlpha=Math.max(0,1-k)*.5;ctx.strokeStyle=r.color;ctx.lineWidth=2;
      ctx.beginPath();ctx.arc(r.x,r.y,S*.2+k*S*.5,0,7);ctx.stroke()}
    ripples=ripples.filter(r=>r.life<.4);
    for(const p of parts){p.life+=dt;p.vy+=(p.g||0)*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=.97;p.vy*=.97;
      ctx.globalAlpha=Math.max(0,1-p.life/p.max);ctx.fillStyle=p.color;ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,7);ctx.fill()}
    parts=parts.filter(p=>p.life<p.max);ctx.globalAlpha=1;
    if(!ended&&G.arrows.every(a=>a.state==='gone'))win();
  }
  requestAnimationFrame(frame);
}

/* ---------- input ---------- */
function pick(px,py){
  const gx=(px-OX)/S-.5,gy=(py-OY)/S-.5;let best=null,bd=.88;
  for(const a of G.arrows){if(a.state!=='idle')continue;
    for(const [x,y] of a.cells){const d=Math.hypot(x-gx,y-gy);if(d<bd){bd=d;best=a}}}
  return best;
}
cv.addEventListener('pointerdown',e=>{
  if(!G||ended||paused)return;const r=cv.getBoundingClientRect(),px=e.clientX-r.left,py=e.clientY-r.top;
  const a=pick(px,py);if(!a)return;
  ripples.push({x:px,y:py,life:0,color:C.ink});
  if(locked(a)){a.shakeUntil=performance.now()+300;sfx('lock');buzz(15);toast(T('lockToast',{n:ar(a.lock-removed())}));return}
  if(a.ice){a.ice=false;sfx('crack');buzz(12);P.st.ice++;store.set('mk_st',P.st);checkAch();for(const [x,y] of a.cells)burst(cx(x),cy(y),0,-1,C.ice,4,6.3);return}
  const m=canExit(a,occNow());
  if(m.ok){
    if(m.rev){a.cells.reverse();a._path=null}
    if(a.lock)unlock('lock_1');if(a.two)unlock('two_1');
    a.state='leaving';a.v=6;sfx('whoosh',.8+Math.random()*.4);buzz(8);if(hintId===a.id)hintId=-1;updateLeft();
  }else{
    a.state='bump';a.bt=0;a.reach=m.k+.28;a.errUntil=performance.now()+700;sfx('bump');buzz([30,40,30]);
    mistakes++;hearts--;renderHearts();if(hearts<=0){ended=true;setTimeout(lose,500)}
  }
});

/* ---------- results ---------- */
function overlay({stars,t,p,b,fn,b2,fn2,b3,fn3}){
  $('ovStars').innerHTML=stars==null?'':[1,2,3].map(k=>starSvg(k<=stars)).join('');
  $('ovT').textContent=t;$('ovP').textContent=p;
  const set=(id,label,f)=>{const el=$(id);el.hidden=!label;if(label){el.innerHTML=label;el.onclick=f}};
  set('ovB',b,fn);set('ovB2',b2,fn2);set('ovB3',b3,fn3);
  $('ov').hidden=false;setTimeout(()=>$('ovB').focus(),50);
}
// interstitial after every second completed level, shown before the next screen
const afterAd=fn=>()=>{$('ov').hidden=true;if(pendingAd){pendingAd=false;Ads.interstitial().then(fn)}else fn()};
const goHome=()=>{Ads.banner(false);show('home')};
function win(){
  ended=true;sfx('win');buzz([10,60,10]);celebrate();
  P.wins++;if(P.wins%2===0)pendingAd=true;
  if(cfg.timed)unlock('timed_1');
  if(G.arrows.length>=15&&elapsed<20)unlock('speed');
  if(!usedHelp&&(mode==='daily'||level>=10))unlock('no_help');
  if(cfg.shape!=='rect')P.st.shapes[cfg.shape]=1;
  const stars=hearts,time=T('time',{t:fmt(elapsed)}),resultMeta=time+' · '+T('mistakes',{n:ar(mistakes)});
  setTimeout(()=>{
    if(mode==='daily'){
      const today=dayKey();
      if(P.daily.last!==today){P.daily.streak=P.daily.last===yesterday()?P.daily.streak+1:1;P.daily.last=today}
      P.st.bestStreak=Math.max(P.st.bestStreak,P.daily.streak);
      if(!P.st.dailyBest||elapsed<P.st.dailyBest)P.st.dailyBest=Math.round(elapsed*10)/10;
      save();checkAch();submitAll();
      overlay({stars,t:T('dailyDoneT'),p:resultMeta+' · '+T('streakN',{n:ar(P.daily.streak)}),
        b:T('continueLevels'),fn:afterAd(()=>startGame('level',P.unlocked)),b2:T('home'),fn2:afterAd(goHome)});
    }else{
      if((P.stars[level]||0)<stars)P.stars[level]=stars;
      if(level>=P.unlocked)P.unlocked=level+1;
      let rewardText='';if(!P.rewardedLevels[level]){const earned=10+stars*10;P.coins+=earned;P.rewardedLevels[level]=true;touchEconomy();rewardText=' · '+T('rewardEarned',{n:ar(earned)});}
      save();checkAch();submitAll();
      overlay({stars,t:T(stars===3?'perfectT':'wellDone'),p:resultMeta+rewardText,b:T('levelN',{n:ar(level+1)}),fn:afterAd(()=>startGame('level',level+1)),
        b2:T('home'),fn2:afterAd(goHome)});
    }
  },650);
}
function lose(){
  overlay({stars:null,t:T('outLives'),p:T('outLivesP'),
    b:PLAY+T('watchLife'),fn:()=>{$('ov').hidden=true;Ads.rewarded(T('watchLifeMsg'),true).then(ok=>{
      if(ok){hearts=1;renderHearts();ended=false;toast(T('gotLife'))}else lose()})},
    b3:T('restartLevel'),fn3:()=>startGame(mode,level),b2:T('home'),fn2:()=>{$('ov').hidden=true;goHome()}});
}
function timeUp(){
  sfx('bump');buzz([40,60,40]);
  overlay({stars:null,t:T('timeUp'),p:T('timeUpP',{n:ar(alive().length)}),
    b:PLAY+T('watchTime'),fn:()=>{$('ov').hidden=true;Ads.rewarded(T('watchTimeMsg'),true).then(ok=>{
      if(ok){limit=elapsed+30;ended=false;toast(T('plus30'))}else timeUp()})},
    b3:T('restartLevel'),fn3:()=>startGame(mode,level),b2:T('home'),fn2:()=>{$('ov').hidden=true;goHome()}});
}

/* ---------- tools ---------- */
$('bRestart').onclick=()=>{if(ended)return;
  Ads.rewarded(T('restartMsg'),true).then(ok=>{if(ok)startGame(mode,level);else if(ok===false)toast(T('adIncomplete'))})};
function refill(kind){
  const name=T(kind==='hints'?'hintsName':'guidesName');
  Ads.rewarded(T('refillMsg',{what:name})).then(ok=>{
    if(ok){P[kind]+=3;save();updateTools();toast(T('refillToast',{what:name}))}else if(ok===false)toast(T('adIncomplete'))});
}
$('bHint').onclick=()=>{
  if(ended)return;if(P.hints<=0)return refill('hints');
  const occ=occNow();const free=G.arrows.filter(a=>a.state==='idle'&&!locked(a)&&canExit(a,occ).ok);
  if(!free.length){toast(T('waitMoving'));return}
  hintId=free[Math.floor(Math.random()*free.length)].id;hintUntil=performance.now()+2200;P.hints--;usedHelp=true;save();updateTools();
};
$('bGuide').onclick=()=>{
  if(ended)return;if(P.guides<=0)return refill('guides');
  guideUntil=performance.now()+6000;P.guides--;usedHelp=true;save();updateTools();toast(T('pathsShown'));
};
$('gHome').onclick=goHome;
$('lBack').onclick=()=>show('home');
$('hPlay').onclick=()=>startGame('level',P.unlocked);
$('hDaily').onclick=()=>startGame('daily',0);
$('hLevels').onclick=()=>show('levels');
$('hAch').onclick=()=>Play.showAchievements();
$('hLb').onclick=()=>Play.showLeaderboards();
$('aBack').onclick=()=>show('home');
$('lbBack').onclick=()=>show('home');

/* ---------- coins, daily reward and tool shop ---------- */
function touchEconomy(){P.economyUpdatedAt=Date.now()}
function economyPanel(title,body,buttons){
  $('ecoTitle').textContent=title;$('ecoBody').innerHTML=body;
  const actions=$('ecoActions');actions.innerHTML='';buttons.forEach(({label,run,disabled=false})=>{const b=document.createElement('button');b.type='button';b.textContent=label;b.disabled=disabled;b.onclick=run;actions.appendChild(b)});
  $('eco').hidden=false;
}
function closeEconomy(){$('eco').hidden=true;refreshHome()}
function claimDaily(){
  if(P.rewardDay===dayKey())return;
  const streak=(P.daily.last===dayKey()||P.daily.last===yesterday())?P.daily.streak:0;
  const amount=Math.min(60,25+streak*5);P.coins+=amount;P.rewardDay=dayKey();touchEconomy();save();refreshHome();
  economyPanel(T('dailyReward'),`<p>${T('dailyEarned',{n:ar(amount)})}</p><p>${T('coinsLabel')}: <b>${ar(P.coins)}</b></p>`,[{label:T('done'),run:closeEconomy}]);
}
function openShop(){
  const body=`<p>${T('coinsLabel')}: <b>${ar(P.coins)}</b></p><p>${T('buyHint')}</p><p>${T('buyPath')}</p>`;
  economyPanel(T('shop'),body,[
    {label:T('buyHint'),run:()=>buyTool('hints')},
    {label:T('buyPath'),run:()=>buyTool('guides')},
    {label:T('close'),run:closeEconomy}
  ]);
}
function buyTool(kind){
  if(P.coins<40){toast(T('notEnough'));return}
  P.coins-=40;if(kind==='hints')P.hints+=1;else P.guides+=1;touchEconomy();save();updateTools();openShop();
}
$('hReward').onclick=claimDaily;$('hShop').onclick=openShop;$('ecoClose').onclick=closeEconomy;

/* settings */
function seg(id,val,on){$(id).querySelectorAll('button').forEach(b=>{b.setAttribute('aria-pressed',b.dataset.v===String(val));
  b.onclick=()=>{on(b.dataset.v);save();seg(id,b.dataset.v,on)}})}
$('hSettings').onclick=()=>{
  seg('optSkin',P.skin,v=>{P.skin=v;document.documentElement.dataset.skin=v});
  seg('optColor',P.colored?1:0,v=>{P.colored=v==='1';drawLogo()});
  seg('optSound',P.sound?1:0,v=>{P.sound=v==='1';if(P.sound)sfx('whoosh')});
  seg('optVib',P.vib?1:0,v=>{P.vib=v==='1';buzz(20)});
  const sel=$('optLang');sel.innerHTML=LANGS.map(l=>`<option value="${l}" lang="${l}"${l===LANG?' selected':''}>${LANG_NAMES[l]}</option>`).join('');
  sel.onchange=()=>{P.lang=sel.value;save();applyLang()};
  $('setPrivacy').hidden=!(NB&&NB.privacyRequired());
  $('set').hidden=false;
};
$('setPrivacy').onclick=()=>{NB&&NB.privacyOptions()};
$('pgChip').onclick=()=>{if(NB&&Play.enabled&&!Play.signedIn)Play.signIn()};
$('setClose').onclick=()=>$('set').hidden=true;

function drawLogo(){
  const c=$('logo').getContext('2d');c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,440,300);
  const s=58,X=x=>70+(x+.5)*s,Y=y=>(y+.5)*s+5;
  c.fillStyle=C.dot;for(let y=0;y<5;y++)for(let x=0;x<6;x++){c.beginPath();c.arc(X(x),Y(y),3,0,7);c.fill()}
  const demo=[{cells:[[0,0],[1,0],[2,0],[2,1]],c:2},{cells:[[5,0],[5,1],[5,2]],c:3},{cells:[[0,4],[0,3],[0,2],[1,2],[2,2],[3,2]],c:1},
              {cells:[[4,4],[3,4],[2,4]],c:4},{cells:[[3,0],[3,1],[4,1]],c:5},{cells:[[4,3],[5,3],[5,4]],c:2}];
  for(const a of demo){a.t=0;pathFor(a,6,5);drawArrow(c,a,P.colored?C.a[a.c-1]:C.ink,false,s,X,Y,0)}
}
const recolor=()=>{readColors();drawLogo()};
matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change',recolor);
new MutationObserver(recolor).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme','data-skin']});
window.addEventListener('resize',layout);
new ResizeObserver(layout).observe($('stage'));
document.fonts?.ready.then(drawLogo);
function applyLang(){
  LANG=P.lang||detectLang();
  document.documentElement.lang=LANG;$('app').dir=LANG==='ar'?'rtl':'ltr';document.title=T('brand');
  document.querySelectorAll('[data-i]').forEach(el=>el.textContent=T(el.dataset.i));
  document.querySelectorAll('[data-ia]').forEach(el=>el.setAttribute('aria-label',T(el.dataset.ia)));
  refreshChip();
  for(const v of ['home','levels','ach','lb'])if(!$(v).hidden)show(v);
}
applyLang();
checkAch(true);
if(NB)NB.ready();
drawLogo();show('home');requestAnimationFrame(frame);
})();
