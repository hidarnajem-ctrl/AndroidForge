const fs=require('fs');
const html=fs.readFileSync(__dirname+'/app/src/main/assets/game.js','utf8');
const a=html.indexOf('/* ---------- board shapes ---------- */');
const b=html.indexOf('/* ---------- views ---------- */',a);
const block=html.slice(a,b);
eval(block + `
let failed=[]; let totalArrows=0; let minArrows=Infinity; let maxArrows=0;
for(let n=1;n<=300;n++){
 const shape=n<4?'rect':SHAPE_ORDER[(n-4)%SHAPE_ORDER.length];
 const cfg={diff:n,seed:n*7919+101,shape,timed:n>=5&&n%5===0,lock:n>=6?.12:0,two:n>=9?.12:0,ice:n>=12?.12:0};
 const g=generate(cfg); const st=greedy(g.arrows,g.W,g.H);
 if(st.stuck.length) failed.push({n,stuck:st.stuck.length,arrows:g.arrows.length});
 totalArrows+=g.arrows.length;minArrows=Math.min(minArrows,g.arrows.length);maxArrows=Math.max(maxArrows,g.arrows.length);
}
console.log(JSON.stringify({levels:300,failed:failed.slice(0,10),failedCount:failed.length,totalArrows,minArrows,maxArrows}));
`);
