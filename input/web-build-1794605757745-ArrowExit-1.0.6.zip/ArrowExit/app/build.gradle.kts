import java.util.Properties
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Upload key for Google Play (keystore/keystore.properties + keystore/upload-key.jks).
// If the folder is missing, release builds come out unsigned and debug builds still work.
val keyProps = Properties().apply {
    val f = rootProject.file("keystore/keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
val hasUploadKey = keyProps.getProperty("storeFile")?.let { rootProject.file("keystore/$it").exists() } == true

android {
    namespace = "com.arrowexit.game"
    compileSdk = 36

    defaultConfig {
        // Change this to your own unique package name before the first upload to Google Play.
        // It can never be changed after that.
        applicationId = "com.arrowexit.game"
        minSdk = 26
        targetSdk = 36
        versionCode = 13
        versionName = "1.0.6"
    }

    signingConfigs {
        if (hasUploadKey) {
            create("upload") {
                storeFile = rootProject.file("keystore/" + keyProps.getProperty("storeFile"))
                storePassword = keyProps.getProperty("storePassword")
                keyAlias = keyProps.getProperty("keyAlias")
                keyPassword = keyProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        release {
            if (hasUploadKey) signingConfig = signingConfigs.getByName("upload")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    // Cloud builders have no one to read lint reports; don't let a lint warning stop the release build.
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
}

dependencies {
    implementation("androidx.core:core-ktx:1.16.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.webkit:webkit:1.14.0")
    implementation("androidx.core:core-splashscreen:1.0.1")

    // In-app review prompt (Google Play decides when it is actually shown)
    implementation("com.google.android.play:review-ktx:2.0.2")

    // Ads + consent (GDPR / UK consent message required by AdMob)
    implementation("com.google.android.gms:play-services-ads:25.5.0")
    implementation("com.google.android.ump:user-messaging-platform:3.2.0")

    // Google Play Games Services v2
    implementation("com.google.android.gms:play-services-games-v2:22.1.0")
}
