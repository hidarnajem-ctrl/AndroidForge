package com.arrowexit.game

import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.webkit.JavascriptInterface

/**
 * Methods the game page can call as window.AndroidBridge.*.
 * They arrive on a background thread, so anything touching views is posted to the UI thread.
 */
class WebBridge(private val act: MainActivity) {

    private fun ui(block: () -> Unit) = act.runOnUiThread(block)

    /** The page has loaded and window.NativeEvents is ready to receive events. */
    @JavascriptInterface fun ready() = ui { act.onPageReady() }

    // ---- ads ----
    @JavascriptInterface fun setBanner(show: Boolean) = ui { act.ads.setBanner(show) }
    @JavascriptInterface fun showInterstitial(id: Int) = ui { act.ads.showInterstitial(id) }
    @JavascriptInterface fun showRewarded(id: Int) = ui { act.ads.showRewarded(id) }
    @JavascriptInterface fun privacyRequired(): Boolean = act.ads.privacyOptionsRequired()
    @JavascriptInterface fun privacyOptions() = ui { act.ads.showPrivacyOptions() }

    // ---- Play Games ----
    @JavascriptInterface fun pgsSignIn() = ui { act.games.signIn() }
    @JavascriptInterface fun pgsUnlock(key: String) = ui { act.games.unlock(key) }
    @JavascriptInterface fun pgsSteps(key: String, steps: Double) = ui { act.games.setSteps(key, steps.toInt()) }
    @JavascriptInterface fun pgsSubmit(board: String, score: Double) = ui { act.games.submitScore(board, score.toLong()) }
    @JavascriptInterface fun pgsShowAchievements() = ui { act.games.showAchievements() }
    @JavascriptInterface fun pgsShowLeaderboards() = ui { act.games.showLeaderboards() }
    @JavascriptInterface fun pgsSave(json: String) = ui { act.games.saveProgress(json) }

    // ---- app integration ----
    @JavascriptInterface fun setInGame(playing: Boolean) = ui { act.setInGame(playing) }
    @JavascriptInterface fun requestReview() = ui { act.requestReview() }

    // ---- haptics (navigator.vibrate is not available inside a WebView) ----
    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            act.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            act.getSystemService(Vibrator::class.java)
        }
    }

    /** Plain buzz of a given length; kept for older pages. */
    @JavascriptInterface fun vibrate(ms: Double) {
        val duration = ms.toLong().coerceIn(1, 400)
        runCatching { vibrator?.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE)) }
    }

    /**
     * Named haptic effects so each action has its own feel:
     * tap, exit, lock, ice, error, win. Uses the phone's tuned system effects where available.
     */
    @JavascriptInterface fun haptic(kind: String) {
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        val predefined = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
        val amp = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && v.hasAmplitudeControl()
        val effect: VibrationEffect = when (kind) {
            "tap" -> if (predefined) VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK)
                     else VibrationEffect.createOneShot(6, 60.coerceAmp(amp))
            "exit" -> if (predefined) VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
                      else VibrationEffect.createOneShot(10, 120.coerceAmp(amp))
            "lock", "ice" -> if (predefined) VibrationEffect.createPredefined(VibrationEffect.EFFECT_HEAVY_CLICK)
                             else VibrationEffect.createOneShot(16, 200.coerceAmp(amp))
            "error" -> if (amp) VibrationEffect.createWaveform(longArrayOf(0, 28, 45, 40), intArrayOf(0, 220, 0, 255), -1)
                       else VibrationEffect.createWaveform(longArrayOf(0, 28, 45, 40), -1)
            "win" -> if (amp) VibrationEffect.createWaveform(longArrayOf(0, 12, 70, 12, 70, 30), intArrayOf(0, 120, 0, 170, 0, 255), -1)
                     else VibrationEffect.createWaveform(longArrayOf(0, 12, 70, 12, 70, 30), -1)
            else -> VibrationEffect.createOneShot(10, VibrationEffect.DEFAULT_AMPLITUDE)
        }
        runCatching { v.vibrate(effect) }
    }

    private fun Int.coerceAmp(supported: Boolean) = if (supported) coerceIn(1, 255) else VibrationEffect.DEFAULT_AMPLITUDE
}
