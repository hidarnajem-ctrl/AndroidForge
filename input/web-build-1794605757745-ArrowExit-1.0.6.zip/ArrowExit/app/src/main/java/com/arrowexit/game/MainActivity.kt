package com.arrowexit.game

import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.view.WindowManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import com.google.android.play.core.review.ReviewManagerFactory

/**
 * Hosts the game page (assets/index.html) in a WebView, with a native AdMob banner under it.
 * The page talks to Android through [WebBridge] (window.AndroidBridge) and receives events
 * through window.NativeEvents (see [runJs]).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    lateinit var ads: AdsManager
        private set
    lateinit var games: PlayGamesManager
        private set

    /** Set once the page reports it is ready; the launch screen stays up until then. */
    @Volatile private var pageReady = false
    private var reviewAsked = false
    /** False once the WebView renderer has died and the view was destroyed. */
    private var webAlive = true

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        // Must run before super.onCreate. Hold the launch screen until the game has drawn,
        // with a safety timeout so a slow device never gets stuck on it.
        val splash = installSplashScreen()
        val startedAt = SystemClock.uptimeMillis()
        splash.setKeepOnScreenCondition { !pageReady && SystemClock.uptimeMillis() - startedAt < SPLASH_MAX_MS }

        super.onCreate(savedInstanceState)

        // Draw edge to edge, then pad the content so nothing sits under the status/navigation bars.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = !night
            isAppearanceLightNavigationBars = !night
        }
        val root = findViewById<View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        web = findViewById(R.id.web)
        web.setBackgroundColor(ContextCompat.getColor(this, R.color.bg))
        web.overScrollMode = View.OVER_SCROLL_NEVER
        // A game, not a document: no text-selection popups or long-press menus.
        web.isLongClickable = false
        web.setOnLongClickListener { true }
        web.isHapticFeedbackEnabled = false

        // Serve assets from https://appassets.androidplatform.net/assets/ so localStorage works normally.
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == ASSET_HOST) return false
                // Any outside link opens in the browser, never inside the game.
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, request.url)) }
                return true
            }

            override fun onPageFinished(view: WebView, url: String) {
                pageReady = true
            }

            // If the system kills the WebView's renderer (low memory), rebuild the screen
            // instead of letting the whole app crash. Progress is in localStorage, so nothing is lost.
            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                webAlive = false
                (view.parent as? android.view.ViewGroup)?.removeView(view)
                view.destroy()
                recreate()
                return true
            }
        }
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
            textZoom = 100
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
        }

        ads = AdsManager(this, findViewById<FrameLayout>(R.id.bannerHost), ::runJs)
        games = PlayGamesManager(this, ::runJs)
        web.addJavascriptInterface(WebBridge(this), "AndroidBridge")
        web.loadUrl("https://$ASSET_HOST/assets/index.html")

        // Back button: let the game close dialogs / go to its home screen first.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.NativeEvents?String(window.NativeEvents.back()):'false'") { result ->
                    if (result != "\"true\"") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })

        ads.start()
    }

    /** Called by the page (through the bridge) once its first screen is ready. */
    fun onPageReady() {
        pageReady = true
        games.onPageReady()
    }

    /** Keeps the screen awake while a level is being played, and only then. */
    fun setInGame(playing: Boolean) {
        if (playing) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    /**
     * Asks Google Play for its in-app review card. Play decides whether it actually appears
     * (it is rate limited), and the result never says whether the player rated, by design.
     */
    fun requestReview() {
        if (reviewAsked || isFinishing) return
        reviewAsked = true
        val manager = ReviewManagerFactory.create(this)
        manager.requestReviewFlow().addOnCompleteListener { task ->
            if (task.isSuccessful && !isFinishing) manager.launchReviewFlow(this, task.result)
        }
    }

    /** Runs JavaScript in the page on the UI thread. */
    fun runJs(script: String) {
        runOnUiThread { if (!isFinishing && webAlive && ::web.isInitialized) web.evaluateJavascript(script, null) }
    }

    override fun onPause() {
        // Tell the page first so it can pause its clock and silence audio while we are away.
        runJs("window.NativeEvents&&NativeEvents.appPause&&NativeEvents.appPause()")
        ads.onPause()
        if (webAlive) web.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (webAlive) web.onResume()
        ads.onResume()
        runJs("window.NativeEvents&&NativeEvents.appResume&&NativeEvents.appResume()")
    }

    override fun onDestroy() {
        ads.onDestroy()
        if (webAlive) web.destroy()
        super.onDestroy()
    }

    companion object {
        const val ASSET_HOST = "appassets.androidplatform.net"
        private const val SPLASH_MAX_MS = 2500L
    }
}
