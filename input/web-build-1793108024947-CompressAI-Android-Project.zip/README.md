# CompressAI Android wrapper

This Android project packages the original Google AI Studio HTML app in `app/src/main/assets/index.html`.
The original HTML, styling and JavaScript are kept as supplied. The Android WebView includes file chooser support so users can select images from the device.

Important: the HTML loads Tailwind CSS, Lucide icons, JSZip, and Google Fonts from external CDNs, so those visual/dependency resources require internet access. Also, the HTML's PDF branch does not actually compress PDF data; it retains the original payload while estimating a smaller size. The image branch uses browser canvas export, which is lossy for formats/quality settings where applicable and should not be described as guaranteed lossless.
