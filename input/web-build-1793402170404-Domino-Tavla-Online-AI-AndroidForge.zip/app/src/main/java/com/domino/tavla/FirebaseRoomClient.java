package com.domino.tavla;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Small Firebase Authentication + Realtime Database REST client. */
public final class FirebaseRoomClient {
    private final String apiKey;
    private final String databaseUrl;
    private String idToken;
    private String uid;

    public FirebaseRoomClient(String apiKey, String databaseUrl) {
        this.apiKey = apiKey == null ? "" : apiKey.trim();
        String cleaned = databaseUrl == null ? "" : databaseUrl.trim();
        while (cleaned.endsWith("/")) cleaned = cleaned.substring(0, cleaned.length() - 1);
        this.databaseUrl = cleaned;
    }

    public String getUid() { return uid; }

    public void signInAnonymously() throws Exception {
        JSONObject body = new JSONObject();
        body.put("returnSecureToken", true);
        JSONObject response = request("https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=" + apiKey,
                "POST", body, null);
        idToken = response.getString("idToken");
        uid = response.getString("localId");
    }

    public void createRoom(String code, String game) throws Exception {
        JSONObject room = new JSONObject();
        room.put("game", game);
        room.put("hostUid", uid);
        room.put("guestUid", JSONObject.NULL);
        room.put("status", "waiting");
        room.put("state", JSONObject.NULL);
        room.put("createdAt", System.currentTimeMillis());
        request(dbUrl("rooms/" + code + ".json"), "PUT", room, idToken);
    }

    public JSONObject getRoom(String code) throws Exception {
        return request(dbUrl("rooms/" + code + ".json"), "GET", null, idToken);
    }

    public void joinRoom(String code) throws Exception {
        // Realtime Database REST supports PUT consistently across Android versions.
        JSONObject room = getRoom(code);
        if (room.has("guestUid") && !room.isNull("guestUid") && !room.optString("guestUid").isEmpty())
            throw new IllegalStateException("الغرفة ممتلئة — يشارك فيها لاعبان بالفعل");
        room.put("guestUid", uid);
        room.put("status", "ready");
        request(dbUrl("rooms/" + code + ".json"), "PUT", room, idToken);
    }

    public void pushState(String code, JSONObject state) throws Exception {
        JSONObject room = getRoom(code);
        room.put("state", state);
        room.put("status", "playing");
        room.put("updatedAt", System.currentTimeMillis());
        request(dbUrl("rooms/" + code + ".json"), "PUT", room, idToken);
    }

    private String dbUrl(String path) throws Exception {
        if (databaseUrl.isEmpty()) throw new IllegalStateException("أدخل رابط Realtime Database الصحيح");
        return databaseUrl + "/" + path + "?auth=" + java.net.URLEncoder.encode(idToken, "UTF-8");
    }

    private JSONObject request(String address, String method, JSONObject body, String token) throws Exception {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(address).openConnection();
            connection.setRequestMethod(method);
            connection.setConnectTimeout(12000);
            connection.setReadTimeout(12000);
            connection.setUseCaches(false);
            connection.setRequestProperty("Accept", "application/json");
            if (body != null) {
                connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream out = connection.getOutputStream()) { out.write(bytes); }
            }
            int status = connection.getResponseCode();
            InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
            StringBuilder result = new StringBuilder();
            if (stream != null) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) result.append(line);
                }
            }
            if (status < 200 || status >= 300) {
                String message = result.toString();
                try { message = new JSONObject(message).optJSONObject("error").optString("message", message); }
                catch (Exception ignored) { }
                throw new IllegalStateException("Firebase " + status + ": " + message);
            }
            String value = result.toString();
            if (value.isEmpty() || "null".equals(value)) return new JSONObject();
            return new JSONObject(value);
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}
