package com.domino.tavla;

import android.content.Context;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;

/** Domino and backgammon UI with local AI and optional Firebase room synchronization. */
public class GameView extends View {
    private static final int HOME = 0;
    private static final int DOMINO = 1;
    private static final int TAVLA = 2;
    private static final int MODE_SCREEN = 3;
    private static final int WAITING_SCREEN = 4;
    private static final int MODE_LOCAL = 0;
    private static final int MODE_AI = 1;
    private static final int MODE_ONLINE = 2;

    private static final int BG = Color.rgb(15, 23, 38);
    private static final int PANEL = Color.rgb(27, 39, 59);
    private static final int PANEL_LIGHT = Color.rgb(39, 55, 78);
    private static final int GOLD = Color.rgb(238, 186, 94);
    private static final int TEAL = Color.rgb(52, 194, 171);
    private static final int CORAL = Color.rgb(226, 111, 104);
    private static final int CREAM = Color.rgb(245, 239, 222);
    private static final int INK = Color.rgb(36, 43, 54);
    private static final int WOOD = Color.rgb(112, 67, 43);
    private static final int WOOD_DARK = Color.rgb(76, 44, 32);

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random();
    private int screen = HOME;
    private float scale = 1f;
    private float logicalHeight = 1800f;
    private String homeMessage = "اختر اللعبة وابدأ التحدي";
    private int chosenGame = DOMINO;
    private int playMode = MODE_LOCAL;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService networkExecutor = Executors.newSingleThreadExecutor();
    private FirebaseRoomClient onlineClient;
    private String roomCode = "";
    private String networkMessage = "بانتظار اللاعب الآخر";
    private int onlinePlayerIndex = 0;
    private boolean onlineHost = false;
    private boolean onlineReady = false;
    private boolean pollInFlight = false;
    private boolean applyingRemoteState = false;
    private long onlineRevision = -1;
    private final Runnable aiDominoRunnable = this::runDominoAi;
    private final Runnable aiTavlaRunnable = this::runTavlaAi;

    // ------------------------------ DOMINO ------------------------------
    private static class Tile {
        int a, b;
        Tile(int a, int b) { this.a = a; this.b = b; }
        int pips() { return a + b; }
    }
    private static class PlacedTile {
        int left, right;
        PlacedTile(int left, int right) { this.left = left; this.right = right; }
    }
    private final ArrayList<Tile> stock = new ArrayList<>();
    private final ArrayList<Tile>[] dominoHands = new ArrayList[]{new ArrayList<Tile>(), new ArrayList<Tile>()};
    private final ArrayList<PlacedTile> chain = new ArrayList<>();
    private int dominoPlayer = 0;
    private int selectedTile = -1;
    private boolean dominoReveal = false;
    private int blockedPasses = 0;
    private boolean dominoOver = false;
    private int dominoWinner = -1;
    private String dominoStatus = "ابدأ بوضع أي قطعة على الطاولة";
    private String dominoResult = "";

    // ------------------------------ BACKGAMMON ------------------------------
    private static class BoardState {
        int[] points = new int[24]; // positive: player 1, negative: player 2
        int[] bar = new int[2];
        int[] off = new int[2];
        BoardState copy() {
            BoardState b = new BoardState();
            b.points = points.clone();
            b.bar = bar.clone();
            b.off = off.clone();
            return b;
        }
    }
    private static class Move {
        int from, to, die; // from=-2 means bar; to=-1 means bear off
        Move(int from, int to, int die) { this.from = from; this.to = to; this.die = die; }
        @Override public boolean equals(Object obj) {
            if (!(obj instanceof Move)) return false;
            Move m = (Move) obj;
            return from == m.from && to == m.to && die == m.die;
        }
        @Override public int hashCode() { return from * 10000 + to * 100 + die; }
    }
    private BoardState tavla = new BoardState();
    private int tavlaPlayer = 0;
    private final ArrayList<Integer> dice = new ArrayList<>();
    private int selectedFrom = Integer.MIN_VALUE;
    private int selectedDie = -1;
    private boolean diceRolled = false;
    private boolean tavlaOver = false;
    private int tavlaWinner = -1;
    private String tavlaStatus = "اضغط (رمي النرد) لبدء الدور";
    private ArrayList<Move> cachedMoves = new ArrayList<>();

    public GameView(Context context) {
        super(context);
        setFocusable(true);
        setTag("game_view");
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    public void goHome() {
        if (playMode == MODE_ONLINE) stopOnlineSession();
        mainHandler.removeCallbacks(aiDominoRunnable);
        mainHandler.removeCallbacks(aiTavlaRunnable);
        screen = HOME;
        homeMessage = "اختر اللعبة وابدأ التحدي";
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        scale = Math.min(getWidth() / 900f, getHeight() / 1300f);
        if (scale <= 0f) scale = 1f;
        logicalHeight = getHeight() / scale;
        canvas.save();
        canvas.scale(scale, scale);
        drawBackground(canvas);
        if (screen == HOME) drawHome(canvas);
        else if (screen == MODE_SCREEN) drawModeScreen(canvas);
        else if (screen == WAITING_SCREEN) drawWaitingScreen(canvas);
        else if (screen == DOMINO) drawDomino(canvas);
        else if (screen == TAVLA) drawTavla(canvas);
        canvas.restore();
    }

    private void drawBackground(Canvas c) {
        c.drawColor(BG);
        // Quiet decorative glow circles.
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.argb(22, 52, 194, 171));
        c.drawCircle(40, logicalHeight * 0.18f, 240, p);
        p.setColor(Color.argb(18, 238, 186, 94));
        c.drawCircle(850, logicalHeight * 0.80f, 290, p);
    }

    // ------------------------------ DRAW HELPERS ------------------------------
    private void fill(Paint paint, int color) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(color);
        paint.setStrokeWidth(1f);
    }

    private void rounded(Canvas c, float l, float t, float r, float b, float radius, int color) {
        fill(p, color);
        c.drawRoundRect(new RectF(l, t, r, b), radius, radius, p);
    }

    private void outline(Canvas c, float l, float t, float r, float b, float radius, int color, float width) {
        p.setStyle(Paint.Style.STROKE);
        p.setColor(color);
        p.setStrokeWidth(width);
        c.drawRoundRect(new RectF(l, t, r, b), radius, radius, p);
        p.setStyle(Paint.Style.FILL);
    }

    private void text(Canvas c, String value, float x, float y, float size, int color, boolean bold) {
        // StaticLayout performs proper Arabic shaping and bidirectional text layout.
        textPaint.setColor(color);
        textPaint.setTextSize(size);
        textPaint.setTypeface(bold ? Typeface.create("sans-serif", Typeface.BOLD) : Typeface.create("sans-serif", Typeface.NORMAL));
        textPaint.setTextLocale(new Locale("ar"));
        int textWidth = 860;
        StaticLayout layout = StaticLayout.Builder.obtain(value, 0, value.length(), textPaint, textWidth)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setIncludePad(false)
                .setMaxLines(2)
                .build();
        c.save();
        c.translate(x - textWidth / 2f, y - layout.getHeight() / 2f);
        layout.draw(c);
        c.restore();
    }

    private void leftText(Canvas c, String value, float x, float y, float size, int color, boolean bold) {
        fill(p, color);
        p.setTextSize(size);
        p.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        p.setTextAlign(Paint.Align.LEFT);
        p.setTextLocale(new Locale("ar"));
        c.drawText(value, x, y, p);
    }

    private void pill(Canvas c, String label, float l, float t, float r, float b, int color, int textColor) {
        rounded(c, l, t, r, b, 24, color);
        text(c, label, (l + r) / 2f, (t + b) / 2f + 10, 27, textColor, true);
    }

    private void drawTopBar(Canvas c, String title) {
        float h = logicalHeight;
        rounded(c, 28, 24, 872, h * 0.095f, 28, PANEL);
        text(c, title, 450, h * 0.075f, 42, CREAM, true);
        pill(c, "رجوع", 48, 48, 180, h * 0.095f - 8, PANEL_LIGHT, CREAM);
        pill(c, "إعادة", 720, 48, 850, h * 0.095f - 8, PANEL_LIGHT, GOLD);
    }

    private void drawHome(Canvas c) {
        float h = logicalHeight;
        // Logo mark
        rounded(c, 325, h * 0.105f, 575, h * 0.215f, 44, PANEL);
        rounded(c, 365, h * 0.135f, 445, h * 0.185f, 12, GOLD);
        rounded(c, 455, h * 0.135f, 535, h * 0.185f, 12, TEAL);
        text(c, "دومينو وطاولة", 450, h * 0.285f, 62, CREAM, true);
        text(c, "ألعاب الطاولة الكلاسيكية على هاتفك", 450, h * 0.325f, 28, Color.rgb(174, 188, 205), false);

        float top = h * 0.405f;
        rounded(c, 65, top, 835, top + h * 0.19f, 32, PANEL);
        outline(c, 65, top, 835, top + h * 0.19f, 32, Color.rgb(67, 89, 112), 2);
        drawDominoMini(c, 225, top + h * 0.095f, 1.05f);
        text(c, "لعبة الدومينو", 595, top + h * 0.085f, 42, CREAM, true);
        text(c, "ضد الكمبيوتر • عبر الإنترنت", 595, top + h * 0.125f, 25, Color.rgb(174, 188, 205), false);
        pill(c, "العب الآن", 495, top + h * 0.145f, 760, top + h * 0.185f, GOLD, INK);

        float top2 = h * 0.625f;
        rounded(c, 65, top2, 835, top2 + h * 0.19f, 32, PANEL);
        outline(c, 65, top2, 835, top2 + h * 0.19f, 32, Color.rgb(67, 89, 112), 2);
        drawBackgammonMini(c, 225, top2 + h * 0.095f);
        text(c, "لعبة الطاولة", 595, top2 + h * 0.085f, 42, CREAM, true);
        text(c, "ضد الكمبيوتر • عبر الإنترنت", 595, top2 + h * 0.125f, 25, Color.rgb(174, 188, 205), false);
        pill(c, "العب الآن", 495, top2 + h * 0.145f, 760, top2 + h * 0.185f, TEAL, INK);

        text(c, homeMessage, 450, h * 0.88f, 26, Color.rgb(169, 183, 199), false);
        text(c, "اختر نمط اللعب: كمبيوتر أو أونلاين أو محلي", 450, h * 0.925f, 21, Color.rgb(112, 130, 151), false);
    }

    private void drawModeScreen(Canvas c) {
        float h = logicalHeight;
        drawTopBar(c, chosenGame == DOMINO ? "اختر نمط الدومينو" : "اختر نمط الطاولة");
        text(c, "كيف تريد أن تلعب؟", 450, h * 0.23f, 42, CREAM, true);
        rounded(c, 75, h * 0.32f, 825, h * 0.47f, 28, PANEL);
        text(c, "لاعب ضد الكمبيوتر", 450, h * 0.375f, 38, GOLD, true);
        text(c, "العب أنت والكمبيوتر ينافسك", 450, h * 0.425f, 25, Color.rgb(177, 191, 208), false);
        rounded(c, 75, h * 0.51f, 825, h * 0.66f, 28, PANEL);
        text(c, "لاعبان عبر الإنترنت", 450, h * 0.56f, 38, TEAL, true);
        text(c, "أنشئ غرفة أو أدخل رمز صديقك", 450, h * 0.615f, 25, Color.rgb(177, 191, 208), false);
        rounded(c, 75, h * 0.70f, 825, h * 0.84f, 28, PANEL);
        text(c, "لاعبان على نفس الهاتف", 450, h * 0.75f, 34, CREAM, true);
        text(c, "تناوبوا على الهاتف نفسه", 450, h * 0.80f, 24, Color.rgb(177, 191, 208), false);
        text(c, "اللعب عبر الإنترنت يحتاج إعداد Firebase مرة واحدة", 450, h * 0.90f, 22, Color.rgb(143, 160, 179), false);
    }

    private void drawWaitingScreen(Canvas c) {
        float h = logicalHeight;
        drawTopBar(c, "غرفة اللعب عبر الإنترنت");
        text(c, onlineHost ? "أرسل رمز الغرفة إلى صديقك" : "تم الانضمام إلى الغرفة", 450, h * 0.27f, 38, CREAM, true);
        rounded(c, 145, h * 0.37f, 755, h * 0.55f, 28, PANEL);
        text(c, roomCode, 450, h * 0.46f, 76, GOLD, true);
        text(c, networkMessage, 450, h * 0.64f, 28, TEAL, true);
        text(c, "ستبدأ اللعبة تلقائياً عند اتصال اللاعبين", 450, h * 0.72f, 24, Color.rgb(177, 191, 208), false);
        pill(c, "نسخ الرمز", 300, h * 0.80f, 600, h * 0.86f, GOLD, INK);
        text(c, "تأكد من اتصال الهاتفين بالإنترنت", 450, h * 0.92f, 21, Color.rgb(143, 160, 179), false);
    }

    private void drawDominoMini(Canvas c, float cx, float cy, float s) {
        float w = 42 * s, hh = 72 * s;
        c.save(); c.rotate(-17, cx, cy);
        rounded(c, cx - w, cy - hh / 2, cx + w, cy + hh / 2, 8, CREAM);
        p.setColor(Color.rgb(190, 181, 159)); p.setStrokeWidth(2); c.drawLine(cx, cy - hh / 2 + 5, cx, cy + hh / 2 - 5, p);
        drawPips(c, cx - w / 2, cy, 3, 7 * s, INK);
        drawPips(c, cx + w / 2, cy, 5, 7 * s, INK);
        c.restore();
    }

    private void drawBackgammonMini(Canvas c, float cx, float cy) {
        rounded(c, cx - 66, cy - 50, cx + 66, cy + 50, 10, WOOD);
        for (int i = 0; i < 6; i++) {
            float x = cx - 52 + i * 21;
            Path a = new Path(); a.moveTo(x - 8, cy - 43); a.lineTo(x + 8, cy - 43); a.lineTo(x, cy + 2); a.close();
            fill(p, i % 2 == 0 ? GOLD : CORAL); c.drawPath(a, p);
            Path b = new Path(); b.moveTo(x - 8, cy + 43); b.lineTo(x + 8, cy + 43); b.lineTo(x, cy - 2); b.close();
            fill(p, i % 2 == 0 ? CORAL : GOLD); c.drawPath(b, p);
        }
    }

    // ------------------------------ DOMINO LOGIC ------------------------------
    private void startDomino() {
        stock.clear(); chain.clear(); dominoHands[0].clear(); dominoHands[1].clear();
        for (int a = 0; a <= 6; a++) for (int b = a; b <= 6; b++) stock.add(new Tile(a, b));
        Collections.shuffle(stock, random);
        for (int i = 0; i < 7; i++) {
            dominoHands[0].add(stock.remove(stock.size() - 1));
            dominoHands[1].add(stock.remove(stock.size() - 1));
        }
        dominoPlayer = (playMode == MODE_LOCAL) ? random.nextInt(2) : 0;
        selectedTile = -1; dominoReveal = (playMode == MODE_AI) || (playMode == MODE_ONLINE);
        blockedPasses = 0; dominoOver = false; dominoWinner = -1; dominoResult = "";
        screen = DOMINO;
        updateDominoTurn();
        invalidate();
    }

    private boolean canPlayLeft(Tile t) {
        if (chain.isEmpty()) return true;
        int end = chain.get(0).left;
        return t.a == end || t.b == end;
    }
    private boolean canPlayRight(Tile t) {
        if (chain.isEmpty()) return true;
        int end = chain.get(chain.size() - 1).right;
        return t.a == end || t.b == end;
    }
    private boolean hasDominoMove(int player) {
        for (Tile t : dominoHands[player]) if (canPlayLeft(t) || canPlayRight(t)) return true;
        return false;
    }
    private void playDomino(int side) {
        if (dominoOver || selectedTile < 0 || selectedTile >= dominoHands[dominoPlayer].size()) return;
        Tile t = dominoHands[dominoPlayer].get(selectedTile);
        boolean valid = side == 0 ? canPlayLeft(t) : canPlayRight(t);
        if (!valid) {
            dominoStatus = side == 0 ? "هذه القطعة لا تطابق الطرف الأيسر" : "هذه القطعة لا تطابق الطرف الأيمن";
            invalidate(); return;
        }
        if (chain.isEmpty()) {
            chain.add(new PlacedTile(t.a, t.b));
        } else if (side == 0) {
            int end = chain.get(0).left;
            chain.add(0, t.a == end ? new PlacedTile(t.b, t.a) : new PlacedTile(t.a, t.b));
        } else {
            int end = chain.get(chain.size() - 1).right;
            chain.add(t.a == end ? new PlacedTile(t.a, t.b) : new PlacedTile(t.b, t.a));
        }
        dominoHands[dominoPlayer].remove(selectedTile);
        selectedTile = -1; blockedPasses = 0;
        if (dominoHands[dominoPlayer].isEmpty()) {
            dominoOver = true;
            dominoWinner = dominoPlayer;
            dominoResult = dominoWinnerName(dominoPlayer) + " فاز!";
            dominoStatus = "انتهت الجولة";
        } else {
            dominoPlayer = 1 - dominoPlayer;
            updateDominoTurn();
        }
        syncOnlineState();
        invalidate();
    }

    private void drawOneDomino() {
        if (dominoOver) return;
        if (hasDominoMove(dominoPlayer)) {
            dominoStatus = "لديك قطعة قابلة للعب؛ لا يمكنك السحب الآن";
        } else if (!stock.isEmpty()) {
            Tile t = stock.remove(stock.size() - 1);
            dominoHands[dominoPlayer].add(t);
            selectedTile = dominoHands[dominoPlayer].size() - 1;
            dominoStatus = "سحبت قطعة " + t.a + " | " + t.b + " — جرّب لعبها أو اسحب مجدداً";
        } else {
            dominoStatus = "لا توجد قطع للسحب؛ اضغط (تمرير الدور)";
        }
        syncOnlineState();
        invalidate();
    }

    private void passDomino() {
        if (dominoOver) return;
        if (hasDominoMove(dominoPlayer)) {
            dominoStatus = "ما زالت لديك حركة ممكنة؛ العب قطعة أولاً";
            invalidate(); return;
        }
        if (!stock.isEmpty()) {
            dominoStatus = "اسحب قطعة من المخزون قبل التمرير";
            invalidate(); return;
        }
        blockedPasses++;
        selectedTile = -1;
        if (blockedPasses >= 2) {
            int s0 = handPips(0), s1 = handPips(1);
            dominoOver = true;
            if (s0 < s1) { dominoWinner = 0; dominoResult = dominoWinnerName(0) + " فاز بالنقاط: " + s0 + " مقابل " + s1; }
            else if (s1 < s0) { dominoWinner = 1; dominoResult = dominoWinnerName(1) + " فاز بالنقاط: " + s1 + " مقابل " + s0; }
            else { dominoWinner = -1; dominoResult = "تعادل! مجموع النقاط متساوٍ"; }
            dominoStatus = "أُغلقت اللعبة — انتهت الجولة";
        } else {
            dominoPlayer = 1 - dominoPlayer;
            updateDominoTurn();
        }
        syncOnlineState();
        invalidate();
    }

    private int handPips(int player) {
        int total = 0;
        for (Tile t : dominoHands[player]) total += t.pips();
        return total;
    }

    private void drawDomino(Canvas c) {
        float h = logicalHeight;
        drawTopBar(c, "لعبة الدومينو");
        rounded(c, 35, h * 0.115f, 865, h * 0.178f, 22, PANEL);
        text(c, "دور " + dominoPlayerName(dominoPlayer), 450, h * 0.145f, 35, GOLD, true);
        text(c, "قطع الخصم: " + dominoHands[1 - dominoPlayer].size() + "   •   المخزون: " + stock.size(), 450, h * 0.168f, 23, Color.rgb(178, 192, 209), false);

        // Board table and chain
        rounded(c, 35, h * 0.205f, 865, h * 0.59f, 28, WOOD_DARK);
        rounded(c, 48, h * 0.213f, 852, h * 0.582f, 22, WOOD);
        text(c, "سلسلة اللعب", 450, h * 0.245f, 25, Color.rgb(246, 215, 171), true);
        if (chain.isEmpty()) {
            text(c, "ضع أول قطعة لبدء السلسلة", 450, h * 0.405f, 34, Color.rgb(249, 225, 190), false);
        } else {
            int cols = 7;
            float tileW = 96, tileH = 58;
            float gapX = 14, gapY = 24;
            float totalW = cols * tileW + (cols - 1) * gapX;
            float startX = (900 - totalW) / 2f;
            float startY = h * 0.275f;
            for (int i = 0; i < chain.size(); i++) {
                int row = i / cols, col = i % cols;
                float x = startX + col * (tileW + gapX);
                float y = startY + row * (tileH + gapY);
                PlacedTile t = chain.get(i);
                drawTile(c, t.left, t.right, x, y, tileW, tileH, false);
            }
            text(c, "الطرف الأيسر: " + chain.get(0).left + "     |     الطرف الأيمن: " + chain.get(chain.size() - 1).right,
                    450, h * 0.555f, 23, Color.rgb(255, 224, 182), true);
        }

        // Player hand panel
        rounded(c, 35, h * 0.625f, 865, h * 0.845f, 25, PANEL);
        ArrayList<Tile> hand = dominoHands[dominoPlayer];
        boolean shouldHideHand = !dominoOver && ((playMode == MODE_AI && dominoPlayer == 1)
                || (playMode == MODE_ONLINE && dominoPlayer != onlinePlayerIndex)
                || (playMode == MODE_LOCAL && !dominoReveal));
        if (shouldHideHand) {
            if (playMode == MODE_AI && dominoPlayer == 1) {
                text(c, "الكمبيوتر يفكر ويختار حركته...", 450, h * 0.72f, 31, GOLD, true);
            } else if (playMode == MODE_ONLINE) {
                text(c, "انتظر حركة اللاعب الآخر", 450, h * 0.72f, 31, TEAL, true);
            } else {
                text(c, "مرّر الهاتف إلى " + dominoPlayerName(dominoPlayer), 450, h * 0.70f, 30, CREAM, true);
                text(c, "قطع اللاعب مخفية حتى يضغط جاهز", 450, h * 0.735f, 23, Color.rgb(172, 188, 204), false);
                pill(c, "أنا جاهز", 300, h * 0.765f, 600, h * 0.82f, GOLD, INK);
            }
        } else {
            text(c, "قطع " + dominoPlayerName(dominoPlayer), 450, h * 0.66f, 30, CREAM, true);
            if (hand.isEmpty() && dominoOver) {
                text(c, "لا توجد قطع متبقية", 450, h * 0.755f, 28, Color.rgb(172, 188, 204), false);
            } else {
                float tileW = Math.min(96f, 760f / Math.max(1, hand.size()) - 8f);
                tileW = Math.max(58f, tileW);
                float tileH = 102f;
                float gap = 8f;
                float total = hand.size() * tileW + Math.max(0, hand.size() - 1) * gap;
                float sx = (900 - total) / 2f;
                for (int i = 0; i < hand.size(); i++) {
                    float x = sx + i * (tileW + gap);
                    boolean selected = i == selectedTile;
                    drawTile(c, hand.get(i).a, hand.get(i).b, x, h * 0.69f, tileW, tileH, selected);
                }
            }
        }
        if (dominoOver) {
            rounded(c, 70, h * 0.85f, 830, h * 0.895f, 20, Color.rgb(31, 75, 73));
            text(c, dominoResult, 450, h * 0.88f, 30, CREAM, true);
            pill(c, "جولة جديدة", 300, h * 0.91f, 600, h * 0.955f, GOLD, INK);
        } else {
            text(c, dominoStatus, 450, h * 0.875f, 23, CREAM, false);
            if (dominoReveal) {
                pill(c, "العب يسار", 48, h * 0.895f, 300, h * 0.95f, GOLD, INK);
                pill(c, "العب يمين", 315, h * 0.895f, 565, h * 0.95f, TEAL, INK);
                pill(c, stock.isEmpty() ? "تمرير الدور" : "سحب قطعة", 580, h * 0.895f, 852, h * 0.95f, PANEL_LIGHT, CREAM);
            } else if (playMode == MODE_LOCAL) {
                text(c, "اضغط (أنا جاهز) بعد استلام الهاتف لعرض قطعك", 450, h * 0.925f, 20, Color.rgb(143, 160, 179), false);
            }
        }
    }

    private void drawTile(Canvas c, int a, int b, float x, float y, float w, float h, boolean selected) {
        if (selected) {
            rounded(c, x - 5, y - 6, x + w + 5, y + h + 6, 13, GOLD);
        }
        rounded(c, x, y, x + w, y + h, 10, CREAM);
        outline(c, x, y, x + w, y + h, 10, Color.rgb(184, 174, 151), 2);
        p.setColor(Color.rgb(177, 166, 143)); p.setStrokeWidth(2);
        c.drawLine(x + w / 2f, y + 7, x + w / 2f, y + h - 7, p);
        drawPips(c, x + w * 0.25f, y + h / 2f, a, Math.min(w, h) * 0.105f, INK);
        drawPips(c, x + w * 0.75f, y + h / 2f, b, Math.min(w, h) * 0.105f, INK);
    }

    private void drawPips(Canvas c, float cx, float cy, int count, float r, int color) {
        fill(p, color);
        float d = r * 2.9f;
        float[][] spots = {
                {-1, -1}, {1, -1}, {-1, 1}, {1, 1}, {0, 0}, {-1, 0}, {1, 0}
        };
        int[][] use = {
                {}, {4}, {0, 3}, {0, 4, 3}, {0, 1, 2, 3}, {0, 1, 4, 2, 3}, {0, 1, 5, 6, 2, 3}, {0, 1, 5, 4, 6, 2, 3}
        };
        if (count < 1 || count > 6) return;
        for (int idx : use[count]) {
            float sx = spots[idx][0];
            float sy = spots[idx][1];
            c.drawCircle(cx + sx * d * 0.42f, cy + sy * d * 0.42f, r, p);
        }
    }

    // ------------------------------ TAVLA LOGIC ------------------------------
    private void startTavla() {
        tavla = new BoardState();
        // Player 1 (positive) moves from point 24 toward point 1.
        tavla.points[23] = 2; tavla.points[12] = 5; tavla.points[7] = 3; tavla.points[5] = 5;
        // Player 2 (negative) moves from point 1 toward point 24.
        tavla.points[0] = -2; tavla.points[11] = -5; tavla.points[16] = -3; tavla.points[18] = -5;
        tavlaPlayer = 0; dice.clear(); selectedFrom = Integer.MIN_VALUE; selectedDie = -1;
        diceRolled = false; tavlaOver = false; tavlaWinner = -1;
        tavlaStatus = "اضغط (رمي النرد) لبدء الدور"; cachedMoves.clear();
        screen = TAVLA;
        updateTavlaTurn();
        invalidate();
    }

    private int signFor(int player) { return player == 0 ? 1 : -1; }
    private int enemy(int player) { return 1 - player; }

    private void rollTavlaDice() {
        if (tavlaOver || diceRolled) return;
        int a = random.nextInt(6) + 1;
        int b = random.nextInt(6) + 1;
        dice.clear();
        if (a == b) { dice.add(a); dice.add(a); dice.add(a); dice.add(a); }
        else { dice.add(a); dice.add(b); }
        diceRolled = true;
        selectedFrom = Integer.MIN_VALUE; selectedDie = -1;
        cachedMoves = optimalMoves(tavla, tavlaPlayer, dice);
        if (cachedMoves.isEmpty()) tavlaStatus = "لا توجد حركة متاحة — أنهِ الدور";
        else tavlaStatus = "" + tavlaPlayerName(tavlaPlayer) + " — اختر حجراً ثم حركة";
        syncOnlineState();
        invalidate();
    }

    private ArrayList<Move> rawMoves(BoardState state, int player, List<Integer> availableDice) {
        ArrayList<Move> moves = new ArrayList<>();
        int sign = signFor(player);
        if (state.bar[player] > 0) {
            for (int die : uniqueDice(availableDice)) {
                int dest = player == 0 ? 24 - die : die - 1;
                if (dest >= 0 && dest < 24 && state.points[dest] * sign >= -1) moves.add(new Move(-2, dest, die));
            }
            return moves;
        }
        boolean home = allInHome(state, player);
        for (int from = 0; from < 24; from++) {
            if (state.points[from] * sign <= 0) continue;
            for (int die : uniqueDice(availableDice)) {
                int to = from + (player == 0 ? -die : die);
                if (to >= 0 && to < 24) {
                    if (state.points[to] * sign >= -1) moves.add(new Move(from, to, die));
                } else if (home && canBearOff(state, player, from, die)) {
                    moves.add(new Move(from, -1, die));
                }
            }
        }
        return moves;
    }

    private ArrayList<Integer> uniqueDice(List<Integer> values) {
        ArrayList<Integer> out = new ArrayList<>();
        for (int v : values) if (!out.contains(v)) out.add(v);
        return out;
    }

    private boolean allInHome(BoardState state, int player) {
        if (state.bar[player] > 0) return false;
        if (player == 0) {
            for (int i = 6; i < 24; i++) if (state.points[i] > 0) return false;
        } else {
            for (int i = 0; i < 18; i++) if (state.points[i] < 0) return false;
        }
        return true;
    }

    private boolean canBearOff(BoardState state, int player, int from, int die) {
        int distance = player == 0 ? from + 1 : 24 - from;
        if (die < distance) return false;
        if (die == distance) return true;
        // An oversized die is only allowed when no checker is farther from the exit.
        if (player == 0) {
            for (int i = from + 1; i <= 5; i++) if (state.points[i] > 0) return false;
        } else {
            for (int i = 18; i < from; i++) if (state.points[i] < 0) return false;
        }
        return true;
    }

    private void applyMove(BoardState state, int player, Move move) {
        int sign = signFor(player);
        if (move.from == -2) state.bar[player]--;
        else state.points[move.from] -= sign;
        if (move.to == -1) {
            state.off[player]++;
        } else {
            int dest = state.points[move.to];
            if (dest * sign == -1) {
                state.points[move.to] = 0;
                state.bar[enemy(player)]++;
            }
            state.points[move.to] += sign;
        }
    }

    private ArrayList<Integer> removeDie(List<Integer> source, int die) {
        ArrayList<Integer> copy = new ArrayList<>(source);
        for (int i = 0; i < copy.size(); i++) if (copy.get(i) == die) { copy.remove(i); break; }
        return copy;
    }

    private int maxMoves(BoardState state, int player, List<Integer> availableDice) {
        if (availableDice.isEmpty()) return 0;
        ArrayList<Move> possible = rawMoves(state, player, availableDice);
        if (possible.isEmpty()) return 0;
        int best = 0;
        for (Move m : possible) {
            BoardState next = state.copy();
            applyMove(next, player, m);
            int value = 1 + maxMoves(next, player, removeDie(availableDice, m.die));
            if (value > best) best = value;
        }
        return best;
    }

    private ArrayList<Move> optimalMoves(BoardState state, int player, List<Integer> availableDice) {
        ArrayList<Move> possible = rawMoves(state, player, availableDice);
        ArrayList<Move> result = new ArrayList<>();
        int best = maxMoves(state, player, availableDice);
        for (Move m : possible) {
            BoardState next = state.copy();
            applyMove(next, player, m);
            if (1 + maxMoves(next, player, removeDie(availableDice, m.die)) == best) result.add(m);
        }
        // When only one of two different dice can be played, the higher die is compulsory
        // when both are individually legal but cannot both be used.
        if (availableDice.size() == 2 && best == 1 && !availableDice.get(0).equals(availableDice.get(1))) {
            int high = Math.max(availableDice.get(0), availableDice.get(1));
            boolean lowLegal = false, highLegal = false;
            for (Move m : possible) {
                if (m.die == high) highLegal = true;
                else lowLegal = true;
            }
            if (lowLegal && highLegal) {
                ArrayList<Move> filtered = new ArrayList<>();
                for (Move m : result) if (m.die == high) filtered.add(m);
                return filtered;
            }
        }
        return result;
    }

    private void selectTavlaDie(int die) {
        if (!diceRolled || tavlaOver) return;
        boolean found = false;
        for (Move m : cachedMoves) if (m.die == die) { found = true; break; }
        if (!found) {
            tavlaStatus = "هذا النرد لا يملك حركة قانونية الآن";
            invalidate(); return;
        }
        selectedDie = die;
        tavlaStatus = selectedFrom == Integer.MIN_VALUE ? "اختر حجراً يتحرك بهذا النرد" : "اختر نقطة الوصول";
        invalidate();
    }

    private void selectTavlaSource(int from) {
        if (!diceRolled || tavlaOver) return;
        boolean found = false;
        for (Move m : cachedMoves) if (m.from == from && (selectedDie == -1 || m.die == selectedDie)) { found = true; break; }
        if (!found) {
            tavlaStatus = from == -2 ? "لا يمكن إدخال حجر من الحاجز بهذه النردات" : "لا يوجد حجر قابل للحركة من هذه النقطة";
            selectedFrom = Integer.MIN_VALUE;
            invalidate(); return;
        }
        selectedFrom = from;
        if (selectedDie == -1) tavlaStatus = "اختر قيمة النرد ثم نقطة الوصول";
        else tavlaStatus = "اختر نقطة الوصول";
        invalidate();
    }

    private void tryTavlaDestination(int to) {
        if (selectedFrom == Integer.MIN_VALUE) {
            // A point tap first selects a source checker.
            selectTavlaSource(to);
            return;
        }
        Move chosen = null;
        for (Move m : cachedMoves) {
            if (m.from == selectedFrom && m.to == to && (selectedDie == -1 || m.die == selectedDie)) {
                chosen = m; break;
            }
        }
        if (chosen == null) {
            // Tapping another owned checker changes the source selection.
            selectTavlaSource(to);
            return;
        }
        executeTavlaMove(chosen);
    }

    private void executeTavlaMove(Move move) {
        applyMove(tavla, tavlaPlayer, move);
        ArrayList<Integer> remaining = removeDie(dice, move.die);
        dice.clear(); dice.addAll(remaining);
        selectedFrom = Integer.MIN_VALUE; selectedDie = -1;
        if (tavla.off[tavlaPlayer] >= 15) {
            tavlaOver = true; tavlaWinner = tavlaPlayer;
            tavlaStatus = "اللاعب " + (tavlaPlayer + 1) + " فاز! أخرج جميع أحجاره";
        } else {
            cachedMoves = optimalMoves(tavla, tavlaPlayer, dice);
            if (dice.isEmpty() || cachedMoves.isEmpty()) tavlaStatus = "انتهت حركاتك — اضغط إنهاء الدور";
            else tavlaStatus = "أحسنت! اختر حجراً للحركة التالية";
        }
        syncOnlineState();
        invalidate();
    }

    private void bearOffSelected() {
        if (!diceRolled || tavlaOver || selectedFrom < 0 || selectedDie == -1) {
            tavlaStatus = "اختر حجراً ونرداً صالحاً أولاً";
            invalidate();
            return;
        }
        for (Move m : cachedMoves) {
            if (m.from == selectedFrom && m.to == -1 && m.die == selectedDie) {
                executeTavlaMove(m);
                return;
            }
        }
        tavlaStatus = "لا يمكن إخراج هذا الحجر بهذا النرد؛ تأكد من دخول جميع أحجارك إلى البيت";
        invalidate();
    }

    private void finishTavlaTurn() {
        if (tavlaOver || !diceRolled) return;
        cachedMoves = optimalMoves(tavla, tavlaPlayer, dice);
        if (!cachedMoves.isEmpty()) {
            tavlaStatus = "لديك حركة قانونية متبقية؛ أكمل اللعب أولاً";
            invalidate(); return;
        }
        tavlaPlayer = 1 - tavlaPlayer;
        dice.clear(); selectedFrom = Integer.MIN_VALUE; selectedDie = -1;
        diceRolled = false; cachedMoves.clear();
        updateTavlaTurn();
        syncOnlineState();
        invalidate();
    }

    // ------------------------------ TAVLA DRAWING ------------------------------
    private float pointX(int column) {
        float left = 58f;
        float tri = 59f;
        float bar = 66f;
        if (column < 6) return left + tri * (column + 0.5f);
        return left + tri * 6 + bar + tri * (column - 5.5f);
    }

    private int pointForColumn(int column, boolean top) {
        return top ? 12 + column : 11 - column;
    }

    private int columnForPoint(int point) {
        if (point >= 12) return point - 12;
        return 11 - point;
    }

    private void drawTavla(Canvas c) {
        float h = logicalHeight;
        drawTopBar(c, "لعبة الطاولة");
        rounded(c, 35, h * 0.112f, 865, h * 0.172f, 22, PANEL);
        text(c, "دور " + tavlaPlayerName(tavlaPlayer) + (tavlaPlayer == 0 ? "  •  العاجي" : "  •  الأزرق"),
                450, h * 0.145f, 31, tavlaPlayer == 0 ? GOLD : TEAL, true);
        text(c, "على الحاجز: " + tavla.bar[tavlaPlayer] + "     •     خارج اللعب: " + tavla.off[tavlaPlayer] + " / 15",
                450, h * 0.166f, 22, Color.rgb(180, 194, 211), false);

        drawTavlaBoard(c, h);

        rounded(c, 35, h * 0.655f, 865, h * 0.955f, 26, PANEL);
        text(c, tavlaStatus, 450, h * 0.695f, 25, CREAM, false);

        // Dice chips
        if (diceRolled && !dice.isEmpty()) {
            float start = 450 - dice.size() * 42f;
            for (int i = 0; i < dice.size(); i++) {
                int value = dice.get(i);
                float x = start + i * 84f;
                boolean chosen = value == selectedDie;
                rounded(c, x - 27, h * 0.72f - 26, x + 27, h * 0.72f + 26, 9, chosen ? GOLD : CREAM);
                outline(c, x - 27, h * 0.72f - 26, x + 27, h * 0.72f + 26, 9, Color.rgb(185, 174, 151), 2);
                text(c, String.valueOf(value), x, h * 0.72f + 10, 34, INK, true);
                // A tap on this region selects this die.
            }
            text(c, "اضغط على النرد لاختياره", 450, h * 0.775f, 20, Color.rgb(164, 180, 199), false);
        } else if (!tavlaOver && diceRolled) {
            text(c, "استخدمت جميع حركات النرد", 450, h * 0.745f, 24, Color.rgb(172, 187, 204), false);
        } else if (!tavlaOver) {
            text(c, "ارمِ النرد لتحصل على حركتين (أو أربع عند الدبل)", 450, h * 0.745f, 24, Color.rgb(172, 187, 204), false);
        }

        if (tavlaOver) {
            rounded(c, 95, h * 0.82f, 805, h * 0.88f, 22, Color.rgb(29, 77, 70));
            text(c, "مبروك! " + tavlaPlayerName(tavlaWinner) + " فاز بالطاولة", 450, h * 0.862f, 32, CREAM, true);
            pill(c, "لعبة جديدة", 300, h * 0.89f, 600, h * 0.945f, GOLD, INK);
        } else {
            pill(c, "رمي النرد", 42, h * 0.835f, 315, h * 0.91f, diceRolled ? PANEL_LIGHT : GOLD, diceRolled ? CREAM : INK);
            pill(c, "إخراج الحجر", 323, h * 0.835f, 575, h * 0.91f, GOLD, INK);
            pill(c, "إنهاء الدور", 585, h * 0.835f, 858, h * 0.91f, TEAL, INK);
            text(c, "اختر حجراً ثم النرد ثم نقطة الوصول. لإخراج حجر استخدم زر (إخراج الحجر).",
                    450, h * 0.935f, 18, Color.rgb(143, 160, 179), false);
        }
    }

    private void drawTavlaBoard(Canvas c, float h) {
        float top = h * 0.19f;
        float center = h * 0.405f;
        float bottom = h * 0.62f;
        rounded(c, 31, top - 16, 869, bottom + 16, 24, WOOD_DARK);
        rounded(c, 42, top - 8, 858, bottom + 8, 19, WOOD);
        // Central bar
        rounded(c, 418, top, 482, bottom, 8, Color.rgb(67, 39, 28));
        rounded(c, 426, top + 10, 474, bottom - 10, 6, Color.rgb(133, 84, 52));

        // Points
        for (int col = 0; col < 12; col++) {
            float x = pointX(col);
            int topIndex = pointForColumn(col, true);
            int bottomIndex = pointForColumn(col, false);
            Path topTri = new Path();
            topTri.moveTo(x - 26, top + 5); topTri.lineTo(x + 26, top + 5); topTri.lineTo(x, center - 5); topTri.close();
            fill(p, col % 2 == 0 ? Color.rgb(219, 161, 91) : Color.rgb(51, 91, 91)); c.drawPath(topTri, p);
            Path bottomTri = new Path();
            bottomTri.moveTo(x - 26, bottom - 5); bottomTri.lineTo(x + 26, bottom - 5); bottomTri.lineTo(x, center + 5); bottomTri.close();
            fill(p, col % 2 == 0 ? Color.rgb(51, 91, 91) : Color.rgb(219, 161, 91)); c.drawPath(bottomTri, p);
            drawCheckerStack(c, topIndex, x, top + 25, 1, top, center);
            drawCheckerStack(c, bottomIndex, x, bottom - 25, -1, center, bottom);
        }

        // Bar stacks
        drawBar(c, 0, 438, center - 35, -1);
        drawBar(c, 1, 462, center + 35, 1);

        // Selected source and legal destinations
        if (diceRolled && !tavlaOver) {
            for (Move m : cachedMoves) {
                if (selectedFrom != Integer.MIN_VALUE && m.from != selectedFrom) continue;
                if (selectedDie != -1 && m.die != selectedDie) continue;
                if (m.to >= 0) {
                    int col = columnForPoint(m.to);
                    float x = pointX(col);
                    boolean isTop = m.to >= 12;
                    float yy = isTop ? top + 8 : bottom - 8;
                    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); p.setColor(TEAL);
                    c.drawCircle(x, yy, 20, p); p.setStyle(Paint.Style.FILL);
                }
            }
            if (selectedFrom >= 0 && selectedFrom < 24) {
                float x = pointX(columnForPoint(selectedFrom));
                boolean isTop = selectedFrom >= 12;
                float yy = isTop ? top + 8 : bottom - 8;
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setColor(GOLD);
                c.drawCircle(x, yy, 29, p); p.setStyle(Paint.Style.FILL);
            }
        }

        // Point labels
        for (int col = 0; col < 12; col++) {
            text(c, String.valueOf(pointForColumn(col, true) + 1), pointX(col), top - 2, 20, Color.rgb(255, 223, 185), false);
            text(c, String.valueOf(pointForColumn(col, false) + 1), pointX(col), bottom + 17, 20, Color.rgb(255, 223, 185), false);
        }
        // Bar text and bearing off button area.
        text(c, "الحاجز", 450, center - 8, 20, CREAM, true);
        text(c, "حاجز", 450, center + 19, 20, GOLD, true);
        text(c, "P1: " + tavla.off[0], 170, bottom + 14, 20, CREAM, true);
        text(c, "P2: " + tavla.off[1], 730, bottom + 14, 20, CREAM, true);
    }

    private void drawCheckerStack(Canvas c, int index, float x, float edgeY, int direction, float areaTop, float areaBottom) {
        int value = tavla.points[index];
        if (value == 0) return;
        int count = Math.abs(value);
        int color = value > 0 ? CREAM : Color.rgb(44, 66, 102);
        int outlineColor = value > 0 ? Color.rgb(168, 153, 126) : Color.rgb(125, 159, 199);
        float radius = 20;
        int visible = Math.min(count, 5);
        for (int i = 0; i < visible; i++) {
            float y = edgeY + direction * i * 37f;
            fill(p, color); c.drawCircle(x, y, radius, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2.5f); p.setColor(outlineColor);
            c.drawCircle(x, y, radius, p); p.setStyle(Paint.Style.FILL);
        }
        if (count > 5) {
            rounded(c, x - 17, edgeY + direction * 5 * 37f - 13, x + 17, edgeY + direction * 5 * 37f + 13, 8, GOLD);
            text(c, String.valueOf(count), x, edgeY + direction * 5 * 37f + 6, 17, INK, true);
        }
    }

    private void drawBar(Canvas c, int player, float x, float y, int direction) {
        int count = tavla.bar[player];
        if (count <= 0) return;
        int color = player == 0 ? CREAM : Color.rgb(44, 66, 102);
        for (int i = 0; i < Math.min(3, count); i++) {
            float yy = y + direction * i * 30;
            fill(p, color); c.drawCircle(x, yy, 13, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(GOLD); c.drawCircle(x, yy, 13, p); p.setStyle(Paint.Style.FILL);
        }
        text(c, String.valueOf(count), x, y + direction * 4 * 10, 16, GOLD, true);
    }

    // ------------------------------ TOUCH INPUT ------------------------------
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() != MotionEvent.ACTION_UP) return true;
        float x = event.getX() / scale;
        float y = event.getY() / scale;
        float h = logicalHeight;
        if (screen == HOME) {
            if (y > h * 0.39f && y < h * 0.60f) { chosenGame = DOMINO; screen = MODE_SCREEN; invalidate(); }
            else if (y > h * 0.61f && y < h * 0.83f) { chosenGame = TAVLA; screen = MODE_SCREEN; invalidate(); }
            else { homeMessage = "اختر الدومينو أو الطاولة للعب"; invalidate(); }
            return true;
        }
        if (screen == MODE_SCREEN) {
            if (y < h * 0.105f && x < 215) { goHome(); return true; }
            if (y >= h * 0.32f && y < h * 0.49f) {
                playMode = MODE_AI;
                if (chosenGame == DOMINO) startDomino(); else startTavla();
            } else if (y >= h * 0.50f && y < h * 0.68f) {
                playMode = MODE_ONLINE;
                startOnlineFlow();
            } else if (y >= h * 0.69f && y < h * 0.86f) {
                playMode = MODE_LOCAL;
                if (chosenGame == DOMINO) startDomino(); else startTavla();
            }
            return true;
        }
        if (screen == WAITING_SCREEN) {
            if (y < h * 0.105f && x < 215) { stopOnlineSession(); goHome(); return true; }
            if (y >= h * 0.78f && y <= h * 0.88f) copyRoomCode();
            return true;
        }

        // Common top bar controls
        if (y < h * 0.105f) {
            if (x < 215) { goHome(); return true; }
            if (x > 700) {
                if (playMode == MODE_ONLINE && !onlineHost) {
                    toast("المضيف فقط يستطيع إعادة بدء المباراة");
                    return true;
                }
                if (screen == DOMINO) startDomino(); else startTavla();
                if (playMode == MODE_ONLINE && onlineHost) { onlineReady = true; publishOnlineState(); }
                return true;
            }
        }

        if (screen == DOMINO) {
            handleDominoTouch(x, y, h);
        } else {
            handleTavlaTouch(x, y, h);
        }
        return true;
    }

    private void handleDominoTouch(float x, float y, float h) {
        if ((playMode == MODE_AI && dominoPlayer == 1)
                || (playMode == MODE_ONLINE && dominoPlayer != onlinePlayerIndex)) return;
        if (dominoOver) {
            if (y > h * 0.90f) {
                if (playMode == MODE_ONLINE && !onlineHost) toast("انتظر المضيف ليبدأ جولة جديدة");
                else {
                    startDomino();
                    if (playMode == MODE_ONLINE) { onlineReady = true; publishOnlineState(); }
                }
            }
            return;
        }
        if (!dominoReveal) {
            if (y >= h * 0.75f && y <= h * 0.84f) {
                dominoReveal = true;
                dominoStatus = "دور اللاعب " + (dominoPlayer + 1) + " — اختر قطعة";
                invalidate();
            }
            return;
        }
        ArrayList<Tile> hand = dominoHands[dominoPlayer];
        if (y >= h * 0.68f && y <= h * 0.83f && !hand.isEmpty()) {
            float tileW = Math.min(96f, 760f / Math.max(1, hand.size()) - 8f);
            tileW = Math.max(58f, tileW);
            float gap = 8f;
            float total = hand.size() * tileW + Math.max(0, hand.size() - 1) * gap;
            float sx = (900 - total) / 2f;
            for (int i = 0; i < hand.size(); i++) {
                float l = sx + i * (tileW + gap);
                if (x >= l - 4 && x <= l + tileW + 4) {
                    selectedTile = i;
                    dominoStatus = "اخترت القطعة " + hand.get(i).a + " | " + hand.get(i).b + " — حدد الطرف";
                    invalidate(); return;
                }
            }
        }
        if (y >= h * 0.89f && y <= h * 0.96f) {
            if (x < 300) playDomino(0);
            else if (x < 575) playDomino(1);
            else {
                if (stock.isEmpty()) passDomino(); else drawOneDomino();
            }
        }
    }

    private void handleTavlaTouch(float x, float y, float h) {
        if ((playMode == MODE_AI && tavlaPlayer == 1)
                || (playMode == MODE_ONLINE && tavlaPlayer != onlinePlayerIndex)) return;
        if (tavlaOver) {
            if (y > h * 0.88f) {
                if (playMode == MODE_ONLINE && !onlineHost) toast("انتظر المضيف ليبدأ جولة جديدة");
                else {
                    startTavla();
                    if (playMode == MODE_ONLINE) { onlineReady = true; publishOnlineState(); }
                }
            }
            return;
        }
        // Dice selection area
        if (diceRolled && y >= h * 0.69f && y <= h * 0.76f) {
            float start = 450 - dice.size() * 42f;
            for (int i = 0; i < dice.size(); i++) {
                float dx = start + i * 84f;
                if (Math.abs(x - dx) < 34) { selectTavlaDie(dice.get(i)); return; }
            }
        }
        // Roll / bear-off / finish controls
        if (y >= h * 0.82f && y <= h * 0.92f) {
            if (x < 320) rollTavlaDice();
            else if (x < 580) bearOffSelected();
            else finishTavlaTurn();
            return;
        }
        if (!diceRolled) return;

        // Tap the bar to select a checker waiting to enter.
        if (x > 410 && x < 490 && y > h * 0.24f && y < h * 0.58f) {
            if (tavla.bar[tavlaPlayer] > 0) selectTavlaSource(-2);
            return;
        }

        int point = hitPoint(x, y, h);
        if (point != Integer.MIN_VALUE) {
            if (selectedFrom == Integer.MIN_VALUE) selectTavlaSource(point);
            else tryTavlaDestination(point);
        }
    }

    private int hitPoint(float x, float y, float h) {
        float top = h * 0.19f, bottom = h * 0.62f;
        boolean isTop = y >= top && y <= h * 0.405f;
        boolean isBottom = y >= h * 0.405f && y <= bottom;
        if (!isTop && !isBottom) return Integer.MIN_VALUE;
        int closest = -1;
        float dist = Float.MAX_VALUE;
        for (int col = 0; col < 12; col++) {
            float d = Math.abs(x - pointX(col));
            if (d < dist) { dist = d; closest = col; }
        }
        if (closest < 0 || dist > 34) return Integer.MIN_VALUE;
        return pointForColumn(closest, isTop);
    }


    // ------------------------------ TURN HELPERS & COMPUTER OPPONENT ------------------------------
    private String dominoPlayerName(int player) {
        if (playMode == MODE_AI && player == 1) return "الكمبيوتر";
        if (playMode == MODE_ONLINE) return player == onlinePlayerIndex ? "أنت" : "الخصم";
        return "اللاعب " + (player + 1);
    }

    private String dominoWinnerName(int player) {
        if (playMode == MODE_AI && player == 1) return "الكمبيوتر";
        if (playMode == MODE_ONLINE) return player == onlinePlayerIndex ? "أنت" : "الخصم";
        return "اللاعب " + (player + 1);
    }

    private String tavlaPlayerName(int player) {
        if (playMode == MODE_AI && player == 1) return "الكمبيوتر";
        if (playMode == MODE_ONLINE) return player == onlinePlayerIndex ? "أنت" : "الخصم";
        return "اللاعب " + (player + 1);
    }

    private void updateDominoTurn() {
        if (playMode == MODE_AI) {
            dominoReveal = dominoPlayer == 0;
            if (dominoPlayer == 1) {
                dominoStatus = "دور الكمبيوتر — يفكر في أفضل قطعة";
                mainHandler.removeCallbacks(aiDominoRunnable);
                mainHandler.postDelayed(aiDominoRunnable, 650);
            } else {
                mainHandler.removeCallbacks(aiDominoRunnable);
                dominoStatus = "دورك — اختر قطعة من يدك";
            }
        } else if (playMode == MODE_ONLINE) {
            dominoReveal = dominoPlayer == onlinePlayerIndex;
            dominoStatus = dominoReveal ? "دورك — العب قطعة" : "دور الخصم — بانتظار حركته";
        } else {
            dominoReveal = false;
            dominoStatus = "دور اللاعب " + (dominoPlayer + 1) + " — مرّر الهاتف واضغط جاهز";
        }
    }

    private void updateTavlaTurn() {
        if (playMode == MODE_AI) {
            if (tavlaPlayer == 1) {
                tavlaStatus = "دور الكمبيوتر — يرمي النرد ويختار الحركة";
                mainHandler.removeCallbacks(aiTavlaRunnable);
                mainHandler.postDelayed(aiTavlaRunnable, 700);
            } else {
                mainHandler.removeCallbacks(aiTavlaRunnable);
                tavlaStatus = "دورك — ارمِ النرد";
            }
        } else if (playMode == MODE_ONLINE) {
            tavlaStatus = tavlaPlayer == onlinePlayerIndex ? "دورك — ارمِ النرد" : "دور الخصم — انتظر حركته";
        } else {
            tavlaStatus = "دور اللاعب " + (tavlaPlayer + 1) + " — ارمِ النرد";
        }
    }

    private void runDominoAi() {
        if (screen != DOMINO || playMode != MODE_AI || dominoPlayer != 1 || dominoOver) return;
        dominoStatus = "الكمبيوتر يبحث عن قطعة مناسبة...";
        invalidate();
        // Draw until the computer can play, or the stock is empty.
        while (!hasDominoMove(1) && !stock.isEmpty()) {
            dominoHands[1].add(stock.remove(stock.size() - 1));
        }
        if (!hasDominoMove(1)) {
            passDomino();
            return;
        }
        int bestIndex = -1;
        int bestSide = 1;
        int bestScore = Integer.MIN_VALUE;
        for (int i = 0; i < dominoHands[1].size(); i++) {
            Tile t = dominoHands[1].get(i);
            if (canPlayLeft(t)) {
                int score = t.pips() + (t.a == t.b ? 5 : 0) + (t.pips() >= 8 ? 2 : 0);
                if (score > bestScore) { bestScore = score; bestIndex = i; bestSide = 0; }
            }
            if (canPlayRight(t)) {
                int score = t.pips() + (t.a == t.b ? 5 : 0) + (t.pips() >= 8 ? 2 : 0);
                if (score > bestScore) { bestScore = score; bestIndex = i; bestSide = 1; }
            }
        }
        if (bestIndex >= 0) {
            selectedTile = bestIndex;
            playDomino(bestSide);
        }
    }

    private void runTavlaAi() {
        if (screen != TAVLA || playMode != MODE_AI || tavlaPlayer != 1 || tavlaOver) return;
        rollTavlaDice();
        int safety = 0;
        while (!tavlaOver && diceRolled && !cachedMoves.isEmpty() && safety++ < 4) {
            Move best = null;
            int bestScore = Integer.MIN_VALUE;
            for (Move candidate : cachedMoves) {
                int score = scoreTavlaMove(candidate, 1);
                if (score > bestScore) { bestScore = score; best = candidate; }
            }
            if (best == null) break;
            executeTavlaMove(best);
        }
        if (!tavlaOver && diceRolled) finishTavlaTurn();
    }

    private int scoreTavlaMove(Move move, int player) {
        int sign = signFor(player);
        int score = random.nextInt(5);
        if (move.to == -1) return 200 + score;
        if (move.from == -2) score += 28;
        else score += Math.max(0, player == 0 ? move.from - move.to : move.to - move.from) * 2;
        if (move.to >= 0 && tavla.points[move.to] * sign == -1) score += 65; // hit a blot
        if (move.to >= 0 && tavla.points[move.to] * sign >= 1) score += 10; // make/strengthen a point
        if (move.from >= 0 && Math.abs(tavla.points[move.from]) == 1) score -= 7; // avoid leaving a blot when possible
        return score;
    }

    // ------------------------------ FIREBASE ONLINE ROOMS ------------------------------
    private SharedPreferences onlinePrefs() {
        return getContext().getSharedPreferences("domino_tavla_online", Context.MODE_PRIVATE);
    }

    private void startOnlineFlow() {
        SharedPreferences prefs = onlinePrefs();
        String apiKey = prefs.getString("api_key", "");
        String dbUrl = prefs.getString("database_url", "");
        if (apiKey.isEmpty() || dbUrl.isEmpty()) showFirebaseConfigDialog();
        else showOnlineRoomOptions();
    }

    private void showFirebaseConfigDialog() {
        LinearLayout layout = new LinearLayout(getContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(42, 18, 42, 8);
        EditText api = new EditText(getContext());
        api.setSingleLine(true);
        api.setHint("Firebase Web API Key");
        api.setInputType(InputType.TYPE_CLASS_TEXT);
        EditText url = new EditText(getContext());
        url.setSingleLine(true);
        url.setHint("Realtime Database URL");
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        SharedPreferences prefs = onlinePrefs();
        api.setText(prefs.getString("api_key", ""));
        url.setText(prefs.getString("database_url", ""));
        TextView note = new TextView(getContext());
        note.setText("أدخل مفتاح Web API ورابط Realtime Database من مشروع Firebase الخاص بك. ستجد خطوات الإعداد في ملف README.");
        note.setTextSize(14);
        note.setPadding(0, 8, 0, 8);
        layout.addView(api);
        layout.addView(url);
        layout.addView(note);
        new AlertDialog.Builder(getContext())
                .setTitle("إعداد اللعب عبر الإنترنت")
                .setView(layout)
                .setNegativeButton("إلغاء", (d, w) -> { screen = MODE_SCREEN; invalidate(); })
                .setPositiveButton("حفظ ومتابعة", (d, w) -> {
                    String key = api.getText().toString().trim();
                    String database = url.getText().toString().trim();
                    if (key.isEmpty() || database.isEmpty()) {
                        toast("يرجى إدخال المفتاح والرابط");
                        screen = MODE_SCREEN; invalidate();
                        return;
                    }
                    prefs.edit().putString("api_key", key).putString("database_url", database).apply();
                    showOnlineRoomOptions();
                }).show();
    }

    private void showOnlineRoomOptions() {
        new AlertDialog.Builder(getContext())
                .setTitle("اللعب عبر الإنترنت")
                .setItems(new String[]{"إنشاء غرفة جديدة", "الانضمام إلى غرفة برمز", "تعديل إعدادات Firebase"}, (dialog, which) -> {
                    if (which == 0) createOnlineRoom();
                    else if (which == 1) showJoinRoomDialog();
                    else showFirebaseConfigDialog();
                })
                .setNegativeButton("إلغاء", (d, w) -> { screen = MODE_SCREEN; invalidate(); })
                .show();
    }

    private FirebaseRoomClient makeOnlineClient() {
        SharedPreferences prefs = onlinePrefs();
        return new FirebaseRoomClient(prefs.getString("api_key", ""), prefs.getString("database_url", ""));
    }

    private String newRoomCode() {
        final String alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        StringBuilder code = new StringBuilder();
        for (int i = 0; i < 8; i++) code.append(alphabet.charAt(random.nextInt(alphabet.length())));
        return code.toString();
    }

    private void createOnlineRoom() {
        final FirebaseRoomClient client = makeOnlineClient();
        final String code = newRoomCode();
        networkMessage = "جارٍ الاتصال بخدمة اللعب...";
        screen = WAITING_SCREEN; invalidate();
        networkExecutor.execute(() -> {
            try {
                client.signInAnonymously();
                client.createRoom(code, chosenGame == DOMINO ? "domino" : "tavla");
                ((Activity) getContext()).runOnUiThread(() -> {
                    onlineClient = client;
                    roomCode = code;
                    onlinePlayerIndex = 0;
                    onlineHost = true;
                    onlineReady = false;
                    onlineRevision = 0;
                    playMode = MODE_ONLINE;
                    networkMessage = "الغرفة جاهزة — بانتظار صديقك";
                    screen = WAITING_SCREEN;
                    invalidate();
                    new AlertDialog.Builder(getContext())
                            .setTitle("تم إنشاء الغرفة")
                            .setMessage("رمز الغرفة: " + code + "\nأرسل الرمز إلى صديقك ليدخل إلى المباراة.")
                            .setPositiveButton("موافق", null).show();
                    scheduleOnlinePoll(700);
                });
            } catch (Exception e) {
                showNetworkError(e);
            }
        });
    }

    private void showJoinRoomDialog() {
        EditText codeInput = new EditText(getContext());
        codeInput.setSingleLine(true);
        codeInput.setHint("أدخل رمز الغرفة");
        codeInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        codeInput.setGravity(Gravity.CENTER);
        new AlertDialog.Builder(getContext())
                .setTitle("الانضمام إلى مباراة")
                .setView(codeInput)
                .setNegativeButton("إلغاء", (d, w) -> { screen = MODE_SCREEN; invalidate(); })
                .setPositiveButton("انضمام", (d, w) -> joinOnlineRoom(codeInput.getText().toString().trim().toUpperCase(Locale.US)))
                .show();
    }

    private void joinOnlineRoom(String code) {
        if (code.length() < 6) { toast("رمز الغرفة غير صحيح"); return; }
        final FirebaseRoomClient client = makeOnlineClient();
        networkMessage = "جارٍ الانضمام إلى الغرفة...";
        screen = WAITING_SCREEN; invalidate();
        networkExecutor.execute(() -> {
            try {
                client.signInAnonymously();
                JSONObject room = client.getRoom(code);
                String expectedGame = chosenGame == DOMINO ? "domino" : "tavla";
                if (!expectedGame.equals(room.optString("game")))
                    throw new IllegalStateException("هذه الغرفة مخصصة للعبة الأخرى");
                if (room.has("guestUid") && !room.isNull("guestUid") && !room.optString("guestUid").isEmpty())
                    throw new IllegalStateException("الغرفة ممتلئة — يشارك فيها لاعبان بالفعل");
                client.joinRoom(code);
                ((Activity) getContext()).runOnUiThread(() -> {
                    onlineClient = client;
                    roomCode = code;
                    onlinePlayerIndex = 1;
                    onlineHost = false;
                    onlineReady = false;
                    onlineRevision = -1;
                    playMode = MODE_ONLINE;
                    networkMessage = "انضممت بنجاح — بانتظار بدء المضيف";
                    screen = WAITING_SCREEN;
                    invalidate();
                    scheduleOnlinePoll(500);
                });
            } catch (Exception e) {
                showNetworkError(e);
            }
        });
    }

    private void scheduleOnlinePoll(long delayMs) {
        mainHandler.removeCallbacks(onlinePollRunnable);
        mainHandler.postDelayed(onlinePollRunnable, delayMs);
    }

    private final Runnable onlinePollRunnable = this::pollOnlineRoom;

    private void pollOnlineRoom() {
        if (playMode != MODE_ONLINE || onlineClient == null || roomCode.isEmpty() || pollInFlight) return;
        pollInFlight = true;
        final FirebaseRoomClient client = onlineClient;
        final String code = roomCode;
        networkExecutor.execute(() -> {
            JSONObject room = null;
            Exception failure = null;
            try { room = client.getRoom(code); }
            catch (Exception e) { failure = e; }
            final JSONObject result = room;
            final Exception error = failure;
            ((Activity) getContext()).runOnUiThread(() -> {
                pollInFlight = false;
                if (playMode != MODE_ONLINE) return;
                if (error != null) {
                    networkMessage = "تعذر تحديث الغرفة — تحقق من الإنترنت";
                } else if (result != null) {
                    if (onlineHost && !onlineReady && result.has("guestUid") && !result.isNull("guestUid")
                            && !result.optString("guestUid").isEmpty()) {
                        networkMessage = "اتصل صديقك — جاري بدء المباراة";
                        if (chosenGame == DOMINO) startDomino(); else startTavla();
                        onlineReady = true;
                        publishOnlineState();
                    } else {
                        JSONObject state = result.optJSONObject("state");
                        if (state != null) {
                            long remoteRevision = state.optLong("revision", 0);
                            if (!onlineReady || remoteRevision > onlineRevision) applyOnlineState(state);
                        }
                    }
                }
                if (playMode == MODE_ONLINE) scheduleOnlinePoll(1500);
            });
        });
    }

    private JSONObject makeOnlineSnapshot(long revision) throws Exception {
        JSONObject root = new JSONObject();
        root.put("revision", revision);
        if (screen == DOMINO) {
            root.put("game", "domino");
            root.put("activePlayer", dominoPlayer);
            root.put("over", dominoOver);
            root.put("winner", dominoWinner);
            root.put("blockedPasses", blockedPasses);
            root.put("result", dominoResult);
            JSONArray stockJson = new JSONArray();
            for (Tile t : stock) stockJson.put(new JSONArray().put(t.a).put(t.b));
            JSONArray handsJson = new JSONArray();
            for (int player = 0; player < 2; player++) {
                JSONArray hand = new JSONArray();
                for (Tile t : dominoHands[player]) hand.put(new JSONArray().put(t.a).put(t.b));
                handsJson.put(hand);
            }
            JSONArray chainJson = new JSONArray();
            for (PlacedTile t : chain) chainJson.put(new JSONArray().put(t.left).put(t.right));
            root.put("stock", stockJson);
            root.put("hands", handsJson);
            root.put("chain", chainJson);
        } else if (screen == TAVLA) {
            root.put("game", "tavla");
            root.put("activePlayer", tavlaPlayer);
            root.put("rolled", diceRolled);
            root.put("over", tavlaOver);
            root.put("winner", tavlaWinner);
            JSONArray points = new JSONArray();
            JSONArray bars = new JSONArray();
            JSONArray outs = new JSONArray();
            JSONArray diceJson = new JSONArray();
            for (int value : tavla.points) points.put(value);
            for (int value : tavla.bar) bars.put(value);
            for (int value : tavla.off) outs.put(value);
            for (int value : dice) diceJson.put(value);
            root.put("points", points);
            root.put("bar", bars);
            root.put("off", outs);
            root.put("dice", diceJson);
        }
        return root;
    }

    private void publishOnlineState() {
        if (playMode != MODE_ONLINE || !onlineReady || onlineClient == null || applyingRemoteState) return;
        final long revision = Math.max(1, onlineRevision + 1);
        final JSONObject snapshot;
        try { snapshot = makeOnlineSnapshot(revision); }
        catch (Exception e) { toast("تعذر تجهيز حالة اللعبة للمزامنة"); return; }
        onlineRevision = revision;
        final FirebaseRoomClient client = onlineClient;
        final String code = roomCode;
        networkExecutor.execute(() -> {
            try { client.pushState(code, snapshot); }
            catch (Exception e) { showNetworkError(e); }
        });
    }

    private void syncOnlineState() {
        if (playMode == MODE_ONLINE && onlineReady && !applyingRemoteState) publishOnlineState();
    }

    private void applyOnlineState(JSONObject state) {
        if (state == null) return;
        applyingRemoteState = true;
        try {
            String game = state.optString("game", "");
            onlineRevision = state.optLong("revision", onlineRevision);
            if ("domino".equals(game)) {
                chosenGame = DOMINO;
                stock.clear(); chain.clear(); dominoHands[0].clear(); dominoHands[1].clear();
                JSONArray stockJson = state.optJSONArray("stock");
                if (stockJson != null) for (int i = 0; i < stockJson.length(); i++) {
                    JSONArray t = stockJson.optJSONArray(i);
                    if (t != null && t.length() >= 2) stock.add(new Tile(t.optInt(0), t.optInt(1)));
                }
                JSONArray hands = state.optJSONArray("hands");
                if (hands != null) for (int player = 0; player < Math.min(2, hands.length()); player++) {
                    JSONArray hand = hands.optJSONArray(player);
                    if (hand != null) for (int i = 0; i < hand.length(); i++) {
                        JSONArray t = hand.optJSONArray(i);
                        if (t != null && t.length() >= 2) dominoHands[player].add(new Tile(t.optInt(0), t.optInt(1)));
                    }
                }
                JSONArray chainJson = state.optJSONArray("chain");
                if (chainJson != null) for (int i = 0; i < chainJson.length(); i++) {
                    JSONArray t = chainJson.optJSONArray(i);
                    if (t != null && t.length() >= 2) chain.add(new PlacedTile(t.optInt(0), t.optInt(1)));
                }
                dominoPlayer = state.optInt("activePlayer", 0);
                dominoOver = state.optBoolean("over", false);
                dominoWinner = state.optInt("winner", -1);
                blockedPasses = state.optInt("blockedPasses", 0);
                dominoResult = state.optString("result", "");
                if (dominoOver) dominoResult = dominoWinner < 0 ? "تعادل!" : dominoWinnerName(dominoWinner) + " فاز!";
                selectedTile = -1;
                dominoReveal = dominoPlayer == onlinePlayerIndex;
                dominoStatus = dominoReveal ? "دورك — العب قطعة" : "دور الخصم — انتظر حركته";
                screen = DOMINO;
            } else if ("tavla".equals(game)) {
                chosenGame = TAVLA;
                JSONArray points = state.optJSONArray("points");
                JSONArray bars = state.optJSONArray("bar");
                JSONArray outs = state.optJSONArray("off");
                JSONArray diceJson = state.optJSONArray("dice");
                if (points != null && points.length() == 24) for (int i = 0; i < 24; i++) tavla.points[i] = points.optInt(i);
                if (bars != null && bars.length() >= 2) for (int i = 0; i < 2; i++) tavla.bar[i] = bars.optInt(i);
                if (outs != null && outs.length() >= 2) for (int i = 0; i < 2; i++) tavla.off[i] = outs.optInt(i);
                dice.clear();
                if (diceJson != null) for (int i = 0; i < diceJson.length(); i++) dice.add(diceJson.optInt(i));
                tavlaPlayer = state.optInt("activePlayer", 0);
                diceRolled = state.optBoolean("rolled", false);
                tavlaOver = state.optBoolean("over", false);
                tavlaWinner = state.optInt("winner", -1);
                selectedFrom = Integer.MIN_VALUE; selectedDie = -1;
                cachedMoves = diceRolled ? optimalMoves(tavla, tavlaPlayer, dice) : new ArrayList<>();
                tavlaStatus = tavlaPlayer == onlinePlayerIndex ? "دورك — أكمل حركات النرد" : "دور الخصم — انتظر حركته";
                screen = TAVLA;
            }
            onlineReady = true;
            invalidate();
        } catch (Exception e) {
            toast("وصلت بيانات مباراة غير مكتملة");
        } finally {
            applyingRemoteState = false;
        }
    }

    private void copyRoomCode() {
        android.content.ClipboardManager clipboard = (android.content.ClipboardManager)
                getContext().getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) {
            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Room code", roomCode));
            toast("تم نسخ رمز الغرفة");
        }
    }

    private void stopOnlineSession() {
        mainHandler.removeCallbacks(onlinePollRunnable);
        onlineClient = null;
        roomCode = "";
        onlineReady = false;
        pollInFlight = false;
        onlineRevision = -1;
        onlineHost = false;
        playMode = MODE_LOCAL;
    }

    private void showNetworkError(Exception error) {
        String message = error == null ? "خطأ غير معروف" : error.getMessage();
        if (message == null || message.trim().isEmpty()) message = "تحقق من إعداد Firebase والإنترنت";
        final String shown = message;
        ((Activity) getContext()).runOnUiThread(() -> {
            networkMessage = "تعذر الاتصال بالخادم";
            if (onlineClient == null) { screen = MODE_SCREEN; playMode = MODE_LOCAL; }
            toast(shown);
            invalidate();
        });
    }

    private void toast(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_LONG).show();
    }

}
