# إعداد المشروع (Android Studio)

1. أنشئ مشروع **Empty Activity (Compose)** باسم الحزمة `com.example.domino` و minSdk 24.
2. ضع الملفات في `app/src/main/java/com/example/domino/`:

| الملف | المسار |
|---|---|
| Model.kt | `model/Model.kt` |
| GameViewModel.kt | `viewmodel/GameViewModel.kt` |
| Components.kt | `ui/Components.kt` |
| GameScreen.kt | `ui/GameScreen.kt` |
| MainActivity.kt | `MainActivity.kt` (استبدل الموجود) |

3. تأكد من الاعتمادات في `app/build.gradle.kts`:

```kotlin
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose") // Kotlin 2.x
}
android { buildFeatures { compose = true } }
dependencies {
    val bom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(bom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
}
```
(مع Kotlin 1.9 استبدل إضافة compose بـ `composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }`.)

4. شغّل التطبيق.

## طريقة اللعب
- الأحجار المضيئة في يدك هي الصالحة للعب؛ اضغط الحجر لوضعه.
- إن طابق الحجر الطرفين تظهر مربعات ◀ ▶ نابضة على اللوحة لاختيار الجهة.
- لا حجر مناسب؟ زر «اسحب من المكدس». اللوحة قابلة للتمرير، وزرا + / − للتكبير.
