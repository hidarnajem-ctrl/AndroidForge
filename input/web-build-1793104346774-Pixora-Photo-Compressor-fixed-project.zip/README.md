# Pixora Photo Compressor Android

Android Studio / AndroidForge Gradle project. The project files are at the archive root.

Build the debug APK with `gradle assembleDebug` or use AndroidForge's Build APK workflow.
The theme color schemes and launcher icon resources are included.
