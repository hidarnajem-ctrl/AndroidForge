package com.example.domino.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domino.model.xpNeeded

object Palette {
    val gold = Color(0xFFFFD54F)
    val goldDark = Color(0xFF3B2000)
    val text = Color(0xFFEDE3C8)
    val panel = Color(0xFF14532D)
    val trim = Color(0xFFC9A24B)
}

@Composable
fun GoldButton(
    text: String,
    modifier: Modifier = Modifier,
    green: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val brush = if (green) Brush.verticalGradient(listOf(Color(0xFF3DDC6B), Color(0xFF138A3A)))
    else Brush.verticalGradient(listOf(Color(0xFFFFC233), Color(0xFFE67E00)))
    Box(
        modifier
            .fillMaxWidth()
            .height(54.dp)
            .graphicsLayer { alpha = if (enabled) 1f else 0.5f }
            .clip(RoundedCornerShape(16.dp))
            .background(brush)
            .border(2.dp, Color(0xFFFFE9A8), RoundedCornerShape(16.dp))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (green) Color.White else Palette.goldDark, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun CoinChip(coins: Int, modifier: Modifier = Modifier) {
    Row(
        modifier.clip(RoundedCornerShape(20.dp)).background(Color(0x99000000))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(22.dp).clip(CircleShape).background(Palette.gold), contentAlignment = Alignment.Center) {
            Text("♛", fontSize = 13.sp, color = Palette.goldDark)
        }
        Spacer(Modifier.width(6.dp))
        Text("$coins", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun LevelBar(level: Int, xp: Int, modifier: Modifier = Modifier) {
    val need = xpNeeded(level)
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(42.dp).clip(CircleShape)
                .background(Brush.verticalGradient(listOf(Color(0xFFFFE082), Color(0xFFE6A100))))
                .border(2.dp, Color(0xFFFFF3C4), CircleShape),
            contentAlignment = Alignment.Center
        ) { Text("$level", color = Palette.goldDark, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text("$xp / $need", color = Palette.text, fontSize = 12.sp)
            Spacer(Modifier.height(3.dp))
            Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(Color(0x66000000))) {
                Box(
                    Modifier.fillMaxWidth((xp.toFloat() / need).coerceIn(0f, 1f))
                        .fillMaxHeight().background(Palette.gold)
                )
            }
        }
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(22.dp))
            .background(Palette.panel)
            .border(2.dp, Palette.trim, RoundedCornerShape(22.dp))
            .padding(16.dp),
        content = content
    )
}

@Composable
fun BottomNav(selected: Screen, onSelect: (Screen) -> Unit) {
    val items = listOf(
        Triple(Screen.COLLECTION, "🎨", "المجموعات"),
        Triple(Screen.HOME, "🏠", "الرئيسية"),
        Triple(Screen.PROFILE, "👤", "الملف الشخصي")
    )
    Row(
        Modifier.fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color(0xFFF2A81D), Color(0xFFB86E00))))
            .navigationBarsPadding()
            .padding(horizontal = 6.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        items.forEach { (screen, icon, label) ->
            val on = screen == selected
            Column(
                Modifier.weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (on) Color(0x55FFFFFF) else Color.Transparent)
                    .clickable { onSelect(screen) }
                    .padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(icon, fontSize = 22.sp)
                Text(label, color = Palette.goldDark, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
