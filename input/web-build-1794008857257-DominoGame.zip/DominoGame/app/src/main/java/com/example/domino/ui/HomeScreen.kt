package com.example.domino.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domino.model.AD_COIN_REWARD
import com.example.domino.model.DominoTile
import com.example.domino.model.ProgressState
import com.example.domino.model.TARGET_SCORE

@Composable
fun HomeScreen(
    progress: ProgressState,
    adReady: Boolean,
    onPlay: () -> Unit,
    onHelp: () -> Unit,
    onFreeCoins: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            LevelBar(progress.level, progress.xp, Modifier.weight(1f))
            CoinChip(progress.coins)
        }
        Spacer(Modifier.weight(1f))
        Text("دومينو", color = Palette.gold, fontSize = 52.sp, fontWeight = FontWeight.Bold)
        Text("العب ضد الكمبيوتر حتى $TARGET_SCORE نقطة", color = Palette.text, fontSize = 14.sp)
        Spacer(Modifier.height(28.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
            TileView(DominoTile(0, 6, 6), cell = 46.dp, modifier = Modifier.graphicsLayer { rotationZ = -14f })
            TileView(DominoTile(1, 3, 5), cell = 46.dp, modifier = Modifier.graphicsLayer { rotationZ = 5f })
            TileView(DominoTile(2, 2, 4), cell = 46.dp, modifier = Modifier.graphicsLayer { rotationZ = 16f })
        }
        Spacer(Modifier.height(32.dp))
        GoldButton("▶  العب الآن", onClick = onPlay)
        Spacer(Modifier.height(12.dp))
        GoldButton("🎬  +$AD_COIN_REWARD عملة مجاناً", green = true, enabled = adReady, onClick = onFreeCoins)
        Spacer(Modifier.height(12.dp))
        GoldButton("📖  طريقة اللعب", green = true, onClick = onHelp)
        Spacer(Modifier.weight(1.3f))
    }
}
