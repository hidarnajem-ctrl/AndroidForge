package com.example.domino.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domino.model.DominoTile
import com.example.domino.model.Side
import com.example.domino.model.Turn
import kotlinx.coroutines.delay

private const val P1 = 0.28f
private const val P2 = 0.5f
private const val P3 = 0.72f
private val Gold = Color(0xFFFFD54F)

private fun pipLayout(n: Int): List<Pair<Float, Float>> = when (n) {
    0 -> emptyList()
    1 -> listOf(P2 to P2)
    2 -> listOf(P1 to P1, P3 to P3)
    3 -> listOf(P1 to P1, P2 to P2, P3 to P3)
    4 -> listOf(P1 to P1, P3 to P1, P1 to P3, P3 to P3)
    5 -> pipLayout(4) + (P2 to P2)
    else -> listOf(P1 to P1, P3 to P1, P1 to P2, P3 to P2, P1 to P3, P3 to P3)
}

private fun DrawScope.drawPips(n: Int, origin: Offset, side: Float, color: Color, glow: Boolean) {
    pipLayout(n).forEach { (fx, fy) ->
        val c = Offset(origin.x + fx * side, origin.y + fy * side)
        if (glow) drawCircle(color.copy(alpha = 0.28f), side * 0.17f, c)
        drawCircle(color, side * 0.085f, c)
    }
}

// ───────────────────────── TileView ─────────────────────────
/** حجر دومينو: عاجي بزوايا منحنية ونقاط واضحة. cell = طول الضلع القصير. */
@Composable
fun TileView(
    tile: DominoTile?,
    modifier: Modifier = Modifier,
    horizontal: Boolean = false,
    cell: Dp = 28.dp,
    highlighted: Boolean = false,
    dimmed: Boolean = false,
    faceDown: Boolean = false,
    skin: TileSkin = LocalTileSkin.current,
    onClick: (() -> Unit)? = null
) {
    val w = if (horizontal) cell * 2 else cell
    val h = if (horizontal) cell else cell * 2
    val scale by animateFloatAsState(
        if (highlighted) 1.08f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "tileScale"
    )
    val shape = RoundedCornerShape(cell * 0.2f)

    Canvas(
        modifier = modifier
            .size(w, h)
            .graphicsLayer { scaleX = scale; scaleY = scale; alpha = if (dimmed) 0.5f else 1f }
            .shadow(if (highlighted) 10.dp else 4.dp, shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
    ) {
        val c = size.minDimension
        val cr = CornerRadius(c * 0.2f)
        if (faceDown || tile == null) {
            drawRoundRect(Brush.linearGradient(listOf(Color(0xFF1B3A5C), Color(0xFF0D2238))), cornerRadius = cr)
            drawRoundRect(Color(0xFFC9A24B), cornerRadius = cr, style = Stroke(c * 0.06f))
            drawCircle(Color(0xFFC9A24B), c * 0.14f, center)
            return@Canvas
        }
        drawRoundRect(Brush.verticalGradient(listOf(skin.faceTop, skin.faceBottom)), cornerRadius = cr)
        drawRoundRect(skin.border, cornerRadius = cr, style = Stroke(1.6.dp.toPx()))

        val inset = c * 0.18f
        val divider = skin.divider
        if (horizontal) {
            drawLine(divider, Offset(size.width / 2, inset), Offset(size.width / 2, size.height - inset), c * 0.04f)
            drawPips(tile.left, Offset(0f, 0f), c, skin.pip, skin.glow)
            drawPips(tile.right, Offset(c, 0f), c, skin.pip, skin.glow)
        } else {
            drawLine(divider, Offset(inset, size.height / 2), Offset(size.width - inset, size.height / 2), c * 0.04f)
            drawPips(tile.left, Offset(0f, 0f), c, skin.pip, skin.glow)
            drawPips(tile.right, Offset(0f, c), c, skin.pip, skin.glow)
        }
    }
}

// ───────────────────────── HandView ─────────────────────────
@Composable
fun HandView(
    hand: List<DominoTile>,
    playableIds: Set<Int>,
    selectedId: Int?,
    myTurn: Boolean,
    onTileClick: (DominoTile) -> Unit,
    modifier: Modifier = Modifier
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        LazyRow(
            modifier = modifier.padding(top = 20.dp),
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            items(hand, key = { it.id }) { t ->
                val lift by animateDpAsState(if (t.id == selectedId) 18.dp else 0.dp, label = "lift")
                TileView(
                    tile = t,
                    cell = 36.dp,
                    highlighted = t.id == selectedId || (myTurn && t.id in playableIds),
                    dimmed = myTurn && t.id !in playableIds,
                    modifier = Modifier.animateItem().offset(y = -lift),
                    onClick = { onTileClick(t) }
                )
            }
        }
    }
}

/** أحجار الخصم مقلوبة. */
@Composable
fun AiHandView(count: Int, modifier: Modifier = Modifier) {
    Row(
        modifier
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) { repeat(count) { TileView(null, faceDown = true, cell = 18.dp) } }
}

// ───────────────────────── ScoreBoard ─────────────────────────
@Composable
private fun ScoreItem(name: String, score: Int, active: Boolean) {
    val color by animateColorAsState(if (active) Gold else Color(0xFFEDE3C8), label = "scoreColor")
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(name, color = color, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        Text("$score", color = color, fontSize = 28.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ScoreBoard(
    playerScore: Int,
    aiScore: Int,
    boneyard: Int,
    turn: Turn,
    modifier: Modifier = Modifier
) {
    Row(
        modifier
            .fillMaxWidth()
            .background(Color(0xCC1B1209), RoundedCornerShape(16.dp))
            .border(1.dp, Color(0x55FFD54F), RoundedCornerShape(16.dp))
            .padding(horizontal = 20.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        ScoreItem("أنت", playerScore, turn == Turn.PLAYER)
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("المكدس", color = Color(0xFFEDE3C8), fontSize = 13.sp)
            Text("$boneyard", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        ScoreItem("الكمبيوتر", aiScore, turn == Turn.AI)
    }
}
