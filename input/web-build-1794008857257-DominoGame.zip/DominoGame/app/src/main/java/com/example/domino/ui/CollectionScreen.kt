package com.example.domino.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domino.model.DominoTile
import com.example.domino.viewmodel.SkinState

private val SampleV = DominoTile(0, 1, 6)
private val SampleH = DominoTile(1, 6, 4)

/** مجموعة التصاميم: الضغط على المفتوح يفعّله، وعلى المقفل يعرض الشراء بالعملات أو الفتح بإعلان. */
@Composable
fun CollectionScreen(
    skins: SkinState,
    coins: Int,
    adReady: Boolean,
    onSelect: (TileSkin) -> Unit,
    onBuy: (TileSkin) -> Unit,
    onWatchAd: (TileSkin) -> Unit,
    modifier: Modifier = Modifier
) {
    var target by remember { mutableStateOf<TileSkin?>(null) }

    Column(modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("المجموعات", color = Palette.gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            CoinChip(coins)
        }
        Spacer(Modifier.height(10.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 12.dp)
        ) {
            items(TileSkins.all, key = { it.id }) { sk ->
                val unlocked = sk.id in skins.unlocked
                val selected = sk.id == skins.selectedId
                Box(
                    Modifier
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color(0x66000000))
                        .border(
                            if (selected) 3.dp else 1.dp,
                            if (selected) Color(0xFF6BFF6B) else Color(0x33FFFFFF),
                            RoundedCornerShape(18.dp)
                        )
                        .clickable { if (unlocked) onSelect(sk) else target = sk }
                        .padding(8.dp)
                ) {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Spacer(Modifier.height(6.dp))
                        TileView(SampleV, cell = 46.dp, skin = sk)
                        Spacer(Modifier.height(8.dp))
                        if (unlocked) {
                            Text(sk.name, color = Palette.text, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 2)
                        } else {
                            CoinChip("${sk.price}")
                        }
                    }
                    if (selected) Text("✅", Modifier.align(Alignment.TopStart), fontSize = 18.sp)
                    if (!unlocked) Text("🔒", Modifier.align(Alignment.TopEnd), fontSize = 18.sp)
                }
            }
        }
    }

    target?.let { sk ->
        AlertDialog(
            onDismissRequest = { target = null },
            confirmButton = { TextButton(onClick = { target = null }) { Text("إغلاق") } },
            title = { Text(sk.name) },
            text = {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    TileView(SampleH, horizontal = true, cell = 44.dp, skin = sk)
                    Text("رصيدك: $coins عملة")
                    Button(
                        enabled = coins >= sk.price,
                        onClick = { onBuy(sk); target = null },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("🪙 شراء بـ ${sk.price} عملة") }
                    Button(
                        enabled = adReady,
                        onClick = { onWatchAd(sk); target = null },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (adReady) "🎬 شاهد إعلاناً للفتح" else "الإعلان قيد التحميل...") }
                }
            }
        )
    }
}

@Composable
private fun CoinChip(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("♛", color = Palette.gold, fontSize = 14.sp)
        Spacer(Modifier.width(4.dp))
        Text(text, color = Palette.gold, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}
