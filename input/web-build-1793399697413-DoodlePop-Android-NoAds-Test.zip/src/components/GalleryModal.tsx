import React from 'react';
import { Image as ImageIcon, Trash2, Download, Play, X, Sparkles } from 'lucide-react';
import { SavedArtwork } from '../types/drawing';

interface GalleryModalProps {
  isOpen: boolean;
  artworks: SavedArtwork[];
  onClose: () => void;
  onOpenArtwork: (artwork: SavedArtwork) => void;
  onDeleteArtwork: (id: string) => void;
  onDownloadArtwork: (artwork: SavedArtwork) => void;
  onTapSound?: () => void;
}

export const GalleryModal: React.FC<GalleryModalProps> = ({
  isOpen,
  artworks,
  onClose,
  onOpenArtwork,
  onDeleteArtwork,
  onDownloadArtwork,
  onTapSound,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-5 animate-kid-pop">
      <div className="relative w-full max-w-lg rounded-3xl bg-white p-4 sm:p-6 shadow-2xl border-4 border-amber-400 text-slate-800 max-h-[88vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b-2 border-amber-100 shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 border border-amber-300 flex items-center justify-center text-xl">
              🖼️
            </div>
            <div>
              <h3 className="text-lg sm:text-xl font-bold text-slate-900 leading-tight">معرض رسوماتي (Gallery)</h3>
              <p className="text-[11px] sm:text-xs text-amber-700 font-semibold">
                محفوظة على هاتفك وتعمل بدون إنترنت ({artworks.length})
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              onTapSound?.();
              onClose();
            }}
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 font-bold flex items-center justify-center"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Artworks List / Grid */}
        <div className="flex-1 overflow-y-auto py-3 px-1 space-y-3 sm:space-y-0 sm:grid sm:grid-cols-2 sm:gap-3">
          {artworks.length === 0 ? (
            <div className="col-span-2 py-12 text-center flex flex-col items-center justify-center">
              <div className="w-16 h-16 rounded-3xl bg-amber-50 border-2 border-dashed border-amber-300 flex items-center justify-center text-3xl mb-3">
                🎨
              </div>
              <h4 className="text-base font-bold text-slate-800">لا توجد رسومات محفوظة بعد</h4>
              <p className="text-xs text-slate-500 mt-1 max-w-xs">
                ارسم لوحتك الجميلة ثم اضغط على زر "حفظ" لحفظها في معرضك الشخصي بدون إنترنت!
              </p>
            </div>
          ) : (
            artworks.map((art) => {
              const formattedDate = new Date(art.createdAt).toLocaleDateString(undefined, {
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              });

              return (
                <div
                  key={art.id}
                  className="rounded-2xl border-2 border-amber-200 bg-amber-50/40 p-2.5 flex flex-col gap-2 shadow-xs hover:shadow-md transition"
                >
                  {/* Thumbnail Preview */}
                  <div
                    className="w-full aspect-[4/3] rounded-xl overflow-hidden border border-slate-200 flex items-center justify-center shadow-inner relative group"
                    style={{ backgroundColor: art.backgroundColor || '#FFFFFF' }}
                  >
                    <img
                      src={art.dataUrl}
                      alt={art.title}
                      className="w-full h-full object-contain"
                      loading="lazy"
                    />
                    <div className="absolute top-1.5 left-1.5 bg-black/60 backdrop-blur-xs text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                      {formattedDate}
                    </div>
                  </div>

                  {/* Title & Actions */}
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-xs font-bold text-slate-800 truncate">{art.title}</span>

                    <div className="flex items-center gap-1 shrink-0">
                      {/* Open & Continue Drawing Button */}
                      <button
                        onClick={() => {
                          onTapSound?.();
                          onOpenArtwork(art);
                          onClose();
                        }}
                        className="kid-btn p-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white shadow-[0_2px_0_#059669] flex items-center gap-1 text-[11px] font-bold px-2.5"
                        title="فتح وإكمال الرسم"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>فتح</span>
                      </button>

                      {/* Download PNG Button */}
                      <button
                        onClick={() => {
                          onTapSound?.();
                          onDownloadArtwork(art);
                        }}
                        className="kid-btn p-1.5 rounded-xl bg-sky-100 hover:bg-sky-200 text-sky-700 border border-sky-300"
                        title="تحميل كصورة"
                      >
                        <Download className="w-3.5 h-3.5 stroke-[2.5]" />
                      </button>

                      {/* Delete Button */}
                      <button
                        onClick={() => {
                          onTapSound?.();
                          onDeleteArtwork(art.id);
                        }}
                        className="kid-btn p-1.5 rounded-xl bg-rose-100 hover:bg-rose-200 text-rose-600 border border-rose-300"
                        title="حذف الرسمة"
                      >
                        <Trash2 className="w-3.5 h-3.5 stroke-[2.5]" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-amber-100 flex items-center justify-between text-xs text-slate-500">
          <span className="flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>يعمل 100% بدون إنترنت على جهازك</span>
          </span>
          <button
            onClick={() => {
              onTapSound?.();
              onClose();
            }}
            className="kid-btn px-4 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-bold shadow-[0_2px_0_#d97706]"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
