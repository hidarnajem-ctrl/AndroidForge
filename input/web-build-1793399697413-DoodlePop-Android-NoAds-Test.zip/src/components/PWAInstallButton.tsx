import React, { useState } from 'react';
import { Download, Share, PlusSquare, X, Smartphone, ExternalLink, Check, Copy } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  onTapSound?: () => void;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ onTapSound }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);
  const [copied, setCopied] = useState(false);

  // If already installed or running as standalone, don't show
  if (isInstalled) {
    return null;
  }

  const appUrl = window.location.origin;

  const handleCopyLink = () => {
    onTapSound?.();
    navigator.clipboard.writeText(appUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <>
      {/* Install Button */}
      <button
        onClick={() => {
          onTapSound?.();
          if (isInstallable) {
            install();
          } else {
            setShowGuide(true);
          }
        }}
        className="kid-btn flex items-center gap-1.5 px-2.5 py-1.5 sm:px-3.5 sm:py-2 rounded-2xl bg-amber-400 hover:bg-amber-300 active:bg-amber-500 text-amber-950 font-bold text-xs sm:text-sm shadow-[0_3px_0_#d97706] border-2 border-amber-500"
        title="تثبيت التطبيق على هاتفك / Install App"
        aria-label="Install App"
      >
        <Smartphone className="w-4 h-4 stroke-[2.5]" />
        <span className="hidden xxs:inline">تثبيت / App</span>
      </button>

      {/* Guide Modal (Android, iOS & APK Guide) */}
      {showGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-kid-pop">
          <div className="relative w-full max-w-sm rounded-3xl bg-white p-5 sm:p-6 shadow-2xl border-4 border-amber-400 text-slate-800 max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setShowGuide(false)}
              className="absolute top-4 right-4 p-1 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center mb-4">
              <div className="w-14 h-14 mx-auto mb-2 rounded-2xl bg-amber-100 border-2 border-amber-400 flex items-center justify-center text-2xl shadow-inner">
                🎨
              </div>
              <h3 className="text-xl font-bold text-slate-900">تثبيت تطبيق DoodlePop</h3>
              <p className="text-xs text-slate-500 mt-1">يعمل كتطبيق أندرويد كامل بدون إنترنت وبشاشة كاملة</p>
            </div>

            {/* Direct Android Install Instructions */}
            <div className="space-y-3 bg-amber-50/80 p-4 rounded-2xl border border-amber-200 text-xs sm:text-sm text-right" dir="rtl">
              <div className="font-bold text-amber-900 flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-amber-600" />
                <span>طريقة التثبيت المباشر على أندرويد (PWA):</span>
              </div>
              <ol className="list-decimal list-inside space-y-1.5 text-slate-700">
                <li>افتح الرابط في متصفح <strong>Google Chrome</strong> على هاتفك.</li>
                <li>اضغط على القائمة (الثلاث نقاط <strong>⋮</strong> بأعلى المتصفح).</li>
                <li>اختر <strong>«تثبيت التطبيق» (Install App)</strong> أو <strong>«إضافة إلى الشاشة الرئيسية»</strong>.</li>
                <li>سيظهر التطبيق فوراً في هاتفك بأيقونته الخاصة مثل أي تطبيق APK!</li>
              </ol>
            </div>

            {/* APK Conversion Info */}
            <div className="mt-3 bg-indigo-50/80 p-3.5 rounded-2xl border border-indigo-200 text-xs text-right" dir="rtl">
              <span className="font-bold text-indigo-900 block mb-1">تحميل ملف APK مباشر:</span>
              <p className="text-slate-600 leading-relaxed mb-2">
                يمكنك تحويل هذا الرابط إلى ملف <strong>APK</strong> جاهز للتحميل والتثبيت خلال دقيقة واحدة عبر أداة <strong>PWABuilder</strong> الرسمية:
              </p>
              <a
                href={`https://www.pwabuilder.com?url=${encodeURIComponent(appUrl)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="kid-btn w-full py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold flex items-center justify-center gap-1.5 shadow-[0_2px_0_#3730a3]"
              >
                <span>فتح PWABuilder لإنشاء ملف APK</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Download Full Project ZIP */}
            <a
              href="/doodlepop-kids-app.zip"
              download="doodlepop-kids-app.zip"
              className="kid-btn mt-3 w-full py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-[0_2px_0_#047857]"
            >
              <Download className="w-4 h-4" />
              <span>تحميل كود المشروع كاملاً (ملف ZIP)</span>
            </a>

            {/* Copy link button */}
            <button
              onClick={handleCopyLink}
              className="kid-btn mt-2.5 w-full py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 border border-slate-300"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'تم نسخ الرابط!' : 'نسخ رابط التطبيق'}</span>
            </button>

            <button
              onClick={() => setShowGuide(false)}
              className="kid-btn mt-3 w-full rounded-2xl bg-amber-400 py-2.5 text-sm font-bold text-amber-950 shadow-[0_3px_0_#d97706] hover:bg-amber-300"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}
    </>
  );
};
