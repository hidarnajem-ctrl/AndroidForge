import React from 'react';
import { Trash2, Sparkles, Check, ArrowLeft } from 'lucide-react';

interface ConfirmationModalProps {
  isOpen: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmationModal: React.FC<ConfirmationModalProps> = ({
  isOpen,
  onConfirm,
  onCancel,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-kid-pop">
      <div className="relative w-full max-w-xs sm:max-w-sm rounded-3xl bg-white p-6 shadow-2xl border-4 border-rose-300 text-center">
        {/* Animated bounce icon */}
        <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-rose-100 border-2 border-rose-300 flex items-center justify-center text-rose-500 shadow-inner">
          <Trash2 className="w-8 h-8 stroke-[2.2] animate-bounce" />
        </div>

        <h3 className="text-xl font-bold text-slate-800">Start Fresh?</h3>
        <p className="text-sm text-slate-600 mt-1 mb-6">
          This will wipe your current canvas clean so you can start a brand new drawing!
        </p>

        <div className="flex flex-col gap-2.5">
          <button
            onClick={onCancel}
            className="kid-btn w-full py-3 px-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-base shadow-[0_4px_0_#059669] flex items-center justify-center gap-2"
          >
            <Check className="w-5 h-5 stroke-[3]" />
            Keep Drawing
          </button>

          <button
            onClick={onConfirm}
            className="kid-btn w-full py-2.5 px-4 rounded-2xl bg-rose-100 hover:bg-rose-200 text-rose-700 font-bold text-sm border-2 border-rose-300 flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-rose-500" />
            Yes, Wipe Clean
          </button>
        </div>
      </div>
    </div>
  );
};
