import React from 'react';
import { Sparkles, Check } from 'lucide-react';
import { ColorOption, COLOR_PALETTE } from '../types/drawing';

interface ColorPaletteProps {
  selectedColor: ColorOption;
  isEraser: boolean;
  onSelectColor: (color: ColorOption) => void;
  onTapSound?: () => void;
}

export const ColorPalette: React.FC<ColorPaletteProps> = ({
  selectedColor,
  isEraser,
  onSelectColor,
  onTapSound,
}) => {
  return (
    <div className="w-full bg-white/95 backdrop-blur-md px-2 py-2 rounded-2xl sm:rounded-3xl shadow-md border-2 border-amber-200/90 overflow-hidden shrink-0">
      <div className="flex items-center justify-start sm:justify-center gap-2 sm:gap-3 overflow-x-auto py-1 px-1 scrollbar-none no-scrollbar">
        {COLOR_PALETTE.map((color) => {
          const isSelected = !isEraser && selectedColor.id === color.id;

          if (color.isRainbow) {
            return (
              <button
                key={color.id}
                onClick={() => {
                  onTapSound?.();
                  onSelectColor(color);
                }}
                className={`kid-btn relative shrink-0 w-11 h-11 sm:w-13 sm:h-13 rounded-2xl flex items-center justify-center transition-all ${
                  isSelected
                    ? 'scale-115 ring-4 ring-purple-500 shadow-lg z-10'
                    : 'hover:scale-105 opacity-90'
                }`}
                style={{
                  background: 'linear-gradient(135deg, #ef4444, #f97316, #eab308, #22c55e, #3b82f6, #a855f7)',
                }}
                title="Magic Rainbow Pen!"
                aria-label="Magic Rainbow Pen"
              >
                <div className="w-full h-full rounded-2xl flex items-center justify-center bg-black/10">
                  <Sparkles className="w-5 h-5 text-white drop-shadow stroke-[2.5] animate-pulse" />
                </div>
                {isSelected && (
                  <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-purple-600 text-white rounded-full flex items-center justify-center text-[10px] font-black shadow border border-white">
                    ★
                  </span>
                )}
              </button>
            );
          }

          const isWhite = color.hex.toUpperCase() === '#FFFFFF';

          return (
            <button
              key={color.id}
              onClick={() => {
                onTapSound?.();
                onSelectColor(color);
              }}
              className={`kid-btn relative shrink-0 w-11 h-11 sm:w-13 sm:h-13 rounded-2xl flex items-center justify-center transition-all ${
                isSelected
                  ? 'scale-115 ring-4 ring-amber-500 shadow-lg z-10'
                  : 'hover:scale-105 opacity-90'
              } ${isWhite ? 'border-2 border-slate-300' : 'border border-black/10'}`}
              style={{
                backgroundColor: color.hex,
                boxShadow: isSelected
                  ? '0 6px 12px rgba(0,0,0,0.25)'
                  : '0 3px 6px rgba(0,0,0,0.15)',
              }}
              title={color.name}
              aria-label={`Select ${color.name}`}
            >
              {isSelected && (
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center font-bold ${
                    isWhite || color.id === 'yellow' ? 'text-slate-900' : 'text-white'
                  }`}
                >
                  <Check className="w-4 h-4 stroke-[3]" />
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
