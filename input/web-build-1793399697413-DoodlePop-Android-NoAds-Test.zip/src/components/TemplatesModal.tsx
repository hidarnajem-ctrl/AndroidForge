import React from 'react';
import { X, Palette, Sparkles } from 'lucide-react';
import { COLORING_TEMPLATES, ColoringTemplate } from '../types/drawing';

interface TemplatesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTemplate: (template: ColoringTemplate) => void;
  onTapSound?: () => void;
  onMagicSound?: () => void;
}

export const TemplatesModal: React.FC<TemplatesModalProps> = ({
  isOpen,
  onClose,
  onSelectTemplate,
  onTapSound,
  onMagicSound,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-5 animate-kid-pop">
      <div className="relative w-full max-w-md rounded-3xl bg-white p-5 sm:p-6 shadow-2xl border-4 border-pink-400 text-slate-800">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b-2 border-pink-100 mb-3">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-pink-100 border border-pink-300 flex items-center justify-center text-xl">
              🎨
            </div>
            <div>
              <h3 className="text-lg sm:text-xl font-bold text-slate-900 leading-tight">قوالب التلوين (Coloring Pages)</h3>
              <p className="text-[11px] sm:text-xs text-pink-700 font-semibold">
                جاهزة للتلوين فوراً بدون إنترنت
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              onTapSound?.();
              onClose();
            }}
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 font-bold flex items-center justify-center"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-slate-600 mb-3 text-center">
          اختر قالباً وسيقوم برسم الخطوط الخارجية على لوحتك لتبدأ تلوينها بالألوان وقلم قوس قزح!
        </p>

        {/* Templates Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-[60vh] overflow-y-auto p-1">
          {COLORING_TEMPLATES.map((tmpl) => (
            <button
              key={tmpl.id}
              onClick={() => {
                onMagicSound?.();
                onSelectTemplate(tmpl);
                onClose();
              }}
              className="kid-btn p-3 rounded-2xl bg-pink-50/70 hover:bg-pink-100 border-2 border-pink-200 flex flex-col items-center justify-center gap-1.5 transition text-center shadow-xs"
            >
              <span className="text-3xl sm:text-4xl">{tmpl.emoji}</span>
              <span className="text-xs font-bold text-slate-800">{tmpl.name}</span>
              <span className="text-[10px] text-pink-700 leading-tight">{tmpl.description}</span>
            </button>
          ))}
        </div>

        {/* Footer */}
        <div className="mt-4 pt-3 border-t border-pink-100 flex items-center justify-between text-xs text-slate-500">
          <span className="flex items-center gap-1 text-pink-700 font-semibold text-[11px]">
            <Sparkles className="w-3.5 h-3.5" />
            <span>يمكنك تلوينها بأي لون تختاره</span>
          </span>
          <button
            onClick={() => {
              onTapSound?.();
              onClose();
            }}
            className="kid-btn px-4 py-1.5 rounded-xl bg-pink-500 hover:bg-pink-400 text-white font-bold shadow-[0_2px_0_#db2777]"
          >
            إلغاء
          </button>
        </div>
      </div>
    </div>
  );
};
