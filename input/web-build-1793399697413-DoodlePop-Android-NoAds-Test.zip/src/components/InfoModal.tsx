import React, { useState } from 'react';
import { X, ShieldCheck, Heart } from 'lucide-react';

interface InfoModalProps { isOpen: boolean; onClose: () => void; }
export const InfoModal: React.FC<InfoModalProps> = ({ isOpen, onClose }) => {
  const [page, setPage] = useState<'about' | 'privacy'>('about');
  if (!isOpen) return null;
  return <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/55 backdrop-blur-sm p-3" role="dialog" aria-modal="true" aria-label="معلومات DoodlePop">
    <div dir="rtl" className="w-full max-w-md max-h-[85dvh] overflow-hidden rounded-3xl border-4 border-amber-300 bg-[#FFFBEB] shadow-2xl flex flex-col">
      <div className="flex items-center justify-between gap-2 p-4 bg-white border-b-2 border-amber-100">
        <div className="flex items-center gap-2"><div className="w-9 h-9 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center"><Heart className="w-5 h-5"/></div><div><h2 className="font-extrabold text-lg text-slate-800">DoodlePop</h2><p className="text-xs text-slate-500">معلومات التطبيق</p></div></div>
        <button onClick={onClose} className="kid-btn w-9 h-9 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center" aria-label="إغلاق"><X className="w-5 h-5"/></button>
      </div>
      <div className="flex gap-2 p-3 bg-white">
        <button onClick={() => setPage('about')} className={`flex-1 rounded-xl py-2 px-3 font-bold border-2 ${page === 'about' ? 'bg-rose-100 border-rose-300 text-rose-800' : 'bg-white border-slate-200 text-slate-600'}`}>من نحن</button>
        <button onClick={() => setPage('privacy')} className={`flex-1 rounded-xl py-2 px-3 font-bold border-2 ${page === 'privacy' ? 'bg-sky-100 border-sky-300 text-sky-800' : 'bg-white border-slate-200 text-slate-600'}`}><span className="inline-flex items-center gap-1"><ShieldCheck className="w-4 h-4"/> سياسة الخصوصية</span></button>
      </div>
      <div className="p-4 overflow-y-auto text-sm leading-7 text-slate-700">
        {page === 'about' ? <div className="space-y-3"><h3 className="text-base font-extrabold text-rose-700">مساحة آمنة للإبداع 🎨</h3><p>DoodlePop تطبيق بسيط للرسم والتلوين للأطفال، يتيح استخدام الألوان والأشكال والملصقات وقوالب التلوين وحفظ الأعمال في معرض محلي على الجهاز.</p><p>يمكن استخدام أدوات الرسم دون اتصال بالإنترنت. قد يحتاج تحميل الإعلانات إلى الاتصال بالشبكة.</p><p className="text-xs text-slate-500">الإصدار 1.0 · المطوّر: hidarnajem-ctrl</p></div> : <div className="space-y-3"><h3 className="text-base font-extrabold text-sky-800">سياسة الخصوصية — DoodlePop</h3><p><b>1. الرسومات والتخزين:</b> تُحفظ الرسومات في التخزين المحلي للتطبيق على جهازك، ولا يرفع التطبيق الرسومات إلى خوادمنا. حذف بيانات التطبيق أو إلغاء تثبيته قد يؤدي إلى فقدان الرسومات المحفوظة داخله. الصور التي تصدّرها إلى معرض الجهاز تبقى تحت إدارة نظام Android.</p><p><b>2. الإعلانات:</b> قد يستخدم التطبيق Google AdMob لعرض إعلانات. يمكن أن يعالج Google Mobile Ads SDK معلومات مثل عنوان IP، ومعرّفات الجهاز/الإعلانات، والتفاعل مع الإعلانات، وبيانات التشخيص بحسب إعدادات الجهاز والإعلانات والقوانين المطبقة. أُعدّت طلبات الإعلانات لتكون موجّهة للأطفال، مع تصنيف محتوى مناسب للأطفال (G) وعدم طلب الإعلانات المخصّصة من خلال إعدادات التطبيق.</p><p><b>3. الإنترنت:</b> أدوات الرسم الأساسية والمعرض المحلي تعمل دون اتصال. يلزم الاتصال بالإنترنت فقط للخدمات الشبكية مثل تحميل الإعلانات، عندما تكون متاحة.</p><p><b>4. الأطفال:</b> لا يطلب التطبيق إنشاء حساب أو إدخال الاسم أو البريد أو الموقع. لا تشجّعوا الأطفال على الضغط على الإعلانات. الإعلانات لا ينبغي أن تتداخل مع أدوات الرسم أو تُعرض بطريقة مضلّلة.</p><p><b>5. الاحتفاظ والحذف:</b> تبقى الرسومات المحفوظة في التخزين المحلي إلى أن يحذفها المستخدم من المعرض أو يمسح بيانات التطبيق/يزيله. بيانات الإعلانات التي يعالجها Google تخضع لسياسات Google وإعدادات خدماتها.</p><p><b>6. جهات خارجية:</b> عند عرض الإعلانات، قد تعالج Google البيانات وفق سياسة الخصوصية الخاصة بها: <a className="text-blue-700 underline" href="https://policies.google.com/privacy" target="_blank" rel="noreferrer">سياسة خصوصية Google</a>.</p><p><b>7. التواصل:</b> للاستفسارات، تواصل مع المطوّر عبر <a className="text-blue-700 underline" href="https://github.com/hidarnajem-ctrl" target="_blank" rel="noreferrer">صفحة المطوّر على GitHub</a>.</p><p className="text-xs text-slate-500">تاريخ التحديث: 31 أكتوبر 2026. يجب أن تتطابق هذه السياسة مع إعدادات AdMob الفعلية وإقرار أمان البيانات في Google Play قبل النشر.</p></div>}
      </div>
      <div className="p-3 border-t-2 border-amber-100 bg-white"><button onClick={onClose} className="kid-btn w-full rounded-xl bg-rose-500 text-white font-extrabold py-2.5 shadow-[0_3px_0_#be123c]">إغلاق</button></div>
    </div>
  </div>;
};
