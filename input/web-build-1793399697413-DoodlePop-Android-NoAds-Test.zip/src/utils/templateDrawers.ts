/**
 * Vector drawers for built-in offline coloring templates.
 * Each drawer draws clean bold black outlines centered in the canvas viewport.
 */

export function drawColoringTemplate(
  templateId: string,
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number
) {
  ctx.save();
  ctx.strokeStyle = '#1E293B';
  ctx.fillStyle = '#FFFFFF';
  ctx.lineWidth = 4.5;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  const cx = width / 2;
  const cy = height / 2;
  const scale = Math.min(width, height) * 0.72;

  switch (templateId) {
    case 'dino': {
      // Cute T-Rex Dinosaur
      const r = scale * 0.42;

      // Head & body contour
      ctx.beginPath();
      ctx.arc(cx - r * 0.2, cy - r * 0.4, r * 0.45, Math.PI * 0.8, Math.PI * 0.1);
      ctx.lineTo(cx + r * 0.5, cy - r * 0.2);
      ctx.arc(cx + r * 0.4, cy - r * 0.1, r * 0.15, 0, Math.PI * 0.5);
      ctx.lineTo(cx + r * 0.1, cy);
      // Back to tail
      ctx.quadraticCurveTo(cx - r * 0.1, cy + r * 0.6, cx + r * 0.7, cy + r * 0.7);
      ctx.quadraticCurveTo(cx + r * 0.1, cy + r * 0.8, cx - r * 0.2, cy + r * 0.7);
      // Feet
      ctx.lineTo(cx - r * 0.2, cy + r * 0.95);
      ctx.lineTo(cx - r * 0.4, cy + r * 0.95);
      ctx.lineTo(cx - r * 0.4, cy + r * 0.6);
      ctx.lineTo(cx - r * 0.6, cy + r * 0.95);
      ctx.lineTo(cx - r * 0.8, cy + r * 0.95);
      ctx.lineTo(cx - r * 0.7, cy + r * 0.3);
      ctx.closePath();
      ctx.stroke();

      // Belly line
      ctx.beginPath();
      ctx.arc(cx - r * 0.3, cy + r * 0.3, r * 0.35, Math.PI * 0.3, Math.PI * 0.9);
      ctx.stroke();

      // Eye
      ctx.beginPath();
      ctx.arc(cx + r * 0.1, cy - r * 0.35, r * 0.08, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(cx + r * 0.12, cy - r * 0.35, r * 0.035, 0, Math.PI * 2);
      ctx.fillStyle = '#1E293B';
      ctx.fill();

      // Spikes on back
      const spikes = [
        { x: cx - r * 0.55, y: cy - r * 0.4 },
        { x: cx - r * 0.68, y: cy - r * 0.15 },
        { x: cx - r * 0.72, y: cy + r * 0.15 },
        { x: cx - r * 0.6, y: cy + r * 0.4 },
        { x: cx - r * 0.35, y: cy + r * 0.65 },
      ];
      spikes.forEach((s) => {
        ctx.beginPath();
        ctx.moveTo(s.x, s.y);
        ctx.lineTo(s.x - r * 0.14, s.y - r * 0.08);
        ctx.lineTo(s.x - r * 0.04, s.y + r * 0.1);
        ctx.stroke();
      });
      break;
    }

    case 'rocket': {
      // Space Rocket
      const r = scale * 0.45;

      // Rocket body
      ctx.beginPath();
      ctx.moveTo(cx, cy - r * 0.95);
      ctx.quadraticCurveTo(cx + r * 0.45, cy - r * 0.3, cx + r * 0.35, cy + r * 0.45);
      ctx.lineTo(cx - r * 0.35, cy + r * 0.45);
      ctx.quadraticCurveTo(cx - r * 0.45, cy - r * 0.3, cx, cy - r * 0.95);
      ctx.stroke();

      // Nose cone divider
      ctx.beginPath();
      ctx.moveTo(cx - r * 0.28, cy - r * 0.45);
      ctx.lineTo(cx + r * 0.28, cy - r * 0.45);
      ctx.stroke();

      // Porthole Window
      ctx.beginPath();
      ctx.arc(cx, cy - r * 0.05, r * 0.2, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(cx, cy - r * 0.05, r * 0.12, 0, Math.PI * 2);
      ctx.stroke();

      // Left Fin
      ctx.beginPath();
      ctx.moveTo(cx - r * 0.35, cy + r * 0.15);
      ctx.quadraticCurveTo(cx - r * 0.75, cy + r * 0.45, cx - r * 0.6, cy + r * 0.65);
      ctx.lineTo(cx - r * 0.32, cy + r * 0.45);
      ctx.stroke();

      // Right Fin
      ctx.beginPath();
      ctx.moveTo(cx + r * 0.35, cy + r * 0.15);
      ctx.quadraticCurveTo(cx + r * 0.75, cy + r * 0.45, cx + r * 0.6, cy + r * 0.65);
      ctx.lineTo(cx + r * 0.32, cy + r * 0.45);
      ctx.stroke();

      // Thruster flame
      ctx.beginPath();
      ctx.moveTo(cx - r * 0.2, cy + r * 0.46);
      ctx.lineTo(cx - r * 0.25, cy + r * 0.75);
      ctx.lineTo(cx, cy + r * 0.95);
      ctx.lineTo(cx + r * 0.25, cy + r * 0.75);
      ctx.lineTo(cx + r * 0.2, cy + r * 0.46);
      ctx.stroke();
      break;
    }

    case 'puppy': {
      // Happy Puppy Face
      const r = scale * 0.42;

      // Head
      ctx.beginPath();
      ctx.arc(cx, cy, r * 0.6, 0, Math.PI * 2);
      ctx.stroke();

      // Left Ear
      ctx.beginPath();
      ctx.moveTo(cx - r * 0.45, cy - r * 0.35);
      ctx.bezierCurveTo(cx - r * 0.9, cy - r * 0.4, cx - r * 0.95, cy + r * 0.35, cx - r * 0.48, cy + r * 0.25);
      ctx.stroke();

      // Right Ear
      ctx.beginPath();
      ctx.moveTo(cx + r * 0.45, cy - r * 0.35);
      ctx.bezierCurveTo(cx + r * 0.9, cy - r * 0.4, cx + r * 0.95, cy + r * 0.35, cx + r * 0.48, cy + r * 0.25);
      ctx.stroke();

      // Eyes
      ctx.beginPath();
      ctx.arc(cx - r * 0.22, cy - r * 0.08, r * 0.085, 0, Math.PI * 2);
      ctx.arc(cx + r * 0.22, cy - r * 0.08, r * 0.085, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(cx - r * 0.22, cy - r * 0.08, r * 0.04, 0, Math.PI * 2);
      ctx.arc(cx + r * 0.22, cy - r * 0.08, r * 0.04, 0, Math.PI * 2);
      ctx.fillStyle = '#1E293B';
      ctx.fill();

      // Muzzle & Nose
      ctx.beginPath();
      ctx.ellipse(cx, cy + r * 0.18, r * 0.12, r * 0.08, 0, 0, Math.PI * 2);
      ctx.fill();

      // Mouth
      ctx.beginPath();
      ctx.moveTo(cx, cy + r * 0.25);
      ctx.lineTo(cx, cy + r * 0.35);
      ctx.quadraticCurveTo(cx - r * 0.15, cy + r * 0.48, cx - r * 0.22, cy + r * 0.36);
      ctx.moveTo(cx, cy + r * 0.35);
      ctx.quadraticCurveTo(cx + r * 0.15, cy + r * 0.48, cx + r * 0.22, cy + r * 0.36);
      ctx.stroke();

      // Tongue
      ctx.beginPath();
      ctx.arc(cx, cy + r * 0.4, r * 0.09, 0, Math.PI);
      ctx.stroke();
      break;
    }

    case 'butterfly': {
      // Butterfly Garden
      const r = scale * 0.45;

      // Body
      ctx.beginPath();
      ctx.ellipse(cx, cy, r * 0.09, r * 0.45, 0, 0, Math.PI * 2);
      ctx.stroke();

      // Head
      ctx.beginPath();
      ctx.arc(cx, cy - r * 0.48, r * 0.1, 0, Math.PI * 2);
      ctx.stroke();

      // Antennae
      ctx.beginPath();
      ctx.moveTo(cx - r * 0.04, cy - r * 0.58);
      ctx.quadraticCurveTo(cx - r * 0.2, cy - r * 0.8, cx - r * 0.25, cy - r * 0.72);
      ctx.moveTo(cx + r * 0.04, cy - r * 0.58);
      ctx.quadraticCurveTo(cx + r * 0.2, cy - r * 0.8, cx + r * 0.25, cy - r * 0.72);
      ctx.stroke();

      // Top Wings
      ctx.beginPath();
      ctx.moveTo(cx - r * 0.08, cy - r * 0.2);
      ctx.bezierCurveTo(cx - r * 0.5, cy - r * 0.85, cx - r * 0.95, cy - r * 0.5, cx - r * 0.65, cy);
      ctx.lineTo(cx - r * 0.08, cy);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(cx + r * 0.08, cy - r * 0.2);
      ctx.bezierCurveTo(cx + r * 0.5, cy - r * 0.85, cx + r * 0.95, cy - r * 0.5, cx + r * 0.65, cy);
      ctx.lineTo(cx + r * 0.08, cy);
      ctx.stroke();

      // Bottom Wings
      ctx.beginPath();
      ctx.moveTo(cx - r * 0.08, cy + r * 0.05);
      ctx.bezierCurveTo(cx - r * 0.7, cy + r * 0.2, cx - r * 0.65, cy + r * 0.75, cx - r * 0.08, cy + r * 0.35);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(cx + r * 0.08, cy + r * 0.05);
      ctx.bezierCurveTo(cx + r * 0.7, cy + r * 0.2, cx + r * 0.65, cy + r * 0.75, cx + r * 0.08, cy + r * 0.35);
      ctx.stroke();

      // Wing decorative patterns for coloring
      ctx.beginPath();
      ctx.arc(cx - r * 0.5, cy - r * 0.35, r * 0.12, 0, Math.PI * 2);
      ctx.arc(cx + r * 0.5, cy - r * 0.35, r * 0.12, 0, Math.PI * 2);
      ctx.arc(cx - r * 0.35, cy + r * 0.35, r * 0.09, 0, Math.PI * 2);
      ctx.arc(cx + r * 0.35, cy + r * 0.35, r * 0.09, 0, Math.PI * 2);
      ctx.stroke();
      break;
    }

    case 'robot': {
      // Friendly Robot
      const r = scale * 0.42;

      // Head
      ctx.beginPath();
      ctx.roundRect(cx - r * 0.45, cy - r * 0.75, r * 0.9, r * 0.55, 12);
      ctx.stroke();

      // Antenna
      ctx.beginPath();
      ctx.moveTo(cx, cy - r * 0.75);
      ctx.lineTo(cx, cy - r * 0.95);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(cx, cy - r * 0.98, r * 0.08, 0, Math.PI * 2);
      ctx.stroke();

      // Eyes
      ctx.beginPath();
      ctx.arc(cx - r * 0.2, cy - r * 0.5, r * 0.1, 0, Math.PI * 2);
      ctx.arc(cx + r * 0.2, cy - r * 0.5, r * 0.1, 0, Math.PI * 2);
      ctx.stroke();

      // Robot Smile (meter)
      ctx.beginPath();
      ctx.roundRect(cx - r * 0.25, cy - r * 0.32, r * 0.5, r * 0.08, 4);
      ctx.stroke();

      // Neck
      ctx.beginPath();
      ctx.rect(cx - r * 0.12, cy - r * 0.2, r * 0.24, r * 0.1);
      ctx.stroke();

      // Body
      ctx.beginPath();
      ctx.roundRect(cx - r * 0.55, cy - r * 0.1, r * 1.1, r * 0.75, 14);
      ctx.stroke();

      // Chest screen/buttons
      ctx.beginPath();
      ctx.roundRect(cx - r * 0.35, cy + r * 0.05, r * 0.7, r * 0.35, 8);
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(cx - r * 0.18, cy + r * 0.22, r * 0.07, 0, Math.PI * 2);
      ctx.arc(cx, cy + r * 0.22, r * 0.07, 0, Math.PI * 2);
      ctx.arc(cx + r * 0.18, cy + r * 0.22, r * 0.07, 0, Math.PI * 2);
      ctx.stroke();

      // Arms
      ctx.beginPath();
      ctx.moveTo(cx - r * 0.55, cy + r * 0.05);
      ctx.lineTo(cx - r * 0.8, cy + r * 0.25);
      ctx.arc(cx - r * 0.85, cy + r * 0.28, r * 0.08, 0, Math.PI * 2);
      ctx.moveTo(cx + r * 0.55, cy + r * 0.05);
      ctx.lineTo(cx + r * 0.8, cy + r * 0.25);
      ctx.arc(cx + r * 0.85, cy + r * 0.28, r * 0.08, 0, Math.PI * 2);
      ctx.stroke();
      break;
    }

    case 'flower':
    default: {
      // Sunny Flower
      const r = scale * 0.45;

      // Stem
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.quadraticCurveTo(cx - r * 0.15, cy + r * 0.5, cx, cy + r * 0.95);
      ctx.stroke();

      // Leaves
      ctx.beginPath();
      ctx.moveTo(cx - r * 0.05, cy + r * 0.5);
      ctx.quadraticCurveTo(cx - r * 0.45, cy + r * 0.35, cx - r * 0.5, cy + r * 0.55);
      ctx.quadraticCurveTo(cx - r * 0.25, cy + r * 0.65, cx - r * 0.05, cy + r * 0.5);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(cx + r * 0.05, cy + r * 0.65);
      ctx.quadraticCurveTo(cx + r * 0.45, cy + r * 0.5, cx + r * 0.5, cy + r * 0.7);
      ctx.quadraticCurveTo(cx + r * 0.25, cy + r * 0.8, cx + r * 0.05, cy + r * 0.65);
      ctx.stroke();

      // Center disc
      ctx.beginPath();
      ctx.arc(cx, cy - r * 0.15, r * 0.25, 0, Math.PI * 2);
      ctx.stroke();

      // 8 Petals
      const petalCount = 8;
      for (let i = 0; i < petalCount; i++) {
        const angle = (i * Math.PI * 2) / petalCount;
        const px = cx + Math.cos(angle) * r * 0.45;
        const py = cy - r * 0.15 + Math.sin(angle) * r * 0.45;

        ctx.beginPath();
        ctx.arc(px, py, r * 0.2, 0, Math.PI * 2);
        ctx.stroke();
      }
      break;
    }
  }

  ctx.restore();
}
