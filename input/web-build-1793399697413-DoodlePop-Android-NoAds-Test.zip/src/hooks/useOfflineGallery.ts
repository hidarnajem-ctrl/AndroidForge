import { useState, useEffect, useCallback } from 'react';
import { SavedArtwork } from '../types/drawing';

const STORAGE_KEY = 'doodlepop_offline_artworks';

export function useOfflineGallery() {
  const [artworks, setArtworks] = useState<SavedArtwork[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {
      // Fallback
    }
    return [];
  });

  // Sync state to localStorage whenever artworks change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(artworks));
    } catch {
      // If quota exceeded, remove oldest artwork
      if (artworks.length > 1) {
        const reduced = artworks.slice(0, artworks.length - 1);
        try {
          localStorage.setItem(STORAGE_KEY, JSON.stringify(reduced));
          setArtworks(reduced);
        } catch {
          // ignore
        }
      }
    }
  }, [artworks]);

  const saveArtwork = useCallback(
    (dataUrl: string, backgroundColor: string, customTitle?: string): SavedArtwork => {
      const id = 'art_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
      const title = customTitle || `رسمتي #${artworks.length + 1}`;
      const newArtwork: SavedArtwork = {
        id,
        title,
        createdAt: Date.now(),
        dataUrl,
        backgroundColor,
      };

      setArtworks((prev) => [newArtwork, ...prev.slice(0, 24)]);
      return newArtwork;
    },
    [artworks.length]
  );

  const deleteArtwork = useCallback((id: string) => {
    setArtworks((prev) => prev.filter((item) => item.id !== id));
  }, []);

  return {
    artworks,
    saveArtwork,
    deleteArtwork,
  };
}
