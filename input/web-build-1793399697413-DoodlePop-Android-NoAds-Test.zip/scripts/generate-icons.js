import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

function crc32(buf) {
  let table = [];
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[n] = c;
  }
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = table[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

function makeChunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const body = Buffer.concat([typeBuf, data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body), 0);
  return Buffer.concat([len, body, crc]);
}

function createPng(width, height, pixelFn) {
  const sig = Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]);
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8;
  ihdrData[9] = 6;
  ihdrData[10] = 0;
  ihdrData[11] = 0;
  ihdrData[12] = 0;
  const ihdr = makeChunk('IHDR', ihdrData);

  const rowSize = 1 + width * 4;
  const rawData = Buffer.alloc(height * rowSize);
  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowSize;
    rawData[rowOffset] = 0;
    for (let x = 0; x < width; x++) {
      const pxOffset = rowOffset + 1 + x * 4;
      const [r, g, b, a] = pixelFn(x, y, width, height);
      rawData[pxOffset] = r;
      rawData[pxOffset + 1] = g;
      rawData[pxOffset + 2] = b;
      rawData[pxOffset + 3] = a;
    }
  }

  const compressed = zlib.deflateSync(rawData);
  const idat = makeChunk('IDAT', compressed);
  const iend = makeChunk('IEND', Buffer.alloc(0));
  return Buffer.concat([sig, ihdr, idat, iend]);
}

// Icon rendering function
function drawKidIcon(x, y, w, h, isMaskable = false) {
  // Normalize to 0..1
  const nx = x / w;
  const ny = y / h;

  // Background: Vibrant cheerful gradient (Warm Coral Pink to Sunset Orange)
  const bgR = Math.round(255 - nx * 15);
  const bgG = Math.round(105 + ny * 60);
  const bgB = Math.round(90 + nx * 50);

  // If not maskable, we round the corners with squircle radius
  const cornerRadius = 0.22;
  const dx = Math.max(0, Math.abs(nx - 0.5) - (0.5 - cornerRadius));
  const dy = Math.max(0, Math.abs(ny - 0.5) - (0.5 - cornerRadius));
  const distCorner = Math.sqrt(dx * dx + dy * dy);
  
  if (!isMaskable && distCorner > cornerRadius) {
    return [0, 0, 0, 0]; // Transparent outside squircle
  }

  // Inside icon:
  // Palette center at (0.48, 0.52)
  const cx = 0.48;
  const cy = 0.52;
  const pdx = (nx - cx) / 0.36;
  const pdy = (ny - cy) / 0.33;
  const palDist = Math.sqrt(pdx * pdx + pdy * pdy);

  // Thumbhole at (0.33, 0.62)
  const thx = (nx - 0.33) / 0.08;
  const thy = (ny - 0.62) / 0.08;
  const thumbDist = Math.sqrt(thx * thx + thy * thy);

  // Blobs on palette:
  const blobs = [
    { x: 0.34, y: 0.36, r: 0.065, color: [239, 68, 68] },   // Red
    { x: 0.48, y: 0.30, r: 0.065, color: [245, 158, 11] },  // Orange
    { x: 0.63, y: 0.35, r: 0.065, color: [234, 179, 8] },   // Yellow
    { x: 0.68, y: 0.49, r: 0.065, color: [34, 197, 94] },   // Green
    { x: 0.58, y: 0.66, r: 0.065, color: [59, 130, 246] },  // Blue
  ];

  // Brush across from top-left (0.2, 0.2) to bottom-right (0.8, 0.8)
  // Let's check brush line
  // Line segment: p1 = (0.75, 0.22), p2 = (0.24, 0.76)
  // Brush handle vector:
  const bx1 = 0.74, by1 = 0.22, bx2 = 0.26, by2 = 0.78;
  const bdx = bx2 - bx1, bdy = by2 - by1;
  const bLenSq = bdx * bdx + bdy * bdy;
  const t = Math.max(0, Math.min(1, ((nx - bx1) * bdx + (ny - by1) * bdy) / bLenSq));
  const projX = bx1 + t * bdx;
  const projY = by1 + t * bdy;
  const brushDist = Math.hypot(nx - projX, ny - projY);

  // Check if pixel is on brush tip (around bx2, by2)
  const tipDist = Math.hypot(nx - bx2, ny - by2);

  // 1. Brush tip (yellow paint splash)
  if (tipDist < 0.055) {
    return [255, 230, 0, 255]; // Yellow paint tip
  }

  // 2. Brush ferrule & wooden handle
  if (brushDist < 0.032 && t > 0.05 && t < 0.95) {
    if (t < 0.25) {
      // Wood handle tip
      return [180, 110, 60, 255];
    } else if (t < 0.75) {
      // Main wooden shaft
      return [217, 145, 90, 255];
    } else {
      // Silver ferrule
      return [210, 220, 230, 255];
    }
  }

  // 3. Blobs on palette
  for (const b of blobs) {
    const dist = Math.hypot(nx - b.x, ny - b.y);
    if (dist < b.r) {
      // Gloss highlight on blob
      const hDist = Math.hypot(nx - (b.x - 0.02), ny - (b.y - 0.02));
      if (hDist < b.r * 0.4) {
        return [
          Math.min(255, b.color[0] + 60),
          Math.min(255, b.color[1] + 60),
          Math.min(255, b.color[2] + 60),
          255
        ];
      }
      return [b.color[0], b.color[1], b.color[2], 255];
    }
  }

  // 4. Palette thumbhole
  if (thumbDist < 1.0) {
    return [bgR, bgG, bgB, 255]; // Shows background through hole
  }

  // 5. Palette board (Creamy warm ivory with soft bevel border)
  if (palDist < 1.0) {
    if (palDist > 0.94) {
      return [230, 215, 195, 255]; // Palette edge outline
    }
    return [255, 252, 245, 255]; // Palette white/ivory surface
  }

  // Background
  return [bgR, bgG, bgB, 255];
}

const publicDir = path.resolve(process.cwd(), 'public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// Generate 192x192
const png192 = createPng(192, 192, (x, y, w, h) => drawKidIcon(x, y, w, h, false));
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), png192);

// Generate 512x512
const png512 = createPng(512, 512, (x, y, w, h) => drawKidIcon(x, y, w, h, false));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), png512);

// Generate maskable 512x512
const pngMaskable = createPng(512, 512, (x, y, w, h) => drawKidIcon(x, y, w, h, true));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), pngMaskable);

// Generate apple-touch-icon 180x180
const pngApple = createPng(180, 180, (x, y, w, h) => drawKidIcon(x, y, w, h, false));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), pngApple);

// Generate favicon.ico (can be a 48x48 PNG renamed or standard)
const pngFavicon = createPng(64, 64, (x, y, w, h) => drawKidIcon(x, y, w, h, false));
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), pngFavicon);

// Generate vector icon.svg
const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FF577F" />
      <stop offset="100%" stop-color="#FF884B" />
    </linearGradient>
    <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
      <feDropShadow dx="0" dy="12" stdDeviation="16" flood-opacity="0.25" flood-color="#000" />
    </filter>
  </defs>
  <rect width="512" height="512" rx="115" fill="url(#bg)"/>
  <ellipse cx="250" cy="270" rx="180" ry="165" fill="#FFFBF5" filter="url(#shadow)"/>
  <circle cx="170" cy="330" r="32" fill="#FF7862" />
  <!-- Color blobs -->
  <circle cx="175" cy="180" r="34" fill="#FF4757" />
  <circle cx="245" cy="150" r="34" fill="#FFA502" />
  <circle cx="320" cy="175" r="34" fill="#2ED573" />
  <circle cx="360" cy="250" r="34" fill="#1E90FF" />
  <circle cx="310" cy="340" r="34" fill="#9B59B6" />
  <!-- Paint brush -->
  <g transform="rotate(-38 270 240)">
    <rect x="252" y="100" width="28" height="230" rx="14" fill="#C68B59" />
    <rect x="250" y="320" width="32" height="40" rx="6" fill="#CED6E0" />
    <path d="M250 360 C250 410, 282 410, 282 360 Z" fill="#FFA502" />
  </g>
</svg>`;
fs.writeFileSync(path.join(publicDir, 'icon.svg'), svg);

console.log('Successfully generated all PWA icons and SVG in public/');
