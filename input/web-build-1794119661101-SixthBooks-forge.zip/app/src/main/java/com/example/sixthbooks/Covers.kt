package com.example.sixthbooks

/**
 * صور الأغلفة المضمّنة في التطبيق، مربوطة باسم ملف الكتاب في books.json.
 * إن أضفت كتاباً جديداً: ضع صورة غلافه في res/drawable-nodpi وأضف سطراً هنا.
 * الكتاب الذي ليس له غلاف هنا يظهر بغلاف عام يحمل عنوانه.
 */
object Covers {
    private val map = mapOf(
        "mathematics.pdf" to R.drawable.cover_mathematics,
        "math-exercises.pdf" to R.drawable.cover_math_exercises,
        "sciences.pdf" to R.drawable.cover_sciences,
        "sciences-activity.pdf" to R.drawable.cover_sciences_activity,
        "reading.pdf" to R.drawable.cover_reading,
        "rules.pdf" to R.drawable.cover_rules,
        "english.pdf" to R.drawable.cover_english,
        "english-activity.pdf" to R.drawable.cover_english_activity,
        "islamic.pdf" to R.drawable.cover_islamic,
        "social-studies.pdf" to R.drawable.cover_social_studies
    )

    fun of(book: Book): Int? = map[book.fileName]
}
