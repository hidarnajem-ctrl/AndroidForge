package com.example.sixthbooks

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Gold = Color(0xFFFFD27A)
private val GoldDeep = Color(0xFFE0A53A)
private val TextShadow = Shadow(Color(0xCC000000), Offset(0f, 3f), 6f)

/** نسبة عرض صورة الرف إلى ارتفاعها، ومساحة أرضية الرف داخلها */
private const val SHELF_RATIO = 1000f / 627f
private const val SHELF_PAD_X = 0.09f
private const val SHELF_PAD_TOP = 0.15f
private const val SHELF_PAD_BOTTOM = 0.155f
private const val COVER_RATIO = 0.707f

@Composable
fun HomeScreen(vm: MainViewModel, onOpen: (Book) -> Unit) {
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) {
        val msg = vm.message
        if (msg != null) {
            snackbar.showSnackbar(msg)
            vm.message = null
        }
    }

    Box(Modifier.fillMaxSize()) {
        // خلفية الخشب لكامل الشاشة
        Image(
            painter = painterResource(R.drawable.bg_wood),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0x33000000), Color(0x66000000))))
        )

        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = { BannerAd(Modifier.navigationBarsPadding()) },
            contentWindowInsets = WindowInsets(0)
        ) { pad ->
            Column(
                Modifier
                    .padding(pad)
                    .fillMaxSize()
            ) {
                Header()
                when {
                    vm.loading -> CenterBox { CircularProgressIndicator(color = Gold) }
                    vm.failed && vm.books.isEmpty() -> ErrorState(onRetry = vm::refresh)
                    else -> Library(vm, onOpen)
                }
            }
        }
    }
}

@Composable
private fun CenterBox(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { content() }
}

/** لوحة العنوان: قماش أخضر داخل إطار خشبي، مثل لوحة الصف */
@Composable
private fun Header() {
    Box(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 4.dp)
            .shadow(10.dp, RoundedCornerShape(18.dp))
            .clip(RoundedCornerShape(18.dp))
            .border(BorderStroke(5.dp, Brush.verticalGradient(listOf(Gold, Color(0xFF8A4B12)))), RoundedCornerShape(18.dp))
    ) {
        Image(
            painter = painterResource(R.drawable.bg_felt),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.matchParentSize()
        )
        Column(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp, horizontal = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "مكتبة الصف السادس الابتدائي",
                style = TextStyle(
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    shadow = TextShadow
                )
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "المنهج العراقي • اضغط على الكتاب لفتحه",
                style = TextStyle(color = Gold, fontSize = 13.sp, shadow = TextShadow)
            )
        }
    }
}

@Composable
private fun ErrorState(onRetry: () -> Unit) {
    CenterBox {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
            Text(
                "تعذّر تحميل قائمة الكتب",
                style = TextStyle(color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, shadow = TextShadow)
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "تأكد من اتصالك بالإنترنت ثم أعد المحاولة",
                style = TextStyle(color = Color(0xFFF1E4D3), textAlign = TextAlign.Center, shadow = TextShadow)
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(containerColor = GoldDeep, contentColor = Color(0xFF3B1F05))
            ) { Text("إعادة المحاولة", fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun Library(vm: MainViewModel, onOpen: (Book) -> Unit) {
    LazyColumn(
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        items(vm.shelves, key = { it.first }) { (name, books) ->
            Shelf(
                name = name,
                books = books,
                vm = vm,
                onTap = { book ->
                    when {
                        vm.isDownloaded(book) -> onOpen(book)
                        !vm.isDownloading(book) -> vm.download(book)
                    }
                }
            )
        }
    }
}

@Composable
private fun Shelf(name: String, books: List<Book>, vm: MainViewModel, onTap: (Book) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        // لافتة اسم الرف
        Surface(
            shape = RoundedCornerShape(50),
            color = Color(0xCC2A1405),
            border = BorderStroke(1.5.dp, GoldDeep),
            shadowElevation = 4.dp,
            modifier = Modifier.padding(top = 6.dp)
        ) {
            Text(
                name,
                color = Gold,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp)
            )
        }

        BoxWithConstraints(
            Modifier
                .fillMaxWidth()
                .aspectRatio(SHELF_RATIO)
        ) {
            val shelfH = maxHeight
            val shelfW = maxWidth
            Image(
                painter = painterResource(R.drawable.shelf_frame),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize()
            )
            // الكتب تقف على أرضية الرف
            Row(
                Modifier
                    .fillMaxSize()
                    .padding(
                        start = shelfW * SHELF_PAD_X,
                        end = shelfW * SHELF_PAD_X,
                        top = shelfH * SHELF_PAD_TOP,
                        bottom = shelfH * SHELF_PAD_BOTTOM
                    ),
                horizontalArrangement = Arrangement.spacedBy(shelfW * 0.07f, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.Bottom
            ) {
                val coverH = shelfH * 0.64f
                books.forEach { book ->
                    BookCover(
                        book = book,
                        height = coverH,
                        downloaded = vm.isDownloaded(book),
                        progress = vm.progress[book.fileName],
                        onClick = { onTap(book) }
                    )
                }
            }
        }
    }
}

@Composable
private fun BookCover(
    book: Book,
    height: Dp,
    downloaded: Boolean,
    progress: Float?,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(topEnd = 4.dp, bottomEnd = 4.dp, topStart = 2.dp, bottomStart = 2.dp)
    Box(
        Modifier
            .height(height)
            .width(height * COVER_RATIO)
            .shadow(12.dp, shape)
            .clip(shape)
            .clickable(onClick = onClick)
    ) {
        val cover = Covers.of(book)
        if (cover != null) {
            Image(
                painter = painterResource(cover),
                contentDescription = book.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            GenericCover(book)
        }

        // لمعة خفيفة على كعب الكتاب لتبدو مجسّمة
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        0f to Color(0x55000000),
                        0.06f to Color(0x22FFFFFF),
                        0.12f to Color.Transparent,
                        1f to Color.Transparent
                    )
                )
        )

        when {
            progress != null -> DownloadOverlay(progress)
            !downloaded -> Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(5.dp)
                    .size(24.dp)
                    .background(Color(0xDD1B5E20), CircleShape)
                    .border(1.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.KeyboardArrowDown,
                    contentDescription = "غير محمّل",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
private fun DownloadOverlay(progress: Float) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xB3000000)),
        contentAlignment = Alignment.Center
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (progress > 0f) {
                CircularProgressIndicator(
                    progress = { progress },
                    color = Gold,
                    trackColor = Color(0x55FFFFFF),
                    strokeWidth = 4.dp,
                    modifier = Modifier.size(48.dp)
                )
            } else {
                CircularProgressIndicator(color = Gold, strokeWidth = 4.dp, modifier = Modifier.size(48.dp))
            }
            Text(
                "${(progress * 100).toInt()}%",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun GenericCover(book: Book) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1E4DB7), Color(0xFF0A2463)))),
        contentAlignment = Alignment.Center
    ) {
        Text(
            book.title,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(6.dp)
        )
    }
}
