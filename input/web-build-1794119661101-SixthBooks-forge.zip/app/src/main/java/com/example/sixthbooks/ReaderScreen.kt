package com.example.sixthbooks

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

private const val MAX_RENDER_WIDTH_PX = 1800
private const val MIN_ZOOM = 1f
private const val MAX_ZOOM = 2.5f

@Composable
fun ReaderScreen(book: Book, file: File, onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("reader", Context.MODE_PRIVATE) }
    val mutex = remember { Mutex() }
    var renderer by remember { mutableStateOf<PdfRenderer?>(null) }
    var error by remember { mutableStateOf(false) }
    var zoom by remember { mutableFloatStateOf(1f) }

    BackHandler(onBack = onBack)

    DisposableEffect(file) {
        var pfd: ParcelFileDescriptor? = null
        var r: PdfRenderer? = null
        try {
            pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            r = PdfRenderer(pfd)
            renderer = r
        } catch (e: Exception) {
            error = true
            pfd?.close()
        }
        onDispose {
            renderer = null
            // ننتظر انتهاء أي صفحة قيد الرسم قبل إغلاق القارئ
            runBlocking {
                mutex.withLock {
                    try {
                        r?.close()
                    } catch (_: Exception) {
                    }
                    try {
                        pfd?.close()
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.surfaceVariant,
        contentWindowInsets = WindowInsets(0),
        topBar = {
            Surface(color = Color(0xFF3B1F0A)) {
                Row(
                    Modifier
                        .statusBarsPadding()
                        .height(56.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = Color.White
                        )
                    }
                    Text(
                        book.title,
                        modifier = Modifier.weight(1f),
                        color = Color(0xFFFFD27A),
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    IconButton(onClick = { zoom = (zoom - 0.5f).coerceAtLeast(MIN_ZOOM) }) {
                        Text("−", color = Color(0xFFFFD27A), fontSize = 26.sp)
                    }
                    IconButton(onClick = { zoom = (zoom + 0.5f).coerceAtMost(MAX_ZOOM) }) {
                        Text("+", color = Color(0xFFFFD27A), fontSize = 26.sp)
                    }
                }
            }
        },
        bottomBar = { BannerAd(Modifier.navigationBarsPadding()) }
    ) { pad ->
        val r = renderer
        when {
            error -> Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "تعذّر فتح الكتاب. احذفه من الجهاز وحمّله مرة أخرى.",
                    modifier = Modifier.padding(24.dp),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            r == null -> Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }

            else -> BoxWithConstraints(
                Modifier
                    .padding(pad)
                    .fillMaxSize()
            ) {
                val count = r.pageCount
                val density = LocalDensity.current
                val screenWidthPx = with(density) { maxWidth.roundToPx() }
                val contentWidth = maxWidth * zoom
                val prefKey = "page_${book.fileName}"
                val listState = rememberLazyListState(
                    initialFirstVisibleItemIndex = prefs.getInt(prefKey, 0).coerceIn(0, (count - 1).coerceAtLeast(0))
                )

                LaunchedEffect(listState) {
                    snapshotFlow { listState.firstVisibleItemIndex }.collect {
                        prefs.edit().putInt(prefKey, it).apply()
                    }
                }

                val hScroll = rememberScrollState()
                Box(
                    Modifier
                        .fillMaxSize()
                        .horizontalScroll(hScroll)
                ) {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .width(contentWidth)
                            .fillMaxHeight(),
                        contentPadding = PaddingValues(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(count) { index ->
                            PdfPage(
                                renderer = r,
                                mutex = mutex,
                                index = index,
                                widthPx = minOf((screenWidthPx * zoom).toInt(), MAX_RENDER_WIDTH_PX)
                            )
                        }
                    }
                }

                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 12.dp),
                    shape = RoundedCornerShape(50),
                    color = Color(0xCC000000)
                ) {
                    Text(
                        "${listState.firstVisibleItemIndex + 1} / $count",
                        color = Color.White,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PdfPage(renderer: PdfRenderer, mutex: Mutex, index: Int, widthPx: Int) {
    val bitmap by produceState<Bitmap?>(initialValue = null, index, widthPx) {
        value = withContext(Dispatchers.Default) {
            mutex.withLock {
                try {
                    renderer.openPage(index).use { page ->
                        val h = (widthPx.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(android.graphics.Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        bmp
                    }
                } catch (e: Exception) {
                    null
                }
            }
        }
    }

    val bmp = bitmap
    if (bmp != null) {
        Image(
            bitmap = bmp.asImageBitmap(),
            contentDescription = null,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(bmp.width.toFloat() / bmp.height),
            contentScale = ContentScale.FillBounds,
            filterQuality = FilterQuality.Medium
        )
    } else {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(0.72f)
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
    }
}
