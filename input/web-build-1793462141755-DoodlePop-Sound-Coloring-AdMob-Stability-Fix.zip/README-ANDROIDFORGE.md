# DoodlePop Android project

This archive preserves the original DoodlePop React/TypeScript drawing application and adds a native Android WebView shell so AndroidForge can build it as an APK.

## Included application features

The original React application source, drawing canvas, brush and eraser tools, color palette, rainbow pen, stamps, brush sizes, paper backgrounds, undo/redo history, clear confirmation, sound effects, confetti celebration, offline status indicator, and browser/PWA support are retained. In the Android APK, the Save action writes PNG drawings directly to `Pictures/DoodlePop` using Android MediaStore.

## Build with AndroidForge

1. Zip the project root (the folder containing `settings.gradle`, `build.gradle`, `app/`, `src/`, and `package.json`).
2. Upload the ZIP to AndroidForge and choose **Android (APK)**.
3. Keep the build variant on **auto** and leave **Force-install NDK** disabled.
4. Start the build.

The Gradle build task downloads Node.js 22.16.0 into the temporary Gradle build directory, installs the JavaScript dependencies, and runs the Vite Android build. The compiled web app is bundled inside the APK at `app/src/main/assets/www`, so the drawing interface itself runs locally and does not need a hosted website or an internet connection after installation. Internet access is required during the first build to download Node.js and packages.

## Android build details

- Application ID: `com.doodlepop.kidsdrawing`
- Minimum Android version: Android 10 (API 29)
- Compile SDK: 35 · Target SDK: 34
- Android shell: native Java Activity + WebView
- Artwork location: `Pictures/DoodlePop`


## Ads and privacy
- AdMob is integrated in the Android shell. Debug variants use Google's test app and ad-unit IDs; Release variants use the configured DoodlePop IDs.
- Requests are configured for child-directed treatment with a G content rating. Review current Google Play Families and AdMob requirements before release.
- The in-app About dialog links to the hosted privacy policy: https://hidarnajem-ctrl.github.io/doodlepop-privacy-policy/
- Google Play approval cannot be guaranteed by code changes alone.


## Blank-screen WebView fix
This build serves the bundled React/Vite assets through AndroidX WebViewAssetLoader at `https://appassets.androidplatform.net/assets/www/index.html`, rather than loading ES modules from `file://`. The build downloads/builds the web assets as before.
