package com.dominoclassic.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dominoclassic.R
import com.dominoclassic.ui.theme.Gold
import com.dominoclassic.ui.theme.Ivory
import com.dominoclassic.ui.theme.Midnight

@Composable
fun ScreenTopBar(title: Int, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back), tint = Gold)
        }
        Text(stringResource(title), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ivory)
    }
}

private fun pipCells(n: Int): List<Pair<Int, Int>> = when (n) {
    0 -> emptyList()
    1 -> listOf(1 to 1)
    2 -> listOf(0 to 0, 2 to 2)
    3 -> listOf(0 to 0, 1 to 1, 2 to 2)
    4 -> listOf(0 to 0, 2 to 0, 0 to 2, 2 to 2)
    5 -> listOf(0 to 0, 2 to 0, 1 to 1, 0 to 2, 2 to 2)
    else -> listOf(0 to 0, 2 to 0, 0 to 1, 2 to 1, 0 to 2, 2 to 2)
}

private fun DrawScope.drawPips(n: Int, y0: Float, w: Float) {
    for ((cx, cy) in pipCells(n)) {
        drawCircle(Midnight, radius = w * 0.08f, center = Offset(w * 0.22f + cx * w * 0.28f, y0 + w * 0.22f + cy * w * 0.28f))
    }
}

/** Vertical domino tile drawn in code (original artwork, no bitmaps). */
@Composable
fun DominoTileArt(top: Int, bottom: Int, modifier: Modifier = Modifier) {
    Canvas(modifier.aspectRatio(0.5f)) {
        val w = size.width; val h = size.height; val r = CornerRadius(w * 0.18f)
        drawRoundRect(Brush.verticalGradient(listOf(Ivory, Color(0xFFE3DCC3))), cornerRadius = r)
        drawRoundRect(Gold, style = Stroke(w * 0.035f), cornerRadius = r)
        drawLine(Gold, Offset(w * 0.12f, h / 2), Offset(w * 0.88f, h / 2), strokeWidth = w * 0.03f)
        drawPips(top, 0f, w)
        drawPips(bottom, h / 2, w)
    }
}
