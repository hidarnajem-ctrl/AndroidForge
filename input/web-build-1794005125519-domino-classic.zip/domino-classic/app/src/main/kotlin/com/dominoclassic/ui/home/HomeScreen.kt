package com.dominoclassic.ui.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dominoclassic.R
import com.dominoclassic.data.AppSettings
import com.dominoclassic.ui.AppViewModel
import com.dominoclassic.ui.DominoTileArt
import com.dominoclassic.ui.theme.*

@Composable
fun HomeScreen(onSoon: (Int) -> Unit, onSettings: () -> Unit, vm: AppViewModel = viewModel()) {
    val s by vm.state.collectAsStateWithLifecycle()
    Column(
        Modifier.fillMaxSize().gameBackground().systemBarsPadding()
            .verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ProfileBar(s)
        Hero()
        MenuCard(Icons.Filled.PlayArrow, R.string.play_computer, Modifier.fillMaxWidth(), primary = true) { onSoon(R.string.play_computer) }
        MenuCard(Icons.Filled.Person, R.string.play_friend, Modifier.fillMaxWidth()) { onSoon(R.string.play_friend) }
        MenuCard(Icons.Filled.Search, R.string.play_online, Modifier.fillMaxWidth()) { onSoon(R.string.play_online) }
        val grid: List<Triple<ImageVector, Int, () -> Unit>> = listOf(
            Triple(Icons.Filled.Favorite, R.string.daily_rewards) { onSoon(R.string.daily_rewards) },
            Triple(Icons.Filled.Check, R.string.missions) { onSoon(R.string.missions) },
            Triple(Icons.Filled.ShoppingCart, R.string.shop) { onSoon(R.string.shop) },
            Triple(Icons.Filled.Info, R.string.statistics) { onSoon(R.string.statistics) },
            Triple(Icons.Filled.Settings, R.string.settings, onSettings),
        )
        grid.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { (icon, label, action) -> MenuCard(icon, label, Modifier.weight(1f), onClick = action) }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ProfileBar(s: AppSettings) {
    val name = s.playerName ?: stringResource(R.string.default_player_name)
    Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface, border = BorderStroke(1.dp, Gold.copy(alpha = 0.35f))) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(52.dp).clip(CircleShape).background(Emerald).border(2.dp, Gold, CircleShape), contentAlignment = Alignment.Center) {
                Text(name.take(1), style = MaterialTheme.typography.titleLarge, color = Ivory)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Ivory)
                Text(stringResource(R.string.level_fmt, s.xp / 100 + 1), style = MaterialTheme.typography.bodySmall, color = Gold)
                LinearProgressIndicator(progress = { (s.xp % 100) / 100f }, modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = Midnight)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(Icons.Filled.Star, null, tint = Gold, modifier = Modifier.size(20.dp))
                Text("${s.coins}", color = Ivory, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun Hero() {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            DominoTileArt(6, 6, Modifier.width(44.dp).rotate(-10f))
            DominoTileArt(2, 5, Modifier.width(44.dp).rotate(10f))
        }
        Text(
            stringResource(R.string.app_name), style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold, color = Gold, modifier = Modifier.padding(top = 10.dp),
        )
    }
}

@Composable
private fun MenuCard(icon: ImageVector, label: Int, modifier: Modifier = Modifier, primary: Boolean = false, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val fill = if (primary) Brush.horizontalGradient(listOf(Emerald, EmeraldLight)) else SolidColor(MaterialTheme.colorScheme.surface)
    Row(
        modifier.heightIn(min = if (primary) 68.dp else 64.dp).clip(shape).background(fill)
            .border(1.dp, if (primary) Gold else Gold.copy(alpha = 0.3f), shape)
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(icon, null, tint = Gold)
        Text(stringResource(label), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = Ivory, maxLines = 2)
    }
}
