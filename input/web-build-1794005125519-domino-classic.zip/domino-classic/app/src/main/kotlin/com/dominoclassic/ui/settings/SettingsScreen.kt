package com.dominoclassic.ui.settings

import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dominoclassic.R
import com.dominoclassic.data.Keys
import com.dominoclassic.engine.Variant
import com.dominoclassic.ui.AppViewModel
import com.dominoclassic.ui.ScreenTopBar
import com.dominoclassic.ui.theme.Gold
import com.dominoclassic.ui.theme.gameBackground

@Composable
fun SettingsScreen(onBack: () -> Unit, vm: AppViewModel = viewModel()) {
    val s by vm.state.collectAsStateWithLifecycle()
    var dialog by remember { mutableStateOf<Int?>(null) }
    val lang = remember { AppCompatDelegate.getApplicationLocales().get(0)?.language ?: "ar" }

    Column(Modifier.fillMaxSize().gameBackground().systemBarsPadding().padding(horizontal = 16.dp)) {
        ScreenTopBar(R.string.settings, onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Section(R.string.language)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("ar" to "العربية", "en" to "English", "es" to "Español").forEach { (tag, name) ->
                    FilterChip(
                        selected = lang == tag,
                        onClick = { AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag)) },
                        label = { Text(name) },
                    )
                }
            }
            Flag(R.string.sound, Keys.SOUND, s.sound, vm)
            Flag(R.string.music, Keys.MUSIC, s.music, vm)
            Flag(R.string.vibration, Keys.VIBRATION, s.vibration, vm)
            Flag(R.string.animations, Keys.ANIMATIONS, s.animations, vm)
            Section(R.string.target_score)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(50, 100, 150, 200).forEach { v ->
                    FilterChip(selected = s.targetScore == v, onClick = { vm.setTargetScore(v) }, label = { Text("$v") })
                }
            }
            Section(R.string.rules)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = s.variant == Variant.DRAW, onClick = { vm.setVariant(Variant.DRAW) }, label = { Text(stringResource(R.string.rule_draw)) })
                FilterChip(selected = s.variant == Variant.BLOCK, onClick = { vm.setVariant(Variant.BLOCK) }, label = { Text(stringResource(R.string.rule_block)) })
            }
            Spacer(Modifier.height(8.dp))
            LinkRow(R.string.privacy_policy) { dialog = R.string.privacy_policy }
            LinkRow(R.string.about) { dialog = R.string.about }
            Spacer(Modifier.height(16.dp))
        }
    }

    dialog?.let { t ->
        AlertDialog(
            onDismissRequest = { dialog = null },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text(stringResource(R.string.close)) } },
            title = { Text(stringResource(t)) },
            text = { Text(stringResource(if (t == R.string.privacy_policy) R.string.privacy_body else R.string.about_body)) },
        )
    }
}

@Composable
private fun Section(title: Int) {
    Text(stringResource(title), style = MaterialTheme.typography.titleSmall, color = Gold, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
}

@Composable
private fun Flag(label: Int, key: Preferences.Key<Boolean>, checked: Boolean, vm: AppViewModel) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 56.dp).toggleable(value = checked, role = Role.Switch, onValueChange = { vm.setFlag(key, it) }),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(stringResource(label), Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = null)
    }
}

@Composable
private fun LinkRow(label: Int, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        Text(stringResource(label), style = MaterialTheme.typography.bodyLarge)
    }
}
