package com.dominoclassic.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.dominoclassic.engine.Variant
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

private val Context.store by preferencesDataStore(name = "settings")

object Keys {
    val SOUND = booleanPreferencesKey("sound")
    val MUSIC = booleanPreferencesKey("music")
    val VIBRATION = booleanPreferencesKey("vibration")
    val ANIMATIONS = booleanPreferencesKey("animations")
    val TARGET = intPreferencesKey("target_score")
    val VARIANT = stringPreferencesKey("variant")
    val NAME = stringPreferencesKey("player_name")
    val XP = intPreferencesKey("xp")
    val COINS = intPreferencesKey("coins")
}

data class AppSettings(
    val sound: Boolean = true,
    val music: Boolean = true,
    val vibration: Boolean = true,
    val animations: Boolean = true,
    val targetScore: Int = 100,
    val variant: Variant = Variant.DRAW,
    val playerName: String? = null,
    val xp: Int = 0,
    val coins: Int = 0,
)

class SettingsRepository(private val context: Context) {
    val settings: Flow<AppSettings> = context.store.data
        .catch { emit(emptyPreferences()) }
        .map { p ->
            AppSettings(
                sound = p[Keys.SOUND] ?: true,
                music = p[Keys.MUSIC] ?: true,
                vibration = p[Keys.VIBRATION] ?: true,
                animations = p[Keys.ANIMATIONS] ?: true,
                targetScore = p[Keys.TARGET] ?: 100,
                variant = p[Keys.VARIANT]?.let { runCatching { Variant.valueOf(it) }.getOrNull() } ?: Variant.DRAW,
                playerName = p[Keys.NAME],
                xp = p[Keys.XP] ?: 0,
                coins = p[Keys.COINS] ?: 0,
            )
        }

    suspend fun edit(block: (MutablePreferences) -> Unit) {
        context.store.edit { block(it) }
    }
}
