package com.dominoclassic.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.dominoclassic.ui.home.HomeScreen
import com.dominoclassic.ui.settings.SettingsScreen

@Composable
fun AppNav() {
    val nav = rememberNavController()
    NavHost(nav, startDestination = "home") {
        composable("home") {
            HomeScreen(onSoon = { nav.navigate("soon/$it") }, onSettings = { nav.navigate("settings") })
        }
        composable("settings") { SettingsScreen(onBack = { nav.popBackStack() }) }
        composable("soon/{title}", arguments = listOf(navArgument("title") { type = NavType.IntType })) { e ->
            ComingSoonScreen(e.arguments!!.getInt("title")) { nav.popBackStack() }
        }
    }
}
