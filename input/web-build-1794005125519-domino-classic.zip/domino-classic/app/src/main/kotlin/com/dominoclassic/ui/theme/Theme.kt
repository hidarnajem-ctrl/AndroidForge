package com.dominoclassic.ui.theme

import androidx.compose.foundation.background
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape

val Midnight = Color(0xFF06241F)
val DeepEmerald = Color(0xFF0A3B31)
val Emerald = Color(0xFF0E7C5F)
val EmeraldLight = Color(0xFF14A07A)
val Gold = Color(0xFFD4AF37)
val Ivory = Color(0xFFF4EFE0)
val Panel = Color(0xFF0B2F28)

private val Scheme = darkColorScheme(
    primary = Gold, onPrimary = Midnight,
    secondary = Emerald, onSecondary = Ivory,
    secondaryContainer = Emerald, onSecondaryContainer = Ivory,
    background = Midnight, onBackground = Ivory,
    surface = Panel, onSurface = Ivory,
    surfaceVariant = Color(0xFF123F35), onSurfaceVariant = Color(0xFFB9CFC7),
    outline = Color(0xFF5E8277),
)

@Composable
fun DominoTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = Scheme,
    typography = Typography(),
    shapes = Shapes(medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(24.dp)),
    content = content,
)

fun Modifier.gameBackground(): Modifier =
    background(Brush.verticalGradient(listOf(Midnight, DeepEmerald)))
