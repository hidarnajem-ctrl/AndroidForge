package com.dominoclassic.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.dominoclassic.R
import com.dominoclassic.ui.theme.gameBackground

/** Honest stand-in for features that belong to later stages. */
@Composable
fun ComingSoonScreen(title: Int, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().gameBackground().systemBarsPadding().padding(horizontal = 16.dp)) {
        ScreenTopBar(title, onBack)
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text(stringResource(R.string.coming_soon_body), style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
        }
    }
}
