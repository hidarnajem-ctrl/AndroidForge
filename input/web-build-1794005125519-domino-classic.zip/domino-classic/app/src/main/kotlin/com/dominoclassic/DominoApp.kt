package com.dominoclassic

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.dominoclassic.data.SettingsRepository

class DominoApp : Application() {
    val settings by lazy { SettingsRepository(this) }

    override fun onCreate() {
        super.onCreate()
        // Arabic is the default language until the player chooses another one.
        if (AppCompatDelegate.getApplicationLocales().isEmpty()) {
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags("ar"))
        }
    }
}
