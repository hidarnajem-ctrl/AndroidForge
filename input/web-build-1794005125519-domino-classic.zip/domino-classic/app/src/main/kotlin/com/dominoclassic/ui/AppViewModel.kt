package com.dominoclassic.ui

import android.app.Application
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dominoclassic.DominoApp
import com.dominoclassic.data.AppSettings
import com.dominoclassic.data.Keys
import com.dominoclassic.engine.Variant
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as DominoApp).settings

    val state: StateFlow<AppSettings> =
        repo.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    fun setFlag(key: Preferences.Key<Boolean>, value: Boolean) {
        viewModelScope.launch { repo.edit { it[key] = value } }
    }
    fun setTargetScore(value: Int) {
        viewModelScope.launch { repo.edit { it[Keys.TARGET] = value } }
    }
    fun setVariant(value: Variant) {
        viewModelScope.launch { repo.edit { it[Keys.VARIANT] = value.name } }
    }
}
