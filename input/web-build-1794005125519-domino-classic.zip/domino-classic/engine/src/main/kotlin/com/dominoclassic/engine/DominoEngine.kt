package com.dominoclassic.engine

import kotlin.random.Random

class IllegalMoveException(message: String) : IllegalArgumentException(message)

/**
 * Pure, immutable rules engine. No UI or network code.
 * Rules: 2 players, 7 tiles each, 14-tile stock.
 *  - DRAW: with no playable tile you must draw until you can play; if the stock is empty you pass.
 *  - BLOCK: no drawing; with no playable tile you pass.
 * Round ends when a hand is empty (winner scores opponent's pips) or both players
 * pass consecutively (lowest hand wins the pip DIFFERENCE; equal hands score 0).
 */
object DominoEngine {
    const val HAND_SIZE = 7

    fun newRound(variant: Variant, random: Random = Random.Default, leader: PlayerId? = null): RoundState {
        val t = Tile.fullSet().shuffled(random)
        val hands = mapOf(PlayerId.ONE to t.subList(0, HAND_SIZE), PlayerId.TWO to t.subList(HAND_SIZE, 2 * HAND_SIZE))
        val stock = t.subList(2 * HAND_SIZE, t.size)
        val opening = if (leader == null) openingTile(hands) else null
        val starter = leader ?: hands.entries.first { opening in it.value }.key
        return RoundState(variant, hands, stock, emptyList(), starter, 0, null, opening)
    }

    /** Highest double in either hand, otherwise the highest-pip tile. */
    fun openingTile(hands: Map<PlayerId, List<Tile>>): Tile {
        val all = hands.values.flatten()
        return all.filter { it.isDouble }.maxByOrNull { it.low }
            ?: all.maxWith(compareBy<Tile> { it.pips }.thenBy { it.high })
    }

    fun place(chain: List<PlacedTile>, tile: Tile, side: Side): List<PlacedTile> {
        if (chain.isEmpty()) return listOf(PlacedTile(tile, tile.low, tile.high))
        return when (side) {
            Side.LEFT -> { val e = chain.first().leftPip; listOf(PlacedTile(tile, tile.other(e), e)) + chain }
            Side.RIGHT -> { val e = chain.last().rightPip; chain + PlacedTile(tile, e, tile.other(e)) }
        }
    }

    fun legalMoves(s: RoundState): List<Move> {
        if (s.isOver) return emptyList()
        val hand = s.hands.getValue(s.current)
        if (s.chain.isEmpty()) return (s.openingTile?.let { listOf(it) } ?: hand).map { Move.Play(it, Side.RIGHT) }
        val l = s.leftEnd!!; val r = s.rightEnd!!
        val plays = hand.flatMap { t ->
            buildList {
                if (t.has(l)) add(Move.Play(t, Side.LEFT))
                if (t.has(r)) add(Move.Play(t, Side.RIGHT))
            }
        }
        if (plays.isNotEmpty()) return plays
        return if (s.variant == Variant.DRAW && s.stock.isNotEmpty()) listOf(Move.Draw) else listOf(Move.Pass)
    }

    fun apply(s: RoundState, move: Move): RoundState {
        if (move !in legalMoves(s)) throw IllegalMoveException("Illegal move $move for ${s.current}")
        val me = s.current
        return when (move) {
            is Move.Play -> {
                val hand = s.hands.getValue(me) - move.tile
                val next = s.copy(
                    hands = s.hands + (me to hand),
                    chain = place(s.chain, move.tile, move.side),
                    consecutivePasses = 0,
                    openingTile = null,
                    current = me.opponent,
                )
                if (hand.isEmpty()) next.copy(current = me, result = RoundResult(me, EndReason.DOMINO, pips(next, me.opponent)))
                else next
            }
            Move.Draw -> s.copy(hands = s.hands + (me to s.hands.getValue(me) + s.stock.first()), stock = s.stock.drop(1))
            Move.Pass -> {
                val next = s.copy(consecutivePasses = s.consecutivePasses + 1, current = me.opponent)
                if (next.consecutivePasses >= 2) next.copy(result = blockedResult(next)) else next
            }
        }
    }

    fun pips(s: RoundState, p: PlayerId) = s.hands.getValue(p).sumOf { it.pips }

    private fun blockedResult(s: RoundState): RoundResult {
        val a = pips(s, PlayerId.ONE); val b = pips(s, PlayerId.TWO)
        return when {
            a == b -> RoundResult(null, EndReason.BLOCKED, 0)
            a < b -> RoundResult(PlayerId.ONE, EndReason.BLOCKED, b - a)
            else -> RoundResult(PlayerId.TWO, EndReason.BLOCKED, a - b)
        }
    }
}

object DominoMatch {
    fun start(variant: Variant, targetScore: Int = 100, random: Random = Random.Default) = MatchState(
        variant, targetScore, mapOf(PlayerId.ONE to 0, PlayerId.TWO to 0), 1,
        DominoEngine.newRound(variant, random), null,
    )

    fun apply(m: MatchState, move: Move): MatchState {
        require(m.matchWinner == null) { "Match already finished" }
        val wasOver = m.round.isOver
        val round = DominoEngine.apply(m.round, move)
        val res = round.result
        if (wasOver || res == null) return m.copy(round = round)
        val scores = res.winner?.let { w -> m.scores + (w to m.scores.getValue(w) + res.points) } ?: m.scores
        val winner = scores.entries.firstOrNull { it.value >= m.targetScore }?.key
        return m.copy(round = round, scores = scores, matchWinner = winner)
    }

    /** Starts the next round; the previous round's winner leads (any tile). */
    fun nextRound(m: MatchState, random: Random = Random.Default): MatchState {
        require(m.round.isOver && m.matchWinner == null) { "Cannot start next round now" }
        return m.copy(
            roundNumber = m.roundNumber + 1,
            round = DominoEngine.newRound(m.variant, random, m.round.result!!.winner),
        )
    }
}
