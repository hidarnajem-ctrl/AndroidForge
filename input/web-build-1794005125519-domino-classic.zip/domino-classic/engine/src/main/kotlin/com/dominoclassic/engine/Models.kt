package com.dominoclassic.engine

enum class Variant { DRAW, BLOCK }
enum class Side { LEFT, RIGHT }
enum class PlayerId { ONE, TWO; val opponent get() = if (this == ONE) TWO else ONE }
enum class EndReason { DOMINO, BLOCKED }

/** Double-six tile, normalized so low <= high. */
data class Tile(val low: Int, val high: Int) {
    init { require(low in 0..6 && high in 0..6 && low <= high) { "Invalid tile $low-$high" } }
    val isDouble get() = low == high
    val pips get() = low + high
    fun has(n: Int) = low == n || high == n
    fun other(n: Int) = if (low == n) high else low

    companion object {
        fun of(a: Int, b: Int) = Tile(minOf(a, b), maxOf(a, b))
        fun fullSet(): List<Tile> = (0..6).flatMap { a -> (a..6).map { b -> Tile(a, b) } }
    }
}

/** A tile on the table with its orientation: leftPip faces the left end. */
data class PlacedTile(val tile: Tile, val leftPip: Int, val rightPip: Int)

sealed interface Move {
    data class Play(val tile: Tile, val side: Side) : Move
    data object Draw : Move
    data object Pass : Move
}

data class RoundResult(val winner: PlayerId?, val reason: EndReason, val points: Int)

data class RoundState(
    val variant: Variant,
    val hands: Map<PlayerId, List<Tile>>,
    val stock: List<Tile>,
    val chain: List<PlacedTile>,
    val current: PlayerId,
    val consecutivePasses: Int,
    val result: RoundResult?,
    /** Tile the first player is forced to open with (null = any tile). */
    val openingTile: Tile?,
) {
    val leftEnd: Int? get() = chain.firstOrNull()?.leftPip
    val rightEnd: Int? get() = chain.lastOrNull()?.rightPip
    val isOver get() = result != null
}

data class MatchState(
    val variant: Variant,
    val targetScore: Int,
    val scores: Map<PlayerId, Int>,
    val roundNumber: Int,
    val round: RoundState,
    val matchWinner: PlayerId?,
)
