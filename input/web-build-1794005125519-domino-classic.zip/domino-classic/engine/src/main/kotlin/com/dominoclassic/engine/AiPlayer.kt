package com.dominoclassic.engine

import kotlin.random.Random

enum class Difficulty { EASY, MEDIUM, EXPERT }

/**
 * Plays by the same legal-move list as the human. It only reads its own hand,
 * the table, the stock SIZE and the opponent's hand SIZE (never the hidden tiles).
 */
class AiPlayer(private val difficulty: Difficulty, private val random: Random = Random.Default) {

    fun choose(state: RoundState, me: PlayerId): Move {
        require(state.current == me && !state.isOver) { "Not $me's turn" }
        val moves = DominoEngine.legalMoves(state)
        val plays = moves.filterIsInstance<Move.Play>()
        if (plays.isEmpty()) return moves.first()
        return when (difficulty) {
            Difficulty.EASY -> plays.random(random)
            Difficulty.MEDIUM -> plays.maxWith(compareBy<Move.Play> { it.tile.isDouble }.thenBy { it.tile.pips })
            Difficulty.EXPERT -> expert(state, me, plays)
        }
    }

    private fun expert(state: RoundState, me: PlayerId, plays: List<Move.Play>): Move {
        val hand = state.hands.getValue(me)
        val unseen = Tile.fullSet() - hand.toSet() - state.chain.map { it.tile }.toSet()
        return plays.maxBy { p ->
            val remaining = hand - p.tile
            if (remaining.isEmpty()) return@maxBy 1_000.0
            val chain = DominoEngine.place(state.chain, p.tile, p.side)
            val l = chain.first().leftPip; val r = chain.last().rightPip
            // Share of hidden tiles that could answer the new ends: lower = better for us.
            val oppChance = unseen.count { it.has(l) || it.has(r) }.toDouble() / maxOf(1, unseen.size)
            val ownCover = remaining.count { it.has(l) || it.has(r) }
            val variety = remaining.flatMap { listOf(it.low, it.high) }.toSet().size
            p.tile.pips + (if (p.tile.isDouble) 4.0 else 0.0) - 10.0 * oppChance + 2.0 * ownCover + 0.5 * variety +
                random.nextDouble(0.0, 0.01)
        }
    }
}
