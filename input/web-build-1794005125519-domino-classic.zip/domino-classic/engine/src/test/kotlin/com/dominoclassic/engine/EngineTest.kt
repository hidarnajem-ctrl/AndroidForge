package com.dominoclassic.engine

import kotlin.random.Random
import kotlin.test.*
import com.dominoclassic.engine.PlayerId.ONE
import com.dominoclassic.engine.PlayerId.TWO

class EngineTest {
    private fun t(a: Int, b: Int) = Tile.of(a, b)
    private fun state(
        h1: List<Tile>, h2: List<Tile>, stock: List<Tile> = emptyList(),
        chain: List<PlacedTile> = emptyList(), current: PlayerId = ONE,
        variant: Variant = Variant.DRAW, passes: Int = 0, opening: Tile? = null,
    ) = RoundState(variant, mapOf(ONE to h1, TWO to h2), stock, chain, current, passes, null, opening)
    private val c34 = listOf(PlacedTile(t(3, 4), 3, 4))

    @Test fun fullSetHas28UniqueTiles() {
        assertEquals(28, Tile.fullSet().toSet().size)
        assertEquals(168, Tile.fullSet().sumOf { it.pips })
    }

    @Test fun dealIs7_7_14() {
        val s = DominoEngine.newRound(Variant.DRAW, Random(1))
        assertEquals(7, s.hands.getValue(ONE).size); assertEquals(7, s.hands.getValue(TWO).size)
        assertEquals(14, s.stock.size)
        assertEquals(28, (s.hands.values.flatten() + s.stock).toSet().size)
    }

    @Test fun openingIsHighestDoubleElseHighestTile() {
        repeat(200) { seed ->
            val s = DominoEngine.newRound(Variant.BLOCK, Random(seed))
            val all = s.hands.values.flatten()
            val expected = all.filter { it.isDouble }.maxByOrNull { it.low }
                ?: all.maxWith(compareBy<Tile> { it.pips }.thenBy { it.high })
            val moves = DominoEngine.legalMoves(s)
            assertEquals(listOf(expected), moves.map { (it as Move.Play).tile })
            assertTrue(expected in s.hands.getValue(s.current))
        }
    }

    @Test fun legalMovesMatchEnds() {
        val s = state(listOf(t(3, 5), t(4, 4), t(0, 1)), listOf(t(2, 2)), chain = c34)
        assertEquals(
            setOf(Move.Play(t(3, 5), Side.LEFT), Move.Play(t(4, 4), Side.RIGHT)),
            DominoEngine.legalMoves(s).toSet(),
        )
    }

    @Test fun placementOrientsTiles() {
        val s = state(listOf(t(3, 5), t(0, 1)), listOf(t(2, 2)), chain = c34)
        val n = DominoEngine.apply(s, Move.Play(t(3, 5), Side.LEFT))
        assertEquals(5, n.leftEnd); assertEquals(4, n.rightEnd)
        assertEquals(TWO, n.current)
        val n2 = DominoEngine.apply(n.copy(hands = n.hands + (TWO to listOf(t(4, 6), t(0, 0)))), Move.Play(t(4, 6), Side.RIGHT))
        assertEquals(6, n2.rightEnd); assertEquals(ONE, n2.current)
    }

    @Test fun drawIsForcedThenSamePlayerContinues() {
        val s = state(listOf(t(0, 1)), listOf(t(2, 2)), stock = listOf(t(3, 3), t(5, 5)), chain = c34)
        assertEquals(listOf<Move>(Move.Draw), DominoEngine.legalMoves(s))
        val n = DominoEngine.apply(s, Move.Draw)
        assertEquals(ONE, n.current); assertEquals(2, n.hands.getValue(ONE).size); assertEquals(1, n.stock.size)
        assertTrue(Move.Play(t(3, 3), Side.LEFT) in DominoEngine.legalMoves(n))
    }

    @Test fun passOnlyWhenAllowed() {
        val emptyStock = state(listOf(t(0, 1)), listOf(t(2, 2)), chain = c34)
        assertEquals(listOf<Move>(Move.Pass), DominoEngine.legalMoves(emptyStock))
        val block = state(listOf(t(0, 1)), listOf(t(2, 2)), stock = listOf(t(5, 5)), chain = c34, variant = Variant.BLOCK)
        assertEquals(listOf<Move>(Move.Pass), DominoEngine.legalMoves(block))
        val playable = state(listOf(t(3, 1)), listOf(t(2, 2)), chain = c34)
        assertFalse(Move.Pass in DominoEngine.legalMoves(playable))
        assertFalse(Move.Draw in DominoEngine.legalMoves(playable))
    }

    @Test fun illegalMovesThrow() {
        val s = state(listOf(t(3, 5), t(0, 1)), listOf(t(2, 2)), chain = c34)
        assertFailsWith<IllegalMoveException> { DominoEngine.apply(s, Move.Play(t(0, 1), Side.LEFT)) }
        assertFailsWith<IllegalMoveException> { DominoEngine.apply(s, Move.Play(t(2, 2), Side.LEFT)) }
        assertFailsWith<IllegalMoveException> { DominoEngine.apply(s, Move.Pass) }
        assertFailsWith<IllegalMoveException> { DominoEngine.apply(s, Move.Draw) }
    }

    @Test fun goingOutScoresOpponentPips() {
        val s = state(listOf(t(3, 5)), listOf(t(6, 6), t(1, 2)), chain = c34)
        val n = DominoEngine.apply(s, Move.Play(t(3, 5), Side.LEFT))
        assertEquals(RoundResult(ONE, EndReason.DOMINO, 15), n.result)
        assertTrue(DominoEngine.legalMoves(n).isEmpty())
    }

    @Test fun blockedLowestHandWinsDifference() {
        val chain = listOf(PlacedTile(t(6, 6), 6, 6))
        val s = state(listOf(t(0, 1)), listOf(t(2, 3)), chain = chain)
        val a = DominoEngine.apply(s, Move.Pass)
        assertNull(a.result); assertEquals(TWO, a.current)
        val b = DominoEngine.apply(a, Move.Pass)
        assertEquals(RoundResult(ONE, EndReason.BLOCKED, 4), b.result)
    }

    @Test fun blockedTieScoresNothing() {
        val chain = listOf(PlacedTile(t(6, 6), 6, 6))
        val s = state(listOf(t(0, 2)), listOf(t(1, 1)), chain = chain)
        val r = DominoEngine.apply(DominoEngine.apply(s, Move.Pass), Move.Pass).result
        assertEquals(RoundResult(null, EndReason.BLOCKED, 0), r)
    }

    @Test fun matchScoresOnceAndDeclaresWinner() {
        val round = state(listOf(t(3, 5)), listOf(t(6, 6), t(1, 2)), chain = c34)
        val m = MatchState(Variant.DRAW, 100, mapOf(ONE to 90, TWO to 40), 3, round, null)
        val done = DominoMatch.apply(m, Move.Play(t(3, 5), Side.LEFT))
        assertEquals(105, done.scores.getValue(ONE)); assertEquals(ONE, done.matchWinner)
        assertFailsWith<IllegalArgumentException> { DominoMatch.nextRound(done) }
    }

    @Test fun nextRoundWinnerLeadsWithAnyTile() {
        val round = state(listOf(t(3, 5)), listOf(t(6, 6)), chain = c34)
        val m = DominoMatch.apply(MatchState(Variant.DRAW, 100, mapOf(ONE to 0, TWO to 0), 1, round, null), Move.Play(t(3, 5), Side.LEFT))
        val n = DominoMatch.nextRound(m, Random(3))
        assertEquals(2, n.roundNumber); assertEquals(ONE, n.round.current)
        assertTrue(n.round.chain.isEmpty()); assertNull(n.round.openingTile)
        assertEquals(7, DominoEngine.legalMoves(n.round).size)
    }

    @Test fun aiVsAiAlwaysFinishesAndConservesTiles() {
        for (variant in Variant.entries) for (d1 in Difficulty.entries) for (d2 in Difficulty.entries) repeat(15) { seed ->
            val rnd = Random(seed * 31 + d1.ordinal * 7 + d2.ordinal)
            val ais = mapOf(ONE to AiPlayer(d1, rnd), TWO to AiPlayer(d2, rnd))
            var s = DominoEngine.newRound(variant, rnd)
            var steps = 0
            while (!s.isOver) {
                s = DominoEngine.apply(s, ais.getValue(s.current).choose(s, s.current))
                assertEquals(28, s.hands.values.sumOf { it.size } + s.stock.size + s.chain.size)
                assertTrue(++steps < 200, "round did not terminate")
            }
            assertNotNull(s.result)
        }
    }

    @Test fun expertBeatsEasyOverManyRounds() {
        val rnd = Random(42); var expert = 0; var easy = 0
        repeat(300) { i ->
            val ei = if (i % 2 == 0) ONE else TWO
            val ais = mapOf(ei to AiPlayer(Difficulty.EXPERT, rnd), ei.opponent to AiPlayer(Difficulty.EASY, rnd))
            var s = DominoEngine.newRound(Variant.DRAW, rnd)
            while (!s.isOver) s = DominoEngine.apply(s, ais.getValue(s.current).choose(s, s.current))
            when (s.result!!.winner) { ei -> expert++; ei.opponent -> easy++; else -> {} }
        }
        assertTrue(expert > easy, "expert=$expert easy=$easy")
    }
}
