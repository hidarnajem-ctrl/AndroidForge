plugins { id("org.jetbrains.kotlin.jvm") }
repositories { mavenCentral() }
dependencies { testImplementation(kotlin("test")) }
java { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile>().configureEach { kotlinOptions.jvmTarget = "17" }
tasks.test { useJUnitPlatform() }
