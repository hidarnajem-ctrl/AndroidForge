# Domino Classic
Modules: `:engine` (pure Kotlin rules, AI, tests) and `:app` (Jetpack Compose UI).
Requirements: JDK 17, Android SDK 34, Gradle 8.7+ (tested config: AGP 8.5.2, Kotlin 1.9.24).

- Engine tests: `gradle :engine:test`
- Debug APK: `gradle :app:assembleDebug`

Stage 1 done: theme, 3 languages (Arabic default, RTL), navigation, home, settings (DataStore).
Not yet built: game table UI, online/Firebase, AdMob, progression/shop. Home buttons for these open a
"coming soon" screen on purpose.
Language: Android per-app locale (AppCompat). Arabic is applied on first launch.
