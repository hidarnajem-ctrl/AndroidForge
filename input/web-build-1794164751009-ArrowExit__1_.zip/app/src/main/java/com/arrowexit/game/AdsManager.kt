package com.arrowexit.game

import android.app.Activity
import android.view.View
import android.widget.FrameLayout
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Banner, interstitial and rewarded ads, shown only after the consent flow allows it.
 * Ad unit IDs live in res/values/ads.xml (Google's test IDs until you replace them).
 *
 * Results sent back to the page: NativeEvents.adDone(id, r)
 *   r = 1  rewarded ad watched to the end / interstitial closed
 *   r = 0  rewarded ad closed early
 *   r = -1 no ad was ready
 */
class AdsManager(
    private val act: Activity,
    private val bannerHost: FrameLayout,
    private val runJs: (String) -> Unit,
) {
    private lateinit var consent: ConsentInformation
    private val initStarted = AtomicBoolean(false)
    private var ready = false

    private var banner: AdView? = null
    private var wantBanner = false
    private var interstitial: InterstitialAd? = null
    private var rewarded: RewardedAd? = null

    fun start() {
        consent = UserMessagingPlatform.getConsentInformation(act)
        val params = ConsentRequestParameters.Builder().build()
        consent.requestConsentInfoUpdate(act, params, {
            UserMessagingPlatform.loadAndShowConsentFormIfRequired(act) { _ ->
                if (consent.canRequestAds()) initAds()
            }
        }, { _ ->
            if (consent.canRequestAds()) initAds()
        })
        // Consent from a previous session lets ads start right away.
        if (consent.canRequestAds()) initAds()
    }

    private fun initAds() {
        if (!initStarted.compareAndSet(false, true)) return
        Thread {
            MobileAds.initialize(act) {
                act.runOnUiThread {
                    ready = true
                    loadInterstitial()
                    loadRewarded()
                    if (wantBanner) showBanner()
                }
            }
        }.start()
    }

    // ---- privacy (a settings entry is required when the consent message applies to the user) ----
    fun privacyOptionsRequired(): Boolean =
        ::consent.isInitialized &&
            consent.privacyOptionsRequirementStatus == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED

    fun showPrivacyOptions() {
        UserMessagingPlatform.showPrivacyOptionsForm(act) { _ -> }
    }

    // ---- banner ----
    fun setBanner(show: Boolean) {
        wantBanner = show
        if (show) showBanner() else {
            bannerHost.visibility = View.GONE
            banner?.pause()
        }
    }

    private fun showBanner() {
        if (!ready) return
        val view = banner ?: AdView(act).also {
            it.adUnitId = act.getString(R.string.admob_banner)
            it.setAdSize(bannerSize())
            bannerHost.addView(it)
            it.loadAd(AdRequest.Builder().build())
            banner = it
        }
        view.resume()
        bannerHost.visibility = View.VISIBLE
    }

    @Suppress("DEPRECATION") // still supported in 25.x; Google suggests the newer large anchored sizes
    private fun bannerSize(): AdSize {
        val dm = act.resources.displayMetrics
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(act, (dm.widthPixels / dm.density).toInt())
    }

    // ---- interstitial ----
    private fun loadInterstitial() {
        InterstitialAd.load(act, act.getString(R.string.admob_interstitial), AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) { interstitial = ad }
                override fun onAdFailedToLoad(error: LoadAdError) { interstitial = null }
            })
    }

    fun showInterstitial(id: Int) {
        val ad = interstitial
        if (ad == null) {
            done(id, -1)
            if (ready) loadInterstitial()
            return
        }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { interstitial = null; loadInterstitial(); done(id, 1) }
            override fun onAdFailedToShowFullScreenContent(error: AdError) { interstitial = null; loadInterstitial(); done(id, -1) }
        }
        ad.show(act)
    }

    // ---- rewarded ----
    private fun loadRewarded() {
        RewardedAd.load(act, act.getString(R.string.admob_rewarded), AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) { rewarded = ad }
                override fun onAdFailedToLoad(error: LoadAdError) { rewarded = null }
            })
    }

    fun showRewarded(id: Int) {
        val ad = rewarded
        if (ad == null) {
            done(id, -1)
            if (ready) loadRewarded()
            return
        }
        var earned = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { rewarded = null; loadRewarded(); done(id, if (earned) 1 else 0) }
            override fun onAdFailedToShowFullScreenContent(error: AdError) { rewarded = null; loadRewarded(); done(id, -1) }
        }
        ad.show(act) { earned = true }
    }

    private fun done(id: Int, result: Int) = runJs("window.NativeEvents&&NativeEvents.adDone($id,$result)")

    fun onPause() { banner?.pause() }
    fun onResume() { if (wantBanner) banner?.resume() }
    fun onDestroy() { banner?.destroy() }
}
