package com.hidarnajem.sixthbooks

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.google.android.play.core.review.ReviewManagerFactory

object Rating {

    /** بعد كم مرة يغلق فيها المستخدم كتاباً يظهر طلب التقييم داخل التطبيق (مرة واحدة فقط) */
    private const val ASK_AFTER_READS = 4

    /** يفتح صفحة التطبيق في Google Play ليقيّمه المستخدم */
    fun openStore(context: Context) {
        val pkg = context.packageName
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    /**
     * يُستدعى عند إغلاق كتاب. بعد عدد من القراءات يعرض نافذة التقييم الرسمية من Google
     * داخل التطبيق نفسه. (Google تتحكم بظهورها وقد لا تظهر في كل مرة، ولا تظهر إلا
     * إن كان التطبيق مثبّتاً من Google Play)
     */
    fun onReaderClosed(activity: Activity) {
        val prefs = activity.getSharedPreferences("rating", Context.MODE_PRIVATE)
        if (prefs.getBoolean("asked", false)) return
        val reads = prefs.getInt("reads", 0) + 1
        prefs.edit().putInt("reads", reads).apply()
        if (reads < ASK_AFTER_READS) return

        prefs.edit().putBoolean("asked", true).apply()
        val manager = ReviewManagerFactory.create(activity)
        manager.requestReviewFlow().addOnCompleteListener { task ->
            if (task.isSuccessful) {
                manager.launchReviewFlow(activity, task.result)
            }
        }
    }
}
