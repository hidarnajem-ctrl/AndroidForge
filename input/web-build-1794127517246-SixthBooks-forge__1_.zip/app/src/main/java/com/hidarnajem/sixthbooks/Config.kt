package com.hidarnajem.sixthbooks

/**
 * إعدادات التطبيق.
 * معرّف تطبيق AdMob موجود في app/build.gradle.kts داخل admobAppId.
 */
object Config {
    const val BOOKS_JSON_URL =
        "https://pub-ead7102558aa4f74a05896836f77c054.r2.dev/books.json"

    // معرّفات الإعلانات الحقيقية (تُستخدم في نسخة release التي تُنشر على Google Play)
    private const val REAL_BANNER_ID = "ca-app-pub-1341061237626351/2929169137"
    private const val REAL_INTERSTITIAL_ID = "ca-app-pub-1341061237626351/3048588632"

    // معرّفات الاختبار الرسمية من Google (تُستخدم تلقائياً في نسخة debug للتجربة،
    // حتى لا تظهر إعلاناتك الحقيقية أثناء التجربة فيُعلَّق حسابك بسبب نقرات غير صالحة)
    private const val TEST_BANNER_ID = "ca-app-pub-3940256099942544/9214589741"
    private const val TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"

    val BANNER_ID: String = if (BuildConfig.DEBUG) TEST_BANNER_ID else REAL_BANNER_ID
    val INTERSTITIAL_ID: String = if (BuildConfig.DEBUG) TEST_INTERSTITIAL_ID else REAL_INTERSTITIAL_ID

    // روابط صفحة "حول التطبيق"
    const val PRIVACY_URL = "https://pub-ead7102558aa4f74a05896836f77c054.r2.dev/privacy.html"
    const val SOURCE_URL = "https://sv.icc.edu.egov.iq/"
    const val CONTACT_EMAIL = "hidar.najem@gmail.com"
    const val DEVELOPER = "حيدر نجم عبدعلي"

    // يظهر إعلان بيني كل N مرة يفتح فيها المستخدم كتاباً
    const val INTERSTITIAL_EVERY_N_OPENS = 3
}
