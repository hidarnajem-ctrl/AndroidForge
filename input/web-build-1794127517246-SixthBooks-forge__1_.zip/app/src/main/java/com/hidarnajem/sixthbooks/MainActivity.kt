package com.hidarnajem.sixthbooks

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // خلفية الواجهة داكنة (خشب)، فنجعل أيقونات شريط الحالة فاتحة
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        AdManager.init(applicationContext)

        setContent {
            AppTheme {
                // واجهة عربية بالكامل (من اليمين لليسار)
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    var openName by rememberSaveable { mutableStateOf<String?>(null) }
                    val openBook = vm.books.firstOrNull { it.fileName == openName }

                    fun open(book: Book) {
                        AdManager.maybeShowInterstitial(this@MainActivity) {
                            openName = book.fileName
                        }
                    }

                    // بعد اكتمال تحميل كتاب لأول مرة يُفتح مباشرة (إن كان المستخدم ما زال في المكتبة)
                    LaunchedEffect(vm.justDownloaded) {
                        val name = vm.justDownloaded ?: return@LaunchedEffect
                        vm.justDownloaded = null
                        if (openName == null) {
                            vm.books.firstOrNull { it.fileName == name }?.let { open(it) }
                        }
                    }

                    if (openBook != null) {
                        ReaderScreen(
                            book = openBook,
                            file = vm.file(openBook),
                            onBack = {
                                openName = null
                                Rating.onReaderClosed(this@MainActivity)
                            }
                        )
                    } else {
                        HomeScreen(vm) { book -> open(book) }
                    }
                }
            }
        }
    }
}
