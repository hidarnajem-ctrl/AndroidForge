package com.hidarnajem.sixthbooks

data class Book(
    val title: String,
    val subject: String,
    /** اسم الرف الذي يوضع فيه الكتاب. الكتب التي لها نفس الرف تظهر معاً (مثل الكتاب وكتاب النشاط) */
    val shelf: String,
    val url: String,
    val sizeMb: Int
) {
    /** اسم الملف كما هو في الرابط، ويُستخدم كمعرّف فريد وكاسم للملف المحفوظ */
    val fileName: String get() = url.substringAfterLast('/')
}
