package com.pixora.photocompressor.data

import android.net.Uri

enum class OutputFormat(val extension: String, val mimeType: String, val displayName: String) {
    JPEG("jpg", "image/jpeg", "JPEG"),
    WEBP("webp", "image/webp", "WebP (Recommended)"),
    PNG("png", "image/png", "PNG")
}

data class ImageMetadata(
    val uri: Uri,
    val fileName: String,
    val width: Int,
    val height: Int,
    val byteSize: Long,
    val mimeType: String,
    val hasAlpha: Boolean
) {
    val formattedSize: String
        get() = formatBytes(byteSize)

    val dimensionsLabel: String
        get() = "${width} × ${height} px"
}

data class CompressConfig(
    val quality: Int = 75,
    val format: OutputFormat = OutputFormat.WEBP,
    val maxWidth: Int? = null,
    val maxHeight: Int? = null,
    val keepAspectRatio: Boolean = true
)

data class CompressResult(
    val fileUri: Uri,
    val width: Int,
    val height: Int,
    val originalSize: Long,
    val compressedSize: Long,
    val format: OutputFormat,
    val durationMs: Long
) {
    val bytesSaved: Long
        get() = (originalSize - compressedSize).coerceAtLeast(0L)

    val percentReduction: Int
        get() = if (originalSize > 0) {
            (((originalSize - compressedSize).toDouble() / originalSize.toDouble()) * 100).toInt().coerceIn(0, 99)
        } else 0

    val formattedOriginalSize: String
        get() = formatBytes(originalSize)

    val formattedCompressedSize: String
        get() = formatBytes(compressedSize)

    val formattedSavedSize: String
        get() = formatBytes(bytesSaved)

    val dimensionsLabel: String
        get() = "${width} × ${height} px"
}

fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
    val value = bytes / Math.pow(1024.0, digitGroups.toDouble())
    return String.format(java.util.Locale.US, "%.1f %s", value, units[digitGroups])
}
