package com.pixora.photocompressor.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pixora.photocompressor.R
import com.pixora.photocompressor.data.CompressConfig
import com.pixora.photocompressor.data.CompressResult
import com.pixora.photocompressor.data.ImageCompressorEngine
import com.pixora.photocompressor.data.ImageMetadata
import com.pixora.photocompressor.data.OutputFormat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiState(
    val selectedImage: ImageMetadata? = null,
    val config: CompressConfig = CompressConfig(quality = 75, format = OutputFormat.WEBP),
    val isAnalyzing: Boolean = false,
    val isCompressing: Boolean = false,
    val isSaving: Boolean = false,
    val result: CompressResult? = null,
    val showPngJpegWarning: Boolean = false,
    val userMessage: String? = null,
    val isErrorMessage: Boolean = false
)

class PhotoCompressorViewModel(application: Application) : AndroidViewModel(application) {

    private val engine = ImageCompressorEngine(application.applicationContext)
    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    fun onImagePicked(uri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(isAnalyzing = true, userMessage = null, result = null) }
            val metaResult = engine.extractMetadata(uri)
            metaResult.onSuccess { metadata ->
                val showWarning = metadata.hasAlpha && _uiState.value.config.format == OutputFormat.JPEG
                _uiState.update {
                    it.copy(
                        selectedImage = metadata,
                        isAnalyzing = false,
                        showPngJpegWarning = showWarning,
                        config = it.config.copy(
                            maxWidth = metadata.width,
                            maxHeight = metadata.height
                        )
                    )
                }
                compress()
            }.onFailure {
                _uiState.update {
                    it.copy(
                        isAnalyzing = false,
                        userMessage = getApplication<Application>().getString(R.string.error_decode_failed),
                        isErrorMessage = true
                    )
                }
            }
        }
    }

    fun setQuality(quality: Int) {
        _uiState.update {
            it.copy(config = it.config.copy(quality = quality.coerceIn(10, 100)))
        }
    }

    fun setFormat(format: OutputFormat) {
        val currentMeta = _uiState.value.selectedImage
        val showWarning = currentMeta?.hasAlpha == true && format == OutputFormat.JPEG
        _uiState.update {
            it.copy(
                config = it.config.copy(format = format),
                showPngJpegWarning = showWarning
            )
        }
    }

    fun setDimensions(width: Int?, height: Int?, keepAspect: Boolean = true) {
        val meta = _uiState.value.selectedImage
        var targetW = width
        var targetH = height

        if (keepAspect && meta != null && meta.width > 0 && meta.height > 0) {
            val ratio = meta.width.toDouble() / meta.height.toDouble()
            if (width != null && width > 0 && (height == null || height == _uiState.value.config.maxHeight)) {
                targetH = (width / ratio).toInt().coerceAtLeast(1)
            } else if (height != null && height > 0) {
                targetW = (height * ratio).toInt().coerceAtLeast(1)
            }
        }

        _uiState.update {
            it.copy(
                config = it.config.copy(
                    maxWidth = targetW,
                    maxHeight = targetH,
                    keepAspectRatio = keepAspect
                )
            )
        }
    }

    fun applyScalePreset(scalePercent: Int) {
        val meta = _uiState.value.selectedImage ?: return
        val factor = scalePercent / 100.0
        val newW = (meta.width * factor).toInt().coerceAtLeast(16)
        val newH = (meta.height * factor).toInt().coerceAtLeast(16)
        setDimensions(newW, newH, keepAspect = true)
        compress()
    }

    fun compress() {
        val meta = _uiState.value.selectedImage ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isCompressing = true, userMessage = null) }
            val result = engine.compressImage(meta.uri, _uiState.value.config)
            result.onSuccess { compressResult ->
                _uiState.update {
                    it.copy(
                        isCompressing = false,
                        result = compressResult
                    )
                }
            }.onFailure {
                _uiState.update {
                    it.copy(
                        isCompressing = false,
                        userMessage = getApplication<Application>().getString(R.string.error_compression_failed),
                        isErrorMessage = true
                    )
                }
            }
        }
    }

    fun saveToGallery() {
        val result = _uiState.value.result ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }
            val saveResult = engine.saveImageToGallery(
                cacheUri = result.fileUri,
                format = result.format,
                title = "pixora_compressed"
            )
            saveResult.onSuccess {
                _uiState.update {
                    it.copy(
                        isSaving = false,
                        userMessage = getApplication<Application>().getString(R.string.status_saved_success),
                        isErrorMessage = false
                    )
                }
            }.onFailure {
                _uiState.update {
                    it.copy(
                        isSaving = false,
                        userMessage = getApplication<Application>().getString(R.string.error_save_failed),
                        isErrorMessage = true
                    )
                }
            }
        }
    }

    fun createShareIntent(): Intent? {
        val result = _uiState.value.result ?: return null
        return Intent(Intent.ACTION_SEND).apply {
            type = result.format.mimeType
            putExtra(Intent.EXTRA_STREAM, result.fileUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    fun dismissMessage() {
        _uiState.update { it.copy(userMessage = null) }
    }
}
