package com.pixora.photocompressor.data

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.roundToInt

class ImageCompressorEngine(private val context: Context) {

    suspend fun extractMetadata(uri: Uri): Result<ImageMetadata> = withContext(Dispatchers.IO) {
        runCatching {
            var fileName = "image"
            var fileSize = 0L
            val mimeType = context.contentResolver.getType(uri) ?: "image/jpeg"

            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIndex != -1) fileName = cursor.getString(nameIndex) ?: "image"
                    if (sizeIndex != -1) fileSize = cursor.getLong(sizeIndex)
                }
            }

            if (fileSize <= 0) {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    fileSize = stream.available().toLong()
                }
            }

            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, options)
            } ?: throw IllegalStateException("Cannot open input stream for image")

            if (options.outWidth <= 0 || options.outHeight <= 0) {
                throw IllegalArgumentException("Unsupported image format or invalid file")
            }

            val rotation = getExifOrientationDegrees(uri)
            val isSwapped = rotation == 90 || rotation == 270
            val finalWidth = if (isSwapped) options.outHeight else options.outWidth
            val finalHeight = if (isSwapped) options.outWidth else options.outHeight
            val hasAlpha = options.outMimeType?.equals("image/png", ignoreCase = true) == true ||
                    options.outMimeType?.equals("image/webp", ignoreCase = true) == true

            ImageMetadata(
                uri = uri,
                fileName = fileName,
                width = finalWidth,
                height = finalHeight,
                byteSize = fileSize,
                mimeType = options.outMimeType ?: mimeType,
                hasAlpha = hasAlpha
            )
        }
    }

    suspend fun compressImage(
        uri: Uri,
        config: CompressConfig
    ): Result<CompressResult> = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        runCatching {
            val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, boundsOptions)
            } ?: throw IllegalStateException("Cannot open image file")

            val origWidth = boundsOptions.outWidth
            val origHeight = boundsOptions.outHeight
            if (origWidth <= 0 || origHeight <= 0) {
                throw IllegalArgumentException("Invalid image dimensions")
            }

            var targetWidth = origWidth
            var targetHeight = origHeight

            val reqMaxW = config.maxWidth
            val reqMaxH = config.maxHeight

            if (reqMaxW != null && reqMaxW > 0 && reqMaxH != null && reqMaxH > 0) {
                if (config.keepAspectRatio) {
                    val ratio = origWidth.toFloat() / origHeight.toFloat()
                    val targetRatio = reqMaxW.toFloat() / reqMaxH.toFloat()
                    if (targetRatio > ratio) {
                        targetHeight = reqMaxH
                        targetWidth = (reqMaxH * ratio).roundToInt()
                    } else {
                        targetWidth = reqMaxW
                        targetHeight = (reqMaxW / ratio).roundToInt()
                    }
                } else {
                    targetWidth = reqMaxW
                    targetHeight = reqMaxH
                }
            } else if (reqMaxW != null && reqMaxW > 0) {
                if (reqMaxW < origWidth) {
                    val ratio = origHeight.toFloat() / origWidth.toFloat()
                    targetWidth = reqMaxW
                    targetHeight = (reqMaxW * ratio).roundToInt()
                }
            } else if (reqMaxH != null && reqMaxH > 0) {
                if (reqMaxH < origHeight) {
                    val ratio = origWidth.toFloat() / origHeight.toFloat()
                    targetHeight = reqMaxH
                    targetWidth = (reqMaxH * ratio).roundToInt()
                }
            }

            var inSampleSize = 1
            var halfWidth = origWidth / 2
            var halfHeight = origHeight / 2
            while ((halfWidth / inSampleSize) >= targetWidth && (halfHeight / inSampleSize) >= targetHeight) {
                inSampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply {
                this.inSampleSize = inSampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }

            var decodedBitmap = context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOptions)
            } ?: throw IllegalStateException("Failed to decode bitmap from stream")

            val rotation = getExifOrientationDegrees(uri)
            if (rotation != 0) {
                val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
                val rotated = Bitmap.createBitmap(
                    decodedBitmap, 0, 0, decodedBitmap.width, decodedBitmap.height, matrix, true
                )
                if (rotated != decodedBitmap) {
                    decodedBitmap.recycle()
                    decodedBitmap = rotated
                }
            }

            val finalBitmap = if (decodedBitmap.width != targetWidth || decodedBitmap.height != targetHeight) {
                val scaled = Bitmap.createScaledBitmap(decodedBitmap, targetWidth, targetHeight, true)
                if (scaled != decodedBitmap) {
                    decodedBitmap.recycle()
                }
                scaled
            } else {
                decodedBitmap
            }

            val readyBitmap = if (config.format == OutputFormat.JPEG && finalBitmap.hasAlpha()) {
                val whiteBgBitmap = Bitmap.createBitmap(finalBitmap.width, finalBitmap.height, Bitmap.Config.RGB_565)
                val canvas = Canvas(whiteBgBitmap)
                canvas.drawColor(Color.WHITE)
                canvas.drawBitmap(finalBitmap, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG))
                finalBitmap.recycle()
                whiteBgBitmap
            } else {
                finalBitmap
            }

            val compressFormat = when (config.format) {
                OutputFormat.JPEG -> Bitmap.CompressFormat.JPEG
                OutputFormat.PNG -> Bitmap.CompressFormat.PNG
                OutputFormat.WEBP -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        Bitmap.CompressFormat.WEBP_LOSSY
                    } else {
                        @Suppress("DEPRECATION")
                        Bitmap.CompressFormat.WEBP
                    }
                }
            }

            val quality = config.quality.coerceIn(10, 100)
            val byteStream = ByteArrayOutputStream()
            readyBitmap.compress(compressFormat, quality, byteStream)
            val compressedBytes = byteStream.toByteArray()

            val cacheDir = File(context.cacheDir, "compressed_images").apply { mkdirs() }
            val fileName = "pixora_${System.currentTimeMillis()}.${config.format.extension}"
            val cacheFile = File(cacheDir, fileName)
            FileOutputStream(cacheFile).use { it.write(compressedBytes) }

            val fileUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                cacheFile
            )

            val originalSize = getOriginalFileSize(uri)
            val duration = System.currentTimeMillis() - startTime

            CompressResult(
                fileUri = fileUri,
                width = readyBitmap.width,
                height = readyBitmap.height,
                originalSize = originalSize,
                compressedSize = compressedBytes.size.toLong(),
                format = config.format,
                durationMs = duration
            )
        }
    }

    suspend fun saveImageToGallery(
        cacheUri: Uri,
        format: OutputFormat,
        title: String = "pixora_compressed"
    ): Result<Uri> = withContext(Dispatchers.IO) {
        runCatching {
            val contentResolver = context.contentResolver
            val fileName = "${title}_${System.currentTimeMillis()}.${format.extension}"

            val contentValues = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, format.mimeType)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/Pixora")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }

            val targetUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                ?: throw IllegalStateException("Could not create MediaStore entry")

            contentResolver.openInputStream(cacheUri)?.use { input ->
                contentResolver.openOutputStream(targetUri)?.use { output ->
                    input.copyTo(output)
                }
            } ?: throw IllegalStateException("Failed to write to destination storage")

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
                contentResolver.update(targetUri, contentValues, null, null)
            }

            targetUri
        }
    }

    private fun getExifOrientationDegrees(uri: Uri): Int {
        return try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val exif = ExifInterface(stream)
                when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270
                    else -> 0
                }
            } ?: 0
        } catch (_: Exception) {
            0
        }
    }

    private fun getOriginalFileSize(uri: Uri): Long {
        return try {
            var size = 0L
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst() && sizeIndex != -1) {
                    size = cursor.getLong(sizeIndex)
                }
            }
            if (size > 0) size else {
                context.contentResolver.openInputStream(uri)?.use { it.available().toLong() } ?: 0L
            }
        } catch (_: Exception) {
            0L
        }
    }
}
