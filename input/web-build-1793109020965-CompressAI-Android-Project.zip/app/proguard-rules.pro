# Pixora Photo Compressor - custom ProGuard rules
