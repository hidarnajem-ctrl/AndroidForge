# CompressAI Android Project

This Android project wraps the supplied AI Studio HTML prototype in an Android WebView. The HTML is stored at `app/src/main/assets/index.html`.

Build with AndroidForge as an Android APK project. The HTML loads Tailwind, Lucide, and Google Fonts from their CDNs, so those visual dependencies require an internet connection.

Important limitation inherited from the supplied HTML: PDF processing is currently a simulation and does not actually compress PDF data. The page also uses marketing language about AI, but the supplied JavaScript uses browser Canvas for image conversion rather than a real AI model.
